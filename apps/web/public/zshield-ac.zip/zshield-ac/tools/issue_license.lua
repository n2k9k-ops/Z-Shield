--[[
    FILE:         tools/issue_license.lua
    PURPOSE:      Émet une clé de licence Z-Shield pour un client. À exécuter chez TOI (le
                  vendeur), jamais chez le client — c'est ta clé de signature qui est en jeu.

    USAGE (depuis le dossier zshield-ac/) :
        lua5.4 tools/issue_license.lua <server_id> <plan> <jours>

      <server_id> : l'« Identifiant de ce serveur » que le client lit dans sa console au
                    premier démarrage (empreinte de son sv_licenseKey). Ou 'any' pour une clé
                    non liée (déconseillé en vente : elle marche sur n'importe quel serveur).
      <plan>      : starter | pro | network | trial   (purement descriptif)
      <jours>     : durée de validité en jours (ex. 30 pour un mois, 3650 pour ~10 ans)

    EXEMPLE :
        lua5.4 tools/issue_license.lua 7b9d6cd94dbfd140 pro 30

    IMPORTANT : la clé est signée avec le SECRET défini dans server/license.lua. Avant toute
    vente, CHANGE ce secret (il est public dans le dépôt) — sinon n'importe qui peut forger
    des licences. Garde le même secret côté dashboard si tu émets aussi en ligne.
]]

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua'); dofile('shared/sha256.lua')
dofile('server/license.lua')
ZShield.Log.console = false

local server_id = arg and arg[1] or 'any'
local plan = arg and arg[2] or 'pro'
local days = tonumber(arg and arg[3]) or 30

if ZShield.License.SECRET == 'ZSHIELD-LICENSE-SIGNING-SECRET-CHANGE-ME' then
    io.stderr:write('\n[AVERTISSEMENT] Tu utilises le SECRET par défaut du dépôt.\n')
    io.stderr:write('               Change-le dans server/license.lua AVANT de vendre.\n\n')
end

local now = os.time()
local token = ZShield.License.sign({
    server_id = server_id, plan = plan, issued_at = now, expires_at = now + days * 86400,
})

print('--- Licence Z-Shield ---')
print('server_id  : ' .. server_id)
print('plan       : ' .. plan)
print('valide     : ' .. days .. ' jours (jusqu\'au ' .. os.date('%Y-%m-%d', now + days * 86400) .. ')')
print('')
print('Colle cette clé dans le config du client (license.key) :')
print(token)
