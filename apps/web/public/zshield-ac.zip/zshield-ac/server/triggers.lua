--[[
    FILE:         server/triggers.lua
    PURPOSE:      Règles d'événements serveur pilotées par la config (onglet
                  « Détections Événements »). Trois contrôles serveur-vérifiables :
                    - LISTE NOIRE : des noms d'événements totalement interdits ;
                    - LIMITES DE DÉBIT : combien de fois par seconde un joueur peut
                      déclencher un événement donné (anti-flood ciblé) ;
                    - EXCEPTIONS : des événements de confiance exclus des contrôles.
                  Le pare-feu appelle Triggers.check(source, name) avant de laisser
                  passer un événement applicatif.
    DEPENDENCIES: core/util.lua, core/config.lua, server/firewall/ratelimit.lua
    PUBLIC API:   ZShield.Triggers.check(source, name, now) -> { block, reason } | { block=false }
                  ZShield.Triggers.reset()

    Config (section game_events) :
      trigger_blocklist   = { 'esx:giveMoney', ... }        -- noms interdits
      trigger_exceptions  = { 'esx:heartbeat', ... }        -- jamais contrôlés
      trigger_rate_rules  = { ['esx:buy'] = 5, ... }        -- max/s par événement
      trigger_default_rate = 0                               -- 0 = pas de limite globale
]]

ZShield = ZShield or {}
local C = ZShield.Const

local Triggers = {}
local buckets = {}   -- clef "name|source" -> limiteur token bucket

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function inList(list, name)
    if type(list) ~= 'table' then return false end
    -- Accepte { 'a', 'b' } ou { a = true }.
    for _, v in ipairs(list) do if v == name then return true end end
    return list[name] == true
end

function Triggers.reset() buckets = {} end

--- Vérifie un événement. Retourne { block = true, reason } si à refuser.
function Triggers.check(source, name, now)
    if type(name) ~= 'string' or name == '' then return { block = false } end

    -- Exceptions : jamais contrôlées (events internes de confiance).
    if inList(cfg('game_events.trigger_exceptions', nil), name) then
        return { block = false }
    end

    -- Liste noire : refus sec.
    if inList(cfg('game_events.trigger_blocklist', nil), name) then
        return { block = true, severity = C.SEVERITY.HIGH, confidence = 0.9,
            reason = 'blacklisted trigger: ' .. name, category = C.CATEGORY.NETWORK,
            source = source }
    end

    -- Limite de débit par (événement, joueur).
    local rules = cfg('game_events.trigger_rate_rules', nil)
    local perSec = (type(rules) == 'table' and tonumber(rules[name]))
        or tonumber(cfg('game_events.trigger_default_rate', 0)) or 0
    if perSec and perSec > 0 and ZShield.RateLimit and ZShield.RateLimit.tokenBucket then
        local key = name .. '|' .. tostring(source)
        local b = buckets[key]
        if not b then
            b = ZShield.RateLimit.tokenBucket({ capacity = perSec, refillPerSec = perSec })
            buckets[key] = b
        end
        if not b:check(key) then
            return { block = true, severity = C.SEVERITY.MEDIUM, confidence = 0.75,
                reason = 'trigger rate exceeded: ' .. name, category = C.CATEGORY.NETWORK,
                source = source }
        end
    end

    return { block = false }
end

ZShield.Triggers = Triggers
return Triggers
