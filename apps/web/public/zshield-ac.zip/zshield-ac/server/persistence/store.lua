--[[
    FILE:         server/persistence/store.lua
    PURPOSE:      Event store (§37) et couche de persistance (§36). File mémoire bornée :
                  event -> queue -> batch -> persistence. Si SQL tombe : memory queue ->
                  retry -> recovery. L'anti-cheat ne plante JAMAIS parce que la base est
                  temporairement indisponible (§37, §38, §173).
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua, core/config.lua,
                  server/persistence/circuit.lua
    PUBLIC API:   ZShield.Store.enqueue(kind, payload)
                  ZShield.Store.setSink(fn)          -- fn(batch) -> ok  (écriture SQL réelle)
                  ZShield.Store.flush() -> flushed, remaining
                  ZShield.Store.stats()

    §36 : ne JAMAIS écrire en SQL à chaque frame. On accumule en file, on écrit par lots.
    §37 : la file est bornée. Si elle sature (SQL longtemps down), on évince les événements
    les MOINS importants d'abord (télémétrie avant incidents), en comptant les pertes — jamais
    de perte silencieuse.
    §52 : le sink est protégé par un disjoncteur. SQL down -> circuit ouvert -> on garde en
    file sans marteler la base -> récupération automatique quand elle revient.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log

local Store = {
    queue = {},           -- array de { kind, payload, priority, at }
    sink = nil,           -- fn(batch) -> ok : écriture réelle (SQL). Injecté par l'adaptateur.
    circuit = nil,        -- disjoncteur protégeant le sink
    stats = { enqueued = 0, flushed = 0, dropped = 0, batches = 0, sink_errors = 0 },
    maxSize = 5000,
    batchSize = 100,
}

-- Priorité des types d'événements pour l'éviction (§37). Plus élevé = plus important =
-- évincé en DERNIER. Un incident ou un ban se perd après la télémétrie.
local PRIORITY = {
    telemetry = 1,
    metric = 1,
    signal = 2,
    audit = 3,
    incident = 4,
    ban = 5,
    transaction = 5,
}

function Store.configure()
    Store.maxSize = (ZShield.Config and ZShield.Config.value('persistence.event_store_max')) or 5000
    Store.circuit = ZShield.Circuit.new('sql_sink', { failure_threshold = 5, open_ms = 30000 })
end

function Store.setSink(fn)
    Store.sink = fn
end

--- Ajoute un événement à la file. Ne bloque jamais, ne lève jamais.
function Store.enqueue(kind, payload)
    if not (ZShield.Config and ZShield.Config.value('persistence.enabled') ~= false) then
        return false
    end
    local priority = PRIORITY[kind] or 2

    -- File pleine : éviction du moins important (§37), jamais de perte silencieuse.
    if #Store.queue >= Store.maxSize then
        if not Store.evictLowest(priority) then
            -- Rien de moins important à évincer : on refuse ce nouvel événement, compté.
            Store.stats.dropped = Store.stats.dropped + 1
            Log:warn('store', 'event dropped: queue full and nothing lower to evict', {
                kind = kind, size = #Store.queue })
            return false
        end
    end

    Store.queue[#Store.queue + 1] = {
        kind = kind, payload = payload, priority = priority, at = Util.now(),
    }
    Store.stats.enqueued = Store.stats.enqueued + 1
    return true
end

--- Évince l'événement de plus basse priorité (< incoming). Retourne true si évincé.
function Store.evictLowest(incomingPriority)
    local worstIdx, worstPrio
    for i = 1, #Store.queue do
        local p = Store.queue[i].priority
        if not worstPrio or p < worstPrio then worstIdx, worstPrio = i, p end
    end
    if not worstIdx then return false end
    -- Ne jamais évincer quelque chose d'AUSSI ou PLUS important que l'entrant.
    if worstPrio >= incomingPriority then return false end
    table.remove(Store.queue, worstIdx)
    Store.stats.dropped = Store.stats.dropped + 1
    return true
end

--- Écrit un lot via le sink, protégé par le disjoncteur (§52). Retourne flushed, remaining.
--- Si le circuit est ouvert (SQL down), on NE VIDE PAS la file : on la garde intacte pour
--- réessayer plus tard. La sécurité continue de tourner pendant ce temps (§38).
function Store.flush()
    if #Store.queue == 0 then return 0, 0 end
    if not Store.sink then
        -- Aucun sink installé (persistance non branchée) : on garde en file, on ne perd rien.
        return 0, #Store.queue
    end
    if not Store.circuit then Store.configure() end

    -- Prélever un lot (les plus anciens d'abord).
    local batch = {}
    local n = math.min(Store.batchSize, #Store.queue)
    for i = 1, n do batch[i] = Store.queue[i] end

    local ok = Store.circuit:call(function()
        return Store.sink(batch)
    end)

    if ok then
        -- Succès : retirer le lot écrit de la file.
        for _ = 1, n do table.remove(Store.queue, 1) end
        Store.stats.flushed = Store.stats.flushed + n
        Store.stats.batches = Store.stats.batches + 1
        return n, #Store.queue
    else
        -- Échec (ou circuit ouvert) : la file reste intacte. On réessaiera.
        Store.stats.sink_errors = Store.stats.sink_errors + 1
        return 0, #Store.queue
    end
end

--- Vide autant que possible en plusieurs lots (jusqu'à ce que le circuit refuse ou la file
--- soit vide). Appelé périodiquement.
function Store.drain(maxBatches)
    maxBatches = maxBatches or 10
    local total = 0
    for _ = 1, maxBatches do
        local flushed, remaining = Store.flush()
        total = total + flushed
        if flushed == 0 or remaining == 0 then break end
    end
    return total, #Store.queue
end

function Store.size()
    return #Store.queue
end

function Store.getStats()
    local s = Util.deepCopy(Store.stats)
    s.queue_size = #Store.queue
    s.circuit = Store.circuit and Store.circuit:getStats() or nil
    return s
end

--- Réinitialise (tests / arrêt).
function Store.clear()
    Store.queue = {}
end

ZShield.Store = Store
