--[[
    FILE:         server/persistence/circuit.lua
    PURPOSE:      Disjoncteur (§52). Protège d'une dépendance externe défaillante (SQL,
                  Discord) : retry -> backoff -> circuit ouvert -> récupération. Empêche une
                  boucle de retry infinie qui aggraverait la panne.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua
    PUBLIC API:   ZShield.Circuit.new(name, opts) -> breaker
                  breaker:call(fn) -> ok, resultOrErr
                  breaker:state() -> 'closed'|'open'|'half_open'
                  breaker:allow() -> boolean

    §52 : trois états.
      CLOSED    : tout passe. Compte les échecs consécutifs.
      OPEN      : après N échecs, on ouvre : les appels sont refusés immédiatement pendant
                  `open_ms`, sans toucher la dépendance (on lui laisse le temps de récupérer).
      HALF_OPEN : après `open_ms`, un seul appel « sonde » est autorisé. S'il réussit, on
                  referme ; s'il échoue, on rouvre.

    §173 : jamais de point de défaillance unique. Le disjoncteur est LOCAL et ne dépend de
    rien ; c'est lui qui isole la dépendance externe du reste du système.
]]

ZShield = ZShield or {}
local Util = ZShield.Util
local Log = ZShield.Log

local Circuit = {}
Circuit.__index = Circuit

--- opts = { failure_threshold, open_ms }
function Circuit.new(name, opts)
    opts = opts or {}
    local self = setmetatable({}, Circuit)
    self.name = name
    self.failureThreshold = opts.failure_threshold or 5
    self.openMs = opts.open_ms or 30000
    self.state_ = 'closed'
    self.failures = 0
    self.openedAt = 0
    self.probing = false
    self.stats = { calls = 0, failures = 0, rejected = 0, opens = 0, recoveries = 0 }
    return self
end

function Circuit:state()
    -- Transition automatique OPEN -> HALF_OPEN quand la fenêtre est écoulée.
    if self.state_ == 'open' and (Util.now() - self.openedAt) >= self.openMs then
        self.state_ = 'half_open'
        self.probing = false
        Log:info('circuit', 'circuit half-open (probing)', { name = self.name })
    end
    return self.state_
end

--- Un appel est-il autorisé ? En half_open, un seul appel sonde est permis.
function Circuit:allow()
    local st = self:state()
    if st == 'closed' then return true end
    if st == 'open' then return false end
    -- half_open : autoriser une seule sonde.
    if not self.probing then
        self.probing = true
        return true
    end
    return false
end

local function onSuccess(self)
    if self.state_ == 'half_open' then
        -- La sonde a réussi : on referme.
        self.state_ = 'closed'
        self.failures = 0
        self.probing = false
        self.stats.recoveries = self.stats.recoveries + 1
        Log:info('circuit', 'circuit closed (recovered)', { name = self.name })
    else
        self.failures = 0
    end
end

local function onFailure(self)
    self.stats.failures = self.stats.failures + 1
    self.failures = self.failures + 1
    if self.state_ == 'half_open' then
        -- La sonde a échoué : on rouvre pour une nouvelle fenêtre.
        self.state_ = 'open'
        self.openedAt = Util.now()
        self.probing = false
        self.stats.opens = self.stats.opens + 1
        Log:warn('circuit', 'probe failed, circuit re-opened', { name = self.name })
    elseif self.failures >= self.failureThreshold then
        self.state_ = 'open'
        self.openedAt = Util.now()
        self.stats.opens = self.stats.opens + 1
        Log:warn('circuit', 'circuit opened after failures', {
            name = self.name, failures = self.failures })
    end
end

--- Exécute fn sous protection. Retourne ok, resultOrErr.
--- Si le circuit est ouvert, l'appel est refusé sans exécuter fn (protège la dépendance).
function Circuit:call(fn)
    self.stats.calls = self.stats.calls + 1
    if not self:allow() then
        self.stats.rejected = self.stats.rejected + 1
        return false, 'circuit_open'
    end

    local ok, result = pcall(fn)
    if ok and result ~= false then
        onSuccess(self)
        return true, result
    else
        onFailure(self)
        return false, ok and 'call_failed' or tostring(result)
    end
end

function Circuit:getStats()
    return { name = self.name, state = self:state(), failures = self.failures,
             calls = self.stats.calls, opens = self.stats.opens, recoveries = self.stats.recoveries,
             rejected = self.stats.rejected }
end

ZShield.Circuit = Circuit
