--[[
    FILE:         server/serveronly.lua
    PURPOSE:      GARDE « ORIGINE SERVEUR » (anti-executor/anti-injection). Recherche 26/09 :
                  quand un event serveur est déclenché PAR LE RÉSEAU (un client), le natif
                  GetInvokingResource() renvoie nil ; quand il est déclenché par une ressource
                  serveur légitime, il renvoie son nom. Un event censé n'être appelé QUE côté
                  serveur (logique admin, économie interne, events internes de l'anticheat)
                  mais qui arrive du réseau = executor/menu -> on refuse et on trace.

                  Donne à l'opérateur un helper d'une ligne pour blinder ses events sensibles :
                      ZShield.ServerOnly('mon:event:interne', function(...) ... end)
                  Le handler n'est appelé que si l'origine est une ressource serveur.

    Partie PURE (testable) : ZShield.serverOriginOk(invokingResource, source).
    DEPENDENCIES: server/detection/injection.lua (optionnel, pour la trace)
    PUBLIC API:   ZShield.serverOriginOk(invokingResource, source) -> bool
                  ZShield.ServerOnly(eventName, handler)   -- FiveM
]]

ZShield = ZShield or {}

--- Décision pure. L'origine est-elle une ressource serveur légitime ?
--- invokingResource = résultat de GetInvokingResource() ; source = émetteur.
--- Règle : une ressource invoquante non vide => origine serveur OK. nil/'' avec un
--- source joueur (>0) => déclenché par le réseau (client) => REFUS.
function ZShield.serverOriginOk(invokingResource, source)
    if type(invokingResource) == 'string' and invokingResource ~= '' then
        return true
    end
    -- Pas de ressource invoquante : réseau. Un source joueur (>0) => client => refus.
    if source ~= nil and source ~= 0 then
        return false
    end
    -- Aucun source (contexte serveur pur sans ressource nommée) : on autorise.
    return true
end

--- Enregistre un event SERVEUR-ONLY : le handler n'est exécuté que si l'appel vient
--- d'une ressource serveur. Un déclenchement réseau (client) est refusé et tracé.
function ZShield.ServerOnly(eventName, handler)
    if type(RegisterNetEvent) ~= 'function' or type(handler) ~= 'function' then return end
    -- On N'appelle PAS RegisterNetEvent : un event server-only ne doit pas être exposé au
    -- réseau. On écoute via AddEventHandler (déclenchements serveur), et si malgré tout un
    -- client atteint ce nom, GetInvokingResource() sera nil et on refusera.
    AddEventHandler(eventName, function(...)
        local invoking = (type(GetInvokingResource) == 'function') and GetInvokingResource() or nil
        local src = source
        if not ZShield.serverOriginOk(invoking, src) then
            if ZShield.Injection and ZShield.Injection.report then
                pcall(ZShield.Injection.report, src, 'protected_event_from_client',
                    { event = eventName, kind = 'server_only_from_network' })
            end
            if ZShield.Log then
                ZShield.Log:security('serveronly', 'event serveur déclenché par le réseau (refusé)',
                    { event = eventName, source = src })
            end
            return
        end
        return handler(...)
    end)
end

return ZShield.serverOriginOk
