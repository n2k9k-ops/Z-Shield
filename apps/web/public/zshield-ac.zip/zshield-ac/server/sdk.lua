--[[
    FILE:         server/sdk.lua
    PURPOSE:      SDK de sécurité (§76, §77). Bibliothèque permettant à un développeur de
                  sécuriser un event en quelques lignes, sans connaître les rouages internes.
    DEPENDENCIES: server/firewall/firewall.lua, server/context.lua, shared/schema.lua
    PUBLIC API (§76) :
        ZShield.Security:ProtectEvent(name, opts)
        ZShield.Security:ValidatePlayer(source) -> boolean
        ZShield.Security:RequirePermission(perm)  -> validator
        ZShield.Security:RequireContext(states)   -> validator (états autorisés)
        ZShield.Security:RequireDistance(getTarget, maxDist) -> validator
        ZShield.Security:Cooldown(ms)             -> rateLimit spec

    §77 : l'exemple conceptuel de la spec doit fonctionner tel quel :
        ZShield.Security:ProtectEvent("shop:buy", {
            rateLimit = 2,
            validate = function(ctx) return ... end
        })

    Le SDK COMPOSE des validateurs réutilisables. Chaque helper retourne une fonction
    validate(ctx) compatible avec le firewall. Le développeur assemble, le firewall exécute.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Log = ZShield.Log

local Security = {}

--- Protège un event (§77). Interface simplifiée au-dessus du firewall.
--- opts = {
---   schema = {...},              -- validation des args (optionnel)
---   rateLimit = 2,               -- nombre : cooldown en secondes | table : spec complète
---   states = { 'ACTIVE' },       -- états autorisés (optionnel)
---   permission = 'admin',        -- permission requise (optionnel, string ou fonction)
---   validate = function(ctx) end,-- règle métier (optionnel)
---   execute = function(ctx) end, -- exécution
--- }
function Security:ProtectEvent(name, opts)
    opts = opts or {}
    if not ZShield.Firewall then return false, 'firewall not loaded' end

    -- Traduire le rateLimit simplifié. Un nombre = N actions/seconde en token bucket ;
    -- pour un cooldown explicite, passer une table.
    local rateLimit
    if type(opts.rateLimit) == 'number' then
        -- Interprétation : opts.rateLimit actions autorisées par seconde.
        rateLimit = { strategy = 'token_bucket', capacity = opts.rateLimit, refillPerSec = opts.rateLimit }
    elseif type(opts.rateLimit) == 'table' then
        rateLimit = opts.rateLimit
    end

    -- Composer l'autorisation depuis une permission simple.
    local authorize = opts.authorize
    if not authorize and opts.permission then
        authorize = Security:RequirePermission(opts.permission)
    end

    return ZShield.Firewall.register({
        name = name,
        schema = opts.schema,
        states = opts.states,
        rateLimit = rateLimit,
        authorize = authorize,
        validate = opts.validate,
        execute = opts.execute,
        version = opts.version,
    })
end

--- Valide qu'un joueur existe et est dans un état exploitable (§76).
function Security:ValidatePlayer(source)
    if not ZShield.Context then return false end
    local ctx = ZShield.Context.get(source)
    if not ctx then return false end
    -- Un joueur en cours de connexion/déconnexion n'est pas encore/plus valide pour des actions.
    return ctx.state ~= C.PLAYER_STATE.CONNECTING
        and ctx.state ~= C.PLAYER_STATE.DISCONNECTED
end

--- Retourne un validateur exigeant une permission (§76). `perm` peut être :
---   - une string : clé de permission stockée dans le contexte du joueur (calculée serveur)
---   - une fonction : function(ctx) -> boolean, évaluée serveur
function Security:RequirePermission(perm)
    if type(perm) == 'function' then
        return function(ctx)
            if perm(ctx) then return true end
            return false, 'permission denied'
        end
    end
    return function(ctx)
        -- La permission est lue dans le contexte SERVEUR du joueur, jamais crue du client (§04).
        if ZShield.Context and ZShield.Context.value(ctx.source, 'perm.' .. perm) then
            return true
        end
        return false, 'missing permission: ' .. tostring(perm)
    end
end

--- Retourne un validateur exigeant un état (§76, §08). Alternative à opts.states pour les
--- cas dynamiques.
function Security:RequireContext(states)
    return function(ctx)
        if ZShield.Context and ZShield.Context.isValidState(ctx.source, states) then
            return true
        end
        return false, 'invalid state for this action'
    end
end

--- Retourne un validateur exigeant que le joueur soit à moins de `maxDist` d'une cible.
--- `getTarget(ctx) -> vector3` fournit la position cible, calculée SERVEUR (§76).
--- Empêche les actions à distance impossible (interagir avec un objet à 500 m).
function Security:RequireDistance(getTarget, maxDist)
    return function(ctx)
        local player = ZShield.Context and ZShield.Context.get(ctx.source)
        local pos = player and player.last_position
        if not pos then return false, 'no known position' end
        local target = getTarget(ctx)
        if type(target) ~= 'table' then return false, 'no target position' end
        local dx, dy, dz = pos.x - target.x, pos.y - target.y, pos.z - target.z
        local dist = math.sqrt(dx * dx + dy * dy + dz * dz)
        if dist <= maxDist then return true end
        return false, string.format('too far (%.0fm > %.0fm)', dist, maxDist)
    end
end

--- Spec de cooldown prête à passer en opts.rateLimit (§76).
function Security:Cooldown(ms)
    return { strategy = 'cooldown', cooldownMs = ms }
end

--- Contrat d'intégration d'une ressource protégée (§75). Déclaratif, pour la documentation
--- et l'audit : quelle ressource, quels events, quelles permissions.
function Security:RegisterContract(contract)
    Security.contracts = Security.contracts or {}
    Security.contracts[contract.resource] = {
        resource = contract.resource,
        events = contract.events or {},
        permissions = contract.permissions or {},
        registered_at = ZShield.Util and ZShield.Util.now() or 0,
    }
    Log:info('sdk', 'security contract registered', { resource = contract.resource })
    return true
end

function Security:GetContracts()
    return Security.contracts or {}
end

ZShield.Security = Security
