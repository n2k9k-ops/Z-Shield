--[[
    FILE:         server/license_online.lua
    PURPOSE:      KILL-SWITCH de licence EN LIGNE (anti-leak). La vérification hors-ligne
                  (server/license.lua) coupe la protection à l'EXPIRATION, même SaaS
                  injoignable — mais elle ne peut pas révoquer une clé LEAKÉE avant sa
                  date. Ce module ajoute ce maillon : l'agent interroge périodiquement le
                  SaaS, qui renvoie un VERDICT SIGNÉ (actif / révoqué). Une clé volée et
                  revendue est alors désactivable à distance, immédiatement.

    PRINCIPE DE CONCEPTION (important pour ne PAS tuer un serveur légitime) :
      - Le SaaS injoignable ne coupe PAS tout de suite : on accorde une PÉRIODE DE GRÂCE
        (license.online_grace_hours, 72 h par défaut). Un serveur honnête survit à une
        panne réseau ou à une maintenance du SaaS.
      - La RÉVOCATION, elle, est IMMÉDIATE et COLLANTE : une fois qu'un verdict signé
        « révoqué » est reçu, l'état reste révoqué même si les vérifs suivantes échouent
        (un tricheur ne débranche pas le réseau pour ré-obtenir la grâce).
      - Le verdict est SIGNÉ (HMAC avec le secret de licence, comme les jetons) : le SaaS
        est la seule source qui peut prononcer « valide » ou « révoqué ». Un intermédiaire
        ne peut pas forger un « valide ».
      - Anti-rejeu : le verdict porte un horodatage ; on n'accepte pas un verdict plus
        ancien que le dernier appliqué (un « valide » capturé ne peut pas annuler une
        révocation ultérieure).

    Ce module est PUR (aucune I/O, aucune native) : il décide, il ne télécharge pas.
    La couche agent (non testée) fait l'appel HTTP et appelle applyRemote()/tick().

    DEPENDENCIES: shared/sha256.lua, core/util.lua, core/log.lua, server/license.lua
    PUBLIC API:   ZShield.LicenseOnline.signVerdict(spec)      -- (côté SaaS / tests)
                  ZShield.LicenseOnline.applyRemote(token, now) -> state
                  ZShield.LicenseOnline.onUnreachable(now)      -> state
                  ZShield.LicenseOnline.effective(now)          -> { active, state, reason }
                  ZShield.LicenseOnline.reset()

    FORMAT du verdict : "lv1|<server_id>|<status>|<issued_at>~<hmac_hex>"
      status ∈ { active, revoked }. Signé avec le SECRET de licence (ZShield.License).
]]

ZShield = ZShield or {}
local Log = ZShield.Log
local Util = ZShield.Util

local LO = {
    STATE = {
        UNKNOWN   = 'UNKNOWN',   -- pas encore de verdict distant
        ACTIVE    = 'ACTIVE',    -- SaaS confirme : clé active
        REVOKED   = 'REVOKED',   -- SaaS confirme : clé révoquée (leak, remboursement…)
        GRACE     = 'GRACE',     -- SaaS injoignable, dans la période de grâce
        LOCKED    = 'LOCKED',    -- grâce dépassée sans confirmation -> protection coupée
    },
    _last = {
        state = 'UNKNOWN',
        applied_at = nil,     -- horodatage du dernier verdict signé appliqué (anti-rejeu)
        last_ok = nil,        -- dernier instant où le SaaS a confirmé (pour la grâce)
        revoked = false,      -- collant : une fois vrai, le reste
    },
}

local function secret()
    if ZShield.License and ZShield.License.secret then return ZShield.License.secret() end
    return (ZShield.License and ZShield.License.SECRET) or ''
end

local function sign(payload)
    return ZShield.Sha256.hmac(secret(), payload)
end

--- Émet un verdict signé (fait côté SaaS ; ici pour tests / outil vendeur).
--- spec = { server_id, status = 'active'|'revoked', issued_at }
function LO.signVerdict(spec)
    local payload = string.format('lv1|%s|%s|%d',
        tostring(spec.server_id or 'any'),
        tostring(spec.status or 'active'),
        tonumber(spec.issued_at) or Util.wallclock())
    return payload .. '~' .. sign(payload)
end

-- Vérifie et décode un verdict signé. Retourne (fields|nil, reason).
local function parseVerdict(token)
    if type(token) ~= 'string' or token == '' then return nil, 'verdict vide' end
    local sep = token:find('~[^~]*$')
    if not sep then return nil, 'verdict malformé' end
    local payload, sig = token:sub(1, sep - 1), token:sub(sep + 1)
    local expected = sign(payload)
    -- Comparaison à temps constant (longueur d'abord).
    if #sig ~= #expected then return nil, 'signature invalide' end
    local diff = 0
    for i = 1, #expected do diff = diff | (expected:byte(i) ~ sig:byte(i)) end
    if diff ~= 0 then return nil, 'signature invalide' end
    local ver, server_id, status, issued_at =
        payload:match('^(lv%d+)|([^|]*)|([^|]*)|(%d+)$')
    if ver ~= 'lv1' then return nil, 'format non supporté' end
    return { server_id = server_id, status = status, issued_at = tonumber(issued_at) }, nil
end

--- Applique un verdict distant SIGNÉ. Anti-rejeu (horodatage croissant). La révocation
--- est collante. Retourne l'état effectif après application.
function LO.applyRemote(token, now, identity)
    now = now or Util.wallclock()
    identity = identity or (ZShield.License and ZShield.License.identity())
    local v, reason = parseVerdict(token)
    if not v then
        if Log then Log:security('license', 'verdict distant rejeté', { reason = reason }) end
        return LO.effective(now)
    end
    -- Liaison serveur : 'any' passe partout, sinon doit matcher ce serveur.
    if v.server_id ~= 'any' and identity and v.server_id ~= identity then
        if Log then Log:security('license', 'verdict pour un autre serveur', { server_id = v.server_id }) end
        return LO.effective(now)
    end
    -- Anti-rejeu : un verdict plus ancien que le dernier appliqué est ignoré.
    if LO._last.applied_at and v.issued_at <= LO._last.applied_at then
        return LO.effective(now)
    end

    LO._last.applied_at = v.issued_at
    if v.status == 'revoked' then
        LO._last.revoked = true            -- collant
        LO._last.state = LO.STATE.REVOKED
        if Log then Log:security('license', 'LICENCE RÉVOQUÉE à distance (kill-switch)', {}) end
    else
        -- Un « active » ne peut PAS ré-activer une clé déjà révoquée (collant).
        if not LO._last.revoked then
            LO._last.state = LO.STATE.ACTIVE
            LO._last.last_ok = now
        end
    end
    return LO.effective(now)
end

--- Le SaaS n'a pas pu être joint à `now`. Décide grâce vs verrouillage.
function LO.onUnreachable(now)
    now = now or Util.wallclock()
    if LO._last.revoked then return LO.effective(now) end   -- révoqué : reste révoqué
    return LO.effective(now)
end

--- État EFFECTIF (ce que l'anticheat doit faire). { active, state, reason }.
--- active=false => la protection en ligne considère la licence non valable.
function LO.effective(now)
    now = now or Util.wallclock()
    if LO._last.revoked then
        return { active = false, state = LO.STATE.REVOKED,
            reason = 'licence révoquée à distance' }
    end
    -- La grâce se mesure depuis la DERNIÈRE confirmation du SaaS (ou, si jamais
    -- confirmée, depuis la première évaluation). Tant qu'on est dans la fenêtre, la
    -- protection reste active ; au-delà, on verrouille (le SaaS reste silencieux
    -- trop longtemps — potentiel contournement du kill-switch).
    local graceH = tonumber(ZShield.Config
        and ZShield.Config.value('license.online_grace_hours', 72)) or 72
    local confirmed = LO._last.last_ok ~= nil
    local anchor = LO._last.last_ok or LO._first_seen
    if not anchor then
        LO._first_seen = now
        anchor = now
    end
    local elapsedH = (now - anchor) / 3600
    if elapsedH <= graceH then
        if confirmed then
            return { active = true, state = LO.STATE.ACTIVE,
                reason = string.format('confirmée par le SaaS (il y a %.0f h)', elapsedH) }
        end
        return { active = true, state = LO.STATE.GRACE,
            reason = string.format('SaaS non confirmé, grâce (%.0f/%.0f h)', elapsedH, graceH) }
    end
    return { active = false, state = LO.STATE.LOCKED,
        reason = 'SaaS injoignable au-delà de la période de grâce' }
end

function LO.reset()
    LO._last = { state = 'UNKNOWN', applied_at = nil, last_ok = nil, revoked = false }
    LO._first_seen = nil
end

ZShield.LicenseOnline = LO
return LO
