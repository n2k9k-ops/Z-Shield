--[[
    FILE:         server/detection/spawnprotect.lua
    PURPOSE:      ANTI SPAWN-KILL / bypass de protection au spawn. Le serveur connaît l'instant
                  de spawn de chaque joueur. Infliger des dégâts à une victime encore dans sa
                  fenêtre de protection de spawn est illégitime (spawn-kill, ou contournement de
                  la protection). On signale l'ATTAQUANT.

    100 % serveur : instants de spawn et events de dégât connus du serveur.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.SpawnProtect.markSpawn(victim, now)
                  ZShield.SpawnProtect.observeDamage(attacker, victim, now) -> signal|nil
                  ZShield.SpawnProtect.forget(source) / .register()
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local SP = {}
SP._spawn = {}   -- victim -> spawn_ts

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

function SP.markSpawn(victim, now)
    SP._spawn[victim] = tonumber(now) or Util.now()
end

function SP.observeDamage(attacker, victim, now)
    if cfg('spawnprotect.enabled', false) ~= true then return nil end
    now = tonumber(now) or Util.now()
    local spawnedAt = SP._spawn[victim]
    if not spawnedAt then return nil end
    local protectMs = tonumber(cfg('spawnprotect.protect_ms', 5000)) or 5000
    if (now - spawnedAt) <= protectMs and attacker ~= victim then
        return {
            detector = 'spawnprotect', category = C.CATEGORY.DAMAGE,
            severity = C.SEVERITY.MEDIUM, confidence = 0.6,
            reason = string.format('dégâts sur une victime protégée au spawn (%.1f s après spawn)',
                (now - spawnedAt) / 1000),
            source = attacker,
            metadata = { victim = victim, since_spawn_ms = now - spawnedAt, kind = 'spawnkill' },
        }
    end
    return nil
end

function SP.forget(source) SP._spawn[source] = nil end

function SP.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'spawnprotect', category = C.CATEGORY.DAMAGE,
            evaluate = function() return {} end })
    end
end

ZShield.SpawnProtect = SP
return SP
