--[[
    FILE:         server/detection/desync.lua
    PURPOSE:      DÉSYNC D'ORIGINE D'ACTION + LAG-SWITCH. Deux abus liés à la manipulation de
                  l'état/temps réseau, tous deux OBSERVABLES SERVEUR :

                  1) DÉSYNC : un joueur inflige des dégâts / tire depuis une ORIGINE très
                     éloignée de sa dernière position connue du serveur. C'est la signature
                     d'un teleport-shoot / godmode par désynchronisation : « je suis ici pour
                     le serveur, mais je frappe de là-bas ». On compare l'origine de l'action
                     à la dernière position rapportée ; au-delà d'un seuil -> signal.

                  2) LAG-SWITCH : le joueur gèle volontairement sa connexion (aucun rapport
                     pendant un temps) PUIS l'effet arrive d'un coup, ou continue d'affecter
                     le monde pendant le gel. Un gel long CORRÉLÉ à un effet est suspect.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Desync.observePosition(source, pos, now)
                  ZShield.Desync.observeAction(source, action) -> signal|nil
                  ZShield.Desync.observeGap(source, gap) -> signal|nil
                  ZShield.Desync.forget(source) / .register()

    action = { origin = {x,y,z}, now = ms }
    gap    = { gap_ms = number, effect_during_gap = bool, now = ms }
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local DS = {}
DS._pos = {}   -- source -> { pos, at }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function dist(a, b)
    local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

--- Met à jour la dernière position connue du serveur (télémétrie de mouvement).
function DS.observePosition(source, pos, now)
    if type(pos) ~= 'table' then return end
    DS._pos[source] = { pos = pos, at = tonumber(now) or Util.now() }
end

--- Valide l'origine d'une action offensive vs la dernière position connue.
function DS.observeAction(source, action)
    if cfg('desync.enabled', false) ~= true then return nil end
    if type(action) ~= 'table' or type(action.origin) ~= 'table' then return nil end
    local last = DS._pos[source]
    if not last then return nil end   -- pas de référence encore

    local maxDesync = tonumber(cfg('desync.max_origin_m', 8)) or 8
    local d = dist(last.pos, action.origin)
    if d > maxDesync then
        return {
            detector = 'desync', category = C.CATEGORY.DAMAGE,
            severity = C.SEVERITY.HIGH, confidence = 0.6,
            reason = string.format('action à %.0f m de la position serveur (désync/teleport-shoot)', d),
            source = source, metadata = { distance = d, kind = 'origin_desync' },
        }
    end
    return nil
end

--- Détecte un lag-switch : gel prolongé corrélé à un effet monde.
function DS.observeGap(source, gap)
    if cfg('desync.lagswitch_enabled', false) ~= true then return nil end
    if type(gap) ~= 'table' then return nil end
    local minGap = tonumber(cfg('desync.min_gap_ms', 1500)) or 1500
    local g = tonumber(gap.gap_ms) or 0
    if g >= minGap and gap.effect_during_gap == true then
        return {
            detector = 'desync', category = C.CATEGORY.NETWORK,
            severity = C.SEVERITY.MEDIUM, confidence = 0.5,
            reason = string.format('gel de connexion %d ms avec effet monde (lag-switch)', g),
            source = source, metadata = { gap_ms = g, kind = 'lagswitch' },
        }
    end
    return nil
end

function DS.forget(source) DS._pos[source] = nil end

function DS.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'desync', category = C.CATEGORY.DAMAGE,
            evaluate = function() return {} end })
    end
end

ZShield.Desync = DS
return DS
