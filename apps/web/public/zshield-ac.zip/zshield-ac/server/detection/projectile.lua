--[[
    FILE:         server/detection/projectile.lua
    PURPOSE:      Détecteur de projectiles serveur-autoritatif, alimenté par
                  startProjectileEvent (§08). Deux exploits fréquents, vérifiables
                  côté serveur :
                    - PROJECTILE À DISTANCE : le projectile part d'une position très
                      éloignée du joueur réel (explosion/roquette téléportée sur une
                      cible) — position de tir incohérente avec la position serveur.
                    - SPAM DE PROJECTILES : cadence de lancement impossible (grief).
    DEPENDENCIES: shared/constants.lua, core/log.lua, core/config.lua
    PUBLIC API:   ZShield.Projectile.observe(owner, data, now, playerPos) -- pur/testable
                  ZShield.Projectile.forget(owner)
                  ZShield.Projectile.emit(owner, data, now, playerPos)

    Champs startProjectileEvent (docs.fivem.net) : weaponHash, projectileHash, ownerId,
    firePositionX/Y/Z, initialPositionX/Y/Z, targetEntity. On ne compare que des bornes
    serveur-vérifiables (§26 : on ÉMET, la corrélation décide ; jamais un signal client
    seul ne sanctionne).
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Log = ZShield.Log

local Projectile = {}

Projectile._ctx = {}   -- owner -> { shots = { ts... } }

local WINDOW_MS = 1000

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function ctxOf(owner)
    local c = Projectile._ctx[owner]
    if not c then c = { shots = {} }; Projectile._ctx[owner] = c end
    return c
end

local function dist3(a, b)
    local dx = (a.x or 0) - (b.x or 0)
    local dy = (a.y or 0) - (b.y or 0)
    local dz = (a.z or 0) - (b.z or 0)
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

--- Observe un lancement de projectile. `now` en ms (injecté). `playerPos` = position
--- serveur connue du joueur (optionnelle) { x, y, z }.
--- Retourne un signal { severity, confidence, reason, category, source, protection } ou nil.
function Projectile.observe(owner, data, now, playerPos)
    if not owner then return nil end
    data = data or {}
    now = now or 0
    if not cfg('game_events.projectile_detector', true) then return nil end

    local best = nil
    local function consider(sig)
        if sig and (not best or sig.confidence > best.confidence) then best = sig end
    end

    -- --- Whitelist de projectiles (mode « autoriser uniquement ») ---
    -- Un projectile dont le hash n'est pas dans la liste active est refusé.
    if ZShield.Blacklist and ZShield.Blacklist.notWhitelisted then
        local h = data.projectileHash or data.weaponHash
        if h and ZShield.Blacklist.notWhitelisted('projectile', h) then
            consider({
                severity = C.SEVERITY.HIGH, confidence = 0.9,
                reason = 'projectile not in whitelist',
                protection = 'sp_explosions', category = C.CATEGORY.ENTITY, block = true,
            })
        end
    end

    -- --- Cadence de lancement ---
    local c = ctxOf(owner)
    local shots = c.shots
    local cutoff = now - WINDOW_MS
    local i = 1
    while shots[i] and shots[i] < cutoff do i = i + 1 end
    if i > 1 then
        local kept = {}
        for j = i, #shots do kept[#kept + 1] = shots[j] end
        c.shots = kept; shots = kept
    end
    shots[#shots + 1] = now

    local maxRate = tonumber(cfg('game_events.max_projectiles_per_sec', 8)) or 8
    local count = #shots
    if count > maxRate then
        local over = count - maxRate
        consider({
            severity = C.SEVERITY.HIGH,
            confidence = math.min(0.5 + over * 0.08, 0.9),
            reason = string.format('projectile spam %d/s over cap %d', count, maxRate),
            protection = 'sp_explosions',
            category = C.CATEGORY.ENTITY,
        })
    end

    -- --- Position de tir incohérente avec le joueur ---
    if playerPos and data.firePositionX ~= nil then
        local firePos = { x = data.firePositionX, y = data.firePositionY, z = data.firePositionZ }
        local d = dist3(firePos, playerPos)
        local maxOffset = tonumber(cfg('game_events.projectile_max_offset_m', 150)) or 150
        if d > maxOffset then
            consider({
                severity = C.SEVERITY.HIGH,
                confidence = math.min(0.55 + (d - maxOffset) / 500, 0.9),
                reason = string.format('projectile fired %dm from player (remote explosion)', math.floor(d)),
                protection = 'sp_explosions',
                category = C.CATEGORY.ENTITY,
            })
        end
    end

    if not best then return nil end
    best.source = owner
    return best
end

function Projectile.forget(owner)
    Projectile._ctx[owner] = nil
end

--- Résout la position serveur connue du joueur (via le détecteur de mouvement s'il
--- a observé une position). Retourne { x, y, z } ou nil.
local function knownPlayerPos(owner)
    if ZShield.Context and ZShield.Context.get then
        local ctx = ZShield.Context.get(owner)
        if ctx and ctx.last_position then return ctx.last_position end
    end
    return nil
end

function Projectile.emit(owner, data, now)
    local sig = Projectile.observe(owner, data, now, knownPlayerPos(owner))
    if sig and ZShield.Detection then
        ZShield.Detection.emit({
            detector = 'projectile.behaviour',
            category = sig.category,
            severity = sig.severity,
            confidence = sig.confidence,
            reason = sig.reason,
            source = sig.source,
            protection = sig.protection,
            metadata = { protection = sig.protection },
        })
    end
    return sig
end

ZShield.Projectile = Projectile
return Projectile
