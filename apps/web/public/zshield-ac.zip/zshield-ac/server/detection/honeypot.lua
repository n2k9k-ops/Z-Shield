--[[
    FILE:         server/detection/honeypot.lua
    PURPOSE:      PIÈGES À MENUS (honeypots). La recherche défensive est unanime : les
                  SIGNATURES de noms de menu (Eulen, RedEngine…) sont renommables donc peu
                  fiables ; en revanche un HONEYPOT est quasi sans faux positif.

                  Principe : on ENREGISTRE des events serveur « appâts » aux noms très
                  tentants (admin:giveMoney, god:enable, anticheat:disable…). AUCUN flux
                  client légitime ne déclenche ces events — seul un menu/dumper qui sonde
                  ou spamme les events du serveur va tomber dessus. Un déclenchement =
                  tricheur CONFIRMÉ (incident critique). Zéro dépendance à un nom de cheat.

                  Complément honnête : ça n'attrape pas un cheat discret qui n'énumère pas ;
                  mais ça coince les menus « recovery »/troll qui pulvérisent les events, et
                  ça ne coûte rien en faux positifs (les noms n'existent nulle part ailleurs).

    Module semi-pur : onTrigger() est pur/testable ; register() fait le câblage FiveM.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Honeypot.onTrigger(source, name) -> incident spec
                  ZShield.Honeypot.register()   -- enregistre les events appâts (FiveM)
                  ZShield.Honeypot.defaults()   -- liste par défaut des appâts
]]

ZShield = ZShield or {}
local C = ZShield.Const

local HP = {}

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

-- Appâts par défaut : noms très tentants pour un menu, qu'AUCUN serveur bien conçu
-- n'expose comme event client->serveur. L'opérateur peut compléter/retirer via config.
function HP.defaults()
    return {
        'admin:giveMoney', 'adminmenu:giveall', 'esx_admin:giveMoney',
        'qb-admin:giveMoney', 'god:enable', 'godmode:enable',
        'anticheat:disable', 'ac:disable', 'zshield:disable',
        'admin:setgroup', 'esx:setAdmin', 'giveall:weapons',
    }
end

--- Construit l'incident CRITIQUE d'un déclenchement d'appât (tricheur confirmé).
function HP.onTrigger(source, name)
    return {
        source = source,
        detector = 'honeypot',
        category = C.CATEGORY.RESOURCE,
        severity = (C.SEVERITY and C.SEVERITY.CRITICAL) or 'CRITICAL',
        confidence = 0.99,
        risk_after = 100,
        occurrences = 2,            -- confirmé : pas d'observation préalable nécessaire
        protection = 'nw_injection_traces',
        instant_ban = true,
        reason = string.format('event-appât déclenché par un client (« %s ») — tricheur confirmé', tostring(name)),
        metadata = { event = name, kind = 'honeypot' },
    }
end

--- Enregistre les events appâts (FiveM uniquement). Tout déclenchement ouvre un incident.
function HP.register()
    if cfg('honeypot.enabled', true) ~= true then return end
    if type(RegisterNetEvent) ~= 'function' or type(AddEventHandler) ~= 'function' then return end
    local list = cfg('honeypot.events', nil)
    if type(list) ~= 'table' or #list == 0 then list = HP.defaults() end
    for _, name in ipairs(list) do
        if type(name) == 'string' and name ~= '' then
            pcall(RegisterNetEvent, name)
            AddEventHandler(name, function()
                local src = source
                if not src or src == 0 then return end
                local sig = HP.onTrigger(src, name)
                if ZShield.Incident and ZShield.Incident.open then
                    pcall(ZShield.Incident.open, sig)
                elseif ZShield.RouteSignal then
                    pcall(ZShield.RouteSignal, sig)
                end
                if ZShield.Log then
                    ZShield.Log:security('honeypot', 'appât déclenché', { source = src, event = name })
                end
            end)
        end
    end
    if ZShield.Log then ZShield.Log:info('honeypot', 'events appâts enregistrés', { count = #list }) end
end

ZShield.Honeypot = HP
return HP
