--[[
    FILE:         server/detection/correlation.lua
    PURPOSE:      Moteur de corrélation (§12). Mémoire temporelle des signaux par joueur.
                  Reconnaît qu'une séquence de signaux dans une fenêtre est corrélée — mais
                  corrélation ≠ preuve (§12). Conserve l'explication de chaque décision.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua, core/bus
    PUBLIC API:   ZShield.Correlation.record(signal)
                  ZShield.Correlation.window(source, ms) -> array de signaux récents
                  ZShield.Correlation.correlate(source) -> { correlated, signals, categories, span }
                  ZShield.Correlation.prune(source), ZShield.Correlation.clear(source)

    §12 : T+0 event anomaly, T+2 entity anomaly, T+4 movement anomaly, T+5 state
    inconsistency → le moteur reconnaît la corrélation temporelle, MAIS ne la transforme pas
    automatiquement en preuve. Il fournit au risk engine un contexte enrichi et explicable.

    La mémoire est bornée par joueur (§14) : au-delà de MAX_SIGNALS, éviction du plus ancien.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log
local Bus = ZShield.Bus

local Correlation = { players = {} } -- source -> { signals = {}, }

-- Fenêtre de corrélation par défaut : signaux dans cet intervalle considérés liés.
local DEFAULT_WINDOW_MS = 6000

-- Nombre minimal de catégories DISTINCTES dans la fenêtre pour parler de corrélation
-- multi-signaux. Un seul détecteur qui répète n'est pas une corrélation : c'est une
-- répétition (traitée par la déduplication d'incident, §102).
local MIN_DISTINCT_CATEGORIES = 2

local function store(source)
    local s = Correlation.players[source]
    if not s then s = { signals = {} }; Correlation.players[source] = s end
    return s
end

--- Enregistre un signal dans la mémoire temporelle du joueur. Appelé via abonnement au
--- bus 'detection.signal'.
function Correlation.record(signal)
    if not signal or signal.source == nil then return end
    local s = store(signal.source)
    s.signals[#s.signals + 1] = signal

    -- Borne la mémoire (§14) : éviction du plus ancien au-delà du plafond.
    while #s.signals > C.LIMITS.MAX_SIGNALS_PER_PLAYER do
        table.remove(s.signals, 1)
    end
end

--- Retire les signaux plus vieux que MAX_SIGNAL_AGE_MS (§14). Un signal ne vit pas
--- éternellement.
function Correlation.prune(source, now)
    local s = Correlation.players[source]
    if not s then return 0 end
    now = now or Util.now()
    local cutoff = now - C.LIMITS.MAX_SIGNAL_AGE_MS
    local kept, removed = {}, 0
    for i = 1, #s.signals do
        if s.signals[i].at >= cutoff then kept[#kept + 1] = s.signals[i] else removed = removed + 1 end
    end
    s.signals = kept
    return removed
end

--- Signaux du joueur dans les `ms` dernières millisecondes.
function Correlation.window(source, ms)
    local s = Correlation.players[source]
    if not s then return {} end
    ms = ms or DEFAULT_WINDOW_MS
    local cutoff = Util.now() - ms
    local out = {}
    for i = 1, #s.signals do
        if s.signals[i].at >= cutoff then out[#out + 1] = s.signals[i] end
    end
    return out
end

--- Analyse de corrélation pour un joueur. Retourne un objet EXPLICABLE (§12) :
--- {
---   correlated = boolean,     -- plusieurs catégories distinctes dans la fenêtre ?
---   signal_count = n,
---   categories = { 'movement', 'entity' },
---   distinct_categories = 2,
---   span_ms = 4000,           -- étendue temporelle des signaux
---   combined_score = 42.5,    -- somme des scores (borné plus loin par le risk engine)
---   max_severity = 'HIGH',
---   signals = { ... }         -- pour la chaîne de preuve (§29)
--- }
function Correlation.correlate(source, windowMs)
    Correlation.prune(source)
    local signals = Correlation.window(source, windowMs or DEFAULT_WINDOW_MS)

    local result = {
        correlated = false,
        signal_count = #signals,
        categories = {},
        distinct_categories = 0,
        span_ms = 0,
        combined_score = 0,
        max_severity = nil,
        signals = signals,
    }
    if #signals == 0 then return result end

    local catSet, first, last = {}, signals[1].at, signals[1].at
    local maxSevIdx = 0
    for i = 1, #signals do
        local sig = signals[i]
        catSet[sig.category or 'unknown'] = true
        result.combined_score = result.combined_score + sig.score
        if sig.at < first then first = sig.at end
        if sig.at > last then last = sig.at end
        -- Gravité max (index dans SEVERITY_ORDER).
        for idx = 1, #C.SEVERITY_ORDER do
            if C.SEVERITY_ORDER[idx] == sig.severity and idx > maxSevIdx then maxSevIdx = idx end
        end
    end

    for cat in pairs(catSet) do result.categories[#result.categories + 1] = cat end
    table.sort(result.categories)
    result.distinct_categories = #result.categories
    result.span_ms = last - first
    result.max_severity = maxSevIdx > 0 and C.SEVERITY_ORDER[maxSevIdx] or nil

    -- Corrélation reconnue si plusieurs CATÉGORIES distinctes dans la fenêtre.
    -- Explicitement : ce n'est PAS une preuve (§12), juste un contexte pour le risque.
    result.correlated = result.distinct_categories >= MIN_DISTINCT_CATEGORIES

    if result.correlated then
        Log:security('correlation', 'multi-signal correlation observed', {
            source = source,
            categories = result.categories,
            span_ms = result.span_ms,
            note = 'correlation is context, not proof',
        })
    end

    return result
end

function Correlation.clear(source)
    Correlation.players[source] = nil
end

function Correlation.count(source)
    local s = Correlation.players[source]
    return s and #s.signals or 0
end

-- S'abonne au bus pour enregistrer automatiquement les signaux émis par la détection.
function Correlation.attach()
    Bus:on('detection.signal', function(signal)
        Correlation.record(signal)
    end)
end

ZShield.Correlation = Correlation
