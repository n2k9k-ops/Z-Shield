--[[
    FILE:         server/detection/teleport.lua
    PURPOSE:      ANTI-TÉLÉPORT « MENU » (récurrent). Le blink ponctuel est traité par flight ;
                  ici on vise le MOTIF d'un menu de triche : des téléports LONGUE DISTANCE
                  RÉPÉTÉS (TP vers waypoint, TP entre points d'intérêt). Un lag isolé produit un
                  saut ; un menu en produit plusieurs. On compte les grands sauts non-fiables sur
                  une fenêtre : au-delà d'un nombre, c'est un usage de téléportation.

    100 % serveur : positions rapportées ; les téléports de confiance déclenchés par le serveur
    (opts.trusted) sont exclus.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Teleport.observe(source, jump) -> signal|nil
                  ZShield.Teleport.forget(source) / .register()

    jump = { jump_m = number, trusted = bool, now = ms }
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local TP = {}
TP._j = {}   -- source -> { timestamps des grands sauts }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

function TP.observe(source, jump)
    if cfg('teleport.enabled', false) ~= true then return nil end
    if type(jump) ~= 'table' then return nil end
    if jump.trusted == true then return nil end
    local d = tonumber(jump.jump_m) or 0
    local minJump = tonumber(cfg('teleport.min_jump_m', 100)) or 100
    if d < minJump then return nil end
    local now = tonumber(jump.now) or Util.now()
    local windowMs = tonumber(cfg('teleport.window_ms', 30000)) or 30000
    local minRepeats = tonumber(cfg('teleport.min_repeats', 3)) or 3

    local list = TP._j[source] or {}
    local kept = {}
    for _, t in ipairs(list) do if (now - t) <= windowMs then kept[#kept + 1] = t end end
    kept[#kept + 1] = now
    TP._j[source] = kept

    if #kept >= minRepeats then
        return {
            detector = 'teleport', category = C.CATEGORY.MOVEMENT,
            severity = C.SEVERITY.HIGH, confidence = 0.6,
            reason = string.format('%d téléports longue distance (>%.0f m) en %.0f s — menu de TP',
                #kept, minJump, windowMs / 1000),
            source = source, metadata = { jumps = #kept, min_jump = minJump, kind = 'teleport_menu' },
        }
    end
    return nil
end

function TP.forget(source) TP._j[source] = nil end

function TP.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'teleport', category = C.CATEGORY.MOVEMENT,
            evaluate = function() return {} end })
    end
end

ZShield.Teleport = TP
return TP
