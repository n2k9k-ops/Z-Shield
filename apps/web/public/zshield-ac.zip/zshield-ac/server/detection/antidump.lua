--[[
    FILE:         server/detection/antidump.lua
    PURPOSE:      ANTI SERVER-DUMPER (vol de fichiers / de ressources serveur). Un
                  « dumper » sonde le serveur pour aspirer sa logique : il ÉNUMÈRE en
                  rafale les events serveur (il a scanné les .lua client à la recherche
                  de tout `TriggerServerEvent`) et déclenche en masse des events, dont
                  beaucoup INCONNUS (events fantômes), pour cartographier/aspirer le serveur.

                  Un client honnête déclenche peu d'events DISTINCTS dans une courte
                  fenêtre. Un dumper en déclenche beaucoup, et un fort taux d'INCONNUS.
                  On mesure donc, PAR JOUEUR et PAR FENÊTRE :
                    - le nombre d'events DISTINCTS,
                    - le nombre d'events INCONNUS (non enregistrés au pare-feu).
                  Au-delà des seuils -> signal de « dump » (routé en trace d'injection).

    Module PUR (aucune I/O, aucune native) : le pare-feu l'alimente à chaque event
    entrant (Firewall.dispatch) et route la conséquence. Testable hors FiveM.

    DEPENDENCIES: core/config.lua (optionnel)
    PUBLIC API:   ZShield.AntiDump.observe(source, name, now, isUnknown)
                      -> { dumping, distinct, unknown }
                  ZShield.AntiDump.reset(source)
                  ZShield.AntiDump.resetAll()
]]

ZShield = ZShield or {}

local AntiDump = { _ctx = {} }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function ctxOf(source)
    local c = AntiDump._ctx[source]
    if not c then
        c = { start = nil, names = {}, distinct = 0, unknown = 0, flagged = false }
        AntiDump._ctx[source] = c
    end
    return c
end

--- Observe un event entrant. `isUnknown` = vrai si l'event n'est pas enregistré
--- (event fantôme, typique du sondage/dump). Retourne l'état d'énumération.
function AntiDump.observe(source, name, now, isUnknown)
    if cfg('antidump.enabled', true) ~= true then return { dumping = false, distinct = 0, unknown = 0 } end
    if source == nil or source == 0 or type(name) ~= 'string' then
        return { dumping = false, distinct = 0, unknown = 0 }
    end
    now = tonumber(now) or 0
    local window = tonumber(cfg('antidump.window_ms', 8000)) or 8000
    local maxDistinct = tonumber(cfg('antidump.max_distinct', 25)) or 25
    local maxUnknown = tonumber(cfg('antidump.max_unknown', 8)) or 8

    local c = ctxOf(source)
    -- (Re)démarre la fenêtre glissante si elle est écoulée (ou au premier event).
    if c.start == nil or (now - c.start) > window then
        c.start = now
        c.names = {}
        c.distinct = 0
        c.unknown = 0
        c.flagged = false
    end

    if not c.names[name] then
        c.names[name] = true
        c.distinct = c.distinct + 1
    end
    if isUnknown == true then
        c.unknown = c.unknown + 1
    end

    local dumping = (c.distinct >= maxDistinct) or (c.unknown >= maxUnknown)
    -- Un seul signal par fenêtre : on ne spamme pas la trace pendant la rafale.
    local firstTime = dumping and not c.flagged
    if dumping then c.flagged = true end

    return { dumping = firstTime, distinct = c.distinct, unknown = c.unknown }
end

function AntiDump.reset(source) AntiDump._ctx[source] = nil end
function AntiDump.resetAll() AntiDump._ctx = {} end

ZShield.AntiDump = AntiDump
return AntiDump
