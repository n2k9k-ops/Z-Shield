--[[
    FILE:         server/detection/weapon.lua
    PURPOSE:      Détecteur d'arme serveur-autoritatif, alimenté par weaponDamageEvent
                  (§08). Complète le pare-feu game events (qui borne le dégât dur et
                  annule à la source) par des signaux COMPORTEMENTAUX que seul le suivi
                  dans le temps révèle :
                    - cadence de tir soutenue anormale (wp_fire_rate / wp_shots_impossible) ;
                    - dégâts incompatibles avec l'arme utilisée (wp_damage_fake) ;
                    - indice statistique de tir instantanément létal répété (ai_precision),
                      émis en confiance FAIBLE (à corréler, jamais sanction seule).
    DEPENDENCIES: shared/constants.lua, core/log.lua, core/config.lua
    PUBLIC API:   ZShield.Weapon.observe(sender, data, now)  -- pur/testable, horloge injectée
                  ZShield.Weapon.forget(sender)
                  ZShield.Weapon.register()                  -- branche sur le bus de détection

    Champs weaponDamageEvent utilisés (docs.fivem.net) : weaponType (hash de l'arme),
    weaponDamage + overrideDefaultDamage (dégât custom), willKill (coup instantanément
    létal), hitGlobalId (cible). Le serveur ne connaît pas toute la balistique ; on ne
    s'appuie que sur des bornes et des cadences serveur-vérifiables (§26 : jamais un
    signal client seul ne bannit — ici on ÉMET, la corrélation décide).
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Log = ZShield.Log

local Weapon = {}

Weapon._ctx = {}   -- sender -> { shots = { ts... }, kills = 0, total = 0 }

-- Fenêtre de cadence (ms) et plafond par défaut. 25 tirs/s est déjà au-delà de toute
-- arme automatique légitime ; on reste prudent pour éviter les faux positifs de lag.
local FIRE_WINDOW_MS = 1000

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

-- Table indicative hash d'arme -> dégât de base plausible (borne haute). Étendue par
-- config (game_events.weapon_base). Absente = on retombe sur le plafond global. Les
-- valeurs sont des bornes hautes tolérantes, pas des dégâts exacts.
local DEFAULT_WEAPON_MAX = {
    -- Pistolets
    [453432689]  = 40,   -- WEAPON_PISTOL
    [1593441988] = 45,   -- WEAPON_COMBATPISTOL
    -- SMG / fusils
    [736523883]  = 45,   -- WEAPON_SMG
    [-1074790547] = 55,  -- WEAPON_ASSAULTRIFLE
    [-1357824103] = 55,  -- WEAPON_CARBINERIFLE
    -- Fusils à pompe
    [487013001]  = 90,   -- WEAPON_PUMPSHOTGUN
    -- Sniper
    [100416529]  = 101,  -- WEAPON_SNIPERRIFLE
    [205991906]  = 216,  -- WEAPON_HEAVYSNIPER
}

local function weaponMax(hash)
    -- Armes add-on déclarées par l'opérateur (« Add-On Weapons ») : { [hash]=dégât_base }.
    -- Permet de BORNER une arme custom (sinon inconnue, donc non contrôlée en dégât)
    -- sans la prendre pour une triche. Fusionné avec les overrides weapon_base.
    local addon = cfg('game_events.addon_weapons', nil)
    if type(addon) == 'table' and addon[hash] then return tonumber(addon[hash]) end
    local overrides = cfg('game_events.weapon_base', nil)
    if type(overrides) == 'table' and overrides[hash] then return tonumber(overrides[hash]) end
    return DEFAULT_WEAPON_MAX[hash]
end

local function ctxOf(sender)
    local c = Weapon._ctx[sender]
    if not c then c = { shots = {}, kills = 0, total = 0 }; Weapon._ctx[sender] = c end
    return c
end

--- Observe un event de dégât d'arme. `now` en millisecondes (injecté pour les tests).
--- Retourne un signal { severity, confidence, reason, category, source, protection } ou nil.
function Weapon.observe(sender, data, now)
    if not sender then return nil end
    data = data or {}
    now = now or 0
    if not cfg('game_events.weapon_detector', true) then return nil end

    local c = ctxOf(sender)
    c.total = c.total + 1
    if data.willKill then c.kills = c.kills + 1 end

    -- --- Cadence de tir soutenue ---
    local shots = c.shots
    local cutoff = now - FIRE_WINDOW_MS
    -- Purge des tirs hors fenêtre (les timestamps sont croissants).
    local i = 1
    while shots[i] and shots[i] < cutoff do i = i + 1 end
    if i > 1 then
        local kept = {}
        for j = i, #shots do kept[#kept + 1] = shots[j] end
        c.shots = kept
        shots = kept
    end
    shots[#shots + 1] = now

    local maxRate = tonumber(cfg('game_events.max_shots_per_sec', 25)) or 25
    local count = #shots

    local best = nil
    local function consider(sig)
        if sig and (not best or sig.confidence > best.confidence) then best = sig end
    end

    if count > maxRate then
        -- Confiance qui monte avec le dépassement : un pic ponctuel pèse peu.
        local over = count - maxRate
        consider({
            severity = C.SEVERITY.HIGH,
            confidence = math.min(0.45 + over * 0.05, 0.9),
            reason = string.format('sustained fire rate %d/s over cap %d', count, maxRate),
            protection = count > maxRate * 2 and 'wp_shots_impossible' or 'wp_fire_rate',
        })
    end

    -- --- Dégâts incompatibles avec l'arme ---
    local dmg = tonumber(data.weaponDamage) or 0
    local hash = tonumber(data.weaponType)
    if data.overrideDefaultDamage and hash and dmg > 0 then
        local wmax = weaponMax(hash)
        if wmax and dmg > wmax * 1.5 then
            consider({
                severity = C.SEVERITY.HIGH,
                confidence = 0.8,
                reason = string.format('damage %d implausible for weapon (max ~%d)', dmg, wmax),
                protection = 'wp_damage_fake',
            })
        end
    end

    -- --- Silent aim / changement de cible : toucher plusieurs cibles DIFFÉRENTES en
    -- une fraction de seconde est humainement impossible (indice, faible confiance). ---
    if data.hitGlobalId then
        c.victims = c.victims or {}
        local vcut = now - 700
        local kept, seen = {}, {}
        for _, e in ipairs(c.victims) do if e.at >= vcut then kept[#kept + 1] = e end end
        kept[#kept + 1] = { id = tostring(data.hitGlobalId), at = now }
        c.victims = kept
        for _, e in ipairs(kept) do seen[e.id] = true end
        local distinct = 0
        for _ in pairs(seen) do distinct = distinct + 1 end
        if distinct >= tonumber(cfg('game_events.silent_aim_victims', 4)) then
            consider({
                severity = C.SEVERITY.MEDIUM, confidence = 0.4,
                reason = string.format('%d distinct victims in <0.7s (silent aim / target switch)', distinct),
                protection = 'ai_target_switch',
            })
        end
    end

    -- --- Indice statistique : ratio de coups instantanément létaux ---
    -- Faible confiance, à corréler : jamais une sanction seule (§26). Sur volume suffisant.
    if c.total >= 12 then
        local ratio = c.kills / c.total
        if ratio > 0.85 then
            consider({
                severity = C.SEVERITY.MEDIUM,
                confidence = 0.35,
                reason = string.format('instant-lethal ratio %.0f%% over %d hits', ratio * 100, c.total),
                protection = 'ai_precision',
            })
        end
    end

    if not best then return nil end
    best.category = C.CATEGORY.DAMAGE
    best.source = sender
    return best
end

--- Oublie l'état d'un joueur (déconnexion). Borne la mémoire.
function Weapon.forget(sender)
    Weapon._ctx[sender] = nil
end

--- Branche sur le bus de détection : émet le signal quand un event de dégât survient.
--- La télémétrie/runtime appelle Weapon.observe via le pare-feu game events (voir attach).
function Weapon.emit(sender, data, now)
    local sig = Weapon.observe(sender, data, now)
    if sig and ZShield.Detection then
        ZShield.Detection.emit({
            detector = 'weapon.behaviour',
            category = sig.category,
            severity = sig.severity,
            confidence = sig.confidence,
            reason = sig.reason,
            source = sig.source,
            protection = sig.protection,
            metadata = { protection = sig.protection },
        })
    end
    return sig
end

ZShield.Weapon = Weapon
return Weapon
