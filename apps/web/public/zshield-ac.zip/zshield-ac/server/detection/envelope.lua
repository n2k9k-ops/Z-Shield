--[[
    FILE:         server/detection/envelope.lua
    PURPOSE:      ENVELOPPES DE DÉBIT UNIVERSELLES. Un seul moteur qui impose un PLAFOND DE
                  CADENCE à CHAQUE classe d'événement (tir, spawn, message, achat, dégât,
                  interaction, statebag, …). Peu importe la triche, si elle génère des events
                  au-delà d'un débit humainement/légitimement possible, l'enveloppe la borne à
                  la source. C'est générique : ajouter une classe protégée = une ligne de config,
                  d'où un nombre de protections extensible sans nouvelle logique.

                  Coriace : c'est une borne dure côté serveur ; un client modifié ne peut pas
                  « demander » plus que son quota — les events au-delà sont simplement ignorés.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Envelope.observe(source, class, now) -> { over, signal }|nil
                  ZShield.Envelope.forget(source) / .register()

    Config `envelope.quotas` = { [class] = maxParFenetre }, `envelope.window_ms`, `envelope.default_quota`.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local EV = {}
EV._w = {}   -- source -> { [class] = { ts... } }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

-- Quotas par défaut, par fenêtre (10 s par défaut). Opérateur-éditables.
local DEFAULT_QUOTAS = {
    fire = 120, spawn_entity = 20, chat = 8, command = 20, purchase = 15,
    damage = 150, interact = 40, statebag = 60, weapon_switch = 30, explosion = 12,
}

function EV.observe(source, class, now)
    if cfg('envelope.enabled', false) ~= true then return nil end
    if type(class) ~= 'string' then return nil end
    now = tonumber(now) or Util.now()
    local windowMs = tonumber(cfg('envelope.window_ms', 10000)) or 10000

    local quotas = cfg('envelope.quotas', nil)
    local quota = (type(quotas) == 'table' and tonumber(quotas[class]))
        or DEFAULT_QUOTAS[class] or tonumber(cfg('envelope.default_quota', 60)) or 60

    local perSrc = EV._w[source]; if not perSrc then perSrc = {}; EV._w[source] = perSrc end
    local list = perSrc[class] or {}
    local kept = {}
    for _, t in ipairs(list) do if (now - t) <= windowMs then kept[#kept + 1] = t end end
    kept[#kept + 1] = now
    perSrc[class] = kept

    if #kept > quota then
        return {
            over = true,
            signal = {
                detector = 'envelope', category = C.CATEGORY.EVENT,
                severity = C.SEVERITY.MEDIUM, confidence = 0.6,
                reason = string.format('classe « %s » : %d events > quota %d en %.0f s (bridé)',
                    class, #kept, quota, windowMs / 1000),
                source = source, metadata = { class = class, count = #kept, quota = quota, kind = 'envelope' },
            },
        }
    end
    return nil
end

function EV.forget(source) EV._w[source] = nil end

function EV.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'envelope', category = C.CATEGORY.EVENT,
            evaluate = function() return {} end })
    end
end

ZShield.Envelope = EV
return EV
