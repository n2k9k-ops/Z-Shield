--[[
    FILE:         server/detection/health.lua
    PURPOSE:      Détecteur d'état joueur serveur-autoritatif (§19 intégrité d'état).
                  Alimenté par la télémétrie (vie/armure du joueur observées serveur).
                  Détecte ce que seul le suivi dans le temps révèle :
                    - vie au-dessus du maximum (pl_health_over_max) ;
                    - armure anormale (pl_armor) ;
                    - régénération instantanée/répétée (pl_regen) ;
                    - invincibilité : dégâts subis mais vie inchangée (pl_invincible).
    DEPENDENCIES: shared/constants.lua, core/log.lua, core/config.lua
    PUBLIC API:   ZShield.Health2.observe(source, sample, now)  -- pur/testable
                  ZShield.Health2.forget(source)
                  ZShield.Health2.register()                     -- bus de détection

    §26 : on ÉMET des signaux ; la corrélation et l'enforcement décident. Les bornes
    (vie/armure au-delà du max) sont HAUTE confiance ; l'invincibilité et la régénération
    montent en confiance avec la RÉPÉTITION, jamais sur une observation isolée.

    NB : nommé Health2 pour ne pas entrer en collision avec ZShield.Health (santé des
    composants internes, §50).
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Log = ZShield.Log

local H = {}
H._ctx = {}   -- source -> { last, last_at, regen_streak, invin_streak, dmg_accum }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function ctxOf(source)
    local c = H._ctx[source]
    if not c then
        c = { last = nil, last_at = 0, regen_streak = 0, invin_streak = 0, dmg_accum = 0 }
        H._ctx[source] = c
    end
    return c
end

--- Observe un échantillon d'état. `sample` : { health, armor, max_health, expected_damage }.
--- `expected_damage` = dégâts cumulés que le joueur AURAIT dû subir depuis la dernière
--- observation (issus du game event firewall). `now` en ms (injecté pour les tests).
function H.observe(source, sample, now)
    if not source then return nil end
    sample = sample or {}
    now = now or 0
    if not cfg('health.detector', true) then return nil end

    local c = ctxOf(source)
    local health = tonumber(sample.health)
    local armor = tonumber(sample.armor)
    local maxHealth = tonumber(sample.max_health) or cfg('health.max_health', 200)
    local maxArmor = cfg('health.max_armor', 100)

    local best = nil
    local function consider(sig)
        if sig and (not best or sig.confidence > best.confidence) then best = sig end
    end

    -- Bornes dures : impossibles légitimement.
    if health and health > maxHealth + 1 then
        consider({ severity = C.SEVERITY.HIGH, confidence = 0.9,
            reason = string.format('health %d over max %d', health, maxHealth),
            protection = 'pl_health_over_max' })
    end
    if armor and armor > maxArmor + 1 then
        consider({ severity = C.SEVERITY.HIGH, confidence = 0.85,
            reason = string.format('armor %d over max %d', armor, maxArmor),
            protection = 'pl_armor' })
    end

    -- Régénération : des remontées de vie fortes et rapprochées (soin instantané répété).
    -- On COMPTE les bonds vers le haut ; les baisses (dégâts) ne remettent pas le compteur
    -- à zéro — c'est justement le motif « dégât puis re-full instantané » qu'on veut voir.
    -- Un simple soin isolé n'atteint pas le seuil ; on repart de zéro après un long calme.
    -- Réanimation légitime : si l'échantillon indique l'événement de revive déclaré
    -- par l'opérateur (« Revive Event Name »), la remontée de vie est normale.
    local reviveEvent = cfg('health.revive_event', nil)
    local isRevive = sample.revive == true
        or (reviveEvent and sample.event ~= nil and sample.event == reviveEvent)

    if health and c.last and not isRevive then
        local gain = health - c.last
        local regenGate = cfg('health.regen_gain', 40)
        if gain >= regenGate then
            if (now - (c.regen_at or 0)) > cfg('health.regen_reset_ms', 4000) then
                c.regen_streak = 1
            else
                c.regen_streak = c.regen_streak + 1
            end
            c.regen_at = now
            if c.regen_streak >= 2 then
                consider({ severity = C.SEVERITY.MEDIUM,
                    confidence = math.min(0.4 + c.regen_streak * 0.12, 0.85),
                    reason = string.format('instant regen +%d (x%d)', gain, c.regen_streak),
                    protection = 'pl_regen' })
            end
        end
    end

    -- Invincibilité : des dégâts auraient dû s'appliquer mais la vie ne baisse pas.
    if sample.expected_damage and sample.expected_damage > 0 then
        c.dmg_accum = c.dmg_accum + sample.expected_damage
    end
    if health and c.last then
        local drop = c.last - health
        if c.dmg_accum >= cfg('health.invin_damage', 30) and drop < c.dmg_accum * 0.25 then
            c.invin_streak = c.invin_streak + 1
            if c.invin_streak >= 2 then
                consider({ severity = C.SEVERITY.HIGH,
                    confidence = math.min(0.5 + c.invin_streak * 0.12, 0.9),
                    reason = string.format('took ~%d damage, health unchanged (x%d)', c.dmg_accum, c.invin_streak),
                    protection = 'pl_invincible' })
            end
            c.dmg_accum = 0
        elseif drop >= c.dmg_accum * 0.5 then
            c.invin_streak = 0
            c.dmg_accum = 0
        end
    end

    if health then c.last = health; c.last_at = now end

    if not best then return nil end
    best.category = C.CATEGORY.STATE
    best.source = source
    return best
end

function H.forget(source) H._ctx[source] = nil end

function H.register()
    if not ZShield.Detection then return false, 'detection engine not loaded' end
    return ZShield.Detection.register({
        id = 'health.state',
        category = C.CATEGORY.STATE,
        version = 1,
        evaluate = function(evalCtx)
            if not evalCtx.health then return nil end
            local s = evalCtx.health
            return H.observe(s.source, s, s.now or 0)
        end,
    })
end

ZShield.Health2 = H
return H
