--[[
    FILE:         server/detection/engine.lua
    PURPOSE:      Moteur de détection (§10, §11). Registre de détecteurs à interface
                  uniforme. Chaque détecteur produit un SIGNAL qui sépare strictement trois
                  axes : severity, confidence, score. C'est la défense n°1 contre les faux
                  positifs (§11, threat model T13).
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua, core/bus (util)
    PUBLIC API:   ZShield.Detection.register(detector) -> ok, err
                  ZShield.Detection.evaluate(context) -> array de signaux
                  ZShield.Detection.emit(signal)  (émet un signal externe, ex: firewall)
                  ZShield.Detection.list() / stats()

    §11 : severity (gravité intrinsèque) ≠ confidence (certitude) ≠ risk (conséquence).
    Une anomalie HIGH mais confidence 0.2 ne doit PAS déclencher de sanction. Le moteur
    calcule un score pondéré = poids(severity) × confidence, mais ne décide RIEN : il
    émet des signaux sur le bus, le risk engine décide (§13).

    §104 : un détecteur qui lève est marqué dégradé, les autres continuent.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log
local Bus = ZShield.Bus

local Detection = {
    detectors = {},          -- id -> detector
    order = {},              -- ordre stable d'évaluation
    stats = { evaluated = 0, signals = 0, detector_errors = 0 },
    health = {},             -- id -> HEALTHY | DEGRADED
}

-- Interface d'un détecteur (§10) :
-- {
--   id = 'movement.teleport',
--   category = C.CATEGORY.MOVEMENT,
--   version = 1,
--   enabled = true,          -- optionnel, défaut true
--   evaluate = function(context) return signalOrNil end
-- }
--
-- Retour de evaluate : nil (rien), ou un signal partiel :
-- { severity = 'HIGH', confidence = 0.9, reason = '...', metadata = {} }
-- Le moteur complète id/category/score/timestamp.

--- Normalise et valide un signal produit par un détecteur.
local function normalizeSignal(detector, raw)
    if type(raw) ~= 'table' then return nil end

    local severity = raw.severity
    if not C.SEVERITY[severity] then
        Log:warn('detection', 'detector produced invalid severity', {
            detector = detector.id, severity = tostring(severity) })
        return nil
    end

    -- confidence bornée [0,1]. Un détecteur qui ne la fournit pas est traité comme
    -- incertain (0.5), jamais comme certain : on ne présume pas la culpabilité.
    local confidence = Util.clamp(tonumber(raw.confidence) or 0.5, 0, 1)

    -- Score = poids de gravité × confiance. C'est la SEULE combinaison des deux axes,
    -- et elle reste bornée. severity et confidence restent disponibles séparément.
    local score = C.SEVERITY_WEIGHT[severity] * confidence

    return {
        detector = detector.id,
        category = detector.category,
        version = detector.version or 1,
        severity = severity,
        confidence = confidence,
        score = score,
        reason = tostring(raw.reason or ''),
        metadata = raw.metadata or {},
        source = raw.source,       -- joueur concerné (peut être nil pour signal serveur)
        scope = raw.scope or C.ANOMALY_SCOPE.PLAYER, -- §99
        at = Util.now(),
    }
end

function Detection.register(detector)
    if type(detector) ~= 'table' or type(detector.id) ~= 'string' then
        return false, 'detector requires an id'
    end
    if type(detector.evaluate) ~= 'function' then
        return false, 'detector requires an evaluate function'
    end
    if Detection.detectors[detector.id] then
        return false, 'detector already registered: ' .. detector.id
    end
    if detector.category and not _validCategory(detector.category) then
        return false, 'unknown category: ' .. tostring(detector.category)
    end

    detector.enabled = detector.enabled ~= false
    detector.version = detector.version or 1
    Detection.detectors[detector.id] = detector
    Detection.order[#Detection.order + 1] = detector.id
    Detection.health[detector.id] = C.HEALTH.HEALTHY
    Log:debug('detection', 'detector registered', { id = detector.id, category = detector.category })
    return true
end

function _validCategory(cat)
    for _, v in pairs(C.CATEGORY) do if v == cat then return true end end
    return false
end

--- Évalue tous les détecteurs actifs contre un contexte. Retourne la liste des signaux.
--- Un détecteur qui lève est marqué DEGRADED et n'interrompt pas les autres (§104).
function Detection.evaluate(context)
    Detection.stats.evaluated = Detection.stats.evaluated + 1
    local signals = {}

    for i = 1, #Detection.order do
        local id = Detection.order[i]
        local detector = Detection.detectors[id]
        if detector and detector.enabled then
            local ok, result = pcall(detector.evaluate, context)
            if ok then
                if result ~= nil then
                    local sig = normalizeSignal(detector, result)
                    if sig then
                        signals[#signals + 1] = sig
                        Detection.stats.signals = Detection.stats.signals + 1
                    end
                end
                -- Un détecteur qui réussit repasse HEALTHY (récupération, §104).
                if Detection.health[id] == C.HEALTH.DEGRADED then
                    Detection.health[id] = C.HEALTH.HEALTHY
                    Log:info('detection', 'detector recovered', { id = id })
                end
            else
                Detection.health[id] = C.HEALTH.DEGRADED
                Detection.stats.detector_errors = Detection.stats.detector_errors + 1
                Log:error('detection', 'detector threw, marked degraded', {
                    id = id, err = tostring(result) })
            end
        end
    end

    -- Émettre chaque signal sur le bus pour la corrélation et le risque.
    for _, sig in ipairs(signals) do
        Bus:emit('detection.signal', sig)
    end
    return signals
end

--- Émet un signal produit AILLEURS que par un détecteur (ex: verdict du firewall converti
--- en signal). Passe par la même normalisation et le même bus.
function Detection.emit(raw)
    local pseudo = { id = raw.detector or 'external', category = raw.category, version = raw.version }
    local sig = normalizeSignal(pseudo, raw)
    if sig then
        Detection.stats.signals = Detection.stats.signals + 1
        Bus:emit('detection.signal', sig)
    end
    return sig
end

function Detection.setEnabled(id, enabled)
    local d = Detection.detectors[id]
    if not d then return false end
    d.enabled = enabled and true or false
    return true
end

function Detection.list()
    local out = {}
    for _, id in ipairs(Detection.order) do
        local d = Detection.detectors[id]
        out[#out + 1] = { id = id, category = d.category, version = d.version,
                          enabled = d.enabled, health = Detection.health[id] }
    end
    return out
end

function Detection.getStats()
    return Util.deepCopy(Detection.stats)
end

ZShield.Detection = Detection
