--[[
    FILE:         server/detection/selfprotect.lua
    PURPOSE:      AUTO-PROTECTION de l'anticheat et des ressources critiques :
                    - ANTI-STOP RESSOURCES : empêcher l'arrêt de ressources protégées (le cœur
                      AC, l'agent, le module client, + toute ressource déclarée par l'opérateur) ;
                    - ANTI-STOP ANTICHEAT : cas particulier — si le cœur AC s'arrête, c'est
                      OBSERVABLE (watchdog : plus de battement) et traité en incident grave ;
                    - ANTI-BYPASS : un client qui ÉMET un event interne de l'AC (préfixe réservé)
                      tente d'usurper/contourner le protocole -> signal fort.

    Module PUR : il DÉCIDE (block / signal) ; la couche glue FiveM applique (CancelEvent sur
    onResourceStopping, etc.). Le watchdog est vérifié par une boucle serveur/agent.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.SelfProtect.isProtected(resource) -> bool
                  ZShield.SelfProtect.observeResourceStop(resource, by) -> { block, signal }
                  ZShield.SelfProtect.observeInternalEventFromClient(source, eventName) -> signal|nil
                  ZShield.SelfProtect.ping(now) / .checkWatchdog(now) -> signal|nil
                  ZShield.SelfProtect.register()
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local SP = { _last_ping = nil }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local DEFAULT_PROTECTED = { ['zshield-ac'] = true, ['zshield-agent'] = true, ['zshield-client'] = true }

function SP.isProtected(resource)
    if type(resource) ~= 'string' then return false end
    if DEFAULT_PROTECTED[resource] then return true end
    local list = cfg('selfprotect.protected_resources', nil)
    if type(list) == 'table' then
        for _, r in ipairs(list) do if r == resource then return true end end
        if list[resource] == true then return true end
    end
    return false
end

-- Un arrêt est-il AUTORISÉ ? (console serveur / identité admin déclarée). `by` = identité
-- de l'appelant ; nil/"" = source non authentifiée -> refus pour une ressource protégée.
local function authorized(by)
    if by == nil or by == '' then return false end
    local admins = cfg('selfprotect.allow_stop_by', nil)
    if type(admins) == 'table' then
        for _, a in ipairs(admins) do if a == by then return true end end
    end
    return false
end

--- Décision sur une tentative d'arrêt de ressource. block=true => la glue annule l'event.
function SP.observeResourceStop(resource, by)
    if cfg('selfprotect.enabled', false) ~= true then return { block = false } end
    if not SP.isProtected(resource) then return { block = false } end
    if authorized(by) then return { block = false } end

    local isAC = resource == 'zshield-ac'
    return {
        block = true,
        signal = {
            detector = 'selfprotect',
            category = C.CATEGORY.RESOURCE,
            severity = isAC and C.SEVERITY.CRITICAL or C.SEVERITY.HIGH,
            confidence = 0.9,
            reason = string.format('tentative d%sarrêt de la ressource protégée « %s »%s',
                "'", resource, isAC and ' (anticheat)' or ''),
            source = by or 'inconnu',
            metadata = { resource = resource, kind = isAC and 'stop_anticheat' or 'stop_resource' },
        },
    }
end

--- Un client émet un event dont le nom commence par le préfixe interne réservé de l'AC :
--- personne d'autre que le serveur ne devrait le produire -> tentative de bypass.
function SP.observeInternalEventFromClient(source, eventName)
    if cfg('selfprotect.enabled', false) ~= true then return nil end
    if type(eventName) ~= 'string' then return nil end
    local prefix = cfg('selfprotect.internal_prefix', 'zshield:')
    -- Les events client LÉGITIMES du module (handshake/report/attest) sont explicitement
    -- exclus : ils font partie du protocole signé.
    local allowed = { ['zshield:cg:register'] = true, ['zshield:cg:report'] = true, ['zshield:cg:attest'] = true }
    if allowed[eventName] then return nil end
    if eventName:sub(1, #prefix) == prefix then
        return {
            detector = 'selfprotect', category = C.CATEGORY.RESOURCE,
            severity = C.SEVERITY.HIGH, confidence = 0.75,
            reason = 'event interne AC émis par un client (tentative de bypass)',
            source = source, metadata = { event = eventName, kind = 'bypass_internal_event' },
        }
    end
    return nil
end

--- Watchdog du cœur AC : le cœur bat régulièrement (ping). Si les battements cessent au-delà
--- du délai, le cœur a probablement été arrêté/neutralisé -> incident grave (vu par l'agent).
function SP.ping(now) SP._last_ping = tonumber(now) or Util.now() end

function SP.checkWatchdog(now)
    if cfg('selfprotect.enabled', false) ~= true then return nil end
    now = tonumber(now) or Util.now()
    if not SP._last_ping then return nil end
    local timeout = tonumber(cfg('selfprotect.watchdog_timeout_ms', 20000)) or 20000
    if (now - SP._last_ping) > timeout then
        return {
            detector = 'selfprotect', category = C.CATEGORY.RESOURCE,
            severity = C.SEVERITY.CRITICAL, confidence = 0.8,
            reason = 'le cœur anticheat ne bat plus (arrêt/neutralisation probable)',
            source = 0, metadata = { silent_ms = now - SP._last_ping, kind = 'anticheat_down' },
        }
    end
    return nil
end

function SP.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'selfprotect', category = C.CATEGORY.RESOURCE,
            evaluate = function() return {} end })
    end
end

ZShield.SelfProtect = SP
return SP
