--[[
    FILE:         server/detection/budget.lua
    PURPOSE:      BUDGETS SERVEUR — rend SERVEUR-AUTORITATIVES trois détections qui étaient
                  auparavant seulement corroborées côté client, par simple COMPTAGE d'events
                  que le serveur reçoit déjà :

                    - NO-RELOAD        : tirs continus au-delà de la capacité du chargeur SANS
                                         event de rechargement -> munitions/no-reload.
                    - STAMINA INFINIE  : sprint continu au-delà d'un budget d'endurance -> stamina hack.
                    - COMBAT-ROLL FLOOD: nombre de roulades de combat par fenêtre au-delà d'un
                                         plafond -> spam de roulade (infinite combat roll).

                  Aucune lecture client : ce sont des ACCUMULATEURS serveur. Une option
                  activée change le comportement (émet un vrai signal) : ces trois passent de
                  🔵 (corroboré) à 🟢 (impact serveur immédiat).

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Budget.shot(source, ev) -> signal|nil       -- no-reload
                  ZShield.Budget.reload(source, weapon)
                  ZShield.Budget.sprint(source, ev) -> signal|nil     -- stamina
                  ZShield.Budget.roll(source, now) -> signal|nil       -- combat roll
                  ZShield.Budget.forget(source) / .register()
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local B = {}
B._shots  = {}   -- source -> { [weapon] = count_since_reload }
B._sprint = {}   -- source -> sprint_start_ms | nil
B._rolls  = {}   -- source -> { timestamps... }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

--- NO-RELOAD : compte les tirs depuis le dernier reload. Au-delà de la capacité du
--- chargeur (+ marge), sans rechargement, c'est un no-reload / munitions infinies.
function B.shot(source, ev)
    if cfg('budget.no_reload_enabled', false) ~= true then return nil end
    if type(ev) ~= 'table' or ev.weapon == nil then return nil end
    local mags = cfg('budget.magazines', nil)
    local mag = (type(mags) == 'table' and tonumber(mags[ev.weapon]))
        or tonumber(ev.mag) or tonumber(cfg('budget.default_magazine', 30)) or 30
    local margin = tonumber(cfg('budget.reload_margin', 1)) or 1

    local per = B._shots[source]; if not per then per = {}; B._shots[source] = per end
    per[ev.weapon] = (per[ev.weapon] or 0) + 1
    if per[ev.weapon] > (mag + margin) then
        return {
            detector = 'budget', category = C.CATEGORY.DAMAGE,
            severity = C.SEVERITY.MEDIUM, confidence = 0.55,
            reason = string.format('%d tirs sans recharge (chargeur %d) — no-reload', per[ev.weapon], mag),
            source = source, metadata = { weapon = ev.weapon, shots = per[ev.weapon], mag = mag, kind = 'no_reload' },
        }
    end
    return nil
end

function B.reload(source, weapon)
    local per = B._shots[source]
    if per then per[weapon] = 0 end
end

--- STAMINA : sprint continu au-delà du budget. ev = { active = bool, now = ms }.
--- active=true : le joueur sprinte à cet instant ; active=false : arrêt (reset).
function B.sprint(source, ev)
    if cfg('budget.stamina_enabled', false) ~= true then return nil end
    if type(ev) ~= 'table' then return nil end
    local now = tonumber(ev.now) or Util.now()
    if ev.active ~= true then B._sprint[source] = nil; return nil end

    local start = B._sprint[source]
    if not start then B._sprint[source] = now; return nil end
    local maxMs = tonumber(cfg('budget.max_sprint_ms', 45000)) or 45000
    if (now - start) > maxMs then
        return {
            detector = 'budget', category = C.CATEGORY.MOVEMENT,
            severity = C.SEVERITY.MEDIUM, confidence = 0.5,
            reason = string.format('sprint continu %.0f s (budget %.0f s) — stamina infinie',
                (now - start) / 1000, maxMs / 1000),
            source = source, metadata = { sprint_ms = now - start, kind = 'infinite_stamina' },
        }
    end
    return nil
end

--- COMBAT-ROLL : nombre de roulades par fenêtre glissante.
function B.roll(source, now)
    if cfg('budget.combat_roll_enabled', false) ~= true then return nil end
    now = tonumber(now) or Util.now()
    local windowMs = tonumber(cfg('budget.roll_window_ms', 10000)) or 10000
    local maxRolls = tonumber(cfg('budget.roll_max', 6)) or 6

    local list = B._rolls[source] or {}
    local kept = {}
    for _, t in ipairs(list) do if (now - t) <= windowMs then kept[#kept + 1] = t end end
    kept[#kept + 1] = now
    B._rolls[source] = kept
    if #kept > maxRolls then
        return {
            detector = 'budget', category = C.CATEGORY.MOVEMENT,
            severity = C.SEVERITY.LOW, confidence = 0.45,
            reason = string.format('%d roulades en %.0f s (max %d) — combat-roll flood',
                #kept, windowMs / 1000, maxRolls),
            source = source, metadata = { rolls = #kept, kind = 'combat_roll' },
        }
    end
    return nil
end

function B.forget(source)
    B._shots[source] = nil; B._sprint[source] = nil; B._rolls[source] = nil
end

function B.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'budget', category = C.CATEGORY.MOVEMENT,
            evaluate = function() return {} end })
    end
end

ZShield.Budget = B
return B
