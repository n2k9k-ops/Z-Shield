--[[
    FILE:         server/detection/invariants.lua
    PURPOSE:      REGISTRE D'INVARIANTS DURS. Un invariant est une règle qui doit TOUJOURS être
                  vraie sur l'état d'un joueur/monde ; si elle est fausse, c'est illégitime, point.
                  Contrairement aux détecteurs heuristiques, un invariant n'a pas de « probabilité »
                  à contourner : la valeur est soit dans les bornes physiques du jeu, soit hors —
                  et le serveur borne/rejette. C'est extensible à volonté : ajouter une protection
                  = ajouter une ligne au registre.

                  Chaque invariant est SERVEUR-AUTORITATIF (évalué sur des valeurs que le serveur
                  connaît/borne) et renvoie une violation exploitable (borne dépassée + valeur).

    DEPENDENCIES: shared/constants.lua, core/config.lua
    PUBLIC API:   ZShield.Invariants.check(source, snap) -> { violations... }
                  ZShield.Invariants.count() -> nombre d'invariants enregistrés
                  ZShield.Invariants.register()

    snap = table d'état { health, armor, max_health, money, speed, mode, ammo, mag,
                          x, y, z, scale, entity_count, entity_quota, stamina,
                          weapon_damage, weapon_base, ... } — champs optionnels, non fournis = ignorés.
]]

ZShield = ZShield or {}
local C = ZShield.Const

local INV = {}

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function num(v) return type(v) == 'number' and v == v and v ~= math.huge and v ~= -math.huge end

-- Registre : chaque entrée = { id, sev, fn(snap, cfg) -> reason|nil }.
-- fn ne se déclenche que si les champs nécessaires sont présents (sinon nil = ignoré).
local RULES = {
    { id = 'health_le_max', sev = 'HIGH', fn = function(s)
        local m = num(s.max_health) and s.max_health or (tonumber(cfg('invariants.max_health', 200)) or 200)
        if num(s.health) and s.health > m + 1 then return ('santé %.0f > max %.0f'):format(s.health, m) end
    end },
    { id = 'armor_le_max', sev = 'HIGH', fn = function(s)
        local m = tonumber(cfg('invariants.max_armor', 100)) or 100
        if num(s.armor) and s.armor > m + 1 then return ('armure %.0f > max %.0f'):format(s.armor, m) end
    end },
    { id = 'health_ge_zero', sev = 'LOW', fn = function(s)
        if num(s.health) and s.health < 0 then return 'santé négative' end
    end },
    { id = 'money_ge_zero', sev = 'MEDIUM', fn = function(s)
        if num(s.money) and s.money < 0 then return 'argent négatif' end
    end },
    { id = 'money_le_cap', sev = 'MEDIUM', fn = function(s)
        local cap = tonumber(cfg('invariants.max_money', 1e12)) or 1e12
        if num(s.money) and s.money > cap then return ('argent %.0f > plafond'):format(s.money) end
    end },
    { id = 'speed_le_max', sev = 'HIGH', fn = function(s)
        local onFoot = s.mode == nil or s.mode == 'foot'
        local m = onFoot and (tonumber(cfg('invariants.max_speed_foot', 12)) or 12)
            or (tonumber(cfg('invariants.max_speed_vehicle', 95)) or 95)
        if num(s.speed) and s.speed > m then return ('vitesse %.1f m/s > max %.0f (%s)'):format(s.speed, m, onFoot and 'à pied' or 'véhicule') end
    end },
    { id = 'ammo_le_cap', sev = 'MEDIUM', fn = function(s)
        if num(s.ammo) and num(s.mag) and s.ammo > s.mag * (tonumber(cfg('invariants.max_reserve_mult', 20)) or 20) then
            return ('munitions %.0f > capacité plausible'):format(s.ammo)
        end
    end },
    { id = 'weapon_damage_le_base', sev = 'HIGH', fn = function(s)
        if num(s.weapon_damage) and num(s.weapon_base) then
            local tol = tonumber(cfg('invariants.damage_tol', 0.25)) or 0.25
            if s.weapon_damage > s.weapon_base * (1 + tol) then
                return ('dégâts %.0f > base %.0f'):format(s.weapon_damage, s.weapon_base)
            end
        end
    end },
    { id = 'coord_in_world', sev = 'HIGH', fn = function(s)
        local m = tonumber(cfg('invariants.max_coord', 1e6)) or 1e6
        for _, k in ipairs({ 'x', 'y', 'z' }) do
            if s[k] ~= nil and not num(s[k]) then return ('coordonnée %s non finie'):format(k) end
            if num(s[k]) and math.abs(s[k]) > m then return ('coordonnée %s hors monde'):format(k) end
        end
    end },
    { id = 'zpos_in_bounds', sev = 'MEDIUM', fn = function(s)
        local hi = tonumber(cfg('invariants.max_altitude', 1500)) or 1500
        local lo = tonumber(cfg('invariants.min_altitude', -120)) or -120
        if num(s.z) and (s.z > hi or s.z < lo) and not s.in_air then
            return ('altitude %.0f hors bornes'):format(s.z)
        end
    end },
    { id = 'scale_in_range', sev = 'MEDIUM', fn = function(s)
        local m = tonumber(cfg('invariants.max_scale', 100)) or 100
        if num(s.scale) and (s.scale <= 0 or s.scale > m) then return ('échelle %.1f hors plage'):format(s.scale) end
    end },
    { id = 'stamina_le_max', sev = 'LOW', fn = function(s)
        local m = tonumber(cfg('invariants.max_stamina', 100)) or 100
        if num(s.stamina) and s.stamina > m + 1 then return ('endurance %.0f > max'):format(s.stamina) end
    end },
    { id = 'entity_count_le_quota', sev = 'HIGH', fn = function(s)
        local q = num(s.entity_quota) and s.entity_quota or (tonumber(cfg('invariants.entity_quota', 50)) or 50)
        if num(s.entity_count) and s.entity_count > q then return ('%.0f entités > quota %.0f'):format(s.entity_count, q) end
    end },
}

--- Vérifie tous les invariants ACTIVÉS contre un instantané d'état. Retourne les violations.
function INV.check(source, snap)
    if cfg('invariants.enabled', false) ~= true then return {} end
    if type(snap) ~= 'table' then return {} end
    local out = {}
    local disabled = cfg('invariants.disabled', nil)
    disabled = type(disabled) == 'table' and disabled or {}
    for _, rule in ipairs(RULES) do
        -- Chaque invariant peut être coupé individuellement : invariants.disabled = { id = true }.
        if disabled[rule.id] ~= true then
            local reason = rule.fn(snap)
            if reason then
                out[#out + 1] = {
                    detector = 'invariant.' .. rule.id, category = C.CATEGORY.STATE,
                    severity = C.SEVERITY[rule.sev] or C.SEVERITY.MEDIUM, confidence = 0.8,
                    reason = 'invariant violé : ' .. reason, source = source,
                    metadata = { invariant = rule.id, kind = 'invariant' },
                }
            end
        end
    end
    return out
end

function INV.count() return #RULES end

function INV.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'invariants', category = C.CATEGORY.STATE,
            evaluate = function() return {} end })
    end
end

ZShield.Invariants = INV
return INV
