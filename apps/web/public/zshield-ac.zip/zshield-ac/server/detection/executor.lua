--[[
    FILE:         server/detection/executor.lua
    PURPOSE:      ANTI-EXECUTOR + BLACKLIST DE RESSOURCES DYNAMIQUE. Un « executor » (injecteur
                  de script Lua) fait tourner du code non déclaré côté client, qui émet des
                  events vers le serveur. Deux angles serveur :
                    1. ALLOWLIST : un event dont la ressource émettrice n'est PAS dans la liste
                       des ressources légitimes démarrées = script injecté (executor / resource
                       injection). C'est le plus robuste : on liste ce qui est permis.
                    2. SIGNATURES : un nom de ressource/event correspondant à un motif connu
                       d'outil de triche. Utile contre les setups non modifiés, mais TRIVIALEMENT
                       contournable par renommage — d'où l'allowlist en défense principale.

    Module pur : la glue lui fournit `resource`/`event` de chaque net-event (GetInvokingResource
    côté FiveM). Corrélant, sauf allowlist stricte où l'opérateur peut choisir de bloquer.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Executor.observeEvent(source, ev) -> signal|nil
                  ZShield.Executor.register()

    ev = { resource = string, event = string, now = ms }
]]

ZShield = ZShield or {}
local C = ZShield.Const

local EX = {}

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function inList(list, value)
    if type(list) ~= 'table' then return false end
    for _, v in ipairs(list) do if v == value then return true end end
    return list[value] == true
end

local function matchesAny(patterns, hay)
    if type(patterns) ~= 'table' or type(hay) ~= 'string' then return nil end
    local low = hay:lower()
    for _, p in ipairs(patterns) do
        if type(p) == 'string' and p ~= '' and low:find(p:lower(), 1, true) then return p end
    end
    return nil
end

function EX.observeEvent(source, ev)
    if cfg('executor.enabled', false) ~= true then return nil end
    if type(ev) ~= 'table' then return nil end
    local res = ev.resource
    local evt = ev.event

    -- 1) Signature connue (renommable, mais attrape les setups paresseux).
    local pats = cfg('executor.blocklist_patterns', nil)
    local hit = matchesAny(pats, res or '') or matchesAny(pats, evt or '')
    if hit then
        return {
            detector = 'executor', category = C.CATEGORY.RESOURCE,
            severity = C.SEVERITY.HIGH, confidence = 0.7,
            reason = string.format('signature d%soutil de triche (« %s »)', "'", hit),
            source = source, metadata = { resource = res, event = evt, pattern = hit, kind = 'executor_signature' },
        }
    end

    -- 2) Allowlist stricte : si activée, une ressource hors liste qui émet = injectée.
    local allow = cfg('executor.allowlist', nil)
    if type(allow) == 'table' and res ~= nil and not inList(allow, res) then
        return {
            detector = 'executor', category = C.CATEGORY.RESOURCE,
            severity = C.SEVERITY.HIGH, confidence = 0.65,
            reason = string.format('event émis par une ressource non déclarée « %s » (executor/injection)', tostring(res)),
            source = source, metadata = { resource = res, event = evt, kind = 'unknown_resource' },
        }
    end
    return nil
end

function EX.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'executor', category = C.CATEGORY.RESOURCE,
            evaluate = function() return {} end })
    end
end

ZShield.Executor = EX
return EX
