--[[
    FILE:         server/detection/reach.lua
    PURPOSE:      DÉTECTION REACH / DISTANCE D'ACTION. Beaucoup d'exploits agissent à une
                  distance impossible : coup de MÊLÉE qui touche à 15 m, LOOT/fouille d'un corps
                  à l'autre bout de la rue, RAMASSAGE d'un pickup lointain, INTERACTION avec un
                  objet/joueur hors de portée. Le serveur connaît la distance entre l'acteur et
                  la cible : au-delà de la portée légitime du TYPE d'action, c'est un reach hack.

    Distinct de `desync` (origine du TIR loin de la position) : ici c'est la CIBLE de l'action
    qui est trop loin, par type d'action.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Reach.observe(source, action) -> signal|nil
                  ZShield.Reach.register()

    action = { kind = 'melee'|'loot'|'pickup'|'interact', dist = number(m) }
]]

ZShield = ZShield or {}
local C = ZShield.Const

local R = {}

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function maxFor(kind)
    local m = {
        melee    = tonumber(cfg('reach.max_melee_m', 4)) or 4,
        loot     = tonumber(cfg('reach.max_loot_m', 6)) or 6,
        pickup   = tonumber(cfg('reach.max_pickup_m', 6)) or 6,
        interact = tonumber(cfg('reach.max_interact_m', 6)) or 6,
    }
    return m[kind] or tonumber(cfg('reach.default_max_m', 6)) or 6
end

function R.observe(source, action)
    if cfg('reach.enabled', false) ~= true then return nil end
    if type(action) ~= 'table' then return nil end
    local d = tonumber(action.dist)
    if not d then return nil end
    local kind = tostring(action.kind or 'interact')
    local limit = maxFor(kind)
    if d > limit then
        return {
            detector = 'reach', category = C.CATEGORY.EVENT,
            severity = C.SEVERITY.HIGH, confidence = 0.6,
            reason = string.format('%s à %.1f m (max %.0f m) — reach hack', kind, d, limit),
            source = source, metadata = { action = kind, dist = d, max = limit, kind = 'reach' },
        }
    end
    return nil
end

function R.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'reach', category = C.CATEGORY.EVENT,
            evaluate = function() return {} end })
    end
end

ZShield.Reach = R
return R
