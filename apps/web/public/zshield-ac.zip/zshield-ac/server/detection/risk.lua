--[[
    FILE:         server/detection/risk.lua
    PURPOSE:      Moteur de risque (§13, §14). Score dynamique par joueur, décroissant dans
                  le temps (temporal decay), avec niveaux configurables. C'est ici que
                  severity/confidence deviennent une CONSÉQUENCE (risk), et jamais avant.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua, core/config.lua, core/bus
    PUBLIC API:   ZShield.Risk.addSignal(source, signal)
                  ZShield.Risk.explain(source, explanation, delta)  -- §13 legitimate explanations
                  ZShield.Risk.score(source) -> score (0..100, decay appliqué)
                  ZShield.Risk.level(source) -> NORMAL|OBSERVE|SUSPICIOUS|HIGH_RISK|CRITICAL
                  ZShield.Risk.snapshot(source) -> table explicable
                  ZShield.Risk.clear(source), ZShield.Risk.attach()

    §13 : score = base + signaux récents + anomalies répétées + contexte + confiance
    + gravité − decay − explications légitimes. Le score DÉCROÎT (§14) : une demi-vie
    configurable divise le score par deux à intervalle régulier s'il n'est pas alimenté.
    Un score actif n'est jamais conservé éternellement.

    §11 rappel : un signal HIGH mais confidence 0.2 apporte peu de score (score du signal
    = poids × confiance, déjà calculé par le moteur de détection). Le risque hérite donc
    de la prudence de la détection.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log
local Bus = ZShield.Bus

local Risk = { players = {} } -- source -> { score, last_update, history }

local function store(source)
    local p = Risk.players[source]
    if not p then
        p = { score = 0, last_update = Util.now(), history = {} }
        Risk.players[source] = p
    end
    return p
end

-- Applique la décroissance temporelle depuis la dernière mise à jour (§14).
-- Demi-vie configurable : après `half_life` secondes sans alimentation, le score est /2.
-- Formule : score * 0.5 ^ (elapsed / half_life).
local function applyDecay(p, now)
    if ZShield.Config and ZShield.Config.value('scoring.decay') == false then
        p.last_update = now
        return
    end
    local halfLifeS = (ZShield.Config and ZShield.Config.value('scoring.decay_half_life_s')) or 600
    local elapsedS = (now - p.last_update) / 1000
    if elapsedS <= 0 then return end
    local factor = 0.5 ^ (elapsedS / halfLifeS)
    p.score = p.score * factor
    p.last_update = now
    -- Sous un plancher, on remet à zéro pour ne pas traîner des résidus infinis.
    if p.score < 0.5 then p.score = 0 end
end

--- Ajoute un signal au score du joueur. Le score du signal a déjà intégré
--- severity × confidence (§11) ; ici on l'accumule et on borne à 100.
function Risk.addSignal(source, signal)
    if source == nil then return end
    if ZShield.Config and ZShield.Config.value('scoring.enabled') == false then return end

    local p = store(source)
    local now = Util.now()
    applyDecay(p, now)

    local before = p.score
    p.score = Util.clamp(p.score + (signal.score or 0), 0, C.LIMITS.MAX_RISK_SCORE)

    -- Historique borné pour la chaîne de preuve (§29).
    p.history[#p.history + 1] = {
        detector = signal.detector, severity = signal.severity,
        confidence = signal.confidence, score = signal.score,
        before = before, after = p.score, at = now, reason = signal.reason,
    }
    while #p.history > 64 do table.remove(p.history, 1) end

    local levelBefore = _levelFor(before)
    local levelAfter = _levelFor(p.score)
    if levelAfter ~= levelBefore then
        Log:security('risk', 'risk level changed', {
            source = source, from = levelBefore, to = levelAfter,
            score = math.floor(p.score), detector = signal.detector,
        })
        Bus:emit('risk.level_changed', {
            source = source, from = levelBefore, to = levelAfter,
            score = p.score, signal = signal,
        })
    end
end

--- Réduit le score suite à une explication légitime (§13). Ex : un admin confirme qu'un
--- téléport était volontaire. Rend le système auto-correcteur plutôt qu'accumulateur.
function Risk.explain(source, explanation, delta)
    local p = Risk.players[source]
    if not p then return end
    applyDecay(p, Util.now())
    local before = p.score
    p.score = Util.clamp(p.score - math.abs(delta or 10), 0, C.LIMITS.MAX_RISK_SCORE)
    Log:info('risk', 'legitimate explanation applied', {
        source = source, explanation = explanation, before = math.floor(before), after = math.floor(p.score),
    })
end

-- Détermine le niveau à partir d'un score, selon les seuils de config.
function _levelFor(score)
    local th = (ZShield.Config and ZShield.Config.value('scoring.thresholds')) or
               { observe = 20, suspicious = 40, high_risk = 65, critical = 85 }
    if score >= th.critical then return C.RISK_LEVEL.CRITICAL end
    if score >= th.high_risk then return C.RISK_LEVEL.HIGH_RISK end
    if score >= th.suspicious then return C.RISK_LEVEL.SUSPICIOUS end
    if score >= th.observe then return C.RISK_LEVEL.OBSERVE end
    return C.RISK_LEVEL.NORMAL
end

--- Score courant, decay appliqué à la lecture (donc toujours à jour).
function Risk.score(source)
    local p = Risk.players[source]
    if not p then return 0 end
    applyDecay(p, Util.now())
    return p.score
end

function Risk.level(source)
    return _levelFor(Risk.score(source))
end

--- Snapshot explicable (§13, §152) : score, niveau, historique récent. Permet à un admin
--- de comprendre QUELS signaux ont produit le score.
function Risk.snapshot(source)
    local p = Risk.players[source]
    if not p then
        return { score = 0, level = C.RISK_LEVEL.NORMAL, history = {} }
    end
    applyDecay(p, Util.now())
    return {
        score = math.floor(p.score * 10) / 10,
        level = _levelFor(p.score),
        signal_count = #p.history,
        history = Util.deepCopy(p.history),
    }
end

function Risk.clear(source)
    Risk.players[source] = nil
end

--- S'abonne au bus pour scorer automatiquement les signaux émis par la détection.
function Risk.attach()
    Bus:on('detection.signal', function(signal)
        if signal.source ~= nil then
            Risk.addSignal(signal.source, signal)
        end
    end)
end

ZShield.Risk = Risk
