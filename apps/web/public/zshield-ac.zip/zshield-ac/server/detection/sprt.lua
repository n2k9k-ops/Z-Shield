--[[
    FILE:         server/detection/sprt.lua
    PURPOSE:      TEST SÉQUENTIEL DU RAPPORT DE VRAISEMBLANCE (SPRT, Wald 1945). Technique
                  statistique RÉELLE, utilisée notamment pour tester la force des moteurs d'échecs
                  (chessprogramming.org) : au lieu d'un seuil fixe (« >X headshots = ban »), on
                  ACCUMULE la preuve tir après tir et on décide UNIQUEMENT quand la confiance est
                  suffisante — avec des taux d'erreur BORNÉS PAR CONSTRUCTION (faux positif ≤ α,
                  faux négatif ≤ β). C'est le contraire d'un seuil arbitraire : c'est un test avec
                  garanties mathématiques.

                  Modèle de Bernoulli : chaque observation est un indicateur binaire (ex. « ce tir
                  est-il « surhumain » ? »). Sous H0 (joueur légitime) la probabilité est p0 ; sous
                  H1 (tricheur) elle est p1 > p0. On met à jour le log-rapport de vraisemblance :
                     x=1 -> += log(p1/p0)     x=0 -> += log((1-p1)/(1-p0))
                  Bornes de décision :
                     A = log((1-β)/α)  (atteinte -> H1 : tricheur)
                     B = log(β/(1-α))  (atteinte -> H0 : légitime, on réarme)

    RÉFÉRENCES : Wald, « Sequential Analysis » (1945) ; chessprogramming.org/Sequential_Probability_Ratio_Test.

    DEPENDENCIES: shared/constants.lua, core/config.lua
    PUBLIC API:   ZShield.Sprt.observe(source, feature, x) -> { decision, llr, signal }|nil
                  ZShield.Sprt.binomTailP(n, k, p0) -> p-value (P(X>=k))
                  ZShield.Sprt.reset(source, feature) / .forget(source) / .register()
]]

ZShield = ZShield or {}
local C = ZShield.Const

local S = {}
S._llr = {}   -- source -> { [feature] = { llr, n } }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function feat(source, feature)
    local s = S._llr[source]; if not s then s = {}; S._llr[source] = s end
    local f = s[feature]; if not f then f = { llr = 0, n = 0 }; s[feature] = f end
    return f
end

--- Une observation binaire x (0/1) pour un joueur et une caractéristique. Retourne une
--- décision quand une borne est franchie, sinon nil (le test « continue »).
function S.observe(source, feature, x)
    if cfg('sprt.enabled', false) ~= true then return nil end
    local alpha = tonumber(cfg('sprt.alpha', 0.01)) or 0.01   -- faux positif max
    local beta  = tonumber(cfg('sprt.beta', 0.05)) or 0.05    -- faux négatif max
    local p0 = tonumber(cfg('sprt.p0', 0.15)) or 0.15         -- taux légitime attendu
    local p1 = tonumber(cfg('sprt.p1', 0.55)) or 0.55         -- taux tricheur attendu
    if p0 <= 0 or p0 >= 1 or p1 <= 0 or p1 >= 1 or p0 >= p1 then return nil end

    local f = feat(source, feature)
    local inc = (x and x > 0) and math.log(p1 / p0) or math.log((1 - p1) / (1 - p0))
    f.llr = f.llr + inc
    f.n = f.n + 1

    local A = math.log((1 - beta) / alpha)   -- borne « tricheur »
    local B = math.log(beta / (1 - alpha))   -- borne « légitime »

    if f.llr >= A then
        local n = f.n
        S.reset(source, feature)
        return {
            decision = 'cheat', llr = A, n = n,
            signal = {
                detector = 'sprt.' .. tostring(feature), category = C.CATEGORY.DAMAGE,
                severity = C.SEVERITY.HIGH, confidence = math.min(0.9, 1 - alpha),
                reason = string.format('SPRT « %s » : preuve accumulée suffisante en %d obs (α=%.3f, β=%.3f)',
                    tostring(feature), n, alpha, beta),
                source = source, metadata = { feature = feature, obs = n, kind = 'sprt' },
            },
        }
    elseif f.llr <= B then
        S.reset(source, feature)   -- déclaré légitime : on réarme le test
        return { decision = 'clean', llr = B, n = f.n }
    end
    return nil
end

--- p-value binomiale unilatérale P(X>=k) sous Binomiale(n,p0). Sert au test « ratio de
--- headshots improbable » (comparaison de distribution, cf. Yu & Hammerla). Calcul stable
--- par log-factorielles pour n modéré.
function S.binomTailP(n, k, p0)
    n = math.floor(tonumber(n) or 0); k = math.ceil(tonumber(k) or 0)
    p0 = tonumber(p0) or 0.5
    if n <= 0 or k > n then return 0 end
    if k <= 0 then return 1 end
    -- log C(n,i) via lgamma-like par sommation (n modéré : boucle directe).
    local function logfact(m) local s = 0; for i = 2, m do s = s + math.log(i) end; return s end
    local lp, l1p = math.log(p0), math.log(1 - p0)
    local total = 0
    for i = k, n do
        local logc = logfact(n) - logfact(i) - logfact(n - i)
        total = total + math.exp(logc + i * lp + (n - i) * l1p)
    end
    if total < 0 then total = 0 elseif total > 1 then total = 1 end
    return total
end

--- Aide : évalue un ratio de headshots (k/n) et émet un signal si la p-value est sous le seuil.
function S.headshotTest(source, n, k)
    if cfg('sprt.enabled', false) ~= true then return nil end
    local p0 = tonumber(cfg('sprt.headshot_baseline', 0.20)) or 0.20
    local minN = tonumber(cfg('sprt.headshot_min_n', 15)) or 15
    local pmax = tonumber(cfg('sprt.headshot_pvalue', 1e-4)) or 1e-4
    if n < minN then return nil end
    local p = S.binomTailP(n, k, p0)
    if p < pmax then
        return {
            detector = 'sprt.headshot', category = C.CATEGORY.DAMAGE,
            severity = C.SEVERITY.HIGH, confidence = 0.8,
            reason = string.format('ratio de headshots %d/%d improbable (p=%.1e vs base %.0f%%)',
                k, n, p, p0 * 100),
            source = source, metadata = { n = n, k = k, pvalue = p, kind = 'binomial' },
        }
    end
    return nil
end

function S.reset(source, feature)
    local s = S._llr[source]; if s then s[feature] = nil end
end
function S.forget(source) S._llr[source] = nil end

function S.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'sprt', category = C.CATEGORY.DAMAGE,
            evaluate = function() return {} end })
    end
end

ZShield.Sprt = S
return S
