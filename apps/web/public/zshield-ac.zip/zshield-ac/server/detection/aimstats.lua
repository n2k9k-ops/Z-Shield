--[[
    FILE:         server/detection/aimstats.lua
    PURPOSE:      MOTEUR STATISTIQUE DE VISÉE (§15 poussé). Un aimbot ne se trahit pas sur
                  UN tir, mais sur la DISTRIBUTION de ses tirs : trop de headshots, des
                  « snaps » angulaires instantanés impossibles à la main, des temps de
                  réaction sous le plancher humain. Ce module accumule, par joueur, une
                  fenêtre glissante d'échantillons de tir et signale l'IMPROBABLE
                  STATISTIQUE — jamais un seuil unique, jamais un ban direct (§11/§26).

    POURQUOI SERVEUR-AUTORITATIF : les échantillons (touché, headshot, angle avant tir,
    délai) sont dérivés d'événements de tir que le serveur observe déjà (damage/hit). On ne
    lit RIEN sur la machine du joueur. La force vient du VOLUME : un humain ne tient pas une
    distribution surhumaine sur des dizaines de tirs.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Aimstats.observe(source, sample) -> signal|nil
                  ZShield.Aimstats.stats(source) -> table|nil
                  ZShield.Aimstats.forget(source) / .register()

    sample = {
      hit        = bool,     -- le tir a-t-il touché un joueur ?
      headshot   = bool,     -- touche à la tête ?
      snap_deg   = number,   -- amplitude angulaire du recentrage JUSTE avant le tir (deg)
      react_ms   = number,   -- délai entre cible acquise et tir (ms)
      dist       = number,   -- distance à la cible (m), optionnel (contexte)
    }
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local AS = {}
AS._win = {}   -- source -> { samples = { ... }, n }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

--- Moyenne + p95 d'une liste de nombres (p95 approché par tri partiel simple).
local function summarize(list)
    local n = #list
    if n == 0 then return 0, 0 end
    local sum = 0
    local sorted = {}
    for i = 1, n do sum = sum + list[i]; sorted[i] = list[i] end
    table.sort(sorted)
    local p95 = sorted[math.max(1, math.floor(n * 0.95))]
    return sum / n, p95
end

--- Observe un échantillon de tir. Retourne un signal partiel (severity/confidence/
--- reason/metadata) quand la fenêtre est assez remplie ET statistiquement anormale,
--- sinon nil. Le signal est CORRÉLANT : il alimente le moteur, ne bannit pas seul.
function AS.observe(source, sample)
    if cfg('aimstats.enabled', false) ~= true then return nil end
    if type(sample) ~= 'table' then return nil end

    local window = tonumber(cfg('aimstats.window', 60)) or 60
    local w = AS._win[source]
    if not w then w = { samples = {}, i = 0 }; AS._win[source] = w end

    -- Buffer circulaire : O(1) mémoire, borne dure.
    w.i = (w.i % window) + 1
    w.samples[w.i] = {
        hit = sample.hit == true,
        headshot = sample.headshot == true,
        snap = tonumber(sample.snap_deg) or 0,
        react = tonumber(sample.react_ms) or 9999,
    }

    local samples = w.samples
    local n = #samples
    local minN = tonumber(cfg('aimstats.min_samples', 30)) or 30
    if n < minN then return nil end

    -- Agrégats sur la fenêtre.
    local hits, heads = 0, 0
    local snaps, reacts = {}, {}
    for i = 1, n do
        local s = samples[i]
        if s.hit then
            hits = hits + 1
            if s.headshot then heads = heads + 1 end
        end
        snaps[#snaps + 1] = s.snap
        reacts[#reacts + 1] = s.react
    end
    if hits < math.floor(minN * 0.5) then return nil end   -- pas assez de touches pour juger

    local hsRatio = heads / hits
    local snapMean, snapP95 = summarize(snaps)
    local reactMean = select(1, summarize(reacts))

    -- Seuils de plausibilité HUMAINE (configurables). Dépassés ensemble = très improbable.
    local hsMax    = tonumber(cfg('aimstats.headshot_ratio_max', 0.70)) or 0.70
    local snapMax  = tonumber(cfg('aimstats.snap_deg_mean_max', 45)) or 45      -- recentrage moyen
    local snapPMax = tonumber(cfg('aimstats.snap_deg_p95_max', 120)) or 120     -- pics
    local reactMin = tonumber(cfg('aimstats.reaction_ms_min', 90)) or 90        -- plancher humain

    local flags, why = 0, {}
    if hsRatio  > hsMax    then flags = flags + 1; why[#why+1] = string.format('headshots %.0f%%', hsRatio * 100) end
    if snapMean > snapMax  then flags = flags + 1; why[#why+1] = string.format('snap moyen %.0f°', snapMean) end
    if snapP95  > snapPMax then flags = flags + 1; why[#why+1] = string.format('snap p95 %.0f°', snapP95) end
    if reactMean < reactMin then flags = flags + 1; why[#why+1] = string.format('réaction %.0f ms', reactMean) end

    -- Un seul indicateur = bruit possible (bon joueur, échantillon court). On exige au
    -- moins DEUX indicateurs surhumains concordants pour émettre.
    if flags < 2 then return nil end

    -- Confiance : monte avec le nombre d'indicateurs et la taille d'échantillon, plafonnée
    -- pour rester CORRÉLANTE (jamais 1.0 : un signal aim seul ne bannit pas, §26).
    local sampleBoost = math.min(1.0, n / window)
    local confidence = math.min(0.85, 0.30 + 0.18 * flags + 0.10 * sampleBoost)
    local severity = flags >= 3 and C.SEVERITY.HIGH or C.SEVERITY.MEDIUM

    return {
        detector = 'aimstats',
        category = C.CATEGORY.DAMAGE,
        severity = severity,
        confidence = confidence,
        reason = 'distribution de visée improbable (' .. table.concat(why, ', ') .. ')',
        source = source,
        metadata = {
            samples = n, hits = hits, headshot_ratio = hsRatio,
            snap_mean = snapMean, snap_p95 = snapP95, reaction_mean = reactMean,
            indicators = flags,
        },
    }
end

function AS.stats(source)
    local w = AS._win[source]
    return w and { count = #w.samples } or nil
end

function AS.forget(source) AS._win[source] = nil end

--- Enregistre le détecteur auprès du moteur (émission via observe côté télémétrie).
function AS.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({
            id = 'aimstats', category = C.CATEGORY.DAMAGE,
            evaluate = function() return {} end,   -- piloté par observe(), pas par tick
        })
    end
end

ZShield.Aimstats = AS
return AS
