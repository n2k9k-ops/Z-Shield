--[[
    FILE:         server/detection/esp.lua
    PURPOSE:      DÉTECTION ESP / RADAR INDIRECTE. Un ESP a besoin de CONNAÎTRE les entités
                  (joueurs, véhicules) bien au-delà de ce que le joueur devrait streamer. Ça se
                  traduit, côté serveur, par des demandes de SYNCHRO / OWNERSHIP d'entités
                  situées HORS de la portée de streaming légitime, en VOLUME. Le serveur ne voit
                  pas l'overlay ESP, mais il voit ces requêtes anormales : beaucoup d'entités
                  lointaines réclamées dans une courte fenêtre = radar/ESP probable.

    SERVEUR-AUTORITATIF : les distances et les requêtes de synchro sont connues du serveur
    (OneSync). Corrélant (§26) : on signale un motif, on ne bannit pas sur une requête isolée.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Esp.observe(source, req) -> signal|nil
                  ZShield.Esp.forget(source) / .register()

    req = { entity_dist = number(m), now = ms }   -- distance de l'entité réclamée
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local E = {}
E._far = {}   -- source -> { timestamps des requêtes lointaines }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

function E.observe(source, req)
    if cfg('esp.enabled', false) ~= true then return nil end
    if type(req) ~= 'table' then return nil end
    local d = tonumber(req.entity_dist)
    if not d then return nil end
    local now = tonumber(req.now) or Util.now()

    local range = tonumber(cfg('esp.stream_range_m', 300)) or 300
    if d <= range then return nil end   -- requête dans la portée légitime : rien

    local windowMs = tonumber(cfg('esp.window_ms', 5000)) or 5000
    local maxFar = tonumber(cfg('esp.max_far_requests', 12)) or 12

    local list = E._far[source] or {}
    local kept = {}
    for _, t in ipairs(list) do if (now - t) <= windowMs then kept[#kept + 1] = t end end
    kept[#kept + 1] = now
    E._far[source] = kept

    if #kept > maxFar then
        return {
            detector = 'esp', category = C.CATEGORY.NETWORK,
            severity = C.SEVERITY.MEDIUM, confidence = 0.5,
            reason = string.format('%d entités hors portée (>%.0f m) réclamées en %.0f s — ESP/radar probable',
                #kept, range, windowMs / 1000),
            source = source, metadata = { far_requests = #kept, range = range, kind = 'esp' },
        }
    end
    return nil
end

function E.forget(source) E._far[source] = nil end

function E.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'esp', category = C.CATEGORY.NETWORK,
            evaluate = function() return {} end })
    end
end

ZShield.Esp = E
return E
