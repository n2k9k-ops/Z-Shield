--[[
    FILE:         server/detection/chatspam.lua
    PURPOSE:      ANTI-SPAM CHAT / COMMANDES. Les bots de pub et les spammeurs envoient des
                  messages/commandes à cadence élevée et/ou répètent le même texte. Le serveur
                  reçoit chaque message : on borne le débit par fenêtre et on repère la
                  répétition du même contenu.

    100 % serveur, corrélant. Ne lit aucun contenu privé hors du chat du jeu.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.ChatSpam.observe(source, msg) -> signal|nil
                  ZShield.ChatSpam.forget(source) / .register()

    msg = { kind = 'chat'|'command', text = string?, now = ms }
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local CS = {}
CS._st = {}   -- source -> { times = {}, last_text, dup = 0 }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

function CS.observe(source, msg)
    if cfg('chatspam.enabled', false) ~= true then return nil end
    if type(msg) ~= 'table' then return nil end
    local now = tonumber(msg.now) or Util.now()
    local windowMs = tonumber(cfg('chatspam.window_ms', 10000)) or 10000
    local maxMsg = tonumber(cfg('chatspam.max_messages', 8)) or 8
    local maxDup = tonumber(cfg('chatspam.max_duplicates', 3)) or 3

    local st = CS._st[source]
    if not st then st = { times = {}, last_text = nil, dup = 0 }; CS._st[source] = st end

    -- Débit par fenêtre glissante.
    local kept = {}
    for _, t in ipairs(st.times) do if (now - t) <= windowMs then kept[#kept + 1] = t end end
    kept[#kept + 1] = now
    st.times = kept

    -- Répétition du même texte.
    local text = msg.text and tostring(msg.text) or nil
    if text and text ~= '' then
        if text == st.last_text then st.dup = st.dup + 1 else st.dup = 1; st.last_text = text end
    end

    if #kept > maxMsg then
        return {
            detector = 'chatspam', category = C.CATEGORY.EVENT,
            severity = C.SEVERITY.LOW, confidence = 0.5,
            reason = string.format('%d messages en %.0f s (max %d) — spam', #kept, windowMs / 1000, maxMsg),
            source = source, metadata = { count = #kept, kind = 'rate' },
        }
    end
    if st.dup > maxDup then
        return {
            detector = 'chatspam', category = C.CATEGORY.EVENT,
            severity = C.SEVERITY.LOW, confidence = 0.5,
            reason = string.format('même message répété %d fois — spam/pub', st.dup),
            source = source, metadata = { duplicates = st.dup, kind = 'duplicate' },
        }
    end
    return nil
end

function CS.forget(source) CS._st[source] = nil end

function CS.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'chatspam', category = C.CATEGORY.EVENT,
            evaluate = function() return {} end })
    end
end

ZShield.ChatSpam = CS
return CS
