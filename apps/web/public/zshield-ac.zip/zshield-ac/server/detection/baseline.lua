--[[
    FILE:         server/detection/baseline.lua
    PURPOSE:      LIGNE DE BASE ADAPTATIVE PAR JOUEUR (z-score en ligne, algorithme de Welford).
                  Plutôt qu'un seuil fixe universel, on apprend la distribution NORMALE de chaque
                  métrique PAR JOUEUR (moyenne + variance en ligne, numériquement stable) et on
                  signale un écart soutenu (z-score) — la méthode des articles de détection
                  d'aimbot par comparaison de distribution (Yu & Hammerla) et la normalisation par
                  cohorte/z-score (state of the art anticheat).

                  ROBUSTESSE : le z-score est calculé AVANT mise à jour, et la ligne de base n'est
                  mise à jour QUE par les valeurs non-aberrantes (rejet trimmé) — un tricheur ne
                  peut donc pas « déplacer » sa propre normale pour se blanchir.

    RÉFÉRENCES : Welford (1962), variance en ligne ; Yu & Hammerla, « A statistical aimbot
    detection method for online FPS games » (IEEE, distribution comparison).

    DEPENDENCIES: shared/constants.lua, core/config.lua
    PUBLIC API:   ZShield.Baseline.observe(source, metric, x) -> signal|nil
                  ZShield.Baseline.stats(source, metric) / .forget(source) / .register()
]]

ZShield = ZShield or {}
local C = ZShield.Const

local BL = {}
BL._m = {}   -- source -> { [metric] = { n, mean, M2, streak } }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function cell(source, metric)
    local s = BL._m[source]; if not s then s = {}; BL._m[source] = s end
    local c = s[metric]; if not c then c = { n = 0, mean = 0, M2 = 0, streak = 0 }; s[metric] = c end
    return c
end

-- Mise à jour de Welford (variance en ligne stable).
local function update(c, x)
    c.n = c.n + 1
    local delta = x - c.mean
    c.mean = c.mean + delta / c.n
    c.M2 = c.M2 + delta * (x - c.mean)
end

--- Observe une valeur de métrique. Retourne un signal si un écart-type soutenu est constaté.
--- `direction` config : 'high' (aberrant si trop grand), 'low' (trop petit), 'both'.
function BL.observe(source, metric, x)
    if cfg('baseline.enabled', false) ~= true then return nil end
    x = tonumber(x); if x == nil then return nil end
    local c = cell(source, metric)
    local minN = tonumber(cfg('baseline.min_samples', 20)) or 20
    local zMax = tonumber(cfg('baseline.z_max', 3.5)) or 3.5
    local need = tonumber(cfg('baseline.consecutive', 4)) or 4
    local dir = cfg('baseline.direction', 'both')

    -- Pas assez d'historique : on apprend, on ne juge pas.
    if c.n < minN then update(c, x); return nil end

    local variance = c.M2 / (c.n - 1)
    local std = math.sqrt(math.max(variance, 1e-9))
    local z = (x - c.mean) / std

    local outlier
    if dir == 'high' then outlier = z >= zMax
    elseif dir == 'low' then outlier = z <= -zMax
    else outlier = math.abs(z) >= zMax end

    if outlier then
        c.streak = c.streak + 1
        -- On NE met PAS à jour la base avec un aberrant (anti-empoisonnement).
        if c.streak >= need then
            local hits = c.streak
            c.streak = 0
            return {
                detector = 'baseline.' .. tostring(metric), category = C.CATEGORY.STATE,
                severity = C.SEVERITY.MEDIUM, confidence = 0.6,
                reason = string.format('« %s » : %d écarts soutenus (z≈%.1f) hors de la normale du joueur',
                    tostring(metric), hits, z),
                source = source, metadata = { metric = metric, z = z, streak = hits, kind = 'zscore' },
            }
        end
        return nil
    end

    -- Valeur normale : on réinitialise la série et on met à jour la base.
    c.streak = 0
    update(c, x)
    return nil
end

function BL.stats(source, metric)
    local s = BL._m[source]; local c = s and s[metric]
    if not c or c.n < 2 then return nil end
    return { n = c.n, mean = c.mean, std = math.sqrt(c.M2 / (c.n - 1)) }
end

function BL.forget(source) BL._m[source] = nil end

function BL.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'baseline', category = C.CATEGORY.STATE,
            evaluate = function() return {} end })
    end
end

ZShield.Baseline = BL
return BL
