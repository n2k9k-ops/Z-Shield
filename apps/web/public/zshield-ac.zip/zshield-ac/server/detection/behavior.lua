--[[
    FILE:         server/detection/behavior.lua
    PURPOSE:      DÉTECTION BOT / MACRO / FARM par RÉGULARITÉ TEMPORELLE. Un humain a un
                  timing irrégulier ; un macro/bot agit à intervalles quasi identiques. On
                  mesure la variabilité des intervalles entre actions répétées (récolte, tir,
                  craft…) : un coefficient de variation très bas sur un volume suffisant =
                  cadence de machine, pas de main humaine.

    100 % serveur : on n'observe que les horodatages d'events déjà reçus. Corrélant (§26).

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Behavior.observe(source, now) -> signal|nil
                  ZShield.Behavior.forget(source) / .register()
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local BH = {}
BH._t = {}   -- source -> { timestamps... }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

function BH.observe(source, now)
    if cfg('behavior.enabled', false) ~= true then return nil end
    now = tonumber(now) or Util.now()
    local minActions = tonumber(cfg('behavior.min_actions', 12)) or 12
    local keep = minActions + 4

    local list = BH._t[source] or {}
    list[#list + 1] = now
    while #list > keep do table.remove(list, 1) end
    BH._t[source] = list
    if #list < minActions then return nil end

    -- Intervalles entre actions successives.
    local intervals = {}
    for i = 2, #list do intervals[#intervals + 1] = list[i] - list[i - 1] end
    local n = #intervals
    local sum = 0
    for _, v in ipairs(intervals) do sum = sum + v end
    local mean = sum / n
    if mean <= 0 then return nil end
    local varSum = 0
    for _, v in ipairs(intervals) do local d = v - mean; varSum = varSum + d * d end
    local std = math.sqrt(varSum / n)
    local cv = std / mean   -- coefficient de variation (0 = parfaitement régulier)

    local maxCv = tonumber(cfg('behavior.max_cv', 0.06)) or 0.06
    if cv < maxCv then
        return {
            detector = 'behavior', category = C.CATEGORY.EVENT,
            severity = C.SEVERITY.MEDIUM, confidence = 0.55,
            reason = string.format('cadence métronomique (CV %.3f sur %d actions) — macro/bot probable', cv, n + 1),
            source = source, metadata = { cv = cv, mean_ms = mean, samples = n + 1, kind = 'bot' },
        }
    end
    return nil
end

function BH.forget(source) BH._t[source] = nil end

function BH.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'behavior', category = C.CATEGORY.EVENT,
            evaluate = function() return {} end })
    end
end

ZShield.Behavior = BH
return BH
