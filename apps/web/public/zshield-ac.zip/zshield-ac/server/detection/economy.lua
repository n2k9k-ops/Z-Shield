--[[
    FILE:         server/detection/economy.lua
    PURPOSE:      Sécurité économique (§20) et inventaire (§19). Ledger serveur-authoritative :
                  chaque changement économique est une transaction EXPLICABLE et
                  reconstructible. Détecte fréquence anormale, montant incohérent, séquence
                  impossible, duplication, récompense répétée.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua, server/detection/engine.lua
    PUBLIC API:   ZShield.Economy.balance(account) -> number
                  ZShield.Economy.apply(txn) -> ok, resultOrSignal
                  ZShield.Economy.history(account, n) -> array
                  ZShield.Economy.reconstruct(account) -> number (somme des deltas)

    §19-20 : le serveur détermine QUEL item, COMBIEN, POURQUOI, QUAND, dans QUEL contexte —
    jamais la valeur client. Ne JAMAIS accepter item/quantity/reward comme vérité (§19).

    §20 : chaque transaction porte transaction_id, player, before, delta, after, reason,
    source, context, timestamp. L'historique permet une reconstruction complète.

    Le ledger est l'AUTORITÉ (§68) : le solde est la somme des deltas validés, pas une valeur
    que le client annonce. Un client qui prétend « j'ai 1M » est ignoré ; le serveur sait.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local Economy = {
    balances = {},       -- account -> number (solde autoritaire)
    ledger = {},         -- account -> array de transactions
    recent = {},         -- account -> { reason -> { last_at, count } } pour dédup/fréquence
    nonces = {},         -- account -> { nonce -> at } anti-duplication (§20)
    stats = { applied = 0, rejected = 0, signals = 0 },
}

-- Bornes de plausibilité par défaut. Configurables par intégration.
local MAX_SINGLE_DELTA = 1000000       -- montant unitaire au-delà duquel c'est suspect
local FREQUENCY_WINDOW_MS = 5000        -- fenêtre de détection de fréquence
local MAX_SAME_REASON_IN_WINDOW = 10    -- même raison N fois en fenêtre = suspect (récompense répétée)
local NONCE_TTL_MS = 60000              -- durée de mémorisation des nonces anti-duplication
local MAX_LEDGER_PER_ACCOUNT = 500      -- historique borné en mémoire (persistance prend le relais)

function Economy.balance(account)
    return Economy.balances[account] or 0
end

--- Reconstruit le solde depuis l'historique (§20) : somme des deltas. Doit égaler le solde
--- courant ; sert de vérification d'intégrité.
function Economy.reconstruct(account)
    local sum = 0
    local l = Economy.ledger[account]
    if l then for i = 1, #l do sum = sum + l[i].delta end end
    return sum
end

local function pushRecent(account, reason, now)
    Economy.recent[account] = Economy.recent[account] or {}
    local r = Economy.recent[account][reason]
    if not r or (now - r.window_start) > FREQUENCY_WINDOW_MS then
        r = { window_start = now, count = 0 }
        Economy.recent[account][reason] = r
    end
    r.count = r.count + 1
    return r.count
end

--- Applique une transaction. Retourne ok, result|signal.
--- txn = {
---   account, delta, reason, source (system|player|admin),
---   context (mission/shop/...), nonce (optionnel, anti-duplication)
--- }
--- Le SERVEUR décide de tout : `delta` doit avoir été calculé côté serveur (le firewall/
--- la logique métier), jamais reçu du client. Ce module VALIDE et TRACE.
function Economy.apply(txn)
    if type(txn) ~= 'table' or type(txn.account) == 'nil' or type(txn.delta) ~= 'number' then
        return false, { rejected = true, reason = 'malformed transaction' }
    end
    if txn.delta ~= txn.delta then -- NaN
        return false, { rejected = true, reason = 'delta is NaN' }
    end

    local account = txn.account
    local now = Util.now()
    local before = Economy.balance(account)

    -- --- Anti-duplication par nonce (§20). Un même nonce rejoué = duplication.
    if txn.nonce then
        Economy.nonces[account] = Economy.nonces[account] or {}
        -- Élague les nonces expirés.
        for n, at in pairs(Economy.nonces[account]) do
            if now - at > NONCE_TTL_MS then Economy.nonces[account][n] = nil end
        end
        if Economy.nonces[account][txn.nonce] then
            Economy.stats.rejected = Economy.stats.rejected + 1
            Economy.stats.signals = Economy.stats.signals + 1
            return false, {
                rejected = true, reason = 'duplicate transaction (nonce replay)',
                signal = {
                    source = type(account) == 'number' and account or nil,
                    category = C.CATEGORY.ECONOMY, severity = C.SEVERITY.HIGH, confidence = 0.9,
                    reason = 'duplicate economy transaction', metadata = { nonce = txn.nonce, reason_tag = txn.reason },
                },
            }
        end
        Economy.nonces[account][txn.nonce] = now
    end

    local signal = nil

    -- --- Montant incohérent (§20) : delta hors bornes de plausibilité.
    if math.abs(txn.delta) > MAX_SINGLE_DELTA then
        signal = {
            source = type(account) == 'number' and account or nil,
            category = C.CATEGORY.ECONOMY, severity = C.SEVERITY.HIGH, confidence = 0.75,
            reason = 'implausible transaction amount',
            metadata = { delta = txn.delta, max = MAX_SINGLE_DELTA, reason_tag = txn.reason },
        }
    end

    -- --- Séquence impossible (§20) : un retrait qui rendrait le solde négatif pour une
    -- source qui ne devrait pas le permettre. Le serveur REFUSE plutôt que d'accepter un
    -- solde négatif issu d'une manipulation.
    local after = before + txn.delta
    if after < 0 and txn.allow_negative ~= true then
        Economy.stats.rejected = Economy.stats.rejected + 1
        Economy.stats.signals = Economy.stats.signals + 1
        return false, {
            rejected = true, reason = 'transaction would produce negative balance',
            signal = {
                source = type(account) == 'number' and account or nil,
                category = C.CATEGORY.ECONOMY, severity = C.SEVERITY.MEDIUM, confidence = 0.7,
                reason = 'impossible sequence: negative balance', metadata = { before = before, delta = txn.delta },
            },
        }
    end

    -- --- Fréquence / récompense répétée (§20) : même raison trop souvent en fenêtre.
    if txn.reason then
        local count = pushRecent(account, txn.reason, now)
        if count > MAX_SAME_REASON_IN_WINDOW and not signal then
            signal = {
                source = type(account) == 'number' and account or nil,
                category = C.CATEGORY.ECONOMY, severity = C.SEVERITY.MEDIUM,
                confidence = math.min(0.5 + (count - MAX_SAME_REASON_IN_WINDOW) * 0.05, 0.9),
                reason = 'repeated reward / abnormal frequency',
                metadata = { reason_tag = txn.reason, count = count, window_ms = FREQUENCY_WINDOW_MS },
            }
        end
    end

    -- --- Appliquer : le solde autoritaire est mis à jour, la transaction tracée (§20).
    Economy.balances[account] = after
    local record = {
        transaction_id = Util.uuid('txn'),
        account = account,
        before = before,
        delta = txn.delta,
        after = after,
        reason = txn.reason,
        source = txn.source or 'system',
        context = txn.context,
        at = now,
        wallclock = Util.wallclock(),
    }
    Economy.ledger[account] = Economy.ledger[account] or {}
    local l = Economy.ledger[account]
    l[#l + 1] = record
    -- Historique borné (la persistance conserve le reste, §36).
    while #l > MAX_LEDGER_PER_ACCOUNT do table.remove(l, 1) end
    Economy.stats.applied = Economy.stats.applied + 1

    if signal then
        Economy.stats.signals = Economy.stats.signals + 1
        -- On applique la transaction MAIS on émet un signal : le serveur trace l'anomalie
        -- sans forcément bloquer une opération peut-être légitime (§11, deux-phases).
        if ZShield.Detection then ZShield.Detection.emit(signal) end
    end

    return true, { transaction = record, signal = signal }
end

--- Historique d'un compte (§20), le plus récent en dernier.
function Economy.history(account, n)
    local l = Economy.ledger[account] or {}
    if not n then return Util.deepCopy(l) end
    local out = {}
    for i = math.max(1, #l - n + 1), #l do out[#out + 1] = l[i] end
    return out
end

--- Récupère une transaction par id pour la chaîne de preuve (§29).
function Economy.getTransaction(account, txnId)
    local l = Economy.ledger[account] or {}
    for i = 1, #l do if l[i].transaction_id == txnId then return l[i] end end
    return nil
end

function Economy.onPlayerDrop(account)
    -- On garde le ledger (preuve/persistance) mais on libère les structures transitoires.
    Economy.recent[account] = nil
    Economy.nonces[account] = nil
end

function Economy.getStats()
    return Util.deepCopy(Economy.stats)
end

--- Enregistre un détecteur économique. La plupart des signaux économiques sont émis
--- directement par apply() ; ce détecteur permet une évaluation par batch si besoin.
function Economy.registerDetector()
    if not ZShield.Detection then return false, 'detection engine not loaded' end
    return ZShield.Detection.register({
        id = 'economy.integrity',
        category = C.CATEGORY.ECONOMY,
        version = 1,
        evaluate = function(evalCtx)
            if not evalCtx.economy_check then return nil end
            local acc = evalCtx.economy_check.account
            -- Vérification d'intégrité : le solde doit égaler la reconstruction.
            if Economy.balance(acc) ~= Economy.reconstruct(acc) then
                return {
                    source = type(acc) == 'number' and acc or nil,
                    category = C.CATEGORY.ECONOMY, severity = C.SEVERITY.CRITICAL, confidence = 0.95,
                    reason = 'ledger integrity mismatch',
                    metadata = { balance = Economy.balance(acc), reconstructed = Economy.reconstruct(acc) },
                }
            end
            return nil
        end,
    })
end

ZShield.Economy = Economy
