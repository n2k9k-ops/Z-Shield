--[[
    FILE:         server/detection/vehicle.lua
    PURPOSE:      Détecteur de véhicule serveur-autoritatif. Alimenté par la télémétrie
                  (état du véhicule occupé par le joueur). Détecte :
                    - réparation instantanée/répétée (vh_repair) ;
                    - vitesse impossible pour tout véhicule (vh_speed) ;
                    - changement de modèle en cours de session (vh_model).
    DEPENDENCIES: shared/constants.lua, core/log.lua, core/config.lua
    PUBLIC API:   ZShield.Vehicle.observe(source, sample, now)  -- pur/testable
                  ZShield.Vehicle.forget(source)
                  ZShield.Vehicle.register()

    §26 : on ÉMET ; la corrélation décide. La réparation monte en confiance avec la
    répétition (un joueur peut réparer une fois légitimement) ; la vitesse au-delà de
    toute borne physique est un signal direct mais reste en confiance modérée (lag).
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Log = ZShield.Log

local V = {}
V._ctx = {}   -- source -> { last_health, last_at, repair_streak, model }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function ctxOf(source)
    local c = V._ctx[source]
    if not c then c = { last_health = nil, last_at = 0, repair_streak = 0, model = nil }; V._ctx[source] = c end
    return c
end

--- Observe l'état du véhicule. `sample` : { vehicle_health, speed_ms, model }.
--- `now` en ms (injecté pour les tests).
function V.observe(source, sample, now)
    if not source then return nil end
    sample = sample or {}
    now = now or 0
    if not cfg('vehicle.detector', true) then return nil end

    local c = ctxOf(source)
    local best = nil
    local function consider(sig)
        if sig and (not best or sig.confidence > best.confidence) then best = sig end
    end

    -- Vitesse impossible : au-delà de toute borne physique de véhicule.
    local speed = tonumber(sample.speed_ms)
    if speed then
        local maxSpeed = tonumber(cfg('vehicle.max_speed_ms', 150)) or 150 -- ~540 km/h
        if speed > maxSpeed then
            consider({ severity = C.SEVERITY.HIGH, confidence = 0.7,
                reason = string.format('vehicle speed %d m/s over cap %d', speed, maxSpeed),
                protection = 'vh_speed' })
        end
    end

    -- Réparation : remontées fortes et rapprochées de la vie du véhicule (réparation
    -- instantanée répétée). On COMPTE les bonds vers le haut ; une casse intermédiaire
    -- ne remet pas à zéro — c'est le motif « abîmé puis re-full » qu'on cherche. Reset
    -- après un long calme.
    local vh = tonumber(sample.vehicle_health)
    if vh and c.last_health then
        local gain = vh - c.last_health
        if gain >= cfg('vehicle.repair_gain', 300) then
            if (now - (c.repair_at or 0)) > cfg('vehicle.repair_reset_ms', 5000) then
                c.repair_streak = 1
            else
                c.repair_streak = c.repair_streak + 1
            end
            c.repair_at = now
            if c.repair_streak >= 2 then
                consider({ severity = C.SEVERITY.MEDIUM,
                    confidence = math.min(0.4 + c.repair_streak * 0.12, 0.85),
                    reason = string.format('instant repair +%d (x%d)', gain, c.repair_streak),
                    protection = 'vh_repair' })
            end
        end
    end

    -- Changement de modèle en session (rare légitimement).
    if sample.model ~= nil then
        if c.model ~= nil and c.model ~= sample.model then
            consider({ severity = C.SEVERITY.LOW, confidence = 0.35,
                reason = 'vehicle model changed in session',
                protection = 'vh_model' })
        end
        c.model = sample.model
    end

    if vh then c.last_health = vh; c.last_at = now end

    if not best then return nil end
    best.category = C.CATEGORY.ENTITY
    best.source = source
    return best
end

function V.forget(source) V._ctx[source] = nil end

function V.register()
    if not ZShield.Detection then return false, 'detection engine not loaded' end
    return ZShield.Detection.register({
        id = 'vehicle.state',
        category = C.CATEGORY.ENTITY,
        version = 1,
        evaluate = function(evalCtx)
            if not evalCtx.vehicle then return nil end
            local s = evalCtx.vehicle
            return V.observe(s.source, s, s.now or 0)
        end,
    })
end

ZShield.Vehicle = V
return V
