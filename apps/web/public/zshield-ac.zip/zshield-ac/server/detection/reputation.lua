--[[
    FILE:         server/detection/reputation.lua
    PURPOSE:      Détecteur Reputation (§17). Un détecteur peut être techniquement sain
                  (HEALTH.HEALTHY) mais peu FIABLE : trop de faux positifs, ou trop lent.
                  Cette couche mesure la qualité de chaque détecteur et lui attribue un état
                  ACTIVE / DEGRADED / OBSERVATION / DISABLED. Un détecteur en OBSERVATION voit
                  ses signaux journalisés mais NE PEUT PLUS déclencher de sanction : on isole
                  un détecteur qui déraille sans casser toute la chaîne (§31, §17).
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua
    PUBLIC API:   ZShield.Reputation.record(detectorId, outcome)  -- 'confirmed'|'false_positive'|'signal'
                  ZShield.Reputation.state(detectorId) -> C.DETECTOR_STATE
                  ZShield.Reputation.weight(detectorId) -> multiplicateur [0..1]
                  ZShield.Reputation.report()

    Seuils volontairement prudents : on ne rétrograde pas un détecteur sur un incident isolé.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log

local Reputation = { metrics = {} }

local MIN_SAMPLES = 8        -- avant ce nombre de signaux, on ne juge pas
local FP_DEGRADE  = 0.30     -- >30 % de faux positifs => DEGRADED
local FP_OBSERVE  = 0.55     -- >55 % => OBSERVATION (ne sanctionne plus)

local function m(id)
    local x = Reputation.metrics[id]
    if not x then
        x = { signals = 0, confirmed = 0, false_positive = 0,
              state = C.DETECTOR_STATE.ACTIVE, updated = Util.now() }
        Reputation.metrics[id] = x
    end
    return x
end

--- Enregistre une issue pour un détecteur et recalcule son état.
function Reputation.record(detectorId, outcome)
    if type(detectorId) ~= 'string' then return end
    local x = m(detectorId)
    x.updated = Util.now()
    if outcome == 'confirmed' then x.confirmed = x.confirmed + 1
    elseif outcome == 'false_positive' then x.false_positive = x.false_positive + 1 end
    if outcome ~= 'disable' and outcome ~= 'enable' then x.signals = x.signals + 1 end

    -- Commandes explicites d'opérateur.
    if outcome == 'disable' then x.state = C.DETECTOR_STATE.DISABLED; return end
    if outcome == 'enable' then x.state = C.DETECTOR_STATE.ACTIVE; return end
    if x.state == C.DETECTOR_STATE.DISABLED then return end

    -- Pas assez d'échantillons : on laisse ACTIVE.
    local judged = x.confirmed + x.false_positive
    if judged < MIN_SAMPLES then x.state = C.DETECTOR_STATE.ACTIVE; return end

    local fpRate = x.false_positive / judged
    local prev = x.state
    if fpRate > FP_OBSERVE then
        x.state = C.DETECTOR_STATE.OBSERVATION
    elseif fpRate > FP_DEGRADE then
        x.state = C.DETECTOR_STATE.DEGRADED
    else
        x.state = C.DETECTOR_STATE.ACTIVE
    end
    if x.state ~= prev then
        Log:warn('reputation', 'detector reputation changed', {
            detector = detectorId, from = prev, to = x.state,
            fp_rate = string.format('%.2f', fpRate) })
    end
end

function Reputation.state(detectorId)
    local x = Reputation.metrics[detectorId]
    return x and x.state or C.DETECTOR_STATE.ACTIVE
end

--- Multiplicateur de poids appliqué au score d'un signal selon la réputation (§14, §22).
--- ACTIVE=1, DEGRADED=0.5, OBSERVATION=0 (compté mais n'alimente pas une sanction), DISABLED=0.
function Reputation.weight(detectorId)
    local s = Reputation.state(detectorId)
    if s == C.DETECTOR_STATE.ACTIVE then return 1.0 end
    if s == C.DETECTOR_STATE.DEGRADED then return 0.5 end
    return 0.0
end

--- Un signal peut-il contribuer à une sanction ? Non si OBSERVATION/DISABLED.
function Reputation.canEnforce(detectorId)
    local s = Reputation.state(detectorId)
    return s == C.DETECTOR_STATE.ACTIVE or s == C.DETECTOR_STATE.DEGRADED
end

function Reputation.report()
    return Util.deepCopy(Reputation.metrics)
end

ZShield.Reputation = Reputation
