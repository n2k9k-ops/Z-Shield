--[[
    FILE:         server/detection/ownership.lua
    PURPOSE:      CHURN D'OWNERSHIP RÉSEAU + FLOOD DE CRÉATION D'ENTITÉS. Deux motifs serveur
                  typiques des crashers, des entity-spammers et des trainers :
                    - prendre l'OWNERSHIP réseau d'un grand nombre d'entités en très peu de temps
                      (pour les manipuler / crasher les autres clients) ;
                    - CRÉER des entités à une cadence impossible manuellement (spam de véhicules/
                      objets/props).
                  Le serveur voit chaque prise d'ownership et chaque création : au-delà d'un
                  plafond par fenêtre, c'est un motif d'abus.

    100 % serveur, corrélant (§26).

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Ownership.observe(source, ev) -> signal|nil
                  ZShield.Ownership.forget(source) / .register()

    ev = { kind = 'ownership'|'create', now = ms }
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local O = {}
O._ev = {}   -- source -> { ownership = {ts...}, create = {ts...} }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function slide(list, now, windowMs)
    local kept = {}
    for _, t in ipairs(list) do if (now - t) <= windowMs then kept[#kept + 1] = t end end
    return kept
end

function O.observe(source, ev)
    if cfg('ownership.enabled', false) ~= true then return nil end
    if type(ev) ~= 'table' then return nil end
    local kind = tostring(ev.kind or 'ownership')
    local now = tonumber(ev.now) or Util.now()
    local windowMs = tonumber(cfg('ownership.window_ms', 3000)) or 3000

    local st = O._ev[source]
    if not st then st = { ownership = {}, create = {} }; O._ev[source] = st end
    local bucket = (kind == 'create') and st.create or st.ownership
    bucket = slide(bucket, now, windowMs)
    bucket[#bucket + 1] = now
    if kind == 'create' then st.create = bucket else st.ownership = bucket end

    local maxOwn = tonumber(cfg('ownership.max_ownership', 25)) or 25
    local maxCreate = tonumber(cfg('ownership.max_create', 20)) or 20
    local limit = (kind == 'create') and maxCreate or maxOwn

    if #bucket > limit then
        local isCreate = kind == 'create'
        return {
            detector = 'ownership',
            category = isCreate and C.CATEGORY.ENTITY or C.CATEGORY.NETWORK,
            severity = C.SEVERITY.HIGH, confidence = 0.6,
            reason = string.format('%d %s en %.0f s (max %d) — %s',
                #bucket, isCreate and 'créations dentités' or 'prises downership',
                windowMs / 1000, limit, isCreate and 'flood dentités' or 'churn downership'),
            source = source,
            metadata = { count = #bucket, limit = limit, kind = isCreate and 'entity_flood' or 'ownership_churn' },
        }
    end
    return nil
end

function O.forget(source) O._ev[source] = nil end

function O.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'ownership', category = C.CATEGORY.NETWORK,
            evaluate = function() return {} end })
    end
end

ZShield.Ownership = O
return O
