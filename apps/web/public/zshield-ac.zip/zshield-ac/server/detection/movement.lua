--[[
    FILE:         server/detection/movement.lua
    PURPOSE:      Analyse de mouvement (§15). PAS une règle simpliste « distance > X => ban ».
                  Analyse CONTEXTUELLE : téléports de confiance, latence, état, timing serveur.
                  Produit des signaux avec une confiance calibrée, pas des verdicts.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua, server/context.lua,
                  server/detection/engine.lua
    PUBLIC API:   ZShield.Movement.observe(source, position, opts)  -- appelé par télémétrie
                  ZShield.Movement.register()  -- enregistre le détecteur

    §15 : « Ne jamais utiliser une règle simpliste : distance > X => ban. Le moteur doit
    comprendre les téléportations légitimes enregistrées par le serveur. »

    Principe : la POSITION vient du client (assertion, §27), mais le serveur décide ce qui
    est plausible en tenant compte de ce que LUI sait : téléport qu'il a lui-même déclenché
    (§15), latence, état du joueur (mort = pas de mouvement attendu). Un saut inexpliqué
    devient un signal dont la CONFIANCE dépend du contexte, jamais un ban direct (§11).
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local Movement = {}

-- Distance euclidienne entre deux positions {x,y,z}.
local function distance(a, b)
    local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

--- Observe une position rapportée pour un joueur. `opts` peut contenir latency_ms.
--- Retourne un signal partiel (severity/confidence/reason/metadata) ou nil.
--- C'est la fonction qu'un détecteur appelle ; register() l'expose au moteur.
function Movement.analyze(source, position, opts)
    opts = opts or {}
    local ctx = ZShield.Context and ZShield.Context.get(source)
    if not ctx then return nil end
    if type(position) ~= 'table' or type(position.x) ~= 'number' then return nil end

    local cfg = ZShield.Config
    local maxSpeed = (cfg and cfg.value('movement.max_ground_speed_ms')) or 50.0
    local maxTickDist = (cfg and cfg.value('movement.max_tick_distance_m')) or 75.0

    local now = Util.now()
    local prev = ctx.last_position
    local prevAt = ctx.last_position_at

    -- Toujours mettre à jour la dernière position connue (reconstruction serveur).
    local result = nil

    if prev and prevAt then
        local dt = (now - prevAt) / 1000 -- secondes
        if dt > 0 then
            local d = distance(prev, position)
            local speed = d / dt

            -- 1. Un téléport de CONFIANCE enregistré par le serveur explique le saut (§15).
            local trusted = ZShield.Context.consumeTeleport(source)
            if trusted then
                -- Le saut correspond-il à la destination attendue ?
                local toDest = distance(position, trusted.to)
                if toDest <= (trusted.radius or 50.0) then
                    -- Déplacement légitime : aucun signal. On peut même réduire un risque
                    -- résiduel via une explication (§13), mais on reste sobre ici.
                    Movement._updatePos(ctx, position, now)
                    return nil
                end
                -- Téléport enregistré mais le joueur a atterri ailleurs : signal faible
                -- (peut-être bug de script, pas forcément triche).
                result = {
                    severity = C.SEVERITY.LOW, confidence = 0.35,
                    reason = 'teleport landed away from registered destination',
                    metadata = { expected = trusted.reason, offset_m = math.floor(toDest) },
                }
            end

            -- 2. État : un joueur DEAD ne devrait pas se déplacer.
            if not result and ctx.state == C.PLAYER_STATE.DEAD and d > 5 then
                result = {
                    severity = C.SEVERITY.MEDIUM, confidence = 0.6,
                    reason = 'movement while dead',
                    metadata = { distance_m = math.floor(d) },
                }
            end

            -- 3. Saut de distance par tick anormal (téléportation non enregistrée).
            if not result and d > maxTickDist then
                -- La confiance dépend de la latence : une latence élevée peut produire un
                -- rattrapage de position légitime. On ATTÉNUE la confiance quand la latence
                -- est haute plutôt que de bannir (§15, §26).
                local latency = opts.latency_ms or 0
                local confidence = 0.85
                if latency > 200 then confidence = 0.6 end
                if latency > 500 then confidence = 0.4 end -- forte latence : très incertain

                result = {
                    severity = C.SEVERITY.HIGH, confidence = confidence,
                    reason = 'teleport-like distance jump',
                    metadata = { distance_m = math.floor(d), dt_ms = math.floor(dt * 1000),
                                 latency_ms = latency, max_tick_m = maxTickDist },
                }

            -- 4. Vitesse au sol soutenue anormale (speedhack), hors saut ponctuel.
            elseif not result and speed > maxSpeed then
                -- Un dépassement ponctuel est moins probant qu'un dépassement soutenu.
                -- On compte les dépassements consécutifs pour monter la confiance.
                ctx._speed_streak = (ctx._speed_streak or 0) + 1
                local confidence = math.min(0.4 + ctx._speed_streak * 0.15, 0.9)
                result = {
                    severity = C.SEVERITY.HIGH, confidence = confidence,
                    reason = 'ground speed above plausible maximum',
                    metadata = { speed_ms = math.floor(speed), max_ms = maxSpeed,
                                 streak = ctx._speed_streak },
                }
            else
                -- Vitesse normale : réinitialise la série.
                ctx._speed_streak = 0
            end
        end
    end

    Movement._updatePos(ctx, position, now)

    if result then
        result.source = source
        result.category = C.CATEGORY.MOVEMENT
        result.scope = C.ANOMALY_SCOPE.PLAYER
    end
    return result
end

function Movement._updatePos(ctx, position, now)
    ctx.last_position = { x = position.x, y = position.y, z = position.z }
    ctx.last_position_at = now
end

--- Enregistre le détecteur de mouvement auprès du moteur. Le détecteur lit la dernière
--- observation stockée dans le contexte d'évaluation.
function Movement.register()
    if not ZShield.Detection then return false, 'detection engine not loaded' end
    return ZShield.Detection.register({
        id = 'movement.analysis',
        category = C.CATEGORY.MOVEMENT,
        version = 1,
        evaluate = function(evalCtx)
            -- evalCtx.movement = { source, position, latency_ms } fourni par la télémétrie.
            if not evalCtx.movement then return nil end
            local m = evalCtx.movement
            return Movement.analyze(m.source, m.position, { latency_ms = m.latency_ms })
        end,
    })
end

--- Point d'entrée direct pour la télémétrie : observe une position et émet le signal
--- résultant sur le bus (via Detection.emit). Utilisé quand on n'évalue pas en batch.
function Movement.observe(source, position, opts)
    local signal = Movement.analyze(source, position, opts)
    if signal and ZShield.Detection then
        ZShield.Detection.emit(signal)
    end
    return signal
end

ZShield.Movement = Movement
