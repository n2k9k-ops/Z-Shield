--[[
    FILE:         server/detection/fusion.lua
    PURPOSE:      FUSION BAYÉSIENNE MULTI-SIGNAUX. Chaque détecteur produit un indice faible ;
                  pris isolément il ne prouve rien (§26). La fusion combine TOUS ces indices en une
                  seule cote (log-odds) par joueur, façon Bayes naïf : chaque signal ajoute son
                  poids de preuve = log(confiance / (1-confiance)), pondéré par la gravité, avec
                  DÉCROISSANCE temporelle (un vieil indice pèse moins). Quand la cote combinée
                  franchit un seuil, on a une confiance COMPOSITE élevée — bien plus robuste que
                  n'importe quel détecteur seul, et calibrable.

                  Différent de « trainer » (qui compte des détecteurs DISTINCTS concomitants) :
                  ici on agrège la FORCE de preuve de tous les signaux, même répétés.

    RÉFÉRENCE : combinaison de preuves en log-odds (naive Bayes / log-likelihood fusion).

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Fusion.observe(source, sig) -> signal|nil
                  ZShield.Fusion.score(source, now) -> cote courante
                  ZShield.Fusion.forget(source) / .register()
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local F = {}
F._s = {}   -- source -> { odds, at }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local SEV_W = { LOW = 0.4, MEDIUM = 0.7, HIGH = 1.0, CRITICAL = 1.4 }

-- Applique la décroissance de la cote jusqu'à `now`.
local function decay(entry, now)
    if not entry then return 0 end
    local perSec = tonumber(cfg('fusion.decay_per_sec', 0.02)) or 0.02
    local dt = math.max(0, (now - (entry.at or now)) / 1000)
    local o = entry.odds - perSec * dt
    return math.max(0, o)
end

--- Intègre un signal partiel dans la cote combinée du joueur. Retourne un signal composite
--- si le seuil est franchi.
function F.observe(source, sig)
    if cfg('fusion.enabled', false) ~= true then return nil end
    if type(sig) ~= 'table' or not sig.source then return nil end
    -- On ne se re-fusionne pas soi-même (évite les boucles).
    if sig.detector == 'fusion' then return nil end
    local now = Util.now()
    local conf = tonumber(sig.confidence) or 0.3
    conf = math.max(0.01, math.min(0.95, conf))
    local w = SEV_W[sig.severity] or 0.7
    -- Poids de preuve = log-odds de la confiance, pondéré gravité.
    local evidence = w * math.log(conf / (1 - conf))
    -- Les indices « en faveur du tricheur » sont positifs ; on ne cumule que ceux-là (conf>0.5
    -- pousse vers +, conf<0.5 vers −, borné à 0 par la décroissance).
    local cur = decay(F._s[source], now)
    F._s[source] = { odds = cur + evidence, at = now }

    local threshold = tonumber(cfg('fusion.threshold', 4.0)) or 4.0
    if F._s[source].odds >= threshold then
        local odds = F._s[source].odds
        -- On abaisse la cote après émission pour ne pas spammer (une émission par franchissement).
        F._s[source].odds = threshold * 0.6
        -- Probabilité composite ≈ sigmoïde de la cote.
        local prob = 1 / (1 + math.exp(-odds))
        return {
            detector = 'fusion', category = C.CATEGORY.STATE,
            severity = C.SEVERITY.HIGH, confidence = math.min(0.92, prob),
            reason = string.format('faisceau d\'indices convergents (cote %.1f, p≈%.2f) — confiance composite', odds, prob),
            source = source, metadata = { odds = odds, prob = prob, kind = 'fusion' },
        }
    end
    return nil
end

function F.score(source, now) return decay(F._s[source], now or Util.now()) end
function F.forget(source) F._s[source] = nil end

function F.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'fusion', category = C.CATEGORY.STATE,
            evaluate = function() return {} end })
    end
end

ZShield.Fusion = F
return F
