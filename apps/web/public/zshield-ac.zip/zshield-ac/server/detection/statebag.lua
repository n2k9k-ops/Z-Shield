--[[
    FILE:         server/detection/statebag.lua
    PURPOSE:      ANTI-EXPLOIT DE STATE BAGS. Par défaut, un client (propriétaire réseau
                  de son ped/entité) peut écrire des clés de state bag RÉPLIQUÉES. Des
                  menus abusent de ça pour (1) usurper des drapeaux de gameplay (« isAdmin »,
                  « godmode », « job »…), (2) FLOOD le serveur de milliers de clés ou de
                  charges ~1 Mo pour le faire crasher (cf. Cfx issue #2361).

                  Défense côté serveur, en trois angles :
                    1. CLÉS PROTÉGÉES : une clé sensible modifiée par un CLIENT (et non le
                       serveur) est un incident — le serveur est la seule autorité.
                    2. CHARGE : une valeur au-delà d'une taille dure = tentative de crash.
                    3. FLOOD : trop de changements par joueur/fenêtre = tentative de crash.

                  RECOMMANDATION opérateur (server.cfg) : `setr sv_stateBagStrictMode true`
                  empêche nativement l'écriture cliente des state bags répliqués — c'est le
                  plus gros interrupteur. Ce module DÉTECTE en plus (et couvre les serveurs
                  qui ne peuvent pas activer le strict mode).

    Module PUR (aucune I/O, aucune native) : la glue l'alimente via
    AddStateBagChangeHandler. Testable hors FiveM.

    DEPENDENCIES: shared/constants.lua, core/config.lua
    PUBLIC API:   ZShield.StateBag.observe(ev) -> signal|nil
                      ev = { key, writer, value_bytes, from_client, source, now }
                  ZShield.StateBag.reset(source) / resetAll()
]]

ZShield = ZShield or {}
local C = ZShield.Const

local SB = { _ctx = {} }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function ctxOf(source)
    local c = SB._ctx[source]
    if not c then c = { start = nil, count = 0 }; SB._ctx[source] = c end
    return c
end

--- Politique d'une clé protégée : { writer = 'server' } signifie « seul le serveur
--- écrit cette clé ». Retourne la table de politique, ou nil.
local function policyFor(key)
    local prot = cfg('statebags.protect', nil)
    if type(prot) ~= 'table' then return nil end
    return prot[key]
end

--- Observe un changement de state bag. Retourne un signal d'incident, ou nil.
function SB.observe(ev)
    if cfg('statebags.enabled', true) ~= true then return nil end
    if type(ev) ~= 'table' or type(ev.key) ~= 'string' then return nil end
    local source = ev.source
    local now = tonumber(ev.now) or 0

    -- 1) CLÉ PROTÉGÉE écrite par un client (le serveur écrit sans `from_client`).
    local pol = policyFor(ev.key)
    if pol and (pol.writer == 'server' or pol.writer == nil) and ev.from_client == true then
        return {
            detector = 'statebag', category = C.CATEGORY.STATE,
            severity = C.SEVERITY and C.SEVERITY.HIGH or 'HIGH', confidence = 0.85,
            reason = string.format('clé de state bag protégée « %s » modifiée par un client', ev.key),
            source = source, metadata = { key = ev.key, kind = 'protected_key_client_write' },
        }
    end

    -- 2) CHARGE trop grosse (tentative de crash mémoire/bande passante).
    local maxBytes = tonumber(cfg('statebags.max_value_bytes', 65536)) or 65536
    if type(ev.value_bytes) == 'number' and ev.value_bytes > maxBytes then
        return {
            detector = 'statebag', category = C.CATEGORY.STATE,
            severity = C.SEVERITY and C.SEVERITY.HIGH or 'HIGH', confidence = 0.8,
            reason = string.format('charge de state bag anormale (%d octets) — tentative de crash', ev.value_bytes),
            source = source, metadata = { key = ev.key, bytes = ev.value_bytes, kind = 'oversized_payload' },
        }
    end

    -- 3) FLOOD : trop de changements par joueur dans la fenêtre.
    if source ~= nil and ev.from_client == true then
        local window = tonumber(cfg('statebags.window_ms', 10000)) or 10000
        local maxChanges = tonumber(cfg('statebags.max_changes', 60)) or 60
        local c = ctxOf(source)
        if c.start == nil or (now - c.start) > window then
            c.start = now; c.count = 0; c.flagged = false
        end
        c.count = c.count + 1
        if c.count > maxChanges and not c.flagged then
            c.flagged = true
            return {
                detector = 'statebag', category = C.CATEGORY.STATE,
                severity = C.SEVERITY and C.SEVERITY.MEDIUM or 'MEDIUM', confidence = 0.7,
                reason = string.format('flood de state bags (%d en %d ms)', c.count, window),
                source = source, metadata = { count = c.count, kind = 'flood' },
            }
        end
    end

    return nil
end

function SB.reset(source) SB._ctx[source] = nil end
function SB.resetAll() SB._ctx = {} end

ZShield.StateBag = SB
return SB
