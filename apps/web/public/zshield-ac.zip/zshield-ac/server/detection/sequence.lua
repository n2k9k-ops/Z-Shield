--[[
    FILE:         server/detection/sequence.lua
    PURPOSE:      PROVENANCE CAUSALE / SÉQUENCES IMPOSSIBLES. Beaucoup de triches produisent
                  des actions dont le PRÉ-REQUIS n'a jamais eu lieu côté serveur :
                    - tirer / infliger des dégâts EN ÉTANT MORT (état serveur = mort) ;
                    - utiliser une arme JAMAIS DONNÉE par le serveur (injection d'inventaire) ;
                    - agir AVANT le spawn (pré-spawn exploit).
                  Le serveur tient l'état causal (vivant, spawné, armes accordées) et rejette
                  ce qui n'a pas de cause légitime. 100 % serveur-autoritatif.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Sequence.observe(source, event) -> signal|nil
                  ZShield.Sequence.forget(source) / .register()

    event.type :
      'spawn'        -> marque spawné + vivant
      'death'        -> marque mort
      'give_weapon'  -> event.weapon accordé par le serveur
      'remove_weapon'-> event.weapon retiré
      'fire' | 'damage' -> action offensive (event.weapon optionnel) : c'est ce qu'on VALIDE
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local SEQ = {}
SEQ._st = {}   -- source -> { alive, spawned, weapons = {} }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function state(source)
    local s = SEQ._st[source]
    if not s then s = { alive = true, spawned = true, weapons = {} }; SEQ._st[source] = s end
    return s
end

local function sig(source, kind, reason, sev, conf)
    return {
        detector = 'sequence', category = C.CATEGORY.EVENT,
        severity = sev or C.SEVERITY.HIGH, confidence = conf or 0.6,
        reason = reason, source = source, metadata = { kind = kind },
    }
end

function SEQ.observe(source, event)
    if cfg('sequence.enabled', false) ~= true then return nil end
    if type(event) ~= 'table' then return nil end
    local s = state(source)
    local t = event.type

    if t == 'spawn' then s.spawned = true; s.alive = true; return nil
    elseif t == 'death' then s.alive = false; return nil
    elseif t == 'give_weapon' then if event.weapon ~= nil then s.weapons[event.weapon] = true end; return nil
    elseif t == 'remove_weapon' then if event.weapon ~= nil then s.weapons[event.weapon] = nil end; return nil
    elseif t == 'fire' or t == 'damage' then
        -- 1) Action avant spawn.
        if cfg('sequence.check_spawn', true) == true and not s.spawned then
            return sig(source, 'action_before_spawn', 'action offensive avant le spawn', C.SEVERITY.HIGH, 0.6)
        end
        -- 2) Action en étant mort (état serveur).
        if cfg('sequence.check_dead', true) == true and not s.alive then
            return sig(source, 'action_while_dead', 'tir/dégât en étant mort (état serveur)', C.SEVERITY.HIGH, 0.7)
        end
        -- 3) Arme jamais accordée par le serveur (provenance d'inventaire).
        if cfg('sequence.check_weapon_provenance', true) == true
            and event.weapon ~= nil and not s.weapons[event.weapon] then
            return sig(source, 'weapon_never_given',
                'arme utilisée jamais accordée par le serveur (injection)', C.SEVERITY.HIGH, 0.6)
        end
        return nil
    end
    return nil
end

function SEQ.forget(source) SEQ._st[source] = nil end

function SEQ.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'sequence', category = C.CATEGORY.EVENT,
            evaluate = function() return {} end })
    end
end

ZShield.Sequence = SEQ
return SEQ
