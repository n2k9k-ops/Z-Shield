--[[
    FILE:         server/detection/trainer.lua
    PURPOSE:      MÉTA-DÉTECTEUR « SIGNATURE DE TRAINER / MENU ». Un menu de triche fait
                  rarement UNE chose : il enchaîne noclip + god mode + give-all + spawn, etc.
                  Chaque signal isolé peut être un faux positif ; leur CONCOMITANCE, elle,
                  est une signature quasi certaine. Ce module agrège les signaux DÉJÀ produits
                  par les autres détecteurs et lève un signal de FORTE confiance quand
                  plusieurs détecteurs DISTINCTS et sérieux frappent le même joueur dans une
                  courte fenêtre.

    C'est de la corrélation serveur — il ne lit rien de neuf, il combine. Il renforce le
    risque sans jamais bannir sur un détecteur unique (§26).

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Trainer.observeSignal(source, sig) -> signal|nil
                  ZShield.Trainer.forget(source) / .register()

    sig = { detector = string, severity = C.SEVERITY.*, now = ms }
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local TR = {}
TR._seen = {}   -- source -> { [detector] = last_ts }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local SERIOUS = { [C.SEVERITY.HIGH] = true, [C.SEVERITY.CRITICAL] = true }

function TR.observeSignal(source, sig)
    if cfg('trainer.enabled', false) ~= true then return nil end
    if type(sig) ~= 'table' or type(sig.detector) ~= 'string' then return nil end
    -- Par défaut on ne combine que des signaux SÉRIEUX (HIGH/CRITICAL) ; configurable.
    if cfg('trainer.serious_only', true) == true and not SERIOUS[sig.severity] then return nil end

    local now = tonumber(sig.now) or Util.now()
    local windowMs = tonumber(cfg('trainer.window_ms', 15000)) or 15000

    local seen = TR._seen[source] or {}
    seen[sig.detector] = now
    -- Purge des détecteurs hors fenêtre.
    local distinct = 0
    for det, ts in pairs(seen) do
        if (now - ts) > windowMs then seen[det] = nil else distinct = distinct + 1 end
    end
    TR._seen[source] = seen

    local minDistinct = tonumber(cfg('trainer.min_distinct', 3)) or 3
    if distinct >= minDistinct then
        -- Confiance élevée (concomitance rare), mais on laisse l'incident/enforcement
        -- décider : le méta-signal ne bannit pas lui-même.
        local names = {}
        for det in pairs(seen) do names[#names + 1] = det end
        table.sort(names)
        return {
            detector = 'trainer', category = C.CATEGORY.RESOURCE,
            severity = C.SEVERITY.CRITICAL, confidence = math.min(0.9, 0.6 + 0.1 * distinct),
            reason = string.format('signature de menu : %d détecteurs sérieux concomitants (%s)',
                distinct, table.concat(names, ', ')),
            source = source, metadata = { distinct = distinct, detectors = names, kind = 'trainer' },
        }
    end
    return nil
end

function TR.forget(source) TR._seen[source] = nil end

function TR.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'trainer', category = C.CATEGORY.RESOURCE,
            evaluate = function() return {} end })
    end
end

ZShield.Trainer = TR
return TR
