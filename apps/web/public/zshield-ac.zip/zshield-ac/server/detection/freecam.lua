--[[
    FILE:         server/detection/freecam.lua
    PURPOSE:      Détecteur FREECAM / SPECTATE abusif — HEURISTIQUE SERVEUR. La caméra libre
                  découple la vue du ped : le joueur observe (souvent pour repérer/viser à
                  travers la carte) pendant que son PED reste FIGÉ. Le serveur ne voit pas la
                  caméra, mais il voit deux choses : (1) la position du ped ne change plus, et
                  (2) le joueur reste ACTIF (il génère des events de visée/tir/interaction) —
                  donc il n'est ni AFK ni déconnecté. Figé + actif de façon prolongée = signal.

    HONNÊTETÉ : c'est une HEURISTIQUE serveur, plus faible qu'une lecture caméra côté client.
    Elle est réelle (l'option change le comportement du serveur, elle émet un vrai signal) et
    CORRÉLANTE : elle nourrit le risque, ne bannit jamais seule (§26). Le module client la
    précise (divergence caméra/ped), mais ce détecteur tient SANS client.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Freecam.observe(source, sample) -> signal|nil
                  ZShield.Freecam.forget(source) / .register()

    sample = { pos = {x,y,z}, active = bool, dead = bool, now = ms }
      active : le joueur a produit un event non-idle (aim/tir/interaction) depuis le dernier échantillon
      dead   : ped mort (mouvement figé LÉGITIME) -> neutralise
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local FC = {}
FC._st = {}   -- source -> { pos, static_since, activity }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function moved(a, b, eps)
    if not a then return true end
    local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
    return (dx * dx + dy * dy + dz * dz) > (eps * eps)
end

function FC.observe(source, sample)
    if cfg('freecam.enabled', false) ~= true then return nil end
    if type(sample) ~= 'table' or type(sample.pos) ~= 'table' then return nil end
    local now = tonumber(sample.now) or Util.now()
    local eps = tonumber(cfg('freecam.epsilon_m', 0.5)) or 0.5

    local st = FC._st[source]
    if not st then st = { pos = nil, static_since = nil, activity = 0, fired = false }; FC._st[source] = st end

    -- Un ped mort figé est normal : on réinitialise et on sort.
    if sample.dead == true then
        st.pos = sample.pos; st.static_since = nil; st.activity = 0; st.fired = false
        return nil
    end

    if moved(st.pos, sample.pos, eps) then
        -- Le ped a bougé : ce n'est pas une caméra libre. Reset.
        st.pos = sample.pos; st.static_since = now; st.activity = 0; st.fired = false
        return nil
    end

    -- Ped immobile : on démarre le chrono et on compte l'activité non-idle.
    if not st.static_since then st.static_since = now end
    if sample.active == true then st.activity = st.activity + 1 end

    local holdMs = tonumber(cfg('freecam.hold_ms', 4000)) or 4000
    local minAct = tonumber(cfg('freecam.min_activity', 5)) or 5
    local heldFor = now - st.static_since

    if heldFor >= holdMs and st.activity >= minAct and not st.fired then
        st.fired = true   -- une émission par épisode (jusqu'au prochain mouvement)
        return {
            detector = 'freecam',
            category = C.CATEGORY.MOVEMENT,
            severity = C.SEVERITY.MEDIUM,
            confidence = 0.5,
            reason = string.format('ped figé %.1f s en restant actif (%d events) — freecam probable',
                heldFor / 1000, st.activity),
            source = source,
            metadata = { held_ms = heldFor, activity = st.activity, kind = 'freecam' },
        }
    end
    return nil
end

function FC.forget(source) FC._st[source] = nil end

function FC.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'freecam', category = C.CATEGORY.MOVEMENT,
            evaluate = function() return {} end })
    end
end

ZShield.Freecam = FC
return FC
