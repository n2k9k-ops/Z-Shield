--[[
    FILE:         server/detection/markov.lua
    PURPOSE:      ANALYSE DE SÉQUENCES D'ACTIONS (chaîne de Markov / n-gramme + entropie). Un
                  humain enchaîne ses actions de façon variée ; un SCRIPT/MACRO produit des
                  séquences très RÉPÉTITIVES (peu de transitions distinctes) ou des transitions
                  IMPOSSIBLES (ex. recharger→recharger→recharger sans tirer). On modélise le flux
                  d'actions en bigrammes (transition action→action), et on signale :
                    - une ENTROPIE de transition très basse sur un volume suffisant (comportement
                      scripté, quasi déterministe) ;
                    - une TRANSITION INTERDITE déclarée par l'opérateur (séquence causale impossible).

    RÉFÉRENCE : modélisation de séquences (chaînes de Markov / n-grammes) pour la détection de
    bots ; entropie de Shannon comme mesure de régularité.

    DEPENDENCIES: shared/constants.lua, core/config.lua
    PUBLIC API:   ZShield.Markov.observe(source, action) -> signal|nil
                  ZShield.Markov.forget(source) / .register()
]]

ZShield = ZShield or {}
local C = ZShield.Const

local MK = {}
MK._s = {}   -- source -> { last, nxt = { [a] = { [b]=count } }, tot = { [a]=count }, alpha = {}, total }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function forbidden(a, b)
    local list = cfg('markov.forbidden', nil)
    if type(list) ~= 'table' then return false end
    local key = tostring(a) .. '>' .. tostring(b)
    for _, p in ipairs(list) do if p == key then return true end end
    return list[key] == true
end

-- Entropie CONDITIONNELLE normalisée H(suivant|précédent) ∈ [0,1]. Un cycle DÉTERMINISTE
-- (A→B→A→B ou A→A→A) donne 0 même s'il est « équilibré » globalement : depuis un état donné,
-- le suivant est toujours le même. C'est la bonne mesure de « scripté ».
local function condEntropy(s)
    if s.total <= 0 then return 1 end
    local alpha = 0
    for _ in pairs(s.alpha) do alpha = alpha + 1 end
    if alpha <= 1 then return 0 end     -- une seule action jamais variée = totalement prévisible
    local norm = math.log(alpha)
    local weighted = 0
    for a, nexts in pairs(s.nxt) do
        local la = s.tot[a] or 0
        if la > 0 then
            local Ha = 0
            for _, cnt in pairs(nexts) do
                local p = cnt / la
                if p > 0 then Ha = Ha - p * math.log(p) end
            end
            weighted = weighted + la * Ha
        end
    end
    return (weighted / s.total) / norm
end

function MK.observe(source, action)
    if cfg('markov.enabled', false) ~= true then return nil end
    if action == nil then return nil end
    action = tostring(action)
    local s = MK._s[source]
    if not s then s = { last = nil, nxt = {}, tot = {}, alpha = {}, total = 0 }; MK._s[source] = s end
    s.alpha[action] = true

    if s.last ~= nil then
        -- 1) Transition interdite (séquence causale impossible).
        if forbidden(s.last, action) then
            local a, b = s.last, action
            s.last = action
            return {
                detector = 'markov', category = C.CATEGORY.EVENT,
                severity = C.SEVERITY.HIGH, confidence = 0.6,
                reason = string.format('transition interdite %s→%s (séquence impossible)', a, b),
                source = source, metadata = { from = a, to = b, kind = 'forbidden_transition' },
            }
        end
        local a = s.last
        s.nxt[a] = s.nxt[a] or {}
        s.nxt[a][action] = (s.nxt[a][action] or 0) + 1
        s.tot[a] = (s.tot[a] or 0) + 1
        s.total = s.total + 1
    end
    s.last = action

    -- 2) Entropie conditionnelle trop basse sur un volume suffisant -> comportement scripté.
    local minEvents = tonumber(cfg('markov.min_events', 30)) or 30
    if s.total >= minEvents then
        local H = condEntropy(s)
        local minH = tonumber(cfg('markov.min_entropy', 0.25)) or 0.25
        if H < minH then
            s.nxt = {}; s.tot = {}; s.total = 0   -- réarme après signalement
            return {
                detector = 'markov', category = C.CATEGORY.EVENT,
                severity = C.SEVERITY.MEDIUM, confidence = 0.55,
                reason = string.format('séquence d\'actions quasi déterministe (entropie %.2f) — script/macro', H),
                source = source, metadata = { entropy = H, kind = 'low_entropy' },
            }
        end
    end
    return nil
end

function MK.forget(source) MK._s[source] = nil end

function MK.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'markov', category = C.CATEGORY.EVENT,
            evaluate = function() return {} end })
    end
end

ZShield.Markov = MK
return MK
