--[[
    FILE:         server/detection/injection.lua
    PURPOSE:      Système de « traces » d'injection. Le serveur ne voit pas l'injection
                  d'un menu, mais il voit ses CONSÉQUENCES : des actions qu'un client
                  honnête ne peut pas produire. Chacune est une TRACE, avec un poids de
                  preuve. Quand un joueur cumule assez de traces CONFIRMÉES, on ouvre un
                  incident CRITIQUE menant à un bannissement immédiat.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua, core/config.lua
    PUBLIC API:   ZShield.Injection.trace(source, kind, meta) -> total, banNow
                  ZShield.Injection.total(source)
                  ZShield.Injection.shouldBan(source)
                  ZShield.Injection.incidentFor(source)   -- spec pour le moteur de sanction
                  ZShield.Injection.reset(source)
                  ZShield.Injection.report(source, kind, meta) -- trace + incident si seuil

    IMPORTANT : une trace n'est enregistrée que lorsqu'elle est CONFIRMÉE côté serveur
    (§26). On ne bannit jamais sur une supposition ni sur l'écran du joueur. Le seuil est
    calibré pour qu'UNE preuve E5 (event fantôme, export interdit) suffise, ou DEUX preuves
    E4 (event serveur réservé appelé depuis le client, exécution hors ressource).
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log

local Injection = {}

-- Types de traces et poids de preuve (0..5). Alignés sur l'échelle E0..E5 (§15).
Injection.WEIGHTS = {
    phantom_event               = 5, -- event déclenché qui n'existe dans aucune ressource
    forbidden_export            = 5, -- appel d'un export interdit / inexistant
    protected_event_from_client = 4, -- event serveur réservé déclenché depuis un client
    exec_outside_resource       = 4, -- exécution hors du contexte de ressource attendu
    spoofed_identifier          = 3, -- identifiants incohérents (spoofer)
    unexpected_resource_start   = 4, -- ressource non déclarée qui démarre
    server_dump                 = 4, -- énumération/dump d'events serveur (outil de vol de fichiers)
}

Injection._ctx = {}   -- source -> { total, traces = { {kind, weight, at, meta} } }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function ctxOf(source)
    local c = Injection._ctx[source]
    if not c then c = { total = 0, traces = {} }; Injection._ctx[source] = c end
    return c
end

--- Une ressource est-elle de confiance (à ignorer) ? Liste pilotée par l'opérateur
--- (« Ignored Scripts ») pour éviter les faux positifs sur des scripts connus.
local function ignoredResource(name)
    if name == nil then return false end
    local list = cfg('injection.ignored_resources', nil)
    if type(list) ~= 'table' then return false end
    for _, v in ipairs(list) do if v == name then return true end end
    return list[name] == true
end

--- Signature de triche connue (« Anti Synaps » & co.) : un nom d'export/global/
--- ressource figurant dans la liste des signatures est une trace forte immédiate.
--- Retourne l'incident si le seuil est atteint, sinon nil.
function Injection.signatureHit(source, name, meta)
    if not source or type(name) ~= 'string' then return nil end
    local sigs = cfg('injection.cheat_signatures', nil)
    if type(sigs) ~= 'table' then return nil end
    local low = name:lower()
    for _, s in ipairs(sigs) do
        if type(s) == 'string' and s ~= '' and low:find(s:lower(), 1, true) then
            return Injection.report(source, 'forbidden_export',
                { signature = s, name = name, meta = meta })
        end
    end
    return nil
end

--- Enregistre une trace CONFIRMÉE. Retourne (total, banNow).
function Injection.trace(source, kind, meta)
    if not source or not kind then return 0, false end
    local weight = Injection.WEIGHTS[kind]
    if not weight then return Injection.total(source), Injection.shouldBan(source) end

    -- Ressource de confiance : on n'enregistre PAS la trace (évite les faux positifs).
    if type(meta) == 'table' and ignoredResource(meta.resource) then
        return Injection.total(source), Injection.shouldBan(source)
    end
    -- Motif d'exécution exempté (« Execution Patterns Exceptions ») : idem.
    if type(meta) == 'table' and meta.pattern ~= nil then
        local ex = cfg('injection.execution_exceptions', nil)
        if type(ex) == 'table' then
            for _, p in ipairs(ex) do
                if p == meta.pattern then return Injection.total(source), Injection.shouldBan(source) end
            end
        end
    end

    local c = ctxOf(source)
    c.total = c.total + weight
    c.traces[#c.traces + 1] = { kind = kind, weight = weight, at = Util.now(), meta = meta }
    if Log then
        Log:security('injection', 'trace confirmée', {
            source = source, kind = kind, weight = weight, total = c.total,
        })
    end
    return c.total, Injection.shouldBan(source)
end

function Injection.total(source)
    local c = Injection._ctx[source]
    return c and c.total or 0
end

--- Seuil de bannissement : par défaut 5 (une preuve E5, ou deux E4 = 8).
function Injection.shouldBan(source)
    return Injection.total(source) >= (tonumber(cfg('injection.trace_threshold', 5)) or 5)
end

--- Construit la spéc d'incident CRITIQUE pour un ban immédiat. La sévérité CRITICAL
--- court-circuite la deux-phases (§87) ; risque et confiance au maximum -> PERM_BAN.
function Injection.incidentFor(source)
    local c = Injection._ctx[source]
    local kinds = {}
    if c then for _, t in ipairs(c.traces) do kinds[#kinds + 1] = t.kind end end
    return {
        source = source,
        detector = 'injection.traces',
        category = C.CATEGORY.RESOURCE,
        severity = C.SEVERITY.CRITICAL,
        confidence = 0.98,
        risk_after = 100,
        occurrences = 2,               -- déjà « confirmé » : pas d'observation préalable
        protection = 'inj_traces',
        instant_ban = true,
        -- « Stop Server on Backdoor » : demande d'arrêt du serveur si l'opérateur
        -- l'a choisi. Le moteur de sanction / l'adaptateur lit ce drapeau.
        stop_server = cfg('injection.stop_on_backdoor', false) == true,
        reason = 'confirmed injection traces: ' .. table.concat(kinds, ', '),
        evidence_level = C.EVIDENCE.E5,
    }
end

--- Enregistre une trace et, si le seuil est atteint, ouvre l'incident de ban immédiat.
--- Retourne l'incident ouvert (ou nil).
function Injection.report(source, kind, meta)
    local _, banNow = Injection.trace(source, kind, meta)
    if banNow and ZShield.Incident and ZShield.Incident.open then
        return ZShield.Incident.open(Injection.incidentFor(source))
    end
    return nil
end

--- Entrée Lua injectée côté client exécutée dans un contexte serveur : trace forte
--- si l'opérateur active « Anti LUA Input ». Retourne l'incident si seuil atteint.
function Injection.luaInput(source, meta)
    if not source or cfg('injection.anti_lua_input', false) ~= true then return nil end
    return Injection.report(source, 'exec_outside_resource', meta)
end

--- Injection « non isolée » (contourne l'isolation des ressources) : trace forte si
--- l'opérateur active l'option expérimentale « Anti Unisolated Injection ».
function Injection.unisolated(source, meta)
    if not source or cfg('injection.anti_unisolated', false) ~= true then return nil end
    return Injection.report(source, 'exec_outside_resource', meta)
end

function Injection.reset(source) Injection._ctx[source] = nil end

ZShield.Injection = Injection
return Injection
