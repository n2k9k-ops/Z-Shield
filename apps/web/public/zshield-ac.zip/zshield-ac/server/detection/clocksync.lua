--[[
    FILE:         server/detection/clocksync.lua
    PURPOSE:      COHÉRENCE D'HORLOGE (anti-speedhack par manipulation du temps). Certains hacks
                  accélèrent l'horloge locale du jeu pour agir plus vite (speedhack « time scale »).
                  Le serveur compare l'écoulement du temps CÔTÉ CLIENT (horodatages rapportés) à
                  son PROPRE temps : si le temps client avance nettement plus vite que le temps
                  serveur sur une fenêtre (ratio > tolérance), l'horloge est accélérée.

                  Robuste au jitter : on mesure un RATIO cumulé sur plusieurs échantillons, pas un
                  écart ponctuel. Un ralentissement (lag) n'est pas puni ; seul l'excès l'est.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.ClockSync.observe(source, sample) -> signal|nil
                  ZShield.ClockSync.forget(source) / .register()

    sample = { client_ts = ms (horloge client), now = ms (horloge serveur) }
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local CK = {}
CK._s = {}   -- source -> { last_c, last_s, c_sum, s_sum, n }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

function CK.observe(source, sample)
    if cfg('clocksync.enabled', false) ~= true then return nil end
    if type(sample) ~= 'table' then return nil end
    local c = tonumber(sample.client_ts)
    local sv = tonumber(sample.now) or Util.now()
    if not c then return nil end

    local st = CK._s[source]
    if not st then CK._s[source] = { last_c = c, last_s = sv, c_sum = 0, s_sum = 0, n = 0 }; return nil end

    local dc = c - st.last_c
    local ds = sv - st.last_s
    st.last_c = c; st.last_s = sv
    -- On ignore les pas non positifs (rejeu/horloge remise à zéro géré ailleurs).
    if dc <= 0 or ds <= 0 then return nil end

    st.c_sum = st.c_sum + dc
    st.s_sum = st.s_sum + ds
    st.n = st.n + 1

    local minN = tonumber(cfg('clocksync.min_samples', 8)) or 8
    if st.n < minN or st.s_sum <= 0 then return nil end

    local ratio = st.c_sum / st.s_sum   -- >1 : le temps client avance plus vite que le serveur
    local maxRatio = tonumber(cfg('clocksync.max_ratio', 1.15)) or 1.15
    if ratio > maxRatio then
        -- Réarme la fenêtre après signalement.
        st.c_sum, st.s_sum, st.n = 0, 0, 0
        return {
            detector = 'clocksync', category = C.CATEGORY.MOVEMENT,
            severity = C.SEVERITY.HIGH, confidence = 0.6,
            reason = string.format('horloge client accélérée ×%.2f vs serveur — speedhack (time scale)', ratio),
            source = source, metadata = { ratio = ratio, kind = 'timescale' },
        }
    end
    return nil
end

function CK.forget(source) CK._s[source] = nil end

function CK.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'clocksync', category = C.CATEGORY.MOVEMENT,
            evaluate = function() return {} end })
    end
end

ZShield.ClockSync = CK
return CK
