--[[
    FILE:         server/detection/hitreg.lua
    PURPOSE:      VALIDATION DE TIR AVEC COMPENSATION DE LATENCE (hit-registration serveur). Un
                  tir « touché » signalé par le client n'est accepté que s'il est GÉOMÉTRIQUEMENT
                  possible : le serveur garde un HISTORIQUE de positions par joueur, REMBOBINE la
                  position de la victime au moment du tir (position - latence, bornée par une
                  fenêtre max), puis vérifie :
                    - la distance tireur→victime(passée) ≤ portée de l'arme ;
                    - (si direction de visée fournie) l'angle entre la visée et la victime rembobinée
                      ≤ tolérance — sinon « touche » revendiquée sans ligne de visée = silent-aim.
                  Une touche impossible même après compensation est rejetée. C'est le standard des
                  jeux serveur-autoritaires (lag compensation / rewind).

    RÉFÉRENCES : validation de hit serveur-autoritaire (AccelByte ; Roblox « Rewind » ; lag
    compensation Source/valve). Adapté à la DÉTECTION (rejeter l'impossible), pas au gameplay.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.HitReg.record(victim, pos, now)          -- historique de positions
                  ZShield.HitReg.validate(attacker, victim, hit) -> signal|nil
                  ZShield.HitReg.forget(source) / .register()

    hit = { origin={x,y,z}, aim={x,y,z}?, latency_ms=number, weapon=?, range=number?, now=ms }
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local HR = {}
HR._hist = {}   -- victim -> ring de { pos, at }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function dist(a, b)
    local dx, dy, dz = a.x - b.x, a.y - b.y, (a.z or 0) - (b.z or 0)
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

--- Enregistre la position d'une victime potentielle (télémétrie de mouvement).
function HR.record(victim, pos, now)
    if type(pos) ~= 'table' then return end
    now = tonumber(now) or Util.now()
    local h = HR._hist[victim] or {}
    h[#h + 1] = { pos = pos, at = now }
    -- Borne l'historique à la fenêtre de rewind + marge.
    local maxAge = (tonumber(cfg('hitreg.max_rewind_ms', 1000)) or 1000) + 500
    local cut = now - maxAge
    while h[1] and h[1].at < cut do table.remove(h, 1) end
    HR._hist[victim] = h
end

-- Retourne la position de la victime la plus proche de l'instant `t`.
local function posAt(victim, t)
    local h = HR._hist[victim]; if not h or #h == 0 then return nil end
    local best, bestd
    for _, e in ipairs(h) do
        local d = math.abs(e.at - t)
        if not bestd or d < bestd then bestd, best = d, e.pos end
    end
    return best
end

-- Angle (degrés) entre deux vecteurs.
local function angleDeg(a, b)
    local dot = a.x * b.x + a.y * b.y + (a.z or 0) * (b.z or 0)
    local na = math.sqrt(a.x * a.x + a.y * a.y + (a.z or 0) ^ 2)
    local nb = math.sqrt(b.x * b.x + b.y * b.y + (b.z or 0) ^ 2)
    if na < 1e-6 or nb < 1e-6 then return 0 end
    local c = math.max(-1, math.min(1, dot / (na * nb)))
    return math.deg(math.acos(c))
end

--- Valide une touche. Retourne un signal si elle est impossible même après compensation.
function HR.validate(attacker, victim, hit)
    if cfg('hitreg.enabled', false) ~= true then return nil end
    if type(hit) ~= 'table' or type(hit.origin) ~= 'table' then return nil end
    local now = tonumber(hit.now) or Util.now()
    local maxRewind = tonumber(cfg('hitreg.max_rewind_ms', 1000)) or 1000
    local lat = math.min(tonumber(hit.latency_ms) or 0, maxRewind)
    local vpos = posAt(victim, now - lat) or posAt(victim, now)
    if not vpos then return nil end   -- pas d'historique : on ne juge pas

    -- 1) Portée : la victime rembobinée est-elle à portée de l'arme ?
    local d = dist(hit.origin, vpos)
    local range = tonumber(hit.range) or tonumber(cfg('hitreg.default_range', 120)) or 120
    if d > range then
        return {
            detector = 'hitreg', category = C.CATEGORY.DAMAGE,
            severity = C.SEVERITY.HIGH, confidence = 0.65,
            reason = string.format('touche impossible : cible à %.0f m > portée %.0f m (après compensation)', d, range),
            source = attacker, metadata = { dist = d, range = range, kind = 'range_impossible' },
        }
    end

    -- 2) Ligne de visée : si l'aim est fourni, l'angle vers la victime doit être serré.
    if type(hit.aim) == 'table' then
        local toV = { x = vpos.x - hit.origin.x, y = vpos.y - hit.origin.y, z = (vpos.z or 0) - (hit.origin.z or 0) }
        local ang = angleDeg(hit.aim, toV)
        local tol = tonumber(cfg('hitreg.angle_tol_deg', 12)) or 12
        if ang > tol then
            return {
                detector = 'hitreg', category = C.CATEGORY.DAMAGE,
                severity = C.SEVERITY.HIGH, confidence = 0.6,
                reason = string.format('touche hors ligne de visée : %.0f° d\'écart (tol %.0f°) — silent-aim', ang, tol),
                source = attacker, metadata = { angle = ang, tol = tol, kind = 'no_los' },
            }
        end
    end
    return nil
end

function HR.forget(source) HR._hist[source] = nil end

function HR.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'hitreg', category = C.CATEGORY.DAMAGE,
            evaluate = function() return {} end })
    end
end

ZShield.HitReg = HR
return HR
