--[[
    FILE:         server/detection/provenance.lua
    PURPOSE:      PROVENANCE DES GAINS (anti-duplication / anti-injection économique). Le
                  principe le plus fort contre l'argent/objet injecté : tout GAIN doit avoir
                  une SOURCE LÉGITIME connue du serveur, survenue peu avant. Un magasin, une
                  paie, une récompense enregistrent une source ; quand un gain arrive, on
                  cherche une source correspondante dans la fenêtre. Aucune source -> le gain
                  est INEXPLIQUÉ = signal d'injection.

    SERVEUR-AUTORITATIF par construction : le serveur est seul à enregistrer les sources
    légitimes (via l'intégration des ressources : shops, jobs, coffres). Le client peut
    prétendre « +50 000 $ » ; sans source serveur correspondante, c'est refusé.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Provenance.registerSource(source, entry)  -- côté ressources légit
                  ZShield.Provenance.observe(source, gain) -> signal|nil
                  ZShield.Provenance.forget(source) / .register()

    entry / gain = { kind = 'money'|'item'|..., amount = number, id = string?, now = ms? }
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local P = {}
P._sources = {}   -- source -> file de sources récentes { {kind, amount, at}, ... }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function prune(list, now, windowMs)
    local kept = {}
    for _, e in ipairs(list) do
        if (now - e.at) <= windowMs then kept[#kept + 1] = e end
    end
    return kept
end

--- Enregistre une SOURCE LÉGITIME de gain (appelé par les ressources de confiance).
function P.registerSource(source, entry)
    if type(entry) ~= 'table' then return end
    local now = tonumber(entry.now) or Util.now()
    local q = P._sources[source] or {}
    q[#q + 1] = {
        kind = tostring(entry.kind or 'money'),
        amount = tonumber(entry.amount) or 0,
        at = now,
        used = false,
    }
    P._sources[source] = q
end

--- Observe un GAIN. Retourne un signal si aucune source légitime ne le couvre.
function P.observe(source, gain)
    if cfg('provenance.enabled', false) ~= true then return nil end
    if type(gain) ~= 'table' then return nil end
    local now = tonumber(gain.now) or Util.now()
    local amount = tonumber(gain.amount) or 0
    local kind = tostring(gain.kind or 'money')

    -- Ignore le bruit sous un seuil (petits gains passifs).
    local minAmt = tonumber(cfg('provenance.min_amount', 100)) or 100
    if amount < minAmt then return nil end

    local windowMs = tonumber(cfg('provenance.window_ms', 8000)) or 8000
    local tol = tonumber(cfg('provenance.tolerance_pct', 0.05)) or 0.05

    local q = prune(P._sources[source] or {}, now, windowMs)
    P._sources[source] = q

    -- Cherche une source NON CONSOMMÉE, du bon type, couvrant le montant (± tolérance).
    for _, e in ipairs(q) do
        if not e.used and e.kind == kind and e.amount >= amount * (1 - tol) then
            e.used = true          -- consommée : empêche de « rejouer » une source pour dupliquer
            return nil
        end
    end

    -- Aucune source : gain inexpliqué. Confiance forte (mécanisme serveur), mais reste un
    -- signal pour corrélation (un serveur peut avoir une ressource éco non intégrée).
    local severity = amount >= (minAmt * 20) and C.SEVERITY.HIGH or C.SEVERITY.MEDIUM
    return {
        detector = 'provenance',
        category = C.CATEGORY.ECONOMY,
        severity = severity,
        confidence = 0.65,
        reason = string.format('gain inexpliqué (%s +%.0f sans source)', kind, amount),
        source = source,
        metadata = { kind = kind, amount = amount, kind_sources = #q },
    }
end

function P.forget(source) P._sources[source] = nil end

function P.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({
            id = 'provenance', category = C.CATEGORY.ECONOMY,
            evaluate = function() return {} end,
        })
    end
end

ZShield.Provenance = P
return P
