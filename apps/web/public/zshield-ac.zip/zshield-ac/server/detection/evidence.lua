--[[
    FILE:         server/detection/evidence.lua
    PURPOSE:      Niveaux de preuve E0–E5 (§15). Formalise la MATURITÉ d'une preuve pour
                  conditionner la sanction (§38, §48) : une action douce (LOG/WARN) accepte
                  une preuve faible ; un ban définitif exige E5 (violation serveur confirmée).
                  C'est un garde-fou anti-faux-positif de plus (§28, T13).
    DEPENDENCIES: shared/constants.lua
    PUBLIC API:   ZShield.Evidence.classify(input) -> level (0..5), name
                  ZShield.Evidence.meetsRequirement(level, action) -> bool
                  ZShield.Evidence.requiredFor(action) -> level

    Barème :
      E0 télémétrie brute (aucune anomalie)          : confidence < 0.3, pas de blocage
      E1 signal normalisé                            : un signal valide
      E2 anomalie validée                            : confidence >= 0.6
      E3 anomalie corrélée                           : >= 2 catégories corrélées
      E4 preuve forte                                : corrélée + confidence >= 0.8, ou risque HIGH
      E5 violation serveur confirmée                 : action bloquée à la source par le serveur
                                                       (deny/block natif) ou ledger serveur violé
]]

ZShield = ZShield or {}
local C = ZShield.Const

local Evidence = { counts = { [0]=0, [1]=0, [2]=0, [3]=0, [4]=0, [5]=0 } }

--- input = {
---   confidence = number, blocked = bool (blocage serveur natif), server_confirmed = bool,
---   correlated = bool, correlated_categories = n, risk_level = C.RISK_LEVEL.*,
--- }
function Evidence.classify(input)
    input = input or {}
    local conf = tonumber(input.confidence) or 0

    -- E5 : le serveur a EMPÊCHÉ ou CONSTATÉ la violation lui-même (pas un signal client).
    if input.server_confirmed or input.blocked then
        return C.EVIDENCE.E5, 'E5'
    end

    local cats = tonumber(input.correlated_categories) or (input.correlated and 2 or 0)

    -- E4 : corrélation forte, ou risque déjà HIGH/CRITICAL avec bonne confiance.
    if (cats >= 2 and conf >= 0.8)
       or (input.risk_level == C.RISK_LEVEL.HIGH_RISK and conf >= 0.7)
       or input.risk_level == C.RISK_LEVEL.CRITICAL then
        return C.EVIDENCE.E4, 'E4'
    end

    -- E3 : plusieurs catégories corrélées.
    if cats >= 2 then return C.EVIDENCE.E3, 'E3' end

    -- E2 : anomalie validée (confiance suffisante).
    if conf >= 0.6 then return C.EVIDENCE.E2, 'E2' end

    -- E1 : un signal existe.
    if conf > 0.3 then return C.EVIDENCE.E1, 'E1' end

    -- E0 : télémétrie brute.
    return C.EVIDENCE.E0, 'E0'
end

--- Classe un signal ET incrémente l'histogramme (pour le dashboard / le reporting).
function Evidence.observe(input)
    local level = Evidence.classify(input)
    Evidence.counts[level] = (Evidence.counts[level] or 0) + 1
    return level
end

--- Répartition des preuves par niveau, pour le reporting (§15, dashboard).
function Evidence.distribution()
    local out = {}
    for lvl = 0, 5 do out[C.EVIDENCE_NAME[lvl]] = Evidence.counts[lvl] or 0 end
    return out
end

--- S'abonne au bus : chaque signal produit est classé et compté. Non invasif —
--- ne décide rien, alimente seulement l'histogramme de maturité de preuve.
function Evidence.attach()
    if not (ZShield.Bus and ZShield.Bus.on) then return false end
    ZShield.Bus:on('detection.signal', function(sig)
        if type(sig) ~= 'table' then return end
        Evidence.observe({
            confidence = sig.confidence,
            blocked = sig.metadata and (sig.metadata.blocked == true or sig.metadata.denied == true) or false,
        })
    end)
    return true
end

function Evidence.requiredFor(action)
    return C.ACTION_MIN_EVIDENCE[action] or C.EVIDENCE.E2
end

--- Une preuve de niveau `level` autorise-t-elle `action` ? (§38)
function Evidence.meetsRequirement(level, action)
    local need = Evidence.requiredFor(action)
    return (tonumber(level) or 0) >= need
end

ZShield.Evidence = Evidence
