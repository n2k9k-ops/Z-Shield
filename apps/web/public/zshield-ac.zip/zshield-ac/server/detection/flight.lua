--[[
    FILE:         server/detection/flight.lua
    PURPOSE:      Détection VOL / NOCLIP / BLINK par cinématique VERTICALE et par saut sur
                  un tick. Complémentaire de server/detection/movement.lua qui, lui, juge la
                  vitesse HORIZONTALE moyenne : ici on attrape ce que la moyenne masque —
                  une ascension impossible (fly hack), une altitude aberrante (hors carte),
                  et un « blink » (téléportation instantanée sur un seul échantillon).

    SERVEUR-AUTORITATIF : on ne lit que des positions rapportées (assertions client, §27) ;
    le serveur décide de la PLAUSIBILITÉ. Un téléport de confiance enregistré par le serveur
    (opts.trusted) et les états légitimes (avion, parachute, chute) neutralisent le signal.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Flight.observe(source, position, opts) -> signal|nil
                  ZShield.Flight.forget(source) / .register()

    position = { x, y, z }
    opts = {
      now       = ms,        -- horodatage serveur (défaut Util.now())
      trusted   = bool,      -- téléport légitime déclenché/validé serveur
      in_air    = bool,      -- avion / hélico / parachute (ascension normale permise)
      falling   = bool,      -- chute (descente rapide normale)
    }
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local Flight = {}
Flight._last = {}   -- source -> { pos, at }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function dist3(a, b)
    local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

--- Observe une position. Retourne un signal partiel ou nil.
function Flight.observe(source, position, opts)
    if cfg('flight.enabled', false) ~= true then return nil end
    if type(position) ~= 'table' or type(position.z) ~= 'number' then return nil end
    opts = opts or {}
    local now = tonumber(opts.now) or Util.now()

    local prev = Flight._last[source]
    Flight._last[source] = { pos = position, at = now }
    if not prev then return nil end

    -- 1) Altitude aberrante : hors des bornes plausibles du monde (sauf en aéronef).
    local maxAlt = tonumber(cfg('flight.max_altitude_m', 1500)) or 1500
    local minAlt = tonumber(cfg('flight.min_altitude_m', -120)) or -120
    if not opts.in_air and (position.z > maxAlt or position.z < minAlt) then
        return Flight._signal(source, C.SEVERITY.MEDIUM, 0.5,
            string.format('altitude hors-monde (%.0f m)', position.z),
            { z = position.z, kind = 'altitude' })
    end

    local dt = (now - prev.at) / 1000
    if dt <= 0 then return nil end

    -- 2) Blink : saut total sur un seul échantillon au-delà d'un seuil, sans téléport de
    --    confiance. Un vrai déplacement passe par des positions intermédiaires.
    local total = dist3(prev.pos, position)
    local blink = tonumber(cfg('flight.blink_distance_m', 75)) or 75
    if not opts.trusted and total > blink then
        return Flight._signal(source, C.SEVERITY.HIGH, 0.6,
            string.format('téléport instantané (%.0f m en 1 tick)', total),
            { distance = total, kind = 'blink' })
    end

    -- 3) Vol : vitesse d'ASCENSION verticale au-delà du plausible (sauté/monté à la main),
    --    hors aéronef. La descente rapide (chute) est permise.
    local dz = position.z - prev.pos.z
    local climb = dz / dt
    local maxClimb = tonumber(cfg('flight.max_climb_speed_ms', 20)) or 20
    if not opts.in_air and not opts.falling and climb > maxClimb then
        return Flight._signal(source, C.SEVERITY.HIGH, 0.55,
            string.format('ascension impossible (%.1f m/s)', climb),
            { climb = climb, kind = 'fly' })
    end

    return nil
end

function Flight._signal(source, severity, confidence, reason, meta)
    meta = meta or {}
    return {
        detector = 'flight',
        category = C.CATEGORY.MOVEMENT,
        severity = severity,
        confidence = confidence,
        reason = reason,
        source = source,
        metadata = meta,
    }
end

function Flight.forget(source) Flight._last[source] = nil end

function Flight.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({
            id = 'flight', category = C.CATEGORY.MOVEMENT,
            evaluate = function() return {} end,
        })
    end
end

ZShield.Flight = Flight
return Flight
