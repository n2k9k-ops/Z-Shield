--[[
    FILE:         server/detection/command.lua
    PURPOSE:      Anti-flood de commandes (§99 spam/abus). Un joueur qui exécute des
                  commandes à une cadence impossible (macro/abus) est signalé. Sert aussi
                  de garde-fou contre le brute-force de commandes admin.
    DEPENDENCIES: shared/constants.lua, core/log.lua, core/config.lua
    PUBLIC API:   ZShield.CommandGuard.observe(source, name, now)  -- pur/testable
                  ZShield.CommandGuard.forget(source)
                  ZShield.CommandGuard.attach()                    -- hook runtime

    §26 : on ÉMET ; la corrélation décide. La confiance monte avec le débit.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Log = ZShield.Log

local CG = {}
CG._ctx = {}   -- source -> { ts = { ... } }

local WINDOW_MS = 1000

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

--- Observe l'exécution d'une commande. `now` en ms (injecté). Retourne un signal ou nil.
function CG.observe(source, name, now)
    if not source then return nil end
    now = now or 0
    if not cfg('command.detector', true) then return nil end

    local c = CG._ctx[source]
    if not c then c = { ts = {} }; CG._ctx[source] = c end

    local ts = c.ts
    local cutoff = now - WINDOW_MS
    local i = 1
    while ts[i] and ts[i] < cutoff do i = i + 1 end
    if i > 1 then
        local kept = {}
        for j = i, #ts do kept[#kept + 1] = ts[j] end
        c.ts = kept; ts = kept
    end
    ts[#ts + 1] = now

    local maxRate = tonumber(cfg('command.max_per_sec', 8)) or 8
    local count = #ts
    if count > maxRate then
        local over = count - maxRate
        return {
            severity = C.SEVERITY.MEDIUM,
            confidence = math.min(0.4 + over * 0.06, 0.85),
            reason = string.format('command flood %d/s over cap %d', count, maxRate),
            protection = 'sp_commands',
            category = C.CATEGORY.NETWORK,
            source = source,
        }
    end
    return nil
end

function CG.forget(source) CG._ctx[source] = nil end

function CG.emit(source, name, now)
    local sig = CG.observe(source, name, now)
    if sig and ZShield.Detection then
        ZShield.Detection.emit({
            detector = 'command.flood',
            category = sig.category,
            severity = sig.severity,
            confidence = sig.confidence,
            reason = sig.reason,
            source = sig.source,
            protection = sig.protection,
            metadata = { protection = sig.protection },
        })
    end
    return sig
end

ZShield.CommandGuard = CG
return CG
