--[[
    FILE:         server/detection/godmode.lua
    PURPOSE:      GOD MODE PAR « DÉGÂTS NON APPLIQUÉS » + RÉPARATION VÉHICULE INJECTÉE.
                  Là où health.lua surveille la régénération, ce module attrape l'invincibilité
                  par la CONSÉQUENCE observée serveur :
                    - un joueur ENCAISSE des dégâts (event serveur) mais sa santé NE BAISSE PAS
                      (voire remonte) -> god mode ;
                    - la santé d'un VÉHICULE remonte fortement SANS event de réparation
                      légitime -> réparation injectée (provenance).

    100 % serveur : la santé avant/après et les événements de dégât/réparation sont connus
    du serveur. Corrélant (§26).

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Godmode.observeDamage(source, ev) -> signal|nil
                  ZShield.Godmode.observeVehicle(source, ev) -> signal|nil
                  ZShield.Godmode.register()

    ev (damage)  = { damage_taken, hp_before, hp_after }
    ev (vehicle) = { veh_before, veh_after, repair_event = bool }
]]

ZShield = ZShield or {}
local C = ZShield.Const

local G = {}
G._dmg = {}   -- source -> streak de dégâts encaissés SANS baisse de santé

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

function G.forget(source) if source ~= nil then G._dmg[source] = nil end end

--- Dégâts encaissés mais santé inchangée / en hausse -> god mode. RENFORCÉ : on suit une
--- SÉRIE. Un événement isolé (une armure qui absorbe, un soin qui coïncide) est un signal
--- MOYEN ; une série d'encaissements SANS baisse est quasi impossible sans invincibilité,
--- donc la confiance/gravité montent avec la série (moins de faux positifs, détection dure
--- sur le vrai god mode). Un encaissement NORMAL (santé qui baisse) remet la série à zéro.
function G.observeDamage(source, ev)
    if cfg('godmode.enabled', false) ~= true then return nil end
    if type(ev) ~= 'table' then return nil end
    local dmg = tonumber(ev.damage_taken)
    local before = tonumber(ev.hp_before)
    local after = tonumber(ev.hp_after)
    if not (dmg and before and after) then return nil end

    local minDmg = tonumber(cfg('godmode.min_damage', 5)) or 5
    if dmg >= minDmg and after >= before then
        local streak = (G._dmg[source] or 0) + 1
        G._dmg[source] = streak
        -- 1er : MEDIUM corroborant. 2e+ : HIGH, confiance croissante (plafonnée, §26).
        local severity = (streak >= 2) and C.SEVERITY.HIGH or C.SEVERITY.MEDIUM
        local confidence = math.min(0.85, 0.45 + 0.18 * (streak - 1))
        return {
            detector = 'godmode', category = C.CATEGORY.DAMAGE,
            severity = severity, confidence = confidence,
            reason = string.format('%.0f dégâts encaissés mais santé %.0f→%.0f x%d (invincibilité)',
                dmg, before, after, streak),
            source = source,
            metadata = { damage = dmg, before = before, after = after, streak = streak, kind = 'godmode' },
        }
    elseif dmg >= minDmg and after < before then
        -- Encaissement normal : la santé a baissé -> ce n'est pas du god mode, on réinitialise.
        G._dmg[source] = nil
    end
    return nil
end

--- Santé véhicule en forte hausse SANS event de réparation -> réparation injectée.
function G.observeVehicle(source, ev)
    if cfg('godmode.veh_enabled', false) ~= true then return nil end
    if type(ev) ~= 'table' then return nil end
    local before = tonumber(ev.veh_before)
    local after = tonumber(ev.veh_after)
    if not (before and after) then return nil end
    local delta = tonumber(cfg('godmode.veh_repair_delta', 200)) or 200
    if (after - before) >= delta and ev.repair_event ~= true then
        return {
            detector = 'godmode', category = C.CATEGORY.ENTITY,
            severity = C.SEVERITY.MEDIUM, confidence = 0.55,
            reason = string.format('santé véhicule %.0f→%.0f sans réparation (injectée)', before, after),
            source = source, metadata = { before = before, after = after, kind = 'veh_repair' },
        }
    end
    return nil
end

function G.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'godmode', category = C.CATEGORY.DAMAGE,
            evaluate = function() return {} end })
    end
end

ZShield.Godmode = G
return G
