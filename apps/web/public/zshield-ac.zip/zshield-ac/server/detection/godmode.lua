--[[
    FILE:         server/detection/godmode.lua
    PURPOSE:      GOD MODE PAR « DÉGÂTS NON APPLIQUÉS » + RÉPARATION VÉHICULE INJECTÉE.
                  Là où health.lua surveille la régénération, ce module attrape l'invincibilité
                  par la CONSÉQUENCE observée serveur :
                    - un joueur ENCAISSE des dégâts (event serveur) mais sa santé NE BAISSE PAS
                      (voire remonte) -> god mode ;
                    - la santé d'un VÉHICULE remonte fortement SANS event de réparation
                      légitime -> réparation injectée (provenance).

    100 % serveur : la santé avant/après et les événements de dégât/réparation sont connus
    du serveur. Corrélant (§26).

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Godmode.observeDamage(source, ev) -> signal|nil
                  ZShield.Godmode.observeVehicle(source, ev) -> signal|nil
                  ZShield.Godmode.register()

    ev (damage)  = { damage_taken, hp_before, hp_after }
    ev (vehicle) = { veh_before, veh_after, repair_event = bool }
]]

ZShield = ZShield or {}
local C = ZShield.Const

local G = {}

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

--- Dégâts encaissés mais santé inchangée / en hausse -> god mode.
function G.observeDamage(source, ev)
    if cfg('godmode.enabled', false) ~= true then return nil end
    if type(ev) ~= 'table' then return nil end
    local dmg = tonumber(ev.damage_taken)
    local before = tonumber(ev.hp_before)
    local after = tonumber(ev.hp_after)
    if not (dmg and before and after) then return nil end

    local minDmg = tonumber(cfg('godmode.min_damage', 5)) or 5
    if dmg >= minDmg and after >= before then
        return {
            detector = 'godmode', category = C.CATEGORY.DAMAGE,
            severity = C.SEVERITY.HIGH, confidence = 0.65,
            reason = string.format('%.0f dégâts encaissés mais santé %.0f→%.0f (invincibilité)', dmg, before, after),
            source = source, metadata = { damage = dmg, before = before, after = after, kind = 'godmode' },
        }
    end
    return nil
end

--- Santé véhicule en forte hausse SANS event de réparation -> réparation injectée.
function G.observeVehicle(source, ev)
    if cfg('godmode.veh_enabled', false) ~= true then return nil end
    if type(ev) ~= 'table' then return nil end
    local before = tonumber(ev.veh_before)
    local after = tonumber(ev.veh_after)
    if not (before and after) then return nil end
    local delta = tonumber(cfg('godmode.veh_repair_delta', 200)) or 200
    if (after - before) >= delta and ev.repair_event ~= true then
        return {
            detector = 'godmode', category = C.CATEGORY.ENTITY,
            severity = C.SEVERITY.MEDIUM, confidence = 0.55,
            reason = string.format('santé véhicule %.0f→%.0f sans réparation (injectée)', before, after),
            source = source, metadata = { before = before, after = after, kind = 'veh_repair' },
        }
    end
    return nil
end

function G.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'godmode', category = C.CATEGORY.DAMAGE,
            evaluate = function() return {} end })
    end
end

ZShield.Godmode = G
return G
