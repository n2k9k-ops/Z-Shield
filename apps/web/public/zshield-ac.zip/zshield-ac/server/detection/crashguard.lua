--[[
    FILE:         server/detection/crashguard.lua
    PURPOSE:      ANTI-CRASH par ENTITÉS/ATTRIBUTS MALFORMÉS. Beaucoup de crashers envoient des
                  valeurs impossibles (NaN, infini, coordonnées/échelles absurdes) qui, propagées
                  aux autres clients, les font planter. Le serveur valide chaque attribut numérique
                  d'entité AVANT propagation : toute valeur non finie ou hors bornes -> DROP (on
                  n'attend pas la corrélation, un crasher doit être bloqué à la source).

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.CrashGuard.checkEntity(attrs) -> { drop, signal }|nil
                  ZShield.CrashGuard.register()

    attrs = table de champs numériques { x, y, z, heading, health, scale, ... } (les non-numériques
    sont ignorés).
]]

ZShield = ZShield or {}
local C = ZShield.Const

local CG = {}

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

-- Un nombre est-il « sain » ? (ni NaN, ni infini, dans les bornes).
local function bad(v, maxAbs)
    if type(v) ~= 'number' then return false end
    if v ~= v then return true end                 -- NaN (v ~= v uniquement pour NaN)
    if v == math.huge or v == -math.huge then return true end
    if maxAbs and math.abs(v) > maxAbs then return true end
    return false
end

function CG.checkEntity(attrs)
    if cfg('crashguard.enabled', false) ~= true then return nil end
    if type(attrs) ~= 'table' then return nil end
    local maxCoord = tonumber(cfg('crashguard.max_coord', 1e6)) or 1e6
    local maxScale = tonumber(cfg('crashguard.max_scale', 100)) or 100
    local maxHealth = tonumber(cfg('crashguard.max_health', 1e6)) or 1e6

    local offenders = {}
    -- Coordonnées / heading : bornes de monde.
    for _, k in ipairs({ 'x', 'y', 'z', 'heading', 'vx', 'vy', 'vz' }) do
        if bad(attrs[k], maxCoord) then offenders[#offenders + 1] = k end
    end
    if bad(attrs.scale, maxScale) then offenders[#offenders + 1] = 'scale' end
    if bad(attrs.health, maxHealth) then offenders[#offenders + 1] = 'health' end
    -- Tout autre champ numérique : au moins non-fini.
    for k, v in pairs(attrs) do
        if type(v) == 'number' and bad(v, nil) then offenders[#offenders + 1] = tostring(k) end
    end

    if #offenders > 0 then
        return {
            drop = true,
            signal = {
                detector = 'crashguard', category = C.CATEGORY.ENTITY,
                severity = C.SEVERITY.HIGH, confidence = 0.85,
                reason = 'attribut d\'entité malformé (NaN/infini/hors bornes) — crasher bloqué',
                source = attrs.source or 0,
                metadata = { fields = offenders, kind = 'malformed_entity' },
            },
        }
    end
    return nil
end

function CG.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'crashguard', category = C.CATEGORY.ENTITY,
            evaluate = function() return {} end })
    end
end

ZShield.CrashGuard = CG
return CG
