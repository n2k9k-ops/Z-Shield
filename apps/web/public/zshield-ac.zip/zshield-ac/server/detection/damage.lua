--[[
    FILE:         server/detection/damage.lua
    PURPOSE:      INTÉGRITÉ DES DÉGÂTS, DE LA CADENCE ET DE LA PORTÉE, PAR ARME. Là où le
                  firewall pose un plafond de dégâts GLOBAL, ce module valide chaque tir
                  contre les caractéristiques de l'ARME concernée :
                    - dégâts par coup vs base connue de l'arme (+ tolérance) -> modded damage
                    - intervalle entre deux tirs vs cadence min de l'arme     -> rapid fire
                    - distance de la touche vs portée max de l'arme           -> hit hors portée
                      (corroboration SERVEUR d'un silent-aim : toucher à 300 m au pistolet)

    SERVEUR-AUTORITATIF : les dégâts, l'arme, la distance et l'horodatage proviennent
    d'événements que le serveur reçoit déjà (damage/hit). Le client ne peut pas « prouver »
    un dégât : le serveur le confronte au modèle de l'arme.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.DamageIntegrity.observe(source, ev) -> signal|nil
                  ZShield.DamageIntegrity.forget(source) / .register()

    ev = {
      weapon    = number|string,  -- hash/nom de l'arme (clé du modèle)
      damage    = number,         -- dégâts infligés par CE tir
      dist      = number,         -- distance à la cible (m), optionnel
      now       = ms,             -- horodatage serveur (défaut Util.now())
    }

    Modèle d'arme (config `damage_integrity.weapons` = { [weapon] = { base, min_ms, range } }).
    Défauts appliqués quand l'arme n'est pas au catalogue.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local DI = {}
DI._last = {}   -- source -> { [weapon] = last_shot_ms }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function weaponModel(weapon)
    local catalog = cfg('damage_integrity.weapons', nil)
    local m = (type(catalog) == 'table') and catalog[weapon] or nil
    return {
        base   = m and tonumber(m.base)   or tonumber(cfg('damage_integrity.default_base', 60)) or 60,
        min_ms = m and tonumber(m.min_ms) or tonumber(cfg('damage_integrity.default_min_ms', 80)) or 80,
        range  = m and tonumber(m.range)  or tonumber(cfg('damage_integrity.default_range_m', 120)) or 120,
    }
end

--- Observe un tir/dégât. Retourne un signal partiel ou nil.
function DI.observe(source, ev)
    if cfg('damage_integrity.enabled', false) ~= true then return nil end
    if type(ev) ~= 'table' or ev.weapon == nil then return nil end
    local now = tonumber(ev.now) or Util.now()
    local model = weaponModel(ev.weapon)

    -- 1) Dégâts modifiés : au-delà de la base + tolérance (%). Sous la base = normal
    --    (armure, distance) donc on ne signale QUE le sur-dégât.
    local tol = tonumber(cfg('damage_integrity.tolerance_pct', 0.25)) or 0.25
    local dmg = tonumber(ev.damage)
    if dmg and dmg > model.base * (1 + tol) then
        return DI._signal(source, C.SEVERITY.HIGH, 0.6,
            string.format('dégâts modifiés (%.0f vs base %.0f)', dmg, model.base),
            { weapon = ev.weapon, damage = dmg, base = model.base, kind = 'modded_damage' })
    end

    -- 2) Portée impossible : touche au-delà de la portée max de l'arme (silent-aim serveur).
    local d = tonumber(ev.dist)
    if d and d > model.range then
        return DI._signal(source, C.SEVERITY.HIGH, 0.6,
            string.format('touche hors portée (%.0f m > %.0f m)', d, model.range),
            { weapon = ev.weapon, dist = d, range = model.range, kind = 'range' })
    end

    -- 3) Cadence : deux tirs plus rapprochés que l'intervalle min de l'arme -> rapid fire.
    local per = DI._last[source]
    if not per then per = {}; DI._last[source] = per end
    local last = per[ev.weapon]
    per[ev.weapon] = now
    if last then
        local delta = now - last
        if delta >= 0 and delta < model.min_ms then
            return DI._signal(source, C.SEVERITY.MEDIUM, 0.5,
                string.format('cadence anormale (%d ms < %d ms)', delta, model.min_ms),
                { weapon = ev.weapon, interval = delta, min = model.min_ms, kind = 'rapid_fire' })
        end
    end

    return nil
end

function DI._signal(source, severity, confidence, reason, meta)
    return {
        detector = 'damage_integrity',
        category = C.CATEGORY.DAMAGE,
        severity = severity,
        confidence = confidence,
        reason = reason,
        source = source,
        metadata = meta or {},
    }
end

function DI.forget(source) DI._last[source] = nil end

function DI.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({
            id = 'damage_integrity', category = C.CATEGORY.DAMAGE,
            evaluate = function() return {} end,
        })
    end
end

ZShield.DamageIntegrity = DI
return DI
