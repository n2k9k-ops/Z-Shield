--[[
    FILE:         server/detection/entity.lua
    PURPOSE:      Sécurité des entités (§16, §17). Registre des créations d'entités,
                  ownership, quotas par joueur/type/fenêtre, cycle de vie. Détecte le spawn
                  abusif sans casser le gameplay légitime (missions à quota augmenté, §17).
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua, server/context.lua,
                  server/detection/engine.lua
    PUBLIC API:   ZShield.Entity.onCreating(source, model, type) -> allowed, signal
                  ZShield.Entity.register(entityId, meta)
                  ZShield.Entity.remove(entityId)
                  ZShield.Entity.ownedBy(source) -> array
                  ZShield.Entity.setQuota(context, quota)

    §16 : FiveM expose entityCreating/entityCreated ; on s'y branche. Chaque entité est
    associée à creator/model/type/timestamp/context/resource/ownership.
    §17 : quotas contextuels. Gameplay normal = quota normal ; mission spéciale = quota
    augmenté ; admin = quota spécifique. On ne bloque JAMAIS aveuglément.
    §88 : une entité invalide peut être RETIRÉE (containment réversible), pas le joueur banni.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local Entity = {
    registry = {},       -- entityId -> { creator, model, type, at, resource, context }
    byOwner = {},        -- source -> { entityId : true }
    counts = {},         -- source -> { window_start, count }  (fenêtre de quota)
    contextQuota = {},   -- source -> quota override (mission/admin)
    stats = { registered = 0, removed = 0, quota_exceeded = 0 },
}

-- Fenêtre de comptage des créations pour le quota (§17).
local QUOTA_WINDOW_MS = 10000

--- Quota effectif d'un joueur : override contextuel (mission/admin) sinon défaut config.
local function quotaFor(source)
    if Entity.contextQuota[source] then return Entity.contextQuota[source] end
    return (ZShield.Config and ZShield.Config.value('entities.default_quota')) or 50
end

--- Fixe un quota contextuel (§17). Ex : au démarrage d'une mission, on augmente le quota.
function Entity.setQuota(source, quota)
    Entity.contextQuota[source] = quota
end
function Entity.clearQuota(source)
    Entity.contextQuota[source] = nil
end

--- Appelé sur entityCreating (§16). Décide si la création est plausible et retourne
--- allowed, signal|nil. allowed=false signifie « à contenir » (retrait), pas « bannir ».
function Entity.onCreating(source, model, entityType)
    if not (ZShield.Config and ZShield.Config.value('entities.enabled') ~= false) then
        return true, nil
    end
    if source == nil or source == 0 then return true, nil end -- entité serveur/script

    local now = Util.now()
    local counter = Entity.counts[source]
    if not counter or (now - counter.window_start) > QUOTA_WINDOW_MS then
        counter = { window_start = now, count = 0 }
        Entity.counts[source] = counter
    end
    counter.count = counter.count + 1

    local quota = quotaFor(source)
    if counter.count > quota then
        Entity.stats.quota_exceeded = Entity.stats.quota_exceeded + 1
        -- Signal dont la confiance monte avec le dépassement.
        local over = counter.count - quota
        local confidence = math.min(0.5 + over * 0.05, 0.9)
        local signal = {
            source = source,
            category = C.CATEGORY.ENTITY,
            scope = C.ANOMALY_SCOPE.PLAYER,
            severity = over > quota and C.SEVERITY.HIGH or C.SEVERITY.MEDIUM,
            confidence = confidence,
            reason = 'entity spawn quota exceeded',
            metadata = { count = counter.count, quota = quota, over = over,
                         model = model, type = entityType, window_ms = QUOTA_WINDOW_MS },
        }
        -- allowed=false : l'appelant peut refuser la création (containment §88).
        return false, signal
    end

    return true, nil
end

--- Enregistre une entité créée (§16). Appelé sur entityCreated.
function Entity.register(entityId, meta)
    meta = meta or {}
    Entity.registry[entityId] = {
        creator = meta.creator,
        model = meta.model,
        type = meta.type,
        resource = meta.resource,
        context = meta.context,
        at = Util.now(),
    }
    if meta.creator then
        Entity.byOwner[meta.creator] = Entity.byOwner[meta.creator] or {}
        Entity.byOwner[meta.creator][entityId] = true
    end
    Entity.stats.registered = Entity.stats.registered + 1
end

--- Retire une entité du registre (§16 cleanup, §88 containment).
function Entity.remove(entityId)
    local e = Entity.registry[entityId]
    if not e then return false end
    if e.creator and Entity.byOwner[e.creator] then
        Entity.byOwner[e.creator][entityId] = nil
    end
    Entity.registry[entityId] = nil
    Entity.stats.removed = Entity.stats.removed + 1
    return true
end

--- Entités possédées par un joueur (pour ownership §16 et cleanup au départ §110).
function Entity.ownedBy(source)
    local out = {}
    local owned = Entity.byOwner[source]
    if owned then for id in pairs(owned) do out[#out + 1] = id end end
    return out
end

--- Vérifie l'ownership d'une entité (§16). Sert aux events qui manipulent une entité :
--- le joueur en est-il bien le propriétaire ?
function Entity.isOwner(source, entityId)
    local e = Entity.registry[entityId]
    return e ~= nil and e.creator == source
end

--- Nettoyage au départ d'un joueur (§110) : retire ses entités du registre.
function Entity.onPlayerDrop(source)
    for _, id in ipairs(Entity.ownedBy(source)) do
        Entity.registry[id] = nil
    end
    Entity.byOwner[source] = nil
    Entity.counts[source] = nil
    Entity.contextQuota[source] = nil
end

--- Enregistre le détecteur d'entités. Le contexte d'évaluation porte
--- { entity_creating = { source, model, type } }.
function Entity.registerDetector()
    if not ZShield.Detection then return false, 'detection engine not loaded' end
    return ZShield.Detection.register({
        id = 'entity.quota',
        category = C.CATEGORY.ENTITY,
        version = 1,
        evaluate = function(evalCtx)
            if not evalCtx.entity_creating then return nil end
            local e = evalCtx.entity_creating
            local _, signal = Entity.onCreating(e.source, e.model, e.type)
            return signal
        end,
    })
end

function Entity.getStats()
    return Util.deepCopy(Entity.stats)
end

ZShield.Entity = Entity
