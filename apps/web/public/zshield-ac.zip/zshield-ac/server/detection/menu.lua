--[[
    FILE:         server/detection/menu.lua
    PURPOSE:      ANTI-MENU (menu de triche). Deux angles serveur, complémentaires :
                    1. SIGNATURES d'events/triggers : de nombreux menus déclenchent des events
                       aux noms caractéristiques (godmode, giveall, spawnall, noclip…). Un nom
                       correspondant à un motif connu -> signal. Renommable, mais utile.
                    2. RAFALE D'ACTIONS PUISSANTES : un menu permet d'enchaîner en quelques
                       secondes des actions « admin » (spawn véhicule + give arme + god + tp).
                       Une rafale de ces actions dans une courte fenêtre est une signature
                       comportementale bien plus robuste que le nom.

                  La corrélation multi-détecteurs (server/detection/trainer.lua) reste le juge
                  final : anti-menu FOURNIT des signaux, l'ensemble décide.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Menu.observeTrigger(source, ev) -> signal|nil
                  ZShield.Menu.forget(source) / .register()

    ev = { name = string, power = bool, now = ms }
      name  : nom d'event/trigger
      power : action « puissante » (spawn/give/god/tp) — compte pour la rafale
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local M = {}
M._burst = {}   -- source -> { timestamps d'actions puissantes }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

-- Motifs génériques d'events de menu (opérateur-éditables via config.menu.patterns).
-- Volontairement génériques : les noms de produits changent, ces fragments décrivent des
-- ACTIONS de menu. Trivialement contournables par renommage -> voir la rafale + trainer.
local DEFAULT_PATTERNS = {
    'godmode', 'noclip', 'giveall', 'give_all', 'spawnall', 'spawn_all',
    'teleportall', 'tpall', 'reviveall', 'killall', 'explodeall', 'admin_menu',
    'trainer', 'cheatmenu', 'esp_toggle', 'aimbot_toggle',
}

function M.observeTrigger(source, ev)
    if cfg('menu.enabled', false) ~= true then return nil end
    if type(ev) ~= 'table' then return nil end
    local now = tonumber(ev.now) or Util.now()

    -- 1) Signature de nom.
    local name = ev.name
    if type(name) == 'string' and name ~= '' then
        local pats = cfg('menu.patterns', DEFAULT_PATTERNS)
        local low = name:lower()
        for _, p in ipairs(pats) do
            if type(p) == 'string' and p ~= '' and low:find(p:lower(), 1, true) then
                return {
                    detector = 'menu', category = C.CATEGORY.EVENT,
                    severity = C.SEVERITY.HIGH, confidence = 0.65,
                    reason = string.format('event de menu de triche (« %s » ~ « %s »)', name, p),
                    source = source, metadata = { name = name, pattern = p, kind = 'menu_signature' },
                }
            end
        end
    end

    -- 2) Rafale d'actions puissantes.
    if ev.power == true then
        local windowMs = tonumber(cfg('menu.burst_window_ms', 4000)) or 4000
        local maxBurst = tonumber(cfg('menu.burst_max', 5)) or 5
        local list = M._burst[source] or {}
        local kept = {}
        for _, t in ipairs(list) do if (now - t) <= windowMs then kept[#kept + 1] = t end end
        kept[#kept + 1] = now
        M._burst[source] = kept
        if #kept > maxBurst then
            return {
                detector = 'menu', category = C.CATEGORY.EVENT,
                severity = C.SEVERITY.HIGH, confidence = 0.7,
                reason = string.format('rafale de %d actions puissantes en %.0f s — usage de menu',
                    #kept, windowMs / 1000),
                source = source, metadata = { burst = #kept, kind = 'menu_burst' },
            }
        end
    end
    return nil
end

function M.forget(source) M._burst[source] = nil end

function M.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'menu', category = C.CATEGORY.EVENT,
            evaluate = function() return {} end })
    end
end

ZShield.Menu = M
return M
