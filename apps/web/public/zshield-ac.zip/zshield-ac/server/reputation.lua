--[[
    FILE:         server/reputation.lua
    PURPOSE:      RÉPUTATION PERSISTANTE PAR JOUEUR. Le risque d'une session s'efface à la
                  déconnexion — un tricheur qui se reconnecte repartait « propre ». La réputation
                  survit à la reconnexion : elle est indexée par IDENTIFIANT stable (license/HWID),
                  accumulée à chaque incident, et DÉCROÎT lentement dans le temps (un vieux fait
                  pèse moins). À la connexion, on ré-amorce le risque de session avec la réputation
                  courante : un récidiviste redémarre « chaud ».

    En production, le store est persistant (event store / DB) ; ici l'API est pure et testable
    en mémoire, la couche persistance branche add/get sur le store.

    DEPENDENCIES: core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Reputation.add(id, delta, now)
                  ZShield.Reputation.get(id, now) -> score (avec décroissance)
                  ZShield.Reputation.seedRisk(id, now) -> risk_initial
                  ZShield.Reputation.flagged(id, now) -> bool
                  ZShield.Reputation.forget(id) / .snapshot()
]]

ZShield = ZShield or {}
local Util = ZShield.Util

local R = {}
R._rep = {}   -- id -> { score, at }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

-- Applique la décroissance temporelle jusqu'à `now` et renvoie le score courant.
local function decayed(entry, now)
    if not entry then return 0 end
    local perHour = tonumber(cfg('reputation.decay_per_hour', 5)) or 5
    local hours = math.max(0, (now - entry.at) / 3600000)
    local score = entry.score - perHour * hours
    return math.max(0, score)
end

--- Ajoute `delta` à la réputation d'un identifiant (borne haute configurable).
function R.add(id, delta, now)
    if cfg('reputation.enabled', false) ~= true then return end
    if type(id) ~= 'string' or id == '' then return end
    now = tonumber(now) or Util.now()
    local cur = decayed(R._rep[id], now)
    local maxScore = tonumber(cfg('reputation.max', 100)) or 100
    local score = math.min(maxScore, cur + (tonumber(delta) or 0))
    R._rep[id] = { score = score, at = now }
end

--- Score courant (après décroissance).
function R.get(id, now)
    if type(id) ~= 'string' then return 0 end
    now = tonumber(now) or Util.now()
    return decayed(R._rep[id], now)
end

--- Risque initial à injecter dans la session à la connexion (récidiviste = démarre chaud).
function R.seedRisk(id, now)
    if cfg('reputation.enabled', false) ~= true then return 0 end
    local factor = tonumber(cfg('reputation.seed_factor', 0.5)) or 0.5
    return R.get(id, now) * factor
end

--- Au-delà d'un seuil, l'identifiant est « signalé » (surveillance renforcée à la connexion).
function R.flagged(id, now)
    if cfg('reputation.enabled', false) ~= true then return false end
    local threshold = tonumber(cfg('reputation.join_threshold', 60)) or 60
    return R.get(id, now) >= threshold
end

function R.forget(id) R._rep[id] = nil end
function R.snapshot() return R._rep end

ZShield.Reputation = R
return R
