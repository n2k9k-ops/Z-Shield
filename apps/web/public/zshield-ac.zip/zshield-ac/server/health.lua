--[[
    FILE:         server/health.lua
    PURPOSE:      Santé et auto-surveillance (§50, §51). Registre de l'état de chaque
                  composant, agrégation en un verdict global, et vérifications que
                  l'anti-cheat fait sur LUI-MÊME (queue saturée, erreurs répétées, modules
                  dégradés).
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua
    PUBLIC API:   ZShield.Health.set(component, status, detail)
                  ZShield.Health.report() -> table (§50)
                  ZShield.Health.selfCheck() -> report (§51)
                  ZShield.Health.attach()

    §50 : ZShield.Health() retourne l'état de database, event firewall, detectors,
    dashboard, discord, storage, configuration. Statuts HEALTHY | DEGRADED | FAILED.
    §51 : l'anti-cheat détecte lui-même module arrêté, exception répétée, queue saturée,
    SQL lent, mémoire excessive, événement anormalement fréquent.

    Agrégation PESSIMISTE : un composant FAILED rend l'ensemble FAILED. Un opérateur qui lit
    « HEALTHY » alors qu'un composant est mort est pire que pas de rapport du tout.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log

local Health = {
    components = {},   -- name -> { status, detail, changed_at, updated_at }
}

-- Composants surveillés par défaut (§50).
local DEFAULT_COMPONENTS = {
    'configuration', 'event_firewall', 'detectors', 'correlation', 'risk',
    'incidents', 'enforcement', 'storage', 'database', 'discord',
}

for _, name in ipairs(DEFAULT_COMPONENTS) do
    Health.components[name] = { status = C.HEALTH.UNKNOWN, changed_at = Util.now() }
end

--- Déclare/actualise l'état d'un composant. Journalise les transitions.
function Health.set(component, status, detail)
    local entry = Health.components[component]
    if not entry then
        entry = { status = C.HEALTH.UNKNOWN, changed_at = Util.now() }
        Health.components[component] = entry
    end
    local prev = entry.status
    entry.detail = detail
    entry.updated_at = Util.now()
    if prev ~= status then
        entry.status = status
        entry.changed_at = entry.updated_at
        local level = (status == C.HEALTH.FAILED) and 'warn'
            or (status == C.HEALTH.HEALTHY and prev == C.HEALTH.FAILED) and 'info'
            or 'debug'
        Log[level](Log, 'health', 'component status changed', {
            component = component, from = prev, to = status, detail = detail })
    end
end

function Health.get(component)
    return Health.components[component]
end

--- Verdict global agrégé, pessimiste (§50).
function Health.aggregate()
    local seen = { failed = false, degraded = false, unknown = false, healthy = false }
    for _, e in pairs(Health.components) do
        if e.status == C.HEALTH.FAILED then seen.failed = true
        elseif e.status == C.HEALTH.DEGRADED then seen.degraded = true
        elseif e.status == C.HEALTH.UNKNOWN then seen.unknown = true
        else seen.healthy = true end
    end
    if seen.failed then return C.HEALTH.FAILED end
    if seen.degraded then return C.HEALTH.DEGRADED end
    if seen.unknown and not seen.healthy then return C.HEALTH.UNKNOWN end
    if seen.unknown then return C.HEALTH.DEGRADED end
    return C.HEALTH.HEALTHY
end

--- Rapport complet (§50). Sans aucun secret par construction : chaque composant ne stocke
--- qu'un statut et un détail textuel écrit par le module lui-même.
function Health.report()
    local components = {}
    for name, e in pairs(Health.components) do
        components[name] = { status = e.status, detail = e.detail,
                             changed_at = e.changed_at, updated_at = e.updated_at }
    end
    return {
        overall = Health.aggregate(),
        version = C.VERSION,
        generated_at = Util.wallclock(),
        components = components,
        log_counters = Log:counters(),
    }
end

--- Auto-surveillance (§51). L'anti-cheat inspecte son propre état et met à jour la santé
--- des composants en conséquence. Appelé périodiquement par le bootstrap.
function Health.selfCheck()
    -- 1. Event store saturé (§51).
    if ZShield.Store then
        local stats = ZShield.Store.getStats()
        local size = stats.queue_size or 0
        local max = ZShield.Store.maxSize or 5000
        local saturation = size / max
        if saturation > 0.9 then
            Health.set('storage', C.HEALTH.FAILED, string.format('event store saturé (%d/%d)', size, max))
        elseif saturation > 0.6 then
            Health.set('storage', C.HEALTH.DEGRADED, string.format('event store rempli à %d%%', math.floor(saturation * 100)))
        else
            Health.set('storage', C.HEALTH.HEALTHY, string.format('%d en file', size))
        end
        -- État du disjoncteur SQL (§52).
        if stats.circuit then
            if stats.circuit.state == 'open' then
                Health.set('database', C.HEALTH.FAILED, 'circuit ouvert : base injoignable')
            elseif stats.circuit.state == 'half_open' then
                Health.set('database', C.HEALTH.DEGRADED, 'base en cours de récupération')
            else
                Health.set('database', C.HEALTH.HEALTHY, nil)
            end
        end
    end

    -- 2. Détecteurs dégradés (§51, §104).
    if ZShield.Detection then
        local degraded = 0
        for _, d in ipairs(ZShield.Detection.list()) do
            if d.health == C.HEALTH.DEGRADED then degraded = degraded + 1 end
        end
        if degraded > 0 then
            Health.set('detectors', C.HEALTH.DEGRADED, degraded .. ' détecteur(s) dégradé(s)')
        else
            Health.set('detectors', C.HEALTH.HEALTHY, nil)
        end
    end

    -- 3. Exceptions répétées (§51) : trop d'erreurs récentes = signal d'auto-défaillance.
    local counters = Log:counters()
    if counters.error > 100 then
        Health.set('enforcement', C.HEALTH.DEGRADED, counters.error .. ' erreurs cumulées')
    end

    return Health.report()
end

--- Marque un composant sain au démarrage réussi (§107).
function Health.markUp(component, detail)
    Health.set(component, C.HEALTH.HEALTHY, detail)
end

--- Lignes formatées pour la console (§158 zshield health).
function Health.lines()
    local report = Health.report()
    local out = { string.format('ZShield Health: %s (v%s)', report.overall, report.version) }
    local names = {}
    for n in pairs(report.components) do names[#names + 1] = n end
    table.sort(names)
    for _, n in ipairs(names) do
        local e = report.components[n]
        out[#out + 1] = string.format('  %-16s %-9s %s', n, e.status, e.detail or '')
    end
    return out
end

ZShield.Health = Health
