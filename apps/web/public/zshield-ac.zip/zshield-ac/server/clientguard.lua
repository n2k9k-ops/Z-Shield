--[[
    FILE:         server/clientguard.lua
    PURPOSE:      Réception SERVEUR des rapports du module client (zshield-client).
                  Trois rôles, du plus faible au plus fort côté preuve :
                    1. INGESTION corroborante — les détections client (no-recoil,
                       vision nocturne…) entrent en signaux de FAIBLE confiance, à
                       corréler (§26 : jamais un ban sur un signal client seul) ;
                    2. HEARTBEAT — un client qui cesse d'émettre (module retiré par un
                       tricheur) est OBSERVABLE côté serveur : signal plus fort ;
                    3. INTÉGRITÉ — le hash des scripts client est comparé ; une
                       falsification est un signal fort.

    SÉCURITÉ : chaque rapport est SIGNÉ (HMAC-SHA256) avec un secret de session émis
    par le serveur à la connexion. Fenêtre d'horodatage + anti-rejeu par nonce. Un
    client ne peut donc pas forger les rapports d'un autre, ni rejouer un ancien.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua,
                  shared/sha256.lua, (optionnel) server/detection engine bus
    PUBLIC API:   ZShield.ClientGuard.issueSecret(source) -> secret
                  ZShield.ClientGuard.canonical(source, ts, nonce, ids)
                  ZShield.ClientGuard.verify(source, msg) -> ok, reason
                  ZShield.ClientGuard.ingest(source, msg) -> { accepted, signals }
                  ZShield.ClientGuard.checkMissing(now) -> { sources... }
                  ZShield.ClientGuard.checkIntegrity(source, reportedHash) -> signal|nil
                  ZShield.ClientGuard.forget(source)
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log

local CG = {}
CG._sessions = {}   -- source -> { secret, last_seen, last_ts, enforced, expected_hash }

-- Déclarations anticipées : définies plus bas, utilisées par verify/ingest.
local enforce, emit

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function hmac(key, msg)
    if ZShield.Sha256 and ZShield.Sha256.hmac then return ZShield.Sha256.hmac(key, msg) end
    return nil
end

-- Comparaison à temps constant (anti-oracle temporel), pour toute vérif de secret.
local function constEq(a, b)
    if type(a) ~= 'string' or type(b) ~= 'string' or #a ~= #b then return false end
    local diff = 0
    for i = 1, #a do diff = diff | (string.byte(a, i) ~ string.byte(b, i)) end
    return diff == 0
end
CG.constEq = constEq

--- Dérive le secret de session à partir de la clé de PROVISIONING (partagée
--- opérateur, jamais transmise) et des deux nonces échangés. Le secret lui-même
--- ne circule JAMAIS : seuls les nonces (publics) transitent. Client et serveur
--- le recalculent chacun de leur côté.
function CG.deriveSecret(provisioningKey, sessionId, serverNonce, clientNonce)
    return hmac(provisioningKey, table.concat({
        tostring(sessionId), tostring(serverNonce), tostring(clientNonce) }, '|'))
end

--- Handshake par clé dérivée. `clientNonce` vient du client. Retourne les nonces
--- PUBLICS à renvoyer au client (jamais le secret). Repli « direct » si aucune
--- clé de provisioning n'est configurée (mode dev).
function CG.beginHandshake(source, clientNonce)
    local prov = cfg('client.provisioning_key', nil)
    if type(prov) ~= 'string' or prov == '' then
        return { mode = 'direct', secret = CG.issueSecret(source) }
    end
    local sessionId = Util.uuid('sid')
    local serverNonce = Util.uuid('sn')
    clientNonce = type(clientNonce) == 'string' and clientNonce:sub(1, 64) or 'c0'
    local secret = CG.deriveSecret(prov, sessionId, serverNonce, clientNonce)
    -- ROTATION : on dérive aussi un secret avec l'ANCIENNE clé, si configurée. Un
    -- client qui a encore l'ancienne clé (rotation en cours) reste accepté ; on se
    -- verrouille sur la clé qui vérifie au premier rapport. Aucun joueur coupé.
    local prev = cfg('client.provisioning_key_previous', nil)
    local secretPrev = (type(prev) == 'string' and prev ~= '')
        and CG.deriveSecret(prev, sessionId, serverNonce, clientNonce) or nil
    CG._sessions[source] = { secret = secret, secret_prev = secretPrev,
        last_seen = Util.now(), last_ts = nil, enforced = false,
        expected_hash = cfg('client.expected_hash', nil), challenge = nil, hwid = nil }
    return { mode = 'derived', session_id = sessionId, server_nonce = serverNonce }
end

--- Émet (et mémorise) un secret de session pour ce joueur (mode DIRECT / dev).
--- Le mode durci est CG.beginHandshake (clé dérivée, secret non transmis).
function CG.issueSecret(source)
    local secret = Util.uuid('cs'):gsub('cs_', '') .. Util.uuid('k'):gsub('k_', '')
    -- last_ts = nil : le premier rapport est accepté quel que soit son ts, puis
    -- chaque suivant doit être strictement plus grand (anti-rejeu, mémoire O(1)).
    CG._sessions[source] = { secret = secret, last_seen = Util.now(), last_ts = nil,
        enforced = false, expected_hash = cfg('client.expected_hash', nil), challenge = nil }
    return secret
end

--- Chaîne canonique déterministe à signer (identique client et serveur).
function CG.canonical(source, ts, nonce, ids)
    local list = type(ids) == 'table' and table.concat(ids, ',') or tostring(ids or '')
    return table.concat({ tostring(source), tostring(ts), tostring(nonce), list }, '|')
end

--- Vérifie un rapport signé. `msg` = { ts, nonce, ids = {...}, sig, hash? }.
--- Retourne ok, reason.
---
--- Anti-rejeu : l'horodatage (horloge MONOTONE du client, GetGameTimer) doit être
--- STRICTEMENT CROISSANT par session. On ne compare PAS à l'horloge serveur — les
--- deux horloges sont indépendantes. Un rejeu a forcément un ts <= dernier accepté,
--- donc il est refusé. À la reconnexion, un NOUVEAU secret est émis : un rapport
--- capturé avec l'ancien secret ne vérifie plus. Mémoire O(1) par session.
function CG.verify(source, msg)
    if type(msg) ~= 'table' then return false, 'no message' end
    local sess = CG._sessions[source]
    if not sess then return false, 'no session (client not registered)' end

    local ts = tonumber(msg.ts)
    if not ts then return false, 'no timestamp' end
    if sess.last_ts ~= nil and ts <= sess.last_ts then
        return false, 'stale/replayed timestamp'
    end
    if type(msg.nonce) ~= 'string' or msg.nonce == '' then return false, 'missing nonce' end

    -- La signature couvre source|ts|nonce|ids : elle lie le rapport à CETTE session
    -- (secret), à cet ordre (ts) et à ce contenu (ids). Sans le secret, infalsifiable.
    -- Comparaison à temps constant (évite un oracle temporel sur la signature).
    local canon = CG.canonical(source, ts, msg.nonce, msg.ids)
    if constEq(msg.sig, hmac(sess.secret, canon) or '') then
        sess.last_ts = ts
        return true, nil
    end
    -- Rotation : accepter l'ancienne clé une fois, puis se verrouiller dessus.
    if sess.secret_prev and constEq(msg.sig, hmac(sess.secret_prev, canon) or '') then
        sess.secret = sess.secret_prev
        sess.secret_prev = nil
        sess.last_ts = ts
        return true, nil
    end
    return false, 'bad signature'
end

--- Émet un DÉFI d'attestation d'intégrité (nonce aléatoire, à usage unique). Le
--- client doit répondre HMAC(secret, défi | hash_scripts). Comme le défi change à
--- chaque fois, une réponse capturée ne peut pas être rejouée.
function CG.issueChallenge(source)
    local sess = CG._sessions[source]
    if not sess then return nil end
    sess.challenge = Util.uuid('ch')
    return sess.challenge
end

--- Vérifie la réponse d'attestation. La réponse attendue lie le DÉFI FRAIS, le
--- SECRET de session, et le HASH ATTENDU des scripts. Une falsification (hash
--- différent) ou un rejeu (défi périmé) échoue. Défi consommé (usage unique).
function CG.verifyAttestation(source, response)
    local sess = CG._sessions[source]
    if not sess or not sess.challenge or sess.expected_hash == nil then return nil end
    local expected = hmac(sess.secret, sess.challenge .. '|' .. sess.expected_hash)
    sess.challenge = nil
    if not constEq(response or '', expected or '') then
        emit(source, 'client.attestation', C.SEVERITY.HIGH, 0.7,
            'integrity attestation failed (challenge-response)', C.CATEGORY.RESOURCE)
        enforce(sess, source, 'attestation', 'integrity attestation failed')
        return { tampered = true }
    end
    return { ok = true }
end

-- Émet un signal sur le bus de détection s'il existe (jamais une sanction directe).
function emit(source, detector, severity, confidence, reason, category)
    if not ZShield.Detection or not ZShield.Detection.emit then return end
    ZShield.Detection.emit({
        detector = detector, category = category or C.CATEGORY.STATE,
        severity = severity, confidence = confidence, reason = reason,
        source = source, metadata = { origin = 'client' },
    })
end

--- Vérifie puis INGÈRE un rapport : met à jour le heartbeat, transforme les
--- détections client en signaux de FAIBLE confiance (corroborants).
function CG.ingest(source, msg)
    local ok, reason = CG.verify(source, msg)
    if not ok then
        if Log then Log:security('clientguard', 'rapport client rejeté', { source = source, reason = reason }) end
        return { accepted = false, reason = reason, signals = 0 }
    end
    local sess = CG._sessions[source]
    local now = Util.now()

    -- Anti-flood : borne le nombre de rapports acceptés par fenêtre glissante de 10 s.
    -- Un client honnête émet ~1 rapport / 5 s ; au-delà d'un plafond large, on ignore.
    local maxPer10s = tonumber(cfg('client.max_reports_per_10s', 8)) or 8
    sess.win = sess.win or { start = now, n = 0 }
    if (now - sess.win.start) > 10000 then sess.win = { start = now, n = 0 } end
    sess.win.n = sess.win.n + 1
    if sess.win.n > maxPer10s then
        if Log then Log:security('clientguard', 'flood de rapports client', { source = source }) end
        return { accepted = false, reason = 'report rate exceeded', signals = 0 }
    end

    sess.last_seen = now

    local n = 0
    if type(msg.ids) == 'table' then
        for _, id in ipairs(msg.ids) do
            -- Confiance FAIBLE : un signal client seul ne bannit jamais (§26).
            emit(source, 'client.' .. tostring(id), C.SEVERITY.MEDIUM, 0.35,
                'client-reported: ' .. tostring(id), C.CATEGORY.STATE)
            n = n + 1
        end
    end

    -- Intégrité : hash des scripts client comparé à l'attendu, si configuré.
    -- Une falsification est un signal FORT ; elle peut déclencher une sanction.
    if msg.hash ~= nil and sess.expected_hash ~= nil and msg.hash ~= sess.expected_hash then
        emit(source, 'client.integrity', C.SEVERITY.HIGH, 0.7,
            'client script hash mismatch (tampered)', C.CATEGORY.RESOURCE)
        enforce(sess, source, 'integrity', 'client script hash mismatch (tampered)')
    end

    -- Scellé matériel : le HWID RAPPORTÉ par le client (signé, dans msg) doit
    -- coïncider avec le HWID OBSERVÉ serveur (jetons FiveM, source de vérité, lié
    -- via bindHwid). Une divergence = session détournée ou HWID falsifié : signal.
    if type(msg.hwid) == 'string' and msg.hwid ~= '' and type(sess.hwid) == 'string'
        and sess.hwid ~= '' and msg.hwid ~= sess.hwid then
        emit(source, 'client.hwid_spoof', C.SEVERITY.HIGH, 0.7,
            'client-reported HWID differs from server-observed HWID', C.CATEGORY.RESOURCE)
        enforce(sess, source, 'hwid_spoof', 'client-reported HWID differs from server-observed')
    end

    return { accepted = true, signals = n }
end

--- Intégrité isolée (si l'appelant a déjà le hash). Retourne un signal ou nil.
function CG.checkIntegrity(source, reportedHash)
    local sess = CG._sessions[source]
    if not sess or sess.expected_hash == nil or reportedHash == nil then return nil end
    if reportedHash ~= sess.expected_hash then
        emit(source, 'client.integrity', C.SEVERITY.HIGH, 0.7,
            'client script hash mismatch (tampered)', C.CATEGORY.RESOURCE)
        enforce(sess, source, 'integrity', 'client script hash mismatch (tampered)')
        return { block = false, tampered = true }
    end
    return nil
end

--- Construit une spéc d'incident pour une sanction automatique (kick par défaut,
--- ban si l'opérateur le choisit). N'est appelée que si l'opérateur EXIGE le client
--- ET active l'application (client.enforce). Sûr par défaut : rien sans ces choix.
function CG.incidentFor(source, kind, reason)
    local action = cfg('client.action', 'kick')
    local isBan = action == 'ban'
    return {
        source = source,
        detector = 'client.' .. kind,
        category = C.CATEGORY.RESOURCE,
        severity = isBan and C.SEVERITY.CRITICAL or C.SEVERITY.HIGH,
        confidence = 0.7,
        risk_after = isBan and 100 or 70,
        occurrences = 2,
        protection = 'client_' .. kind,
        instant_ban = isBan,
        requested_action = action,
        reason = reason,
    }
end

-- Ouvre l'incident de sanction une seule fois par session (anti-répétition).
function enforce(sess, source, kind, reason)
    if cfg('client.enforce', false) ~= true then return end
    if sess.enforced then return end
    sess.enforced = true
    if ZShield.Incident and ZShield.Incident.open then
        ZShield.Incident.open(CG.incidentFor(source, kind, reason))
    end
end

--- Heartbeat : liste des joueurs dont le client n'a plus émis depuis le délai.
--- Un module retiré par un tricheur cesse d'émettre — c'est OBSERVABLE ici.
--- Si l'opérateur EXIGE le client : signal serveur ; si de plus il active
--- l'application (client.enforce), une sanction (kick/ban) est ouverte.
function CG.checkMissing(now)
    now = now or Util.now()
    local timeout = tonumber(cfg('client.heartbeat_timeout_ms', 30000)) or 30000
    local require_client = cfg('client.require', false) == true
    local missing = {}
    for source, sess in pairs(CG._sessions) do
        if (now - (sess.last_seen or 0)) > timeout then
            missing[#missing + 1] = source
            if require_client then
                emit(source, 'client.heartbeat_missing', C.SEVERITY.HIGH, 0.6,
                    'client module stopped reporting (possibly removed)', C.CATEGORY.RESOURCE)
                enforce(sess, source, 'heartbeat_missing',
                    'required client module stopped reporting')
            end
        end
    end
    return missing
end

--- SCELLÉ MATÉRIEL (HWID). Le serveur OBSERVE le HWID via les jetons FiveM
--- (GetPlayerToken), non falsifiables par le client — c'est la source de vérité.
--- On le lie à la session. Le client, lui, RAPPORTE aussi son HWID (signé) : une
--- divergence entre les deux est un signal (usurpation / rejeu de session volée).
function CG.bindHwid(source, hwid)
    local sess = CG._sessions[source]
    if not sess or type(hwid) ~= 'string' or hwid == '' then return nil end
    sess.hwid = hwid
    -- Évasion de ban : si ce HWID (observé serveur) est sur la liste noire, on
    -- rouvre une sanction — un banni qui recrée un compte garde son matériel.
    if CG.hwidBanned(hwid) then
        emit(source, 'client.hwid_banned', C.SEVERITY.CRITICAL, 0.95,
            'hardware id on ban-evasion blocklist', C.CATEGORY.RESOURCE)
        enforce(sess, source, 'hwid_banned', 'hardware id on ban-evasion blocklist')
        return { banned = true }
    end
    return { bound = true }
end

--- Le HWID (observé serveur) est-il sur la liste noire d'évasion de ban ?
--- `client.hwid_blocklist` = liste de chaînes HWID (posée par l'opérateur / la
--- plateforme lors d'un ban). Comparaison exacte.
function CG.hwidBanned(hwid)
    if type(hwid) ~= 'string' or hwid == '' then return false end
    local list = cfg('client.hwid_blocklist', nil)
    if type(list) ~= 'table' then return false end
    for _, banned in ipairs(list) do
        if banned == hwid then return true end
    end
    -- Support d'une table-ensemble { [hwid] = true } en plus de la liste.
    return list[hwid] == true
end

function CG.forget(source) CG._sessions[source] = nil end
function CG.session(source) return CG._sessions[source] end

ZShield.ClientGuard = CG
return CG
