--[[
    FILE:         server/connection.lua
    PURPOSE:      Contrôle à la connexion (playerConnecting). Calcule un SCORE DE MENACE à
                  partir de signaux serveur-vérifiables et décide d'autoriser, de surveiller
                  ou de refuser la connexion — avant que le joueur n'entre.
    DEPENDENCIES: shared/constants.lua, core/log.lua, core/config.lua
    PUBLIC API:   ZShield.Connection.assess(info) -> { threat, reasons, allow, deny_reason }
                  ZShield.Connection.noteConnected(identifier) / noteDisconnected(identifier)

    Signaux (§ réglages « Gestion des connexions ») : VPN, nom non alphanumérique, Discord
    non lié, duplication de connexion, identifiants manquants. Chaque signal ajoute au
    score ; au-delà du seuil, la connexion est refusée. Aucune capture, aucune donnée du
    client non vérifiable : on juge des faits (identifiants, IP, nom).
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Log = ZShield.Log

local Connection = {}
Connection._connected = {}   -- identifier -> true (pour la duplication)
Connection._lastLeft = {}    -- identifier -> horodatage de déconnexion (anti-relog)

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function isAlphanumericName(name)
    if type(name) ~= 'string' then return false end
    -- Autorise lettres/chiffres/espaces/._- ; refuse le reste (caractères d'exploit,
    -- unicode invisible, etc.).
    return name:match('^[%w%s%._%-%[%]]+$') ~= nil
end

--- Le pseudo tombe-t-il sous un motif interdit ? `blocklist` : liste de sous-chaînes
--- en minuscule (usurpation « admin/staff/owner », marques, etc.).
local function nameHitsBlocklist(name, blocklist)
    if type(name) ~= 'string' or type(blocklist) ~= 'table' then return nil end
    local low = name:lower()
    for _, needle in ipairs(blocklist) do
        if type(needle) == 'string' and needle ~= '' and low:find(needle:lower(), 1, true) then
            return needle
        end
    end
    return nil
end

--- Évalue une connexion. `info` : { name, identifiers = { steam, license, discord, ip },
--- vpn = bool }. Retourne un verdict.
-- ---------------------------------------------------------------------------
-- LOCKDOWN (whitelist-only) & ANTI-RAID. Le lockdown ferme le serveur aux
-- identifiants non whitelistés (le temps qu'un raid passe). L'anti-raid détecte
-- une rafale de connexions dans une fenêtre et peut déclencher le lockdown auto.
-- ---------------------------------------------------------------------------
Connection._recent = {}         -- horodatages (s) des tentatives récentes
Connection._lockdownUntil = 0   -- lockdown auto actif jusqu'à ce timestamp (s)

local function inWhitelist(ids)
    local list = cfg('connection.whitelist', nil)
    if type(list) ~= 'table' then return false end
    for _, v in pairs(ids or {}) do
        if list[v] == true then return true end
        for _, w in ipairs(list) do if w == v then return true end end
    end
    return false
end

--- Lockdown actif ? Convar `zshield_lockdown "true"`, config connection.lockdown, ou
--- lockdown auto déclenché par un raid.
function Connection.lockdownActive(now)
    now = tonumber(now) or os.time()
    if type(GetConvar) == 'function' and GetConvar('zshield_lockdown', '') == 'true' then return true end
    if cfg('connection.lockdown', false) == true then return true end
    return Connection._lockdownUntil > now
end
function Connection.setLockdown(seconds, now)
    now = tonumber(now) or os.time()
    Connection._lockdownUntil = now + (tonumber(seconds) or 0)
end
function Connection.clearLockdown() Connection._lockdownUntil = 0 end

--- Enregistre une tentative et indique si on est en RAID (rafale de connexions).
--- Pur/testable. Déclenche le lockdown auto si `connection.auto_lockdown`.
function Connection.checkRaid(now)
    now = tonumber(now) or os.time()
    local windowS = (tonumber(cfg('connection.raid_window_ms', 15000)) or 15000) / 1000
    local maxN = tonumber(cfg('connection.raid_max', 8)) or 8
    Connection._recent[#Connection._recent + 1] = now
    local keep = {}
    for _, t in ipairs(Connection._recent) do if now - t <= windowS then keep[#keep + 1] = t end end
    Connection._recent = keep
    local raid = #keep >= maxN
    if raid and cfg('connection.auto_lockdown', false) == true then
        Connection.setLockdown(tonumber(cfg('connection.auto_lockdown_seconds', 120)) or 120, now)
    end
    return { raid = raid, count = #keep }
end

function Connection.assess(info)
    info = info or {}
    local ids = info.identifiers or {}
    local reasons = {}
    local threat = 0
    local nowS = tonumber(info.now) or os.time()

    -- Anti-raid : rafale de connexions -> alerte (et lockdown auto si configuré).
    local rd = Connection.checkRaid(nowS)
    if rd.raid then
        reasons[#reasons + 1] = 'raid détecté (' .. rd.count .. ' connexions)'
        if Log then Log:security('connection', 'RAID détecté', { count = rd.count }) end
        if ZShield.Bus then pcall(function() ZShield.Bus:emit('zshield.raid', { count = rd.count }) end) end
    end

    -- Lockdown : whitelist uniquement. Un identifiant non whitelisté est refusé net.
    if Connection.lockdownActive(nowS) and not inWhitelist(ids) then
        if Log then Log:security('connection', 'connexion refusée (lockdown)', { name = info.name }) end
        return {
            threat = 100, reasons = { 'lockdown' }, allow = false, lockdown = true,
            deny_reason = 'serveur en lockdown (accès whitelist uniquement)',
        }
    end

    -- VPN / proxy (fourni par une source de réputation IP ; ici on lit le drapeau).
    if info.vpn and cfg('connection.anti_vpn', false) then
        threat = threat + 40
        reasons[#reasons + 1] = 'vpn/proxy'
    end

    -- Nom non alphanumérique (exploits d'affichage, caractères invisibles).
    if cfg('connection.require_alphanumeric', false) and not isAlphanumericName(info.name) then
        threat = threat + 35
        reasons[#reasons + 1] = 'non-alphanumeric name'
    end

    -- Longueur de pseudo hors bornes (nom vide, ou trop long pour saturer l'UI).
    local nameLen = type(info.name) == 'string' and #info.name or 0
    local minLen = tonumber(cfg('connection.min_name_length', 0)) or 0
    local maxLen = tonumber(cfg('connection.max_name_length', 0)) or 0
    if minLen > 0 and nameLen < minLen then
        threat = threat + 20
        reasons[#reasons + 1] = 'name too short'
    end
    if maxLen > 0 and nameLen > maxLen then
        threat = threat + 20
        reasons[#reasons + 1] = 'name too long'
    end

    -- Pseudo sur liste interdite (usurpation de staff, marques, etc.).
    local hit = nameHitsBlocklist(info.name, cfg('connection.name_blocklist', nil))
    if hit then
        threat = threat + 45
        reasons[#reasons + 1] = 'blocked name pattern (' .. tostring(hit) .. ')'
    end

    -- Anti-XSS / injection : un pseudo ou un identifiant contenant des marqueurs
    -- d'injection (balises, script, interpolation) n'a aucune raison légitime.
    if cfg('connection.anti_xss', true) then
        local function tainted(s)
            if type(s) ~= 'string' then return false end
            local low = s:lower()
            return low:find('<', 1, true) or low:find('>', 1, true)
                or low:find('script', 1, true) or low:find('javascript:', 1, true)
                or low:find('${', 1, true) or low:find('%c') ~= nil
        end
        local bad = tainted(info.name)
        for _, v in pairs(ids) do if tainted(v) then bad = true end end
        if bad then
            threat = threat + 60
            reasons[#reasons + 1] = 'injection markers in name/identifiers'
        end
    end

    -- Anti-spoofer : identifiants forgés / incohérents. Un license mal formé, ou
    -- l'absence totale d'identifiants forts, trahit une usurpation.
    if cfg('connection.anti_spoofer', false) then
        local lic = ids.license
        local malformed = lic ~= nil and not tostring(lic):match('^license:[0-9a-fA-F]+$')
        local noStrongId = not ids.license and not ids.steam
        if malformed or noStrongId then
            threat = threat + 40
            reasons[#reasons + 1] = malformed and 'malformed license identifier'
                or 'no strong identifier (spoof)'
        end
    end

    -- Discord non lié.
    if cfg('connection.require_discord', false) and not ids.discord then
        threat = threat + 30
        reasons[#reasons + 1] = 'discord not linked'
    end

    -- Identifiants forts manquants (steam + license) : spoof probable.
    if not ids.license then
        threat = threat + 25
        reasons[#reasons + 1] = 'missing license identifier'
    end

    -- Duplication de connexion : le même identifiant déjà en ligne.
    local key = ids.license or ids.steam or ids.discord
    if key and Connection._connected[key] and cfg('connection.anti_duplication', true) then
        threat = threat + 50
        reasons[#reasons + 1] = 'connection duplication'
    end

    -- Anti-relog : reconnexion trop rapide après une déconnexion (contournement de
    -- kick, évasion de sanction). `now` injectable pour les tests.
    local cooldown = tonumber(cfg('connection.relog_cooldown_seconds', 0)) or 0
    if cooldown > 0 and key and Connection._lastLeft[key] then
        local now = tonumber(info.now) or os.time()
        local since = now - Connection._lastLeft[key]
        if since >= 0 and since < cooldown then
            threat = threat + 30
            reasons[#reasons + 1] = 'rapid reconnect (' .. since .. 's < ' .. cooldown .. 's)'
        end
    end

    local maxThreat = tonumber(cfg('connection.max_threat_score', 100)) or 100
    local allow = threat < maxThreat

    if not allow and Log then
        Log:security('connection', 'connexion refusée', { name = info.name, threat = threat, reasons = reasons })
    end

    return {
        threat = threat,
        reasons = reasons,
        allow = allow,
        deny_reason = allow and nil or ('score de menace ' .. threat .. ' : ' .. table.concat(reasons, ', ')),
    }
end

function Connection.noteConnected(identifier)
    if identifier then Connection._connected[identifier] = true end
end
function Connection.noteDisconnected(identifier, now)
    if identifier then
        Connection._connected[identifier] = nil
        -- Horodatage de départ pour l'anti-relog (`now` injectable en test).
        Connection._lastLeft[identifier] = tonumber(now) or os.time()
    end
end

ZShield.Connection = Connection
return Connection
