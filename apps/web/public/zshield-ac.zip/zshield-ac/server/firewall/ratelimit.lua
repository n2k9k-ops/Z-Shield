--[[
    FILE:         server/firewall/ratelimit.lua
    PURPOSE:      Stratégies de limitation de débit (§07). Un même rate limit pour toutes
                  les actions est une erreur : un burst légitime de tir n'a pas le même
                  profil qu'un achat en boutique. On fournit donc plusieurs stratégies.
    DEPENDENCIES: shared/constants.lua, core/util.lua
    PUBLIC API:   ZShield.RateLimit.tokenBucket(opts) -> limiter
                  ZShield.RateLimit.slidingWindow(opts) -> limiter
                  ZShield.RateLimit.cooldown(opts) -> limiter
                  chaque limiter : :check(key) -> allowed, meta
                                   :reset(key), :prune(now)

    §07 : Token Bucket pour les bursts, Sliding Window pour les events sensibles, Cooldown
    pour les actions individuelles, Adaptive pour les joueurs générant des anomalies.

    Le temps vient de Util.now() (monotone serveur), JAMAIS du client (§150). Toutes les
    structures sont bornées et élaguées : un attaquant qui inonde de clés distinctes ne
    doit pas faire croître la mémoire sans limite.
]]

ZShield = ZShield or {}
local Util = ZShield.Util

local RateLimit = {}

-- Plafond de clés suivies par limiter. Au-delà, on élague les plus anciennes.
local MAX_KEYS = 4096

-- Élague les entrées inactives depuis plus de `ttl` ms. Appelé paresseusement.
local function pruneStore(store, ttl, now, lastField)
    local count = 0
    for _ in pairs(store) do count = count + 1 end
    if count < MAX_KEYS then return end
    for key, entry in pairs(store) do
        if now - (entry[lastField] or 0) > ttl then store[key] = nil end
    end
end

-- ---------------------------------------------------------------------------
-- Token Bucket — §07. Absorbe les bursts jusqu'à `capacity`, se recharge à
-- `refillPerSec`. Un joueur peut tirer 10 fois d'affilée puis doit ralentir.
-- ---------------------------------------------------------------------------
function RateLimit.tokenBucket(opts)
    local capacity = opts.capacity or 10
    local refillPerSec = opts.refillPerSec or 1
    local store = {}

    return {
        kind = 'token_bucket',
        check = function(_, key)
            local now = Util.now()
            pruneStore(store, 60000, now, 'last')
            local b = store[key]
            if not b then
                b = { tokens = capacity, last = now }
                store[key] = b
            end
            -- Recharge proportionnelle au temps écoulé.
            local elapsed = (now - b.last) / 1000
            b.tokens = math.min(capacity, b.tokens + elapsed * refillPerSec)
            b.last = now

            if b.tokens >= 1 then
                b.tokens = b.tokens - 1
                return true, { remaining = math.floor(b.tokens), strategy = 'token_bucket' }
            end
            -- Temps avant le prochain jeton.
            local waitMs = math.ceil((1 - b.tokens) / refillPerSec * 1000)
            return false, { remaining = 0, retry_after_ms = waitMs, strategy = 'token_bucket' }
        end,
        reset = function(_, key) store[key] = nil end,
        prune = function(_, now) pruneStore(store, 0, now or Util.now(), 'last') end,
    }
end

-- ---------------------------------------------------------------------------
-- Sliding Window — §07. Au plus `limit` occurrences sur une fenêtre glissante de
-- `windowMs`. Plus strict qu'un bucket : pour les events sensibles (transfert
-- d'argent, don d'item) où l'on veut un plafond ferme sur une période.
-- ---------------------------------------------------------------------------
function RateLimit.slidingWindow(opts)
    local limit = opts.limit or 5
    local windowMs = opts.windowMs or 10000
    local store = {}

    return {
        kind = 'sliding_window',
        check = function(_, key)
            local now = Util.now()
            pruneStore(store, windowMs * 2, now, 'last')
            local w = store[key]
            if not w then w = { stamps = {}, last = now }; store[key] = w end
            w.last = now

            -- Retirer les timestamps sortis de la fenêtre.
            local cutoff = now - windowMs
            local kept = {}
            for i = 1, #w.stamps do
                if w.stamps[i] > cutoff then kept[#kept + 1] = w.stamps[i] end
            end
            w.stamps = kept

            if #w.stamps < limit then
                w.stamps[#w.stamps + 1] = now
                return true, { remaining = limit - #w.stamps, strategy = 'sliding_window' }
            end
            -- Le plus ancien timestamp détermine quand une place se libère.
            local waitMs = math.ceil(w.stamps[1] + windowMs - now)
            return false, { remaining = 0, retry_after_ms = waitMs, strategy = 'sliding_window' }
        end,
        reset = function(_, key) store[key] = nil end,
        prune = function(_, now) pruneStore(store, 0, now or Util.now(), 'last') end,
    }
end

-- ---------------------------------------------------------------------------
-- Cooldown — §07. Une seule action toutes les `cooldownMs`. Pour les actions
-- individuelles à délai fixe (respawn, achat unique).
-- ---------------------------------------------------------------------------
function RateLimit.cooldown(opts)
    local cooldownMs = opts.cooldownMs or 1000
    local store = {}

    return {
        kind = 'cooldown',
        check = function(_, key)
            local now = Util.now()
            pruneStore(store, cooldownMs * 4, now, 'last')
            local last = store[key] and store[key].last
            if not last or now - last >= cooldownMs then
                store[key] = { last = now }
                return true, { strategy = 'cooldown' }
            end
            return false, { retry_after_ms = cooldownMs - (now - last), strategy = 'cooldown' }
        end,
        reset = function(_, key) store[key] = nil end,
        prune = function(_, now) pruneStore(store, 0, now or Util.now(), 'last') end,
    }
end

-- ---------------------------------------------------------------------------
-- Adaptive — §07, §35. Enveloppe un limiter et RESSERRE sa limite pour les clés
-- marquées « suspectes ». Un joueur qui génère des anomalies est surveillé plus
-- strictement, sans pénaliser les joueurs normaux.
-- ---------------------------------------------------------------------------
function RateLimit.adaptive(baseLimiter, opts)
    opts = opts or {}
    -- Facteur appliqué à la limite quand la clé est suspecte (ex: 0.5 = moitié).
    local suspicionFactor = opts.suspicionFactor or 0.5
    local suspects = {}

    -- On enveloppe : pour une clé suspecte, on effectue N checks « fantômes »
    -- supplémentaires afin de consommer le quota plus vite. Simple et sans état
    -- dupliqué. `extraDrain` = combien de jetons de plus par action.
    local extraDrain = math.max(0, math.floor(1 / suspicionFactor) - 1)

    return {
        kind = 'adaptive',
        markSuspect = function(_, key) suspects[key] = Util.now() end,
        clearSuspect = function(_, key) suspects[key] = nil end,
        isSuspect = function(_, key) return suspects[key] ~= nil end,
        check = function(_, key)
            local allowed, meta = baseLimiter:check(key)
            if allowed and suspects[key] and extraDrain > 0 then
                -- Draine des jetons supplémentaires pour resserrer la limite.
                for _ = 1, extraDrain do baseLimiter:check(key) end
            end
            if meta then meta.adaptive = suspects[key] ~= nil end
            return allowed, meta
        end,
        reset = function(_, key) baseLimiter:reset(key); suspects[key] = nil end,
        prune = function(_, now) baseLimiter:prune(now) end,
    }
end

ZShield.RateLimit = RateLimit
