--[[
    FILE:         server/firewall/gameevents.lua
    PURPOSE:      Game Event Firewall (§08). Sépare les GAME events (damage, armes,
                  projectiles, explosions, création d'entité) des NETWORK events applicatifs.
                  Ces events natifs FXServer sont ANNULABLES : la couche empêche à la source
                  (CancelEvent) plutôt que de détecter après coup. C'est la règle d'or (§48,
                  §45) : rendre l'action impossible d'abord, détecter ensuite ce qui passe.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua, core/config.lua,
                  server/detection/engine.lua (émission de signaux), server/context.lua
    PUBLIC API:   ZShield.GameEvents.attach()               -- branche les natives (runtime)
                  ZShield.GameEvents.checkExplosion(ev)     -- pur, testable
                  ZShield.GameEvents.checkWeaponDamage(sender, data)
                  ZShield.GameEvents.checkEntityCreate(source, info)
                  ZShield.GameEvents.stats()

    Coût : nul au repos. Aucune boucle, aucun tick. Le C++ de FXServer n'appelle ces
    handlers QUE lorsqu'un event survient réellement ; le travail par event est O(1).

    IMPORTANT §26/§48 : un signal client (l'event vient du client) ne bannit jamais seul.
    Ici on BLOQUE l'action (réversible, proportionné) et on émet un signal ; la corrélation
    et le risk engine décident d'une éventuelle suite. Blocage ≠ sanction.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log

local GameEvents = {
    stats = { explosions = 0, expl_blocked = 0, damage = 0, dmg_blocked = 0,
              entities = 0, ent_blocked = 0 },
}

-- Explosions notoirement utilisées par les cheats (griefing de masse). Liste indicative,
-- élargie par config ; l'important est le CONTEXTE (§08), pas seulement le type.
-- Types GTA : 2=STICKYBOMB? on reste conservateur et data-driven côté config.
local ALWAYS_REVIEW_EXPLOSIONS = {
    [7]  = 'TANKSHELL',
    [8]  = 'HI_OCTANE',
    [16] = 'BARREL',
    [21] = 'GAS_TANK',
    [26] = 'BOAT',
    [27] = 'SHIP_DESTROY',
}

-- Types d'explosion à composante « feu » (pour l'option « annuler tous les feux »).
-- Indicatif ; l'agent peut aussi lever ev.isFire.
local FIRE_TYPES = {
    [15] = 'PETROL_PUMP',
    [18] = 'MOLOTOV',
    [36] = 'FIREWORK',
    [24] = 'FLARE',
}

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

-- Anti-crash : une valeur NaN, infinie ou de magnitude absurde dans un event est une
-- tentative de crash serveur (§ crash exploits). `limit` borne la magnitude plausible.
local function insane(n, limit)
    if n == nil then return false end
    n = tonumber(n)
    if not n then return false end
    if n ~= n then return true end                    -- NaN
    if n == math.huge or n == -math.huge then return true end
    if limit and math.abs(n) > limit then return true end
    return false
end

-- Limiteur d'explosions partagé, construit à la volée (le module ratelimit peut ne pas
-- être chargé dans certains tests). capacity = burst, refill = rate/s.
local _expl
function GameEvents._explLimiter()
    if _expl then return _expl end
    if not (ZShield.RateLimit and ZShield.RateLimit.tokenBucket) then return nil end
    _expl = ZShield.RateLimit.tokenBucket({
        capacity = cfg('game_events.explosion_burst', 10),
        refillPerSec = cfg('game_events.explosion_rate', 6) / 10,
    })
    return _expl
end
function GameEvents._resetLimiter() _expl = nil end

--- §08 explosions. Retourne verdict : { block=bool, severity, confidence, reason }.
--- Un joueur ne peut légitimement déclencher qu'un nombre borné d'explosions/s.
function GameEvents.checkExplosion(ev)
    ev = ev or {}
    if not cfg('game_events.enabled', true) then return { block = false } end

    -- Explosion sans acteur réseau plausible : suspect.
    local etype = tonumber(ev.explosionType)
    local reasons, severity, confidence, block = {}, C.SEVERITY.MEDIUM, 0.4, false

    -- Anti-crash : coordonnées / échelle impossibles = tentative de crash.
    if cfg('game_events.anti_crash', true) then
        if insane(ev.posX, 1e6) or insane(ev.posY, 1e6) or insane(ev.posZ, 1e6)
           or insane(ev.damageScale, 1000) or insane(ev.cameraShake, 1e6) then
            GameEvents.stats.expl_blocked = GameEvents.stats.expl_blocked + 1
            GameEvents.stats.explosions = GameEvents.stats.explosions + 1
            return { block = true, severity = C.SEVERITY.HIGH, confidence = 0.9,
                reason = 'crash attempt: impossible explosion values',
                category = C.CATEGORY.DAMAGE, source = ev.source }
        end
    end

    -- Options radicales (serveurs pacifiques) : annuler TOUTES les explosions,
    -- ou tous les feux. Choix explicite de l'opérateur, appliqué à la source.
    if cfg('game_events.cancel_all_explosions', false) then
        GameEvents.stats.expl_blocked = GameEvents.stats.expl_blocked + 1
        GameEvents.stats.explosions = GameEvents.stats.explosions + 1
        return { block = true, severity = C.SEVERITY.LOW, confidence = 1.0,
            reason = 'all explosions cancelled by policy',
            category = C.CATEGORY.DAMAGE, source = ev.source }
    end
    if cfg('game_events.cancel_all_fires', false) and (ev.isFire == true or FIRE_TYPES[etype or -1]) then
        GameEvents.stats.expl_blocked = GameEvents.stats.expl_blocked + 1
        GameEvents.stats.explosions = GameEvents.stats.explosions + 1
        return { block = true, severity = C.SEVERITY.LOW, confidence = 1.0,
            reason = 'all fires cancelled by policy',
            category = C.CATEGORY.DAMAGE, source = ev.source }
    end

    -- Explosions invisibles / inaudibles : quasi toujours du grief discret. Les
    -- champs isInvisible / isAudible viennent de l'explosionEvent.
    if cfg('game_events.block_invisible_explosions', true) and ev.isInvisible == true then
        GameEvents.stats.expl_blocked = GameEvents.stats.expl_blocked + 1
        GameEvents.stats.explosions = GameEvents.stats.explosions + 1
        return { block = true, severity = C.SEVERITY.HIGH, confidence = 0.85,
            reason = 'invisible explosion (griefing)',
            category = C.CATEGORY.DAMAGE, source = ev.source }
    end
    if cfg('game_events.block_inaudible_explosions', true) and ev.isAudible == false then
        GameEvents.stats.expl_blocked = GameEvents.stats.expl_blocked + 1
        GameEvents.stats.explosions = GameEvents.stats.explosions + 1
        return { block = true, severity = C.SEVERITY.HIGH, confidence = 0.85,
            reason = 'inaudible explosion (griefing)',
            category = C.CATEGORY.DAMAGE, source = ev.source }
    end

    -- Type d'explosion INTERDIT par l'opérateur (pilotable) : bloqué à la source.
    -- Certains types n'ont aucune raison légitime sur un serveur RP (canon
    -- orbital, obus de char…). Refuser d'emblée coupe le grief avant tout effet.
    local blockTypes = cfg('game_events.explosion_type_blocklist', nil)
    if etype and type(blockTypes) == 'table' and (blockTypes[etype] or blockTypes[tostring(etype)]) then
        GameEvents.stats.expl_blocked = GameEvents.stats.expl_blocked + 1
        GameEvents.stats.explosions = GameEvents.stats.explosions + 1
        return { block = true, severity = C.SEVERITY.HIGH, confidence = 0.9,
            reason = 'blocked explosion type ' .. tostring(etype),
            category = C.CATEGORY.DAMAGE, source = ev.source }
    end

    -- Explosions à fort potentiel de grief : on relève la gravité, sans bannir.
    if etype and ALWAYS_REVIEW_EXPLOSIONS[etype] then
        severity = C.SEVERITY.HIGH
        confidence = 0.55
        reasons[#reasons + 1] = 'high-grief explosion type ' .. tostring(etype)
    end

    -- Fréquence : le vrai signal. Un flood d'explosions par un même acteur est anormal.
    local src = ev.source
    if src and cfg('game_events.block_explosion_flood', true) then
        local limiter = GameEvents._explLimiter()
        if limiter then
            local ok = limiter:check('explosion:' .. tostring(src))
            if not ok then
                block = true
                severity = C.SEVERITY.HIGH
                confidence = 0.8
                reasons[#reasons + 1] = 'explosion flood'
            end
        end
    end

    if block then GameEvents.stats.expl_blocked = GameEvents.stats.expl_blocked + 1 end
    GameEvents.stats.explosions = GameEvents.stats.explosions + 1

    return {
        block = block, severity = severity, confidence = confidence,
        reason = #reasons > 0 and table.concat(reasons, '; ') or 'explosion observed',
        category = C.CATEGORY.DAMAGE, source = src,
    }
end

--- §08 dégâts d'arme. Le serveur ne connaît pas toute la vérité balistique, mais des
--- bornes dures (dégâts impossibles, arme non whitelistée) sont serveur-vérifiables.
function GameEvents.checkWeaponDamage(sender, data)
    data = data or {}
    if not cfg('game_events.enabled', true) then return { block = false } end
    GameEvents.stats.damage = GameEvents.stats.damage + 1

    -- Anti-crash : dégât NaN/infini/absurde = tentative de crash.
    if cfg('game_events.anti_crash', true) and insane(data.weaponDamage, 1e7) then
        GameEvents.stats.dmg_blocked = GameEvents.stats.dmg_blocked + 1
        return { block = true, severity = C.SEVERITY.HIGH, confidence = 0.9,
            reason = 'crash attempt: impossible weapon damage',
            category = C.CATEGORY.DAMAGE, source = sender }
    end

    local dmg = tonumber(data.weaponDamage) or 0
    local maxDmg = cfg('game_events.max_weapon_damage', 250)
    local reasons, severity, confidence, block = {}, C.SEVERITY.MEDIUM, 0.4, false

    -- Option « pas de dégât véhicule aux joueurs » : bloque les dégâts dont la
    -- source est un véhicule (renversement / collision). Hashs natifs GTA.
    if cfg('vehicle.disable_damage_to_players', false) then
        local wt = data.weaponType and Util.u32(data.weaponType)
        if wt and (wt == Util.u32(-1553120962)   -- WEAPON_RUN_OVER_BY_CAR
                or wt == Util.u32(133987706)      -- WEAPON_RAMMED_BY_CAR
                or wt == Util.u32(-1553120962)) then
            GameEvents.stats.dmg_blocked = GameEvents.stats.dmg_blocked + 1
            return { block = true, severity = C.SEVERITY.LOW, confidence = 1.0,
                reason = 'vehicle damage to players disabled by policy',
                category = C.CATEGORY.DAMAGE, source = sender }
        end
    end

    -- Arme sur liste d'interdiction (pilotée depuis le dashboard) : bloquée à la source.
    if ZShield.Blacklist and ZShield.Blacklist.weaponBlocked(data.weaponType) then
        block = true
        severity = C.SEVERITY.HIGH
        confidence = 0.9
        reasons[#reasons + 1] = 'blacklisted weapon'
    end

    -- Dégât au-delà d'un plafond dur : modified damage (impossible légitimement).
    if dmg > maxDmg then
        block = true
        severity = C.SEVERITY.HIGH
        confidence = 0.85
        reasons[#reasons + 1] = string.format('damage %d over cap %d', dmg, maxDmg)
    end

    -- Auto-dégât signalé sur autrui, ou cible == acteur incohérente : signal léger.
    if data.hitGlobalId and sender and tostring(data.hitGlobalId) == tostring(sender)
       and dmg > 0 then
        confidence = math.max(confidence, 0.5)
        reasons[#reasons + 1] = 'self-attributed damage'
    end

    if block then GameEvents.stats.dmg_blocked = GameEvents.stats.dmg_blocked + 1 end
    return {
        block = block, severity = severity, confidence = confidence,
        reason = #reasons > 0 and table.concat(reasons, '; ') or 'weapon damage observed',
        category = C.CATEGORY.DAMAGE, source = sender,
    }
end

--- §16 création d'entité. Complète le détecteur d'entité par un point de blocage natif.
--- Si l'entity lockdown OneSync est actif (§21), l'essentiel est déjà empêché ; ici on
--- borne le quota et refuse les créations en état incohérent.
function GameEvents.checkEntityCreate(source, info)
    info = info or {}
    if not cfg('game_events.enabled', true) then return { block = false } end
    GameEvents.stats.entities = GameEvents.stats.entities + 1

    local reasons, block, severity, confidence = {}, false, C.SEVERITY.MEDIUM, 0.4

    -- Véhicule/modèle sur liste d'interdiction (pilotée depuis le dashboard).
    if ZShield.Blacklist and ZShield.Blacklist.vehicleBlocked(info.model) then
        block = true
        severity = C.SEVERITY.HIGH
        confidence = 0.9
        reasons[#reasons + 1] = 'blacklisted vehicle/model'
    end

    -- Ped ou objet/prop sur liste d'interdiction (grief : peds « monstres »,
    -- props géants pour bloquer une zone). Refusé à la création.
    if ZShield.Blacklist and ZShield.Blacklist.modelBlocked(info.model) then
        block = true
        severity = C.SEVERITY.HIGH
        confidence = 0.9
        reasons[#reasons + 1] = ZShield.Blacklist.pedBlocked(info.model)
            and 'blacklisted ped model' or 'blacklisted object model'
    end

    -- Whitelists (mode « autoriser uniquement »). Le type d'entité est fourni par
    -- le pare-feu (info.kind : 'vehicle' | 'ped' | 'object') ; à défaut on teste
    -- les trois familles (un modèle hors de TOUTES les whitelists actives est refusé).
    if ZShield.Blacklist and ZShield.Blacklist.notWhitelisted then
        local fam = info.kind
        local families = fam and { fam } or { 'vehicle', 'ped', 'object' }
        for _, f in ipairs(families) do
            if ZShield.Blacklist.notWhitelisted(f, info.model) then
                block = true
                severity = C.SEVERITY.HIGH
                confidence = 0.85
                reasons[#reasons + 1] = 'model not in ' .. f .. ' whitelist'
                break
            end
        end
    end

    -- Pickup (arme/objet ramassable) : refusé si l'opérateur bloque les pickups.
    if info.kind == 'pickup' and cfg('game_events.block_pickups', false) then
        block = true
        severity = C.SEVERITY.MEDIUM
        confidence = 0.85
        reasons[#reasons + 1] = 'pickup spawn blocked by policy'
    end

    -- Spawn isolé : entité créée trop loin de son propriétaire (spawn caché de
    -- grief). `info.dist` (mètres) est fourni par l'adaptateur ; clé de distance max.
    local maxDist = tonumber(cfg('game_events.max_spawn_distance_m', 0)) or 0
    if maxDist > 0 and type(info.dist) == 'number' and info.dist > maxDist then
        block = true
        severity = C.SEVERITY.HIGH
        confidence = 0.8
        reasons[#reasons + 1] = string.format('isolated spawn %.0fm > %.0fm', info.dist, maxDist)
    end

    -- Quota de spawn par joueur, via le détecteur d'entité existant s'il est là (§16).
    -- Entity.onCreating(source, model, type) -> allowed, signal.
    if source and ZShield.Entity and ZShield.Entity.onCreating then
        local allowed, signal = ZShield.Entity.onCreating(source, info.model, info.type)
        if allowed == false then
            block = true
            severity = (signal and signal.severity) or C.SEVERITY.HIGH
            confidence = (signal and signal.confidence) or 0.75
            reasons[#reasons + 1] = (signal and signal.reason) or 'entity spawn quota exceeded'
        end
    end

    -- Modèle explicitement blacklisté par l'opérateur (§25 capacité, pas nom de menu).
    local blacklist = cfg('game_events.entity_model_blacklist', nil)
    if blacklist and info.model and blacklist[info.model] then
        block = true
        severity = C.SEVERITY.HIGH
        confidence = 0.9
        reasons[#reasons + 1] = 'blacklisted entity model'
    end

    if block then GameEvents.stats.ent_blocked = GameEvents.stats.ent_blocked + 1 end
    return {
        block = block, severity = severity, confidence = confidence,
        reason = #reasons > 0 and table.concat(reasons, '; ') or 'entity create observed',
        category = C.CATEGORY.ENTITY, source = source,
    }
end

--- Anti-suppression de véhicule (grief : effacer les véhicules d'autrui). Bloque
--- la suppression d'une entité réseau demandée par un joueur qui n'en est PAS le
--- propriétaire. `info` = { owner, kind, netId } fourni par l'adaptateur.
--- Pur/testable : renvoie { block, ... }.
function GameEvents.checkEntityRemove(source, info)
    info = info or {}
    if not cfg('game_events.anti_vehicle_deletion', false) then return { block = false } end
    -- On ne restreint que les véhicules (ou entités sans type connu).
    if info.kind and info.kind ~= 'vehicle' then return { block = false } end
    -- Le propriétaire a le droit de supprimer son propre véhicule.
    if info.owner ~= nil and source ~= nil and tostring(info.owner) == tostring(source) then
        return { block = false }
    end
    GameEvents.stats.ent_blocked = GameEvents.stats.ent_blocked + 1
    return { block = true, severity = C.SEVERITY.HIGH, confidence = 0.8,
        reason = 'vehicle deletion by non-owner (anti-grief)',
        category = C.CATEGORY.ENTITY, source = source }
end

--- Anti changement de modèle : un joueur qui change de modèle de personnage à la
--- volée (souvent pour un ped interdit / avantage) est suspect quand l'opérateur
--- l'interdit. `info` = { to } (modèle cible). Optionnellement une whitelist de
--- modèles joueur autorisés via game_events.allowed_player_models.
function GameEvents.checkModelChange(source, info)
    info = info or {}
    if not cfg('game_events.anti_model_change', false) then return { block = false } end
    local allowed = cfg('game_events.allowed_player_models', nil)
    if type(allowed) == 'table' and info.to ~= nil then
        -- Normalise en hash, que la cible soit un nom ("mp_m_freemode_01") ou un hash.
        local h = type(info.to) == 'number' and Util.u32(info.to) or Util.joaat(tostring(info.to))
        for _, m in ipairs(allowed) do
            local mh = type(m) == 'number' and Util.u32(m) or Util.joaat(tostring(m))
            if mh == h then return { block = false } end   -- modèle autorisé
        end
    end
    return { block = true, severity = C.SEVERITY.MEDIUM, confidence = 0.7,
        reason = 'unauthorized player model change',
        category = C.CATEGORY.ENTITY, source = source }
end

-- Convertit un verdict en signal sur le bus (§10). Ne décide RIEN : alimente la chaîne.
local function emitVerdict(v, detectorId)
    if not v or not ZShield.Detection then return end
    -- Un simple "observé" sans anomalie n'a pas à polluer le bus.
    if not v.block and (v.confidence or 0) < 0.5 then return end
    ZShield.Detection.emit({
        detector = detectorId,
        category = v.category,
        severity = v.severity,
        confidence = v.confidence,
        reason = v.reason,
        source = v.source,
        metadata = { blocked = v.block == true },
    })
end

-- Branche les natives FXServer. Ne fait rien hors runtime (tests) : les fonctions
-- checkXxx restent appelables directement.
function GameEvents.attach()
    if type(AddEventHandler) ~= 'function' then return false end

    AddEventHandler('explosionEvent', function(src, ev)
        ev = ev or {}
        ev.source = tonumber(src)
        local v = GameEvents.checkExplosion(ev)
        emitVerdict(v, 'gameevent.explosion')
        if v.block and type(CancelEvent) == 'function' then CancelEvent() end
    end)

    AddEventHandler('weaponDamageEvent', function(src, data)
        local sender = tonumber(src)
        local v = GameEvents.checkWeaponDamage(sender, data)
        emitVerdict(v, 'gameevent.weapon_damage')
        -- Détecteur comportemental (cadence, dégâts vs arme, ratio létal). Émet ses
        -- propres signaux sur le bus ; ne bloque pas ici (la corrélation décide).
        if ZShield.Weapon and ZShield.Weapon.emit then
            local now = (type(GetGameTimer) == 'function') and GetGameTimer() or (Util.now() * 1000)
            pcall(ZShield.Weapon.emit, sender, data, now)
        end
        if v.block and type(CancelEvent) == 'function' then CancelEvent() end
    end)

    AddEventHandler('startProjectileEvent', function(src, data)
        -- Détecteur comportemental de projectiles (spam, tir à distance). Émet ses
        -- signaux ; le blocage éventuel se fait via la corrélation/enforcement.
        if ZShield.Projectile and ZShield.Projectile.emit then
            local owner = tonumber(src)
            local now = (type(GetGameTimer) == 'function') and GetGameTimer() or (Util.now() * 1000)
            pcall(ZShield.Projectile.emit, owner, data, now)
        end
    end)

    AddEventHandler('entityCreating', function(handle)
        -- L'owner réel vient des natives quand elles existent ; sinon on borne côté quota.
        local owner
        if type(NetworkGetEntityOwner) == 'function' then
            owner = NetworkGetEntityOwner(handle)
        end
        local model
        if type(GetEntityModel) == 'function' then model = GetEntityModel(handle) end
        local v = GameEvents.checkEntityCreate(owner, { model = model, handle = handle })
        emitVerdict(v, 'gameevent.entity_create')
        if v.block and type(CancelEvent) == 'function' then CancelEvent() end
    end)

    Log:info('gameevents', 'game event firewall attached (explosion/damage/entity)')
    return true
end

function GameEvents.getStats() return Util.deepCopy(GameEvents.stats) end

ZShield.GameEvents = GameEvents
