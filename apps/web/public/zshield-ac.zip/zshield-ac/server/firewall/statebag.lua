--[[
    FILE:         server/firewall/statebag.lua
    PURPOSE:      State Bag Security (§10). Les state bags répliqués sont un vecteur d'abus :
                  un client peut tenter d'écrire une clé sensible (godmode, admin, money) que
                  seul le serveur devrait fixer. Cette couche surveille QUI écrit QUOI, à
                  quelle FRÉQUENCE, et refuse les écritures non autorisées.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua, core/config.lua,
                  server/firewall/ratelimit.lua (optionnel), server/detection/engine.lua
    PUBLIC API:   ZShield.StateBag.protect(key, policy)   -- déclare une clé protégée
                  ZShield.StateBag.check(ctx)             -- pur, testable
                  ZShield.StateBag.attach()               -- branche la native
                  ZShield.StateBag.stats()

    Coût : nul au repos. La native n'appelle le handler QUE sur changement d'une clé
    répliquée ; on filtre d'abord par clé protégée (table O(1)) avant tout travail.

    Modèle de policy par clé :
      { writer = 'server'|'any', max_per_10s = n, allowed_type = 'number'|'boolean'|... }
    writer='server' : seule une écriture d'origine serveur (source 0/absent) est légitime ;
    une écriture attribuée à un joueur est refusée et signalée (§01 : le client ne décide
    jamais d'une valeur importante).
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log

local StateBag = {
    policies = {},   -- key -> policy
    stats = { changes = 0, denied = 0, protected_keys = 0 },
    _limiter = nil,
}

-- Clés sensibles protégées par défaut : à ajuster selon le framework, mais ces noms
-- reviennent partout et ne devraient JAMAIS être fixés par un client.
local DEFAULT_PROTECTED = {
    godmode      = { writer = 'server', allowed_type = 'boolean' },
    invincible   = { writer = 'server', allowed_type = 'boolean' },
    isAdmin      = { writer = 'server', allowed_type = 'boolean' },
    admin        = { writer = 'server' },
    money        = { writer = 'server', allowed_type = 'number' },
    bank         = { writer = 'server', allowed_type = 'number' },
    job          = { writer = 'server' },
    frozen       = { writer = 'server', allowed_type = 'boolean' },
    noclip       = { writer = 'server', allowed_type = 'boolean' },
}

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

--- Déclare/écrase une clé protégée et sa policy.
function StateBag.protect(key, policy)
    if type(key) ~= 'string' then return false end
    StateBag.policies[key] = policy or { writer = 'server' }
    StateBag.stats.protected_keys = Util.count(StateBag.policies)
    return true
end

--- Charge les protections par défaut + celles de la config. Idempotent.
function StateBag.loadDefaults()
    for k, p in pairs(DEFAULT_PROTECTED) do
        if StateBag.policies[k] == nil then StateBag.policies[k] = p end
    end
    local extra = cfg('statebags.protect', nil)
    if type(extra) == 'table' then
        for k, p in pairs(extra) do StateBag.policies[k] = p end
    end
    StateBag.stats.protected_keys = Util.count(StateBag.policies)
end

local function limiter()
    if StateBag._limiter then return StateBag._limiter end
    if not (ZShield.RateLimit and ZShield.RateLimit.slidingWindow) then return nil end
    StateBag._limiter = ZShield.RateLimit.slidingWindow({
        limit = cfg('statebags.max_writes_10s', 20), windowMs = 10000,
    })
    return StateBag._limiter
end

--- Vérifie un changement de state bag. ctx = { key, value, source, protectedOnly }.
--- Retourne { deny=bool, severity, confidence, reason } ; deny=true => l'écriture doit
--- être rejetée/réinitialisée par l'appelant.
function StateBag.check(ctx)
    ctx = ctx or {}
    if not cfg('statebags.enabled', true) then return { deny = false } end
    StateBag.stats.changes = StateBag.stats.changes + 1

    local policy = StateBag.policies[ctx.key]
    if not policy then return { deny = false } end   -- clé non protégée : ignorée (coût ~0)

    local src = ctx.source
    local reasons, deny, severity, confidence = {}, false, C.SEVERITY.HIGH, 0.6

    -- writer='server' : une écriture attribuée à un joueur (source > 0) est illégitime.
    if (policy.writer or 'server') == 'server' and src and tonumber(src) and tonumber(src) > 0 then
        deny = true
        confidence = 0.9
        reasons[#reasons + 1] = string.format("client wrote server-only key '%s'", ctx.key)
    end

    -- Type attendu.
    if policy.allowed_type and ctx.value ~= nil and type(ctx.value) ~= policy.allowed_type then
        deny = true
        confidence = math.max(confidence, 0.7)
        reasons[#reasons + 1] = string.format("key '%s' expected %s, got %s",
            ctx.key, policy.allowed_type, type(ctx.value))
    end

    -- Fréquence d'écriture anormale sur une clé protégée.
    if src and tonumber(src) and tonumber(src) > 0 then
        local lim = limiter()
        if lim then
            local ok = lim:check('sb:' .. tostring(src) .. ':' .. ctx.key)
            if not ok then
                deny = true
                reasons[#reasons + 1] = 'protected key write flood'
            end
        end
    end

    if deny then StateBag.stats.denied = StateBag.stats.denied + 1 end
    return {
        deny = deny, severity = severity, confidence = confidence,
        reason = #reasons > 0 and table.concat(reasons, '; ') or 'state bag write observed',
        category = C.CATEGORY.STATE, source = src,
    }
end

-- Branche la native. AddStateBagChangeHandler(keyFilter, bagFilter, handler).
-- keyFilter=nil => toutes les clés ; on filtre nous-mêmes sur les clés protégées.
function StateBag.attach()
    StateBag.loadDefaults()
    if type(AddStateBagChangeHandler) ~= 'function' then return false end

    AddStateBagChangeHandler(nil, nil, function(bagName, key, value, _reserved, replicated)
        -- Résout la source à partir du nom du bag (ex: "player:12") quand c'est possible.
        local source
        local netid = bagName and bagName:match('^player:(%d+)$')
        if netid then source = tonumber(netid) end

        local v = StateBag.check({ key = key, value = value, source = source })
        if not v.deny and (v.confidence or 0) < 0.5 then return end

        if ZShield.Detection then
            ZShield.Detection.emit({
                detector = 'statebag.' .. tostring(key),
                category = v.category, severity = v.severity, confidence = v.confidence,
                reason = v.reason, source = source, metadata = { denied = v.deny, replicated = replicated },
            })
        end

        -- Réinitialisation : on ne peut pas "annuler" un state bag, mais on réécrit la
        -- valeur serveur légitime si un resetter est fourni (§88, réversible).
        if v.deny and type(StateBag.resetter) == 'function' then
            pcall(StateBag.resetter, bagName, key, source)
        end
    end)

    Log:info('statebag', 'state bag firewall attached', { protected = StateBag.stats.protected_keys })
    return true
end

function StateBag.getStats() return Util.deepCopy(StateBag.stats) end

ZShield.StateBag = StateBag
