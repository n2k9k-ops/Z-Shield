--[[
    FILE:         server/firewall/firewall.lua
    PURPOSE:      Pare-feu d'events (§04, §05). Chaque event réseau est traité comme une API
                  publique hostile. Pipeline zéro-confiance : source → schéma → rate limit →
                  autorisation → état → exécution.
    DEPENDENCIES: shared/constants.lua, shared/schema.lua, core/util.lua, core/log.lua,
                  core/config.lua, server/context.lua, server/firewall/ratelimit.lua
    PUBLIC API:   ZShield.Firewall.register(definition) -> ok, err
                  ZShield.Firewall.dispatch(name, source, args) -> verdict, ctx
                  ZShield.Firewall.stats() / ZShield.Firewall.list()

    §04, l'ordre est normatif :
      SOURCE → ARGUMENT/TYPE → RATE LIMIT → PERMISSION → STATE → CONTEXT → BUSINESS → ACTION
    On s'arrête au PREMIER échec et on émet un signal correspondant (bus 'firewall.verdict').

    Le firewall NE FAIT PAS confiance aux arguments : il les valide contre un schéma, puis
    l'exécuteur métier ne reçoit qu'un contexte assaini. Le contre-exemple de §04
    (RegisterNetEvent("reward", function(amount) GiveMoney(source, amount) end)) est
    précisément ce que cette architecture empêche.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Schema = ZShield.Schema
local Util = ZShield.Util
local Log = ZShield.Log
local Bus = ZShield.Bus
local Context = ZShield.Context
local RateLimit = ZShield.RateLimit

local Firewall = { events = {}, stats = { allow = 0, reject = 0, unknown = 0, rate_limit = 0, unauthorized = 0, bad_state = 0 } }

--- Définition d'un event protégé :
--- {
---   name = 'shop:buy',
---   schema = { type='table', fields={...} },   -- valide les args (§06)
---   states = { 'ACTIVE', 'VEHICLE' },           -- états autorisés (§08), optionnel
---   rateLimit = { strategy='token_bucket', capacity=5, refillPerSec=1 }, -- §07, optionnel
---   authorize = function(ctx) return true end,  -- §04, optionnel
---   validate  = function(ctx) return true end,  -- règle métier (§04), optionnel
---   execute   = function(ctx) ... end,          -- exécution, reçoit un contexte assaini
--- }
function Firewall.register(def)
    if type(def) ~= 'table' or type(def.name) ~= 'string' then
        return false, 'event definition requires a name'
    end
    if Firewall.events[def.name] then
        return false, 'event already registered: ' .. def.name
    end
    if def.execute ~= nil and type(def.execute) ~= 'function' then
        return false, 'execute must be a function'
    end

    -- Construire le limiter une seule fois à l'enregistrement.
    local limiter
    if def.rateLimit then
        local rl = def.rateLimit
        if rl.strategy == 'sliding_window' then
            limiter = RateLimit.slidingWindow(rl)
        elseif rl.strategy == 'cooldown' then
            limiter = RateLimit.cooldown(rl)
        else
            limiter = RateLimit.tokenBucket(rl) -- défaut
        end
        if rl.adaptive then
            limiter = RateLimit.adaptive(limiter, rl)
        end
    end

    Firewall.events[def.name] = {
        name = def.name,
        schema = def.schema,
        states = def.states,
        limiter = limiter,
        authorize = def.authorize,
        validate = def.validate,
        execute = def.execute,
        version = def.version or 1,
        registered_at = Util.now(),
        hits = 0,
    }
    Log:debug('firewall', 'event registered', { name = def.name, version = def.version or 1 })
    return true
end

-- Émet un verdict sur le bus et compte. Point unique pour la traçabilité (§29).
local function verdict(name, source, result, reason, meta)
    Firewall.stats[result:lower()] = (Firewall.stats[result:lower()] or 0) + 1
    local payload = {
        event = name, source = source, verdict = result, reason = reason,
        meta = meta, at = Util.now(),
    }
    -- Un rejet est un signal de sécurité ; un allow reste en debug pour ne pas noyer les logs.
    if result == C.VERDICT.ALLOW then
        Log:trace('firewall', 'event allowed', { event = name, source = source })
    else
        Log:security('firewall', 'event ' .. result, { event = name, source = source, reason = reason })
    end
    Bus:emit('firewall.verdict', payload)
    return result, payload
end

--- Traite un event entrant. `source` est le joueur émetteur (fourni par FXServer, non
--- falsifiable côté client). `args` est la charge utile, hostile par défaut.
function Firewall.dispatch(name, source, args)
    -- Si le firewall est désactivé en config, on laisse passer en journalisant (mode dégradé
    -- volontaire). Le core ne doit pas bloquer le gameplay s'il est éteint.
    if ZShield.Config and ZShield.Config.value('events.enabled') == false then
        return C.VERDICT.ALLOW, { event = name, bypassed = true }
    end

    -- --- Règles d'événements pilotées (liste noire, débit par event, exceptions).
    -- S'applique à TOUT événement, connu ou non, avant le reste du pipeline.
    if ZShield.Triggers then
        local tv = ZShield.Triggers.check(source, name)
        if tv and tv.block then
            return verdict(name, source, C.VERDICT.REJECT, tv.reason or 'trigger rule')
        end
    end

    local def = Firewall.events[name]

    -- --- ANTI SERVER-DUMPER : un dumper énumère en rafale les events (dont beaucoup
    -- inconnus) pour aspirer la logique serveur. On mesure par joueur/fenêtre ; au-delà
    -- des seuils, on route une trace d'injection (pipeline de sanction prouvé). Sûr par
    -- défaut : on trace/journalise, on ne bloque le gameplay que si antidump.reject.
    if ZShield.AntiDump and source ~= nil and source ~= 0 then
        local dd = ZShield.AntiDump.observe(source, name, Util.now(), def == nil)
        if dd and dd.dumping then
            if ZShield.Injection and ZShield.Injection.report then
                pcall(function()
                    ZShield.Injection.report(source, 'server_dump',
                        { distinct = dd.distinct, unknown = dd.unknown, event = name })
                end)
            end
            Log:security('antidump', 'énumération/dump d\'events détecté', {
                source = source, distinct = dd.distinct, unknown = dd.unknown,
            })
            if ZShield.Config and ZShield.Config.value('antidump.reject', false) == true then
                return verdict(name, source, C.VERDICT.REJECT, 'server dump / event enumeration')
            end
        end
    end

    -- --- Event inconnu (§05) : politique configurable.
    if not def then
        local policy = (ZShield.Config and ZShield.Config.value('events.unknown_policy')) or 'monitor'
        if policy == 'allow' then
            return C.VERDICT.ALLOW, { event = name, unknown = true }
        end
        local v, payload = verdict(name, source, C.VERDICT.UNKNOWN, 'event not registered')
        -- monitor journalise mais laisse passer le gameplay ; reject bloque.
        payload.blocked = (policy == 'reject')
        return v, payload
    end

    def.hits = def.hits + 1

    -- --- 1. SOURCE : le contexte joueur doit exister. Un event d'un joueur inconnu du
    -- serveur est suspect (déconnexion en cours, ou source forgée).
    if source ~= nil and source ~= 0 and not Context.exists(source) then
        return verdict(name, source, C.VERDICT.REJECT, 'no player context for source')
    end

    -- --- 2. ARGUMENT / TYPE : validation de schéma (§06). Le cœur du zéro-confiance.
    local sanitized = args
    if def.schema then
        local ok, err = Schema.validate(args, def.schema, name)
        if not ok then
            return verdict(name, source, C.VERDICT.REJECT, 'schema: ' .. err)
        end
        -- On travaille sur une copie assainie avec défauts appliqués, jamais l'objet client.
        sanitized = Schema.coerce(args, def.schema)
    end

    -- Contexte d'exécution : ce que reçoivent authorize/validate/execute. Le client n'y
    -- apparaît que sous forme d'arguments déjà validés.
    local ctx = {
        event = name,
        source = source,
        args = sanitized,
        player = Context.get(source),
        now = Util.now(),
    }

    -- --- 3. RATE LIMIT (§07). Clé par joueur+event.
    if def.limiter then
        local key = tostring(source) .. ':' .. name
        local allowed, meta = def.limiter:check(key)
        if not allowed then
            return verdict(name, source, C.VERDICT.RATE_LIMIT, 'rate limited', meta)
        end
    end

    -- --- 4. PERMISSION (§04). authorize() calcule côté serveur, jamais le client.
    if def.authorize then
        local ok, err = def.authorize(ctx)
        if not ok then
            return verdict(name, source, C.VERDICT.UNAUTHORIZED, err or 'not authorized')
        end
    end

    -- --- 5. STATE (§08). L'action doit être permise dans l'état courant du joueur.
    if def.states and source ~= nil and source ~= 0 then
        if not Context.isValidState(source, def.states) then
            local cur = ctx.player and ctx.player.state or 'unknown'
            return verdict(name, source, C.VERDICT.BAD_STATE,
                string.format('state %s not in allowed set', cur))
        end
    end

    -- --- 6. BUSINESS RULE (§04). validate() applique la règle métier serveur-authoritative.
    if def.validate then
        local ok, err = def.validate(ctx)
        if not ok then
            return verdict(name, source, C.VERDICT.REJECT, 'business: ' .. (err or 'rejected'))
        end
    end

    -- --- 7. ACTION. On journalise l'action pour la corrélation, puis on exécute.
    if source ~= nil and source ~= 0 then
        Context.pushAction(source, name)
    end
    if def.execute then
        local ok, err = pcall(def.execute, ctx)
        if not ok then
            -- Une exception métier ne doit pas faire tomber le firewall (§104).
            Log:error('firewall', 'execute threw', { event = name, source = source, err = tostring(err) })
            return verdict(name, source, C.VERDICT.REJECT, 'execute error')
        end
    end

    return verdict(name, source, C.VERDICT.ALLOW, nil)
end

function Firewall.list()
    local out = {}
    for name, def in pairs(Firewall.events) do
        out[#out + 1] = { name = name, version = def.version, hits = def.hits,
                          has_schema = def.schema ~= nil, has_limiter = def.limiter ~= nil }
    end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
end

function Firewall.getStats()
    return Util.deepCopy(Firewall.stats)
end

ZShield.Firewall = Firewall
