--[[
    FILE:         server/integrations/discord.lua
    PURPOSE:      Intégration Discord (§39, §120). Destination de NOTIFICATION sortante
                  uniquement. File + retry + backoff + isolation. Discord n'est JAMAIS une
                  source de décision de sécurité, et sa panne n'affecte JAMAIS l'enforcement.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua, core/config.lua,
                  server/persistence/circuit.lua, core/bus
    PUBLIC API:   ZShield.Discord.configure(opts)
                  ZShield.Discord.notify(payload)
                  ZShield.Discord.pump()      -- envoie un lot (appelé périodiquement)
                  ZShield.Discord.attach()

    §39 : Security Engine -> Incident -> Enforcement -> Discord notification. JAMAIS
    Discord API -> décision. Le flux est strictement sortant et en fin de chaîne.
    §120 : queue, retry, backoff, rate limit, isolation des pannes.
    §38, §173 : Discord DOWN -> la sécurité continue. La file se remplit, se vide quand
    Discord revient, et si elle sature on évince les notifications les moins importantes.
    §117 : le webhook est un SECRET. Il vient d'une convar serveur, n'est jamais journalisé,
    jamais exposé au client.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log

local Discord = {
    enabled = false,
    webhook = nil,        -- secret, jamais journalisé
    queue = {},           -- notifications en attente
    circuit = nil,        -- disjoncteur protégeant l'envoi
    maxQueue = 200,
    stats = { queued = 0, sent = 0, dropped = 0, failures = 0 },
}

-- Priorité de notification pour l'éviction (§120). Un incident CRITICAL part avant un LOG.
local PRIORITY = { CRITICAL = 4, HIGH = 3, MEDIUM = 2, LOW = 1 }

--- Configure l'intégration. Le webhook vient d'une convar serveur (§117), jamais du code.
function Discord.configure(opts)
    opts = opts or {}
    Discord.enabled = opts.enabled == true
    -- Le webhook vient d'une convar serveur (§117), jamais du code en production. Un webhook
    -- passé explicitement dans opts a priorité (config programmatique, tests) ; sinon on lit
    -- la convar. Il n'apparaît jamais en clair dans la config Lua d'un opérateur.
    if opts.webhook then
        Discord.webhook = opts.webhook
    elseif type(GetConvar) == 'function' then
        local w = GetConvar('zshield_discord_webhook', '')
        Discord.webhook = (w ~= '' and w) or nil
    else
        Discord.webhook = nil
    end
    Discord.maxQueue = opts.max_queue or 200
    if ZShield.Circuit then
        Discord.circuit = ZShield.Circuit.new('discord', { failure_threshold = 3, open_ms = 60000 })
    end
    if Discord.enabled and not Discord.webhook then
        Log:warn('discord', 'discord enabled but no webhook configured (set zshield_discord_webhook)')
        Discord.enabled = false
    end
end

--- Met une notification en file (§120). Ne bloque jamais, ne lève jamais.
--- payload = { title, description, severity, fields }
function Discord.notify(payload)
    if not Discord.enabled then return false end
    local severity = payload.severity or 'MEDIUM'
    local priority = PRIORITY[severity] or 2

    -- File pleine : éviction de la moins prioritaire (§120), jamais de perte silencieuse.
    if #Discord.queue >= Discord.maxQueue then
        local worstIdx, worstPrio
        for i = 1, #Discord.queue do
            local p = Discord.queue[i].priority
            if not worstPrio or p < worstPrio then worstIdx, worstPrio = i, p end
        end
        if worstIdx and worstPrio < priority then
            table.remove(Discord.queue, worstIdx)
            Discord.stats.dropped = Discord.stats.dropped + 1
        else
            Discord.stats.dropped = Discord.stats.dropped + 1
            return false -- rien de moins important : on refuse, compté
        end
    end

    Discord.queue[#Discord.queue + 1] = {
        payload = payload, priority = priority, at = Util.now(), attempts = 0,
    }
    Discord.stats.queued = Discord.stats.queued + 1
    return true
end

-- Construit le corps d'un embed Discord (format minimal, sans dépendance).
local SEVERITY_COLOR = { LOW = 8421504, MEDIUM = 15258703, HIGH = 15158332, CRITICAL = 10038562 }
local function buildBody(payload)
    return {
        embeds = { {
            title = tostring(payload.title or 'ZShield'),
            description = tostring(payload.description or ''),
            color = SEVERITY_COLOR[payload.severity] or SEVERITY_COLOR.MEDIUM,
            fields = payload.fields,
            footer = { text = 'ZShield AC v' .. C.VERSION },
        } },
    }
end

--- Envoie un lot de notifications, protégé par le disjoncteur (§52, §120). Retourne sent.
--- Si Discord est down (circuit ouvert), la file reste intacte : on réessaiera (§38).
function Discord.pump()
    if not Discord.enabled or not Discord.webhook then return 0 end
    if #Discord.queue == 0 then return 0 end
    if type(PerformHttpRequest) ~= 'function' then return 0 end
    if not Discord.circuit then Discord.configure() end

    local item = Discord.queue[1]
    local body = buildBody(item.payload)

    -- L'appel HTTP est asynchrone dans FXServer ; on l'enveloppe dans le disjoncteur via un
    -- résultat synchrone optimiste, et on gère l'échec dans le callback.
    local ok = Discord.circuit:call(function()
        PerformHttpRequest(Discord.webhook, function(status)
            if status >= 200 and status < 300 then
                -- Succès : retirer de la file.
                if Discord.queue[1] == item then table.remove(Discord.queue, 1) end
                Discord.stats.sent = Discord.stats.sent + 1
            else
                -- Échec HTTP : incrémenter les tentatives, garder en file (retry §120).
                item.attempts = item.attempts + 1
                Discord.stats.failures = Discord.stats.failures + 1
                if item.attempts >= 5 then
                    -- Abandon après 5 tentatives, compté (jamais silencieux).
                    if Discord.queue[1] == item then table.remove(Discord.queue, 1) end
                    Discord.stats.dropped = Discord.stats.dropped + 1
                    Log:warn('discord', 'notification dropped after retries', { attempts = item.attempts })
                end
            end
        end, 'POST', json and json.encode(body) or '{}', { ['Content-Type'] = 'application/json' })
        return true
    end)

    return ok and 1 or 0
end

--- S'abonne aux incidents décidés pour notifier (§39 : en fin de chaîne, jamais avant).
--- Discord reçoit une notification APRÈS que la sécurité a décidé et agi.
function Discord.attach()
    if not ZShield.Bus then return end
    ZShield.Bus:on('incident.decided', function(incident)
        if not Discord.enabled then return end
        -- Ne notifier que les incidents notables pour ne pas noyer le canal.
        if incident.severity == C.SEVERITY.LOW then return end
        Discord.notify({
            title = 'Incident ' .. tostring(incident.severity),
            description = string.format('Détecteur: %s | Action: %s',
                tostring(incident.detector), tostring(incident.action or 'aucune')),
            severity = incident.severity,
            fields = {
                { name = 'Joueur', value = tostring(incident.source), inline = true },
                { name = 'Risque', value = tostring(incident.risk_after or '?'), inline = true },
                { name = 'Raison', value = tostring(incident.decision and incident.decision.reason or '—'), inline = false },
            },
        })
    end)
end

function Discord.size()
    return #Discord.queue
end

function Discord.getStats()
    local s = Util.deepCopy(Discord.stats)
    s.queue_size = #Discord.queue
    s.enabled = Discord.enabled
    -- Le webhook n'apparaît JAMAIS dans les stats (§117).
    s.circuit = Discord.circuit and Discord.circuit:getStats() or nil
    return s
end

ZShield.Discord = Discord
