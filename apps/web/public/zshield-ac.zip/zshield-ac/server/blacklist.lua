--[[
    FILE:         server/blacklist.lua
    PURPOSE:      Liste d'interdiction pilotée depuis le dashboard : armes et véhicules
                  refusés à la source. Le game event firewall consulte ce module pour
                  BLOQUER (CancelEvent) un dégât d'arme interdite ou la création d'un
                  véhicule interdit — avant tout effet en jeu (§48 : rendre l'action
                  impossible d'abord).
    DEPENDENCIES: core/util.lua, core/log.lua
    PUBLIC API:   ZShield.Blacklist.set(payload)       -- { weapons, vehicles, peds, objects }
                  ZShield.Blacklist.weaponBlocked(hash) -> bool
                  ZShield.Blacklist.vehicleBlocked(model) -> bool
                  ZShield.Blacklist.pedBlocked(model) -> bool
                  ZShield.Blacklist.objectBlocked(model) -> bool
                  ZShield.Blacklist.modelBlocked(model) -> bool  -- ped OU objet
                  ZShield.Blacklist.snapshot()

    Les entrées peuvent être des NOMS ("WEAPON_RPG", "adder") ou des HASH numériques :
    on stocke des hash non signés (joaat des noms), et on compare en non signé. Ainsi le
    client saisit des noms lisibles, le cœur compare au hash réel du runtime.
]]

ZShield = ZShield or {}
local Util = ZShield.Util
local Log = ZShield.Log

local Blacklist = {}
Blacklist._weapons = {}   -- hash(u32) -> true
Blacklist._vehicles = {}  -- hash(u32) -> true
Blacklist._peds = {}      -- hash(u32) -> true : modèles de ped interdits (grief)
Blacklist._objects = {}   -- hash(u32) -> true : modèles d'objet/prop interdits
-- Whitelists (mode « autoriser uniquement »). Quand une whitelist est ACTIVE pour
-- une famille, TOUT modèle absent de la liste est refusé. Plus strict qu'une
-- blacklist : utile pour un serveur qui ne veut qu'un jeu de véhicules/objets connu.
Blacklist._wl = { vehicle = nil, ped = nil, object = nil, projectile = nil }

local function toHash(entry)
    if type(entry) == 'number' then return Util.u32(entry) end
    if type(entry) == 'string' then
        -- Un identifiant purement numérique en chaîne reste un hash.
        local n = tonumber(entry)
        if n and not entry:find('%a') then return Util.u32(n) end
        return Util.joaat(entry)
    end
    return nil
end

local function buildSet(list)
    local set = {}
    if type(list) ~= 'table' then return set end
    -- Accepte { "WEAPON_RPG", ... } ou { { id = "WEAPON_RPG" }, ... }.
    for _, e in ipairs(list) do
        local id = e
        if type(e) == 'table' then id = e.id or e.name or e.hash end
        local h = toHash(id)
        if h then set[h] = true end
    end
    return set
end

local function count(set)
    local n = 0
    for _ in pairs(set) do n = n + 1 end
    return n
end

-- Construit une whitelist depuis le payload : { enabled = bool, list = {...} }.
-- Retourne nil si désactivée (pas de restriction), sinon un ensemble de hash.
local function buildWhitelist(w)
    if type(w) ~= 'table' or w.enabled ~= true then return nil end
    return buildSet(w.list)
end

--- Applique la liste reçue.
--- `payload` : { weapons, vehicles, peds, objects,
---               whitelist = { vehicle={enabled,list}, ped={...}, object={...},
---                             projectile={...} } }.
--- Les clés absentes laissent l'ensemble correspondant vide (remplacement complet).
function Blacklist.set(payload)
    payload = payload or {}
    Blacklist._weapons = buildSet(payload.weapons)
    Blacklist._vehicles = buildSet(payload.vehicles)
    Blacklist._peds = buildSet(payload.peds)
    Blacklist._objects = buildSet(payload.objects)
    local wl = payload.whitelist or {}
    Blacklist._wl = {
        vehicle = buildWhitelist(wl.vehicle),
        ped = buildWhitelist(wl.ped),
        object = buildWhitelist(wl.object),
        projectile = buildWhitelist(wl.projectile),
    }
    local nw, nv = count(Blacklist._weapons), count(Blacklist._vehicles)
    local np, no = count(Blacklist._peds), count(Blacklist._objects)
    if Log then
        Log:info('blacklist', 'liste appliquée',
            { weapons = nw, vehicles = nv, peds = np, objects = no,
              wl_vehicle = Blacklist._wl.vehicle and count(Blacklist._wl.vehicle) or 0 })
    end
    return nw + nv + np + no
end

--- Un modèle est-il REFUSÉ par la whitelist de sa famille ? (absent d'une liste
--- active = refusé). `family` : 'vehicle' | 'ped' | 'object' | 'projectile'.
function Blacklist.notWhitelisted(family, model)
    if model == nil then return false end
    local set = Blacklist._wl[family]
    if not set then return false end            -- pas de whitelist active
    return set[Util.u32(model)] ~= true         -- absent -> refusé
end

function Blacklist.weaponBlocked(hash)
    if hash == nil then return false end
    return Blacklist._weapons[Util.u32(hash)] == true
end

function Blacklist.vehicleBlocked(model)
    if model == nil then return false end
    return Blacklist._vehicles[Util.u32(model)] == true
end

function Blacklist.pedBlocked(model)
    if model == nil then return false end
    return Blacklist._peds[Util.u32(model)] == true
end

function Blacklist.objectBlocked(model)
    if model == nil then return false end
    return Blacklist._objects[Util.u32(model)] == true
end

--- Un modèle interdit, qu'il soit ped OU objet (le serveur ne connaît pas toujours
--- le type à la création : on refuse si l'un ou l'autre le blackliste).
function Blacklist.modelBlocked(model)
    return Blacklist.pedBlocked(model) or Blacklist.objectBlocked(model)
end

function Blacklist.snapshot()
    local wl = Blacklist._wl
    return {
        weapons = count(Blacklist._weapons), vehicles = count(Blacklist._vehicles),
        peds = count(Blacklist._peds), objects = count(Blacklist._objects),
        whitelists = {
            vehicle = wl.vehicle and count(wl.vehicle) or nil,
            ped = wl.ped and count(wl.ped) or nil,
            object = wl.object and count(wl.object) or nil,
            projectile = wl.projectile and count(wl.projectile) or nil,
        },
    }
end

ZShield.Blacklist = Blacklist
return Blacklist
