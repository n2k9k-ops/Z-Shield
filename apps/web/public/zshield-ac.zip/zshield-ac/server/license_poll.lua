--[[
    FILE:         server/license_poll.lua
    PURPOSE:      COUCHE RÉSEAU du kill-switch en ligne. Le module pur
                  server/license_online.lua DÉCIDE (verdict signé -> état) ; ici
                  on fait l'appel HTTP réel vers le SaaS et on lui passe le verdict.

                  Interroge périodiquement :
                      GET <zshield_dashboard_url>/api/license/verify?server=<empreinte>
                  et applique le verdict SIGNÉ via ZShield.LicenseOnline.applyRemote.
                  Une clé leakée/revendue, marquée « révoquée » côté admin, coupe
                  alors la protection à distance (révocation collante).

    SÛR PAR DÉFAUT :
      - Si `zshield_dashboard_url` n'est pas défini, ce module NE FAIT RIEN
        (le kill-switch en ligne est optionnel ; la coupe à l'expiration reste
        assurée hors-ligne par server/license.lua).
      - Le SaaS injoignable NE coupe PAS tout de suite : période de grâce gérée
        par license_online (license.online_grace_hours, 72 h par défaut).
      - Sur révocation confirmée : on désarme la protection et on émet
        `zshield.license.revoked`. On ne kicke les joueurs QUE si
        `license.revoke_kick` est explicitement activé.

    DEPENDENCIES: server/license.lua, server/license_online.lua, core/log.lua
]]

ZShield = ZShield or {}

local Log = ZShield.Log
local LO = ZShield.LicenseOnline

-- Rien à faire hors FXServer (tests / dev local) : pas de natives HTTP.
if type(PerformHttpRequest) ~= 'function' or type(CreateThread) ~= 'function' then
    return
end

local function cfg(key, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(key, default)
    end
    return default
end

--- Base URL du dashboard (sans slash final). Convar prioritaire, puis config.
local function baseUrl()
    local url = ''
    if type(GetConvar) == 'function' then
        url = GetConvar('zshield_dashboard_url', '') or ''
    end
    if url == '' then url = tostring(cfg('license.dashboard_url', '') or '') end
    url = url:gsub('%s+$', ''):gsub('/+$', '')
    return url
end

--- Applique la conséquence d'un verdict « non actif » (révoqué ou verrouillé).
local function onNotActive(eff)
    if not ZShield.licensed then return end -- déjà désarmé
    ZShield.licensed = false
    if ZShield.Health then
        ZShield.Health.set('license', (ZShield.C and ZShield.C.HEALTH and ZShield.C.HEALTH.FAILED) or 'FAILED',
            eff.reason or eff.state)
    end
    if Log then Log:critical('license', 'kill-switch : protection désarmée', { state = eff.state, reason = eff.reason }) end
    if ZShield.Bus then ZShield.Bus:emit('zshield.license.revoked', { state = eff.state, reason = eff.reason }) end

    -- Kick optionnel des joueurs (désactivé par défaut : un faux verdict ne doit
    -- pas vider un serveur légitime ; c'est un levier explicite du vendeur).
    if cfg('license.revoke_kick', false) and type(GetPlayers) == 'function' and type(DropPlayer) == 'function' then
        local msg = tostring(cfg('license.revoke_kick_message',
            'Licence Z-Shield révoquée. Contactez l\'administrateur du serveur.'))
        for _, pid in ipairs(GetPlayers()) do
            pcall(DropPlayer, pid, msg)
        end
    end
end

--- Un tour d'interrogation.
local function pollOnce()
    local url = baseUrl()
    if url == '' then return end
    local identity = ZShield.License and ZShield.License.identity() or 'any'
    local full = url .. '/api/license/verify?server=' .. identity

    PerformHttpRequest(full, function(status, body, _headers)
        local now = ZShield.Util and ZShield.Util.wallclock() or os.time()
        if status == 200 and type(body) == 'string' and body ~= '' then
            local ok, decoded = pcall(function() return json.decode(body) end)
            if ok and type(decoded) == 'table' and type(decoded.verdict) == 'string' then
                LO.applyRemote(decoded.verdict, now)
            else
                LO.onUnreachable(now)
            end
        else
            -- Réponse inexploitable = SaaS « injoignable » pour la logique de grâce.
            LO.onUnreachable(now)
        end
        local eff = LO.effective(now)
        if not eff.active then onNotActive(eff) end
    end, 'GET', '', { ['Accept'] = 'application/json' })
end

--- Boucle de fond. Intervalle en minutes (borne basse 1 min).
CreateThread(function()
    -- Laisse le bootstrap poser la licence et l'empreinte avant le premier appel.
    Citizen.Wait(10000)
    if baseUrl() == '' then
        if Log then Log:info('license', 'kill-switch en ligne inactif (zshield_dashboard_url non défini)') end
        return
    end
    if not LO then
        if Log then Log:warn('license', 'license_online absent : kill-switch en ligne indisponible') end
        return
    end
    while true do
        pcall(pollOnce)
        local mins = tonumber(cfg('license.online_poll_minutes', 15)) or 15
        if mins < 1 then mins = 1 end
        Citizen.Wait(math.floor(mins * 60000))
    end
end)
