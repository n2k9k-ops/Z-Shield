--[[
    FILE:         server/license.lua
    PURPOSE:      Vérification de LICENCE hors-ligne. Une licence est un jeton signé qui
                  porte une DATE D'EXPIRATION. Si la licence manque, est falsifiée ou est
                  expirée (ex : fin de l'essai de 7 jours), la protection est coupée et un
                  message clair s'affiche au démarrage du serveur.
    DEPENDENCIES: shared/sha256.lua, core/util.lua, core/log.lua
    PUBLIC API:   ZShield.License.sign(payload)            -- (émission côté outil vendeur)
                  ZShield.License.verify(token, now) -> result
                  ZShield.License.check() -> result        -- lit la config + l'heure serveur
                  ZShield.License.setSecret(s)             -- (tests / build)

    FORMAT du jeton : "v1|<server_id>|<plan>|<issued_at>|<expires_at>~<hmac_hex>"
      - les champs sont séparés par '|', la signature par '~' ;
      - la signature = HMAC-SHA256(payload, SECRET) — infalsifiable sans le secret.

    Le SECRET est un secret de BUILD partagé avec le serveur d'émission (le dashboard).
    Il ne doit jamais être exposé publiquement ni rendu configurable par l'opérateur —
    sinon n'importe qui forgerait des licences. En production, remplacez la valeur
    ci-dessous par votre secret et utilisez le même côté dashboard.

    NOTE sécurité : une vérification hors-ligne embarque le secret dans la ressource,
    donc un attaquant déterminé peut l'extraire. C'est le compromis de tout contrôle de
    licence local. Pour durcir, l'agent peut en plus valider en ligne auprès du SaaS ;
    ici la vérification hors-ligne suffit à couper la protection à l'expiration, même
    serveur SaaS injoignable.
]]

ZShield = ZShield or {}
local Log = ZShield.Log
local Util = ZShield.Util

local License = {
    -- REMPLACEZ ceci en production (doit être identique côté dashboard).
    SECRET = 'ZSHIELD-LICENSE-SIGNING-SECRET-CHANGE-ME',
    STATE = {
        VALID        = 'VALID',
        MISSING      = 'MISSING',      -- aucune licence fournie
        INVALID      = 'INVALID',      -- signature fausse / jeton malformé
        EXPIRED      = 'EXPIRED',      -- licence dépassée (ex : fin d'essai)
        WRONG_SERVER = 'WRONG_SERVER', -- licence émise pour un AUTRE serveur
    },
    _identity = nil,  -- override de test
}

function License.setSecret(s) License.SECRET = s end
function License.setIdentity(id) License._identity = id end

--- Secret de signature EFFECTIF. Priorité :
---   1) convar serveur   : set zshield_license_secret "..."   (server.cfg, HORS dépôt)
---   2) config           : license.secret
---   3) repli embarqué   : License.SECRET (à ne PAS laisser sur la valeur par défaut)
--- Garder le secret dans un convar évite de le committer dans un dépôt public : sans le
--- secret, personne ne peut forger de licence valide (ni de verdict « actif »).
function License.secret()
    if type(GetConvar) == 'function' then
        local c = GetConvar('zshield_license_secret', '')
        if c ~= nil and c ~= '' then return c end
    end
    if ZShield.Config and ZShield.Config.value then
        local v = ZShield.Config.value('license.secret', '')
        if v ~= nil and v ~= '' then return v end
    end
    return License.SECRET
end

--- Le secret effectif est-il encore la valeur par défaut ? (avertissement au démarrage)
function License.usingDefaultSecret()
    return License.secret() == 'ZSHIELD-LICENSE-SIGNING-SECRET-CHANGE-ME'
end

--- Empreinte stable du serveur courant. Sert à LIER une licence à un seul serveur :
--- une clé émise pour ce serveur ne marchera pas ailleurs. On dérive l'empreinte de la
--- clé cfx (sv_licenseKey), unique par serveur et non transposable. Repli déterministe
--- hors FXServer (tests / dev local).
function License.identity()
    if License._identity then return License._identity end
    local raw = ''
    if type(GetConvar) == 'function' then
        raw = GetConvar('sv_licenseKey', '') or ''
    end
    if raw == '' then raw = 'unbound-local' end
    -- 16 hex : suffisant pour identifier, court à communiquer.
    return ZShield.Sha256.hash(raw):sub(1, 16)
end

local function sign(payload)
    return ZShield.Sha256.hmac(License.secret(), payload)
end

--- Construit un jeton signé. Utilisé par l'outil d'émission (le dashboard fait l'équivalent
--- en Node). spec = { server_id, plan, issued_at, expires_at }.
function License.sign(spec)
    local payload = string.format('v1|%s|%s|%d|%d',
        tostring(spec.server_id or 'any'), tostring(spec.plan or 'trial'),
        tonumber(spec.issued_at) or Util.wallclock(), tonumber(spec.expires_at) or 0)
    return payload .. '~' .. sign(payload)
end

--- Vérifie un jeton à l'instant `now` (secondes) pour l'empreinte `identity`. Retour :
--- { state, plan, server_id, expires_at, days_left, reason }
--- Une licence dont le server_id vaut 'any' n'est liée à aucun serveur (passe partout).
--- Sinon, le server_id doit correspondre à l'empreinte du serveur courant.
function License.verify(token, now, identity)
    now = now or Util.wallclock()
    identity = identity or License.identity()
    if type(token) ~= 'string' or token == '' then
        return { state = License.STATE.MISSING, reason = 'aucune licence' }
    end

    local sep = token:find('~[^~]*$')   -- dernier '~'
    if not sep then
        return { state = License.STATE.INVALID, reason = 'jeton malformé' }
    end
    local payload = token:sub(1, sep - 1)
    local sig = token:sub(sep + 1)

    -- Comparaison de signature (longueur d'abord, puis contenu).
    local expected = sign(payload)
    if #sig ~= #expected then
        return { state = License.STATE.INVALID, reason = 'signature invalide' }
    end
    local diff = 0
    for i = 1, #expected do
        if expected:byte(i) ~= sig:byte(i) then diff = 1 end
    end
    if diff ~= 0 then
        return { state = License.STATE.INVALID, reason = 'signature invalide' }
    end

    local ver, server_id, plan, issued_at, expires_at =
        payload:match('^(v%d+)|([^|]*)|([^|]*)|(%d+)|(%d+)$')
    if ver ~= 'v1' then
        return { state = License.STATE.INVALID, reason = 'format non supporté' }
    end
    expires_at = tonumber(expires_at)

    -- Liaison au serveur : 'any' = passe partout ; sinon doit matcher ce serveur.
    if server_id ~= 'any' and server_id ~= identity then
        return {
            state = License.STATE.WRONG_SERVER, plan = plan, server_id = server_id,
            expires_at = expires_at, days_left = 0,
            reason = 'licence émise pour un autre serveur',
        }
    end

    if now > expires_at then
        return {
            state = License.STATE.EXPIRED, plan = plan, server_id = server_id,
            expires_at = expires_at, days_left = 0,
            reason = 'licence expirée',
        }
    end

    return {
        state = License.STATE.VALID, plan = plan, server_id = server_id,
        expires_at = expires_at,
        days_left = math.max(0, math.ceil((expires_at - now) / 86400)),
    }
end

--- Vérifie la licence configurée à l'heure serveur.
function License.check()
    -- Priorité au convar server.cfg (`set zshield_license_key "..."`) : c'est la
    -- seule chose que le CLIENT saisit. Repli sur la config (license.key).
    local token = ''
    if type(GetConvar) == 'function' then
        token = GetConvar('zshield_license_key', '') or ''
    end
    if token == '' and ZShield.Config and ZShield.Config.value then
        token = ZShield.Config.value('license.key', '') or ''
    end
    return License.verify(token, Util.wallclock())
end

--- Bannière lisible au démarrage / à intervalles. `result` vient de check().
function License.banner(result)
    local line = string.rep('=', 58)
    if result.state == License.STATE.VALID then
        if result.days_left and result.days_left <= 3 then
            return {
                'Z-Shield — licence valide, expire dans ' .. result.days_left .. ' jour(s).',
                'Pensez à renouveler pour ne pas perdre la protection.',
            }
        end
        return nil
    end

    local why = ({
        [License.STATE.MISSING]      = 'aucune licence fournie',
        [License.STATE.INVALID]      = 'licence invalide',
        [License.STATE.EXPIRED]      = 'licence expirée (essai/abonnement terminé)',
        [License.STATE.WRONG_SERVER] = 'licence émise pour un autre serveur',
    })[result.state] or 'licence non valide'

    return {
        line,
        'Z-Shield — PROTECTION DÉSACTIVÉE',
        'Raison : ' .. why .. '.',
        'Votre serveur n\'est PAS protégé. Renouvelez sur https://z-shield.gg',
        'puis collez votre clé dans config/config.lua (license.key).',
        line,
    }
end

ZShield.License = License
