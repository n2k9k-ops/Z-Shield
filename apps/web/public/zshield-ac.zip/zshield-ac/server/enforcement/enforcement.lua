--[[
    FILE:         server/enforcement/enforcement.lua
    PURPOSE:      Exécuteur d'enforcement (§86, §88, §43). Applique les décisions de la
                  politique via des exécuteurs branchables (kick/ban dépendent de FXServer et
                  du framework). Journalise chaque action en audit. Respecte SHADOW/MONITOR.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua, core/config.lua,
                  core/bus, server/enforcement/policy.lua, server/incident.lua
    PUBLIC API:   ZShield.Enforcement.handle(incident) -> result
                  ZShield.Enforcement.setExecutor(action, fn)   (§46 : injecté par l'adaptateur)
                  ZShield.Enforcement.setContainer(kind, fn)
                  ZShield.Enforcement.attach()

    §88 : le containment est réversible (bloquer une action, retirer une entité invalide,
    invalider une transaction, geler une opération). Distinct des sanctions.
    §43 : toute action produit une entrée d'audit.
    §31 : SHADOW ne fait qu'enregistrer ; MONITOR applique le non-destructif ; ENFORCE applique
    tout. L'exécuteur est le seul endroit qui TOUCHE réellement le joueur, et il vérifie le mode.
    §104 : un exécuteur qui lève est isolé ; l'enforcement continue.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log
local Bus = ZShield.Bus

local Enforcement = {
    executors = {},   -- action -> fn(incident, decision) : APPLIQUE réellement (kick/ban/…)
    containers = {},  -- kind -> fn(incident, decision) : containment réversible
    audit = {},       -- journal d'audit en mémoire (§43), borné
    stats = { applied = 0, shadowed = 0, mode_blocked = 0, contained = 0, executor_errors = 0 },
}

local MAX_AUDIT = 1000

--- Enregistre un exécuteur réel pour une action. Fourni par l'adaptateur de framework (§46) :
--- standalone/ESX/QBCore branchent ici leur DropPlayer, ban DB, etc. Le core ne dépend
--- d'aucun framework (§46).
function Enforcement.setExecutor(action, fn)
    Enforcement.executors[action] = fn
end

function Enforcement.setContainer(kind, fn)
    Enforcement.containers[kind] = fn
end

-- Entrée d'audit (§43) : acteur, cible, action, raison, timestamp, résultat.
local function audit(entry)
    entry.at = Util.now()
    entry.wallclock = Util.wallclock()
    Enforcement.audit[#Enforcement.audit + 1] = entry
    while #Enforcement.audit > MAX_AUDIT do table.remove(Enforcement.audit, 1) end
    -- Toute action d'enforcement est un événement de sécurité.
    Log:security('enforcement', 'audit', entry)
    Bus:emit('enforcement.audit', entry)
end

--- Traite un incident : calcule la décision (via Policy), l'enregistre sur l'incident, puis
--- l'exécute selon le mode. Retourne un résumé du résultat.
function Enforcement.handle(incident)
    if not incident then return { applied = false, reason = 'no incident' } end
    if ZShield.Config and ZShield.Config.value('enforcement.enabled') == false then
        return { applied = false, reason = 'enforcement disabled' }
    end

    local decision = ZShield.Policy and ZShield.Policy.decide(incident)
    if not decision then
        return { applied = false, reason = 'no action warranted' }
    end

    -- Enregistrer la décision sur l'incident (chaîne de preuve, §29/§85).
    if ZShield.Incident then
        ZShield.Incident.setDecision(incident.id, {
            action = decision.action, policy = decision.policy, reason = decision.reason,
            confidence = decision.confidence, threshold = decision.threshold, by = 'system',
        })
    end

    -- --- Containment réversible d'abord (§88) : appliqué même en observation, car il
    -- contient un risque technique immédiat sans sanctionner le joueur. MAIS pas en SHADOW.
    if decision.containment and not decision.shadow then
        local container = Enforcement.containers[decision.containment]
        if container then
            local ok, err = pcall(container, incident, decision)
            if ok then
                Enforcement.stats.contained = Enforcement.stats.contained + 1
                audit({ actor = 'system', target = incident.source, action = 'CONTAIN',
                        containment = decision.containment, incident = incident.id,
                        reason = decision.reason, result = 'applied' })
            else
                Enforcement.stats.executor_errors = Enforcement.stats.executor_errors + 1
                Log:error('enforcement', 'container threw', {
                    kind = decision.containment, err = tostring(err) })
            end
        end
    end

    -- --- SHADOW : on enregistre, on n'applique PAS (§31).
    if decision.shadow then
        Enforcement.stats.shadowed = Enforcement.stats.shadowed + 1
        audit({ actor = 'system', target = incident.source, action = decision.action,
                incident = incident.id, reason = decision.reason, result = 'shadow_only',
                note = 'SHADOW mode: decision recorded, not applied' })
        return { applied = false, shadow = true, action = decision.action, decision = decision }
    end

    -- --- MONITOR : action destructive bloquée (§31).
    if decision.blocked_by_mode then
        Enforcement.stats.mode_blocked = Enforcement.stats.mode_blocked + 1
        audit({ actor = 'system', target = incident.source, action = decision.action,
                incident = incident.id, reason = decision.reason, result = 'blocked_by_monitor',
                note = 'MONITOR mode: destructive action not applied' })
        return { applied = false, blocked_by_mode = true, action = decision.action, decision = decision }
    end

    -- --- Appliquer réellement l'action via l'exécuteur branché. LOG/WARN ont un exécuteur
    -- par défaut (journalisation) ; KICK/BAN nécessitent un exécuteur fourni par l'adaptateur.
    local executor = Enforcement.executors[decision.action]
    if not executor then
        -- LOG et WARN sont sûrs sans exécuteur externe.
        if decision.action == C.ACTION.LOG or decision.action == C.ACTION.WARN then
            audit({ actor = 'system', target = incident.source, action = decision.action,
                    incident = incident.id, reason = decision.reason, result = 'applied' })
            Enforcement.stats.applied = Enforcement.stats.applied + 1
            return { applied = true, action = decision.action, decision = decision }
        end
        -- Action dure sans exécuteur : on ne peut pas l'appliquer. On le dit, on ne prétend pas.
        audit({ actor = 'system', target = incident.source, action = decision.action,
                incident = incident.id, reason = decision.reason, result = 'no_executor',
                note = 'no executor registered for this action (adapter not installed)' })
        Log:warn('enforcement', 'no executor for action', { action = decision.action })
        return { applied = false, reason = 'no executor', action = decision.action, decision = decision }
    end

    local ok, err = pcall(executor, incident, decision)
    if not ok then
        Enforcement.stats.executor_errors = Enforcement.stats.executor_errors + 1
        Log:error('enforcement', 'executor threw', { action = decision.action, err = tostring(err) })
        audit({ actor = 'system', target = incident.source, action = decision.action,
                incident = incident.id, reason = decision.reason, result = 'executor_error' })
        return { applied = false, reason = 'executor error', action = decision.action }
    end

    Enforcement.stats.applied = Enforcement.stats.applied + 1
    audit({ actor = 'system', target = incident.source, action = decision.action,
            incident = incident.id, reason = decision.reason, result = 'applied',
            phase = decision.phase })
    return { applied = true, action = decision.action, decision = decision }
end

--- Action manuelle par un administrateur (§43, §118). Toujours auditée avec l'acteur.
function Enforcement.manualAction(opts)
    -- opts = { admin, target, action, reason, incident }
    local executor = Enforcement.executors[opts.action]
    local result = 'applied'
    if executor then
        local ok, err = pcall(executor, { id = opts.incident, source = opts.target }, { action = opts.action, reason = opts.reason })
        if not ok then result = 'executor_error'; Log:error('enforcement', 'manual executor threw', { err = tostring(err) }) end
    elseif not (opts.action == C.ACTION.LOG or opts.action == C.ACTION.WARN) then
        result = 'no_executor'
    end
    audit({ actor = opts.admin or 'admin', target = opts.target, action = opts.action,
            incident = opts.incident, reason = opts.reason, result = result, manual = true })
    return result == 'applied'
end

function Enforcement.getAudit(n)
    n = math.min(n or 100, #Enforcement.audit)
    local out = {}
    for i = math.max(1, #Enforcement.audit - n + 1), #Enforcement.audit do
        out[#out + 1] = Enforcement.audit[i]
    end
    return out
end

function Enforcement.getStats()
    return Util.deepCopy(Enforcement.stats)
end

--- S'abonne à l'ouverture d'incident pour enclencher l'enforcement automatiquement.
function Enforcement.attach()
    Bus:on('incident.opened', function(incident)
        -- Isolé : une erreur d'enforcement ne doit pas casser l'émetteur (§104).
        local ok, err = pcall(Enforcement.handle, incident)
        if not ok then
            Log:error('enforcement', 'handle threw on incident.opened', { err = tostring(err) })
        end
    end)
end

ZShield.Enforcement = Enforcement
