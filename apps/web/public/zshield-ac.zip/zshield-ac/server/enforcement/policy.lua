--[[
    FILE:         server/enforcement/policy.lua
    PURPOSE:      Moteur de politique de sanction (§86, §87). Décide QUELLE action prendre
                  pour un incident, selon le risque, la confiance et le mode. N'exécute
                  rien : il produit une DÉCISION explicable (§85). L'exécution est dans
                  enforcement.lua.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua, core/log.lua
    PUBLIC API:   ZShield.Policy.decide(incident) -> decision | nil
                  ZShield.Policy.setLadder(ladder)  (pour tests / configuration avancée)

    §86 : échelle LOG < WARN < RESTRICT < KICK < TEMP_BAN < PERM_BAN. Chaque palier est
    configurable par seuil de risque.
    §87 : DEUX PHASES. Cas non critique -> observation -> corrélation -> confirmation ->
    enforcement. Cas de risque TECHNIQUE immédiat -> containment (réversible), sans
    forcément bannir. La décision distingue les deux.
    §31 : en mode SHADOW, la politique décide toujours (pour les stats) mais marque la
    décision `shadow = true` : l'exécuteur ne l'appliquera pas.

    §85 : chaque décision porte policy, signals, confidence, threshold, reason. Jamais
    « parce que l'anticheat l'a dit ».
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log

local Policy = {}

-- Échelle par défaut : score de risque -> action. Ordonnée par seuil croissant.
-- Chaque palier peut exiger une CONFIANCE minimale : on ne banni pas définitivement sur
-- une confiance faible même si le score est élevé (§11, §87).
local DEFAULT_LADDER = {
    { min_score = 20, action = C.ACTION.LOG,      min_confidence = 0.0 },
    { min_score = 40, action = C.ACTION.WARN,     min_confidence = 0.3 },
    { min_score = 55, action = C.ACTION.RESTRICT, min_confidence = 0.5 },
    { min_score = 70, action = C.ACTION.KICK,     min_confidence = 0.6 },
    { min_score = 85, action = C.ACTION.TEMP_BAN, min_confidence = 0.75 },
    { min_score = 95, action = C.ACTION.PERM_BAN, min_confidence = 0.9 },
}

Policy.ladder = DEFAULT_LADDER

function Policy.setLadder(ladder)
    -- Trie par seuil croissant pour que la sélection descende jusqu'au plus haut palier atteint.
    table.sort(ladder, function(a, b) return a.min_score < b.min_score end)
    Policy.ladder = ladder
end

-- Catégories considérées comme risque TECHNIQUE immédiat (§87) : elles justifient un
-- containment réversible sans attendre la confirmation, car elles cassent le jeu en direct
-- (spawn d'entités massif, event injecté abusant d'une ressource). Elles ne justifient PAS
-- un ban immédiat pour autant.
local IMMEDIATE_CONTAINMENT_CATEGORIES = {
    [C.CATEGORY.ENTITY]   = true,
    [C.CATEGORY.NETWORK]  = true,
    [C.CATEGORY.RESOURCE] = true,
}

--- Sélectionne le palier le plus haut dont le score ET la confiance sont atteints.
--- Retourne action, palier | nil.
local function selectAction(score, confidence)
    local chosen
    for i = 1, #Policy.ladder do
        local step = Policy.ladder[i]
        if score >= step.min_score and confidence >= (step.min_confidence or 0) then
            chosen = step
        end
    end
    return chosen
end

--- Décide de l'action pour un incident. Retourne une DÉCISION explicable, ou nil si rien
--- à faire (score sous le premier palier).
---
--- incident attendu : { source, category, severity, confidence, risk_after, occurrences }
function Policy.decide(incident)
    local mode = (ZShield.Config and ZShield.Config.value('mode')) or C.MODE.SHADOW

    -- En mode OFF, aucune décision.
    if mode == C.MODE.OFF then return nil end

    -- Réglages pilotés par le client (§ protections). 'drop' = protection désactivée
    -- par le client -> on abandonne l'incident. 'watch' = surveiller sans sanction
    -- dure. 'block' = comportement normal. Par défaut 'block' (aucun réglage reçu).
    local pgate = (ZShield.Protections and ZShield.Protections.gate(incident)) or 'block'
    if pgate == 'drop' then
        Log:debug('policy', 'protection disabled by client, incident dropped', {
            source = incident.source, category = incident.category,
            protection = incident.protection,
        })
        return nil
    end

    local score = incident.risk_after or 0
    local confidence = incident.confidence or 0.5

    local step = selectAction(score, confidence)
    if not step then
        return nil -- sous le premier palier : rien à faire
    end

    -- --- Deux phases (§87) ---
    -- Phase 1 pour les cas NON critiques et NON immédiats : on n'applique pas directement la
    -- sanction dure ; on observe/confirme d'abord si la config two_phase est active.
    local twoPhase = ZShield.Config and ZShield.Config.value('enforcement.two_phase') ~= false
    local immediate = IMMEDIATE_CONTAINMENT_CATEGORIES[incident.category] == true
    local isHardAction = (step.action == C.ACTION.KICK
        or step.action == C.ACTION.TEMP_BAN or step.action == C.ACTION.PERM_BAN)

    local phase = 'enforce'
    local containment = nil

    if immediate then
        -- Risque technique immédiat : containment réversible tout de suite (§88), et la
        -- sanction dure reste soumise à la deux-phases.
        if incident.category == C.CATEGORY.ENTITY then containment = C.CONTAINMENT.REMOVE_ENTITY
        elseif incident.category == C.CATEGORY.NETWORK then containment = C.CONTAINMENT.BLOCK_ACTION
        else containment = C.CONTAINMENT.FREEZE_OPERATION end
    end

    if twoPhase and isHardAction and incident.severity ~= C.SEVERITY.CRITICAL then
        -- Première observation d'une action dure non critique : on rétrograde en WARN et on
        -- passe en phase d'observation. La confirmation (répétition / corrélation) fera
        -- monter le score et déclenchera la sanction dure au prochain incident.
        if (incident.occurrences or 1) < 2 then
            phase = 'observe'
            return Policy.build(incident, C.ACTION.WARN, step, {
                phase = phase,
                containment = containment,
                reason = 'two-phase: observing before hard enforcement',
                downgraded_from = step.action,
                protection_gate = pgate,
            })
        end
    end

    -- Confirmé (répétition, ou critique, ou action douce) : on applique le palier choisi.
    local reason
    if incident.severity == C.SEVERITY.CRITICAL then
        reason = 'critical severity meets threshold'
    elseif (incident.occurrences or 1) >= 2 then
        reason = 'confirmed by repetition/correlation'
    else
        reason = 'threshold reached'
    end

    return Policy.build(incident, step.action, step, {
        phase = phase,
        containment = containment,
        reason = reason,
        protection_gate = pgate,
    })
end

--- Construit l'objet décision explicable (§85), en tenant compte du mode SHADOW (§31).
function Policy.build(incident, action, step, extra)
    extra = extra or {}
    local mode = (ZShield.Config and ZShield.Config.value('mode')) or C.MODE.SHADOW

    -- §31 : en SHADOW, on décide mais on n'applique pas. En MONITOR, on applique les actions
    -- non destructives (LOG, WARN, RESTRICT, containment) mais pas les bans/kicks.
    local shadow = (mode == C.MODE.SHADOW)
    local destructive = (action == C.ACTION.KICK
        or action == C.ACTION.TEMP_BAN or action == C.ACTION.PERM_BAN)
    local monitorBlocked = false
    if mode == C.MODE.MONITOR and destructive then monitorBlocked = true end

    -- Protection en mode « Surveiller » (choix client) : on décide et on alerte,
    -- mais aucune sanction DURE n'est appliquée, quel que soit le mode global.
    local watchOnly = (extra.protection_gate == 'watch')
    if watchOnly and destructive then monitorBlocked = true end

    local decision = {
        action = action,
        policy = 'sanction_ladder',
        phase = extra.phase or 'enforce',
        reason = extra.reason,
        threshold = step and step.min_score,
        confidence = incident.confidence,
        score = incident.risk_after,
        containment = extra.containment,
        downgraded_from = extra.downgraded_from,
        -- Marqueurs d'application. L'exécuteur les respecte.
        shadow = shadow,                 -- SHADOW : décidé, jamais appliqué
        blocked_by_mode = monitorBlocked, -- MONITOR/watch : action destructive non appliquée
        watch_only = watchOnly,          -- protection en « Surveiller » (choix client)
        mode = mode,
        decided_at = Util.now(),
    }

    Log:debug('policy', 'decision computed', {
        source = incident.source, action = action, phase = decision.phase,
        shadow = shadow, blocked_by_mode = monitorBlocked, reason = extra.reason,
    })
    return decision
end

ZShield.Policy = Policy
