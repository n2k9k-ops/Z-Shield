--[[
    FILE:         server/spectate.lua
    PURPOSE:      Observation SERVEUR-AUTORITATIVE d'un joueur (Multi-vue). Quand un
                  administrateur demande à observer un joueur depuis le tableau de
                  bord, la plateforme envoie une commande à l'agent, qui appelle ce
                  coordinateur. L'observation est une CAMÉRA D'ADMINISTRATION placée
                  DANS LE MONDE DU JEU sur la cible : le serveur reconstitue la scène
                  qu'il possède déjà (positions, entités).

                  CE QUE CE N'EST PAS (garde-fou anti-spyware) : jamais une capture,
                  un flux, ou une lecture de l'écran ou de la machine du joueur. Le
                  cœur ne voit que ce que le serveur voit de toute façon.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua
    PUBLIC API:   ZShield.Spectate.setExecutor(fn)   -- injecté par l'adaptateur (caméra FiveM)
                  ZShield.Spectate.request(target, admin) -> ok, err
                  ZShield.Spectate.stop(target)           -> ok
                  ZShield.Spectate.active()               -> liste des observations en cours
                  ZShield.Spectate.isActive(target)       -> bool

    L'exécuteur réel (mise en place de la caméra en jeu) est fourni par l'adaptateur
    de framework : il est FiveM/serveur-spécifique. Sans exécuteur, la demande est
    ENREGISTRÉE et journalisée mais ne fait rien de plus — on ne prétend jamais
    observer si l'adaptateur n'a pas branché la caméra.
]]

ZShield = ZShield or {}
local Log = ZShield.Log
local Util = ZShield.Util
local Bus = ZShield.Bus

local Spectate = {
    executor = nil,           -- fn('start'|'stop', target, meta) : caméra réelle en jeu
    sessions = {},            -- target -> { admin, since }
    stats = { started = 0, stopped = 0, no_executor = 0 },
}

function Spectate.setExecutor(fn)
    Spectate.executor = fn
end

local function now()
    return (Util and Util.wallclock and Util.wallclock()) or os.time()
end

--- Demande l'observation d'une cible. `target` : identifiant serveur du joueur.
--- `admin` : qui observe (traçabilité). Retourne ok, err.
function Spectate.request(target, admin)
    if target == nil or target == '' then
        return false, 'target required'
    end
    target = tostring(target)
    Spectate.sessions[target] = { admin = admin and tostring(admin) or 'unknown', since = now() }
    Spectate.stats.started = Spectate.stats.started + 1

    if Log then
        Log:security('spectate', 'server-side observation requested', {
            target = target, admin = admin,
            note = 'admin camera in the game world; never a capture of the player screen',
        })
    end
    if Bus then Bus:emit('spectate.started', { target = target, admin = admin }) end

    if Spectate.executor then
        local ok, err = pcall(Spectate.executor, 'start', target, { admin = admin })
        if not ok then
            if Log then Log:error('spectate', 'executor threw on start', { err = tostring(err) }) end
            return false, 'executor error'
        end
        return true
    end

    -- Pas d'exécuteur branché : on a enregistré la demande, on ne prétend pas
    -- observer. L'adaptateur doit fournir la caméra en jeu.
    Spectate.stats.no_executor = Spectate.stats.no_executor + 1
    return true, 'no_executor'
end

--- Met fin à l'observation d'une cible.
function Spectate.stop(target)
    if target == nil then return false, 'target required' end
    target = tostring(target)
    Spectate.sessions[target] = nil
    Spectate.stats.stopped = Spectate.stats.stopped + 1
    if Bus then Bus:emit('spectate.stopped', { target = target }) end
    if Spectate.executor then
        pcall(Spectate.executor, 'stop', target, {})
    end
    return true
end

function Spectate.isActive(target)
    return target ~= nil and Spectate.sessions[tostring(target)] ~= nil
end

--- Liste des observations en cours (pour la Multi-vue du dashboard).
function Spectate.active()
    local out = {}
    for target, s in pairs(Spectate.sessions) do
        out[#out + 1] = { target = target, admin = s.admin, since = s.since }
    end
    return out
end

function Spectate.getStats()
    return Util and Util.deepCopy(Spectate.stats) or Spectate.stats
end

ZShield.Spectate = Spectate
return Spectate
