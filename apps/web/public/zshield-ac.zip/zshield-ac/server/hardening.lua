--[[
    FILE:         server/hardening.lua
    PURPOSE:      Audit de durcissement FXServer (§24, §71-73). Produit un rapport
                  CURRENT / RECOMMENDED / WARNING / INCOMPATIBLE pour les convars de sécurité
                  pertinentes. Ne modifie JAMAIS un paramètre critique automatiquement (§24,
                  §71) : il conseille, l'opérateur décide.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua
    PUBLIC API:   ZShield.Hardening.audit() -> report (§73 /zshield audit)
                  ZShield.Hardening.securityScore() -> { score, breakdown }  (§72)

    §24, §71 : pour chaque option — purpose, risk, benefit, compatibility, recommended usage,
    rollback. On expose des convars officiellement documentées (sv_pureLevel,
    sv_filterRequestControl, block_net_game_event, sv_scriptHookAllowed, OneSync).
    §66 : pas de sécurité par l'obscurité — ces recommandations sont explicites et
    documentées, pas des réglages cachés.
    §72 : le score mesure la POSTURE du serveur, pas la qualité d'un joueur.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log

local Hardening = {}

-- Définition des contrôles audités. `recommended` est la valeur conseillée ; `weight` est
-- l'importance dans le score de posture (§72). `compat` note les risques de compatibilité.
local CONTROLS = {
    {
        convar = 'sv_scriptHookAllowed',
        recommended = '0',
        weight = 20,
        category = 'network',
        purpose = 'Autorise ou non ScriptHook côté client.',
        risk = 'Activé, il ouvre la porte à de nombreux menus de triche.',
        benefit = 'Désactivé, réduit fortement la surface de triche client.',
        compat = 'Sûr à désactiver sur la quasi-totalité des serveurs.',
        rollback = 'set sv_scriptHookAllowed 1',
    },
    {
        convar = 'sv_pureLevel',
        recommended = '1',
        weight = 15,
        category = 'network',
        purpose = 'Impose l intégrité des fichiers de jeu (1) ou aussi des ressources (2).',
        risk = 'À 0, des fichiers modifiés côté client passent inaperçus.',
        benefit = 'À 1 ou 2, bloque les modifications de fichiers non autorisées.',
        compat = 'Niveau 2 peut casser des mods clients légitimes : tester d abord.',
        rollback = 'set sv_pureLevel 0',
    },
    {
        convar = 'sv_filterRequestControl',
        recommended = '2',
        weight = 15,
        category = 'network',
        purpose = 'Filtre les demandes de contrôle d entités réseau abusives.',
        risk = 'À 0, un client peut prendre le contrôle d entités qu il ne devrait pas.',
        benefit = 'Réduit le griefing par prise de contrôle d entités.',
        compat = 'Les niveaux élevés peuvent gêner certains scripts de véhicules : vérifier.',
        rollback = 'set sv_filterRequestControl 0',
    },
    {
        convar = 'onesync',
        recommended = 'on',
        weight = 20,
        category = 'network',
        purpose = 'Active OneSync : synchronisation serveur-authoritative des entités.',
        risk = 'Sans OneSync, le serveur a bien moins de visibilité sur l état réel.',
        benefit = 'Indispensable à une architecture serveur-authoritative (§68).',
        compat = 'Requis au-delà de 32 joueurs ; compatible avec la plupart des frameworks.',
        rollback = 'set onesync off',
    },
    {
        convar = 'sv_enforceGameBuild',
        recommended = nil, -- pas de valeur unique recommandée : dépend du serveur
        weight = 5,
        category = 'configuration',
        purpose = 'Fige la version du jeu attendue.',
        risk = 'Non défini, des builds hétérogènes compliquent la détection.',
        benefit = 'Une build fixe rend le comportement plus prévisible.',
        compat = 'Choisir une build supportée par vos ressources.',
        rollback = 'retirer la convar',
    },
}

-- Convars sensibles à ne PAS exposer ni auditer en valeur (secrets §117).
-- On ne les lit jamais dans le rapport.

--- Lit une convar serveur, ou nil si la native n'est pas disponible (test/hors FXServer).
local function readConvar(name)
    if type(GetConvar) ~= 'function' then return nil end
    local v = GetConvar(name, '__unset__')
    if v == '__unset__' then return nil end
    return v
end

--- Évalue un contrôle : compare current à recommended. Retourne un verdict.
local function evaluate(control)
    local current = readConvar(control.convar)
    local status

    if current == nil then
        status = 'WARNING'          -- non défini : à examiner
    elseif control.recommended == nil then
        status = 'INFO'             -- pas de valeur unique recommandée
    elseif current == control.recommended then
        status = 'OK'
    else
        status = 'RECOMMENDED'      -- diffère du conseil : recommandation à considérer
    end

    return {
        convar = control.convar,
        category = control.category,
        current = current or '(non défini)',
        recommended = control.recommended or '(selon serveur)',
        status = status,
        purpose = control.purpose,
        risk = control.risk,
        benefit = control.benefit,
        compatibility = control.compat,
        rollback = control.rollback,
        weight = control.weight,
    }
end

--- Rapport d'audit complet (§73). Ne modifie rien (§24, §71).
function Hardening.audit()
    local results = {}
    for _, control in ipairs(CONTROLS) do
        results[#results + 1] = evaluate(control)
    end

    local counts = { OK = 0, RECOMMENDED = 0, WARNING = 0, INFO = 0, INCOMPATIBLE = 0 }
    for _, r in ipairs(results) do counts[r.status] = (counts[r.status] or 0) + 1 end

    return {
        generated_at = Util.wallclock(),
        controls = results,
        summary = counts,
        note = 'Ce rapport CONSEILLE. Aucune convar n a été modifiée (§24, §71). ' ..
               'Appliquez les changements manuellement après avoir vérifié la compatibilité.',
    }
end

--- Score de posture de sécurité (§72). Mesure la CONFIGURATION du serveur, pas un joueur.
--- Score = somme des poids des contrôles OK / somme totale des poids notables, en %.
function Hardening.securityScore()
    local gained, total = 0, 0
    local breakdown = {}
    for _, control in ipairs(CONTROLS) do
        if control.recommended ~= nil then -- seuls les contrôles à valeur conseillée comptent
            total = total + control.weight
            local current = readConvar(control.convar)
            local ok = current == control.recommended
            if ok then gained = gained + control.weight end
            breakdown[#breakdown + 1] = { convar = control.convar, ok = ok, weight = control.weight }
        end
    end
    local score = total > 0 and math.floor((gained / total) * 100) or 0
    return { score = score, gained = gained, total = total, breakdown = breakdown,
             note = 'Mesure la posture de configuration du serveur, pas la qualité d un joueur (§72).' }
end

--- Lignes formatées pour la console (§73 /zshield audit).
function Hardening.lines()
    local report = Hardening.audit()
    local score = Hardening.securityScore()
    local out = {
        string.format('ZShield Security Audit — posture %d%%', score.score),
        '',
    }
    for _, r in ipairs(report.controls) do
        out[#out + 1] = string.format('[%-11s] %-24s current=%s recommended=%s',
            r.status, r.convar, tostring(r.current), tostring(r.recommended))
        if r.status == 'RECOMMENDED' or r.status == 'WARNING' then
            out[#out + 1] = '              why: ' .. r.benefit
            out[#out + 1] = '              compat: ' .. r.compatibility
        end
    end
    out[#out + 1] = ''
    out[#out + 1] = report.note
    return out
end

ZShield.Hardening = Hardening
