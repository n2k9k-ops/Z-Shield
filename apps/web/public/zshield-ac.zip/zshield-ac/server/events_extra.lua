--[[
    FILE:         server/events_extra.lua
    PURPOSE:      Vérifications pures, pilotées par config, pour des événements
                  d'armes et de véhicules que l'adaptateur de framework alimente
                  (give/remove weapon, munitions, throwing/hijack/plaque/contrôle/
                  attache de véhicule, spawn par IA, auto-suppression). Le cœur
                  fournit la LOGIQUE et la décision ; l'adaptateur fournit les
                  données d'événement (source, propriétaire, vitesse…). Chaque
                  fonction est pure et testable ; basculer l'option change le verdict.
    DEPENDENCIES: shared/constants.lua, core/config.lua
    PUBLIC API:   voir les fonctions ci-dessous (toutes -> { block, reason } | {block=false})
]]

ZShield = ZShield or {}
local C = ZShield.Const

local EX = {}

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function deny(reason, sev, conf, cat)
    return { block = true, reason = reason, severity = sev or C.SEVERITY.HIGH,
        confidence = conf or 0.8, category = cat or C.CATEGORY.ENTITY }
end
local PASS = { block = false }

-- --- Armes -----------------------------------------------------------------

--- Don d'arme non autorisé par le serveur (`ctx.authorized ~= true`).
function EX.checkGiveWeapon(source, weaponHash, ctx)
    if not cfg('weapon.anti_give', false) then return PASS end
    ctx = ctx or {}
    if ctx.authorized == true then return PASS end
    return deny('unauthorized give-weapon', C.SEVERITY.HIGH, 0.85, C.CATEGORY.DAMAGE)
end

--- Retrait d'arme visant un AUTRE joueur (grief de désarmement).
function EX.checkRemoveWeapon(source, targetSource)
    if not cfg('weapon.anti_remove', false) then return PASS end
    if targetSource ~= nil and source ~= nil and tostring(targetSource) ~= tostring(source) then
        return deny('remove-weapon on another player', C.SEVERITY.MEDIUM, 0.8, C.CATEGORY.DAMAGE)
    end
    return PASS
end

--- Gain de munitions injustifié (sans pickup) au-delà d'un plafond.
function EX.checkAmmo(source, delta, ctx)
    if not cfg('weapon.anti_ammo', false) then return PASS end
    ctx = ctx or {}
    local maxGain = tonumber(cfg('weapon.max_ammo_gain', 250)) or 250
    if ctx.pickup ~= true and type(delta) == 'number' and delta > maxGain then
        return deny(string.format('ammo +%d without pickup', delta), C.SEVERITY.MEDIUM, 0.75, C.CATEGORY.DAMAGE)
    end
    return PASS
end

--- Munitions infinies : des tirs sans que le stock ne baisse jamais.
function EX.checkInfiniteAmmo(source, shots, ammoUsed)
    if not cfg('weapon.anti_infinite_ammo', false) then return PASS end
    if type(shots) == 'number' and shots >= 10 and (tonumber(ammoUsed) or 0) <= 0 then
        return deny('infinite ammo (no consumption over shots)', C.SEVERITY.HIGH, 0.8, C.CATEGORY.DAMAGE)
    end
    return PASS
end

-- --- Véhicules --------------------------------------------------------------

--- Véhicule projeté à une vitesse impossible sans conducteur (throwing de grief).
function EX.checkVehicleThrow(source, speedMs, ctx)
    if not cfg('vehicle.anti_throw', false) then return PASS end
    ctx = ctx or {}
    local limit = tonumber(cfg('vehicle.throw_speed_ms', 50)) or 50
    if type(speedMs) == 'number' and speedMs > limit and ctx.occupied ~= true then
        return deny(string.format('vehicle thrown at %.0f m/s (empty)', speedMs))
    end
    return PASS
end

--- Prise de contrôle d'un véhicule OCCUPÉ appartenant à un autre (hijack réseau).
function EX.checkVehicleHijack(source, info)
    if not cfg('vehicle.anti_hijack', false) then return PASS end
    info = info or {}
    if info.occupied == true and info.owner ~= nil and source ~= nil
        and tostring(info.owner) ~= tostring(source) then
        return deny('network hijack of an occupied vehicle')
    end
    return PASS
end

--- Changement de plaque côté client (aucune raison légitime en général).
function EX.checkPlateChange(source, info)
    if not cfg('vehicle.anti_plate_change', false) then return PASS end
    info = info or {}
    if info.from ~= nil and info.to ~= nil and info.from ~= info.to then
        return deny('client-side plate change', C.SEVERITY.MEDIUM, 0.7)
    end
    return PASS
end

--- Requête de contrôle sur le véhicule d'un autre (vol de propriété réseau).
function EX.checkControlRequest(source, ownerSource)
    if not cfg('vehicle.anti_control_request', false) then return PASS end
    if ownerSource ~= nil and source ~= nil and tostring(ownerSource) ~= tostring(source) then
        return deny('control request on another player vehicle', C.SEVERITY.MEDIUM, 0.7)
    end
    return PASS
end

--- Attache d'entités (véhicules collés) — exploit de grief.
function EX.checkAttachment(source, info)
    if not cfg('vehicle.anti_attachment', false) then return PASS end
    return deny('entity attachment blocked by policy', C.SEVERITY.MEDIUM, 0.65)
end

--- Spawn par IA / sans propriétaire joueur (véhicule ou ped).
function EX.checkAISpawn(source, kind, byAI)
    local key = (kind == 'ped') and 'entity.anti_ai_ped_spawn' or 'entity.anti_ai_vehicle_spawn'
    if not cfg(key, false) then return PASS end
    if byAI == true or source == nil then
        return deny('AI/ownerless ' .. tostring(kind) .. ' spawn')
    end
    return PASS
end

--- Ragdoll forcé sur un AUTRE joueur (grief : faire tomber les gens).
function EX.checkForcedRagdoll(source, targetSource)
    if not cfg('vehicle.anti_forced_ragdoll', false)
       and not cfg('game_events.anti_forced_ragdoll', false) then return PASS end
    if targetSource ~= nil and source ~= nil and tostring(targetSource) ~= tostring(source) then
        return deny('forced ragdoll on another player', C.SEVERITY.MEDIUM, 0.7, C.CATEGORY.STATE)
    end
    return PASS
end

--- Auto-suppression des véhicules détruits (action serveur pilotée).
function EX.shouldAutoDelete(info)
    if not cfg('vehicle.auto_delete_destroyed', false) then return false end
    info = info or {}
    return info.destroyed == true
end

ZShield.EventsExtra = EX
return EX
