--[[
    FILE:         server/preflight.lua
    PURPOSE:      Contrôle « préflight » au démarrage : détecte les erreurs de BRANCHEMENT
                  courantes qui, sinon, se paient en production — surtout le grand classique
                  « mes admins se font détecter/kick ». Chaque problème est journalisé en
                  WARN au boot avec la marche à suivre. Ne bloque jamais le démarrage : c'est
                  un diagnostic, pas un garde-fou dur.

    DEPENDENCIES: core/config.lua, core/log.lua
    PUBLIC API:   ZShield.Preflight.analyze(cfg, env) -> { {level, code, msg}... }  (PURE/testable)
                  ZShield.Preflight.run()  -- rassemble l'env FiveM réel + journalise
]]

ZShield = ZShield or {}
local Log = ZShield.Log

local Preflight = {}

--- Analyse PURE : à partir de la config et d'un instantané d'environnement, retourne la
--- liste des avertissements. `env` : {
---   onesync=bool, licensed=bool, screenshot_basic=bool, framework_admin=bool,
---   provisioning_default=bool }
function Preflight.analyze(cfg, env)
    cfg = cfg or {}
    env = env or {}
    local out = {}
    local function warn(code, msg) out[#out + 1] = { level = 'WARN', code = code, msg = msg } end
    local function info(code, msg) out[#out + 1] = { level = 'INFO', code = code, msg = msg } end

    -- 1) LE CLASSIQUE : staff détecté. exempt=true mais AUCUNE source d'identité staff
    --    (ni adaptateur isAdmin, ni permissions ACE, ni identifiants) => tes admins qui
    --    freecam/noclip/spectate SERONT détectés (et sanctionnés en ENFORCE).
    local staff = cfg.staff or {}
    if staff.exempt ~= false then
        local hasAce = type(staff.ace_perms) == 'table' and #staff.ace_perms > 0
        local hasIds = type(staff.identifiers) == 'table' and next(staff.identifiers) ~= nil
        if not env.framework_admin and not hasAce and not hasIds then
            warn('staff_unconfigured',
                'Exemption staff active mais AUCUNE source d\'identité staff : tes admins ' ..
                'risquent d\'être détectés (freecam/noclip/spectate). Renseigne staff.ace_perms ' ..
                '(ex. txadmin.menu.viewids) ou staff.identifiers, ou branche isAdmin de ton framework.')
        end
    else
        warn('staff_exempt_off',
            'staff.exempt = false : le personnel PEUT être sanctionné comme un joueur. ' ..
            'Active-le (recommandé) pour ne pas bannir tes admins.')
    end

    -- 2) Mode : SHADOW = tout est journalisé mais RIEN n'est appliqué.
    local mode = cfg.mode or 'SHADOW'
    if mode == 'SHADOW' then
        info('mode_shadow', 'Mode SHADOW : détections journalisées, AUCUNE sanction. ' ..
            'Passe en MONITOR puis ENFORCE quand tu as vérifié les faux positifs.')
    elseif mode == 'OFF' then
        warn('mode_off', 'Mode OFF : l\'anticheat ne fait RIEN. Passe en SHADOW/ENFORCE.')
    end

    -- 3) OneSync : plusieurs détecteurs (ownership, reach, désync, entités) s'appuient dessus.
    if env.onesync == false then
        warn('onesync_off', 'OneSync semble désactivé : ownership/reach/désync/entités ' ..
            'seront aveugles ou imprécis. Active `set onesync on`.')
    end

    -- 4) Licence.
    if env.licensed == false then
        warn('license_invalid', 'Licence absente/invalide : la protection est DÉSARMÉE. ' ..
            'Renseigne zshield_license_key (voir Installation).')
    end

    -- 5) Whitelists actives mais VIDES => tout bloqué dans la catégorie.
    local bl = cfg.blacklist_runtime  -- optionnel : instantané fourni par l'appelant
    local wl = cfg.whitelist_state    -- { vehicle=n, weapon=n, ped=n, object=n } comptes actifs
    if type(wl) == 'table' then
        for fam, count in pairs(wl) do
            if count == 0 then
                warn('whitelist_empty', 'Whitelist « ' .. tostring(fam) .. ' » ACTIVE mais VIDE : ' ..
                    'TOUT sera bloqué dans cette catégorie. Ajoute tes modèles autorisés (addons compris).')
            end
        end
    end

    -- 6) Capture d'écran de preuve activée sans URL d'upload => ne fera rien.
    local ev = cfg.evidence or {}
    if ev.enabled == true then
        if not ev.upload_url or ev.upload_url == '' then
            warn('evidence_no_url', 'evidence.enabled = true mais evidence.upload_url est vide : ' ..
                'aucune capture ne partira. Renseigne l\'URL d\'upload.')
        elseif env.screenshot_basic == false then
            warn('evidence_no_screenshotbasic', 'Capture activée mais la ressource ' ..
                '`screenshot-basic` n\'est pas démarrée côté client : les captures échoueront.')
        end
    end

    -- 7) Clé de provisioning client par défaut (module client non sécurisé).
    if env.provisioning_default == true then
        warn('provisioning_default', 'zshield_client_provisioning_key est encore la valeur ' ..
            'par défaut : remplace-la par une longue chaîne aléatoire unique à ton serveur.')
    end

    -- 8) Lockdown actif : serveur fermé aux non-whitelistés (info, pas une erreur).
    local conn = cfg.connection or {}
    if conn.lockdown == true then
        info('lockdown_on', 'LOCKDOWN actif : seuls les identifiants whitelistés peuvent se connecter.')
    end

    return out
end

--- Rassemble l'instantané d'environnement FiveM réel, analyse, et journalise.
function Preflight.run()
    local cfg = {}
    local V = ZShield.Config and ZShield.Config.value
    if V then
        cfg = {
            staff = V('staff', {}),
            mode = V('mode', 'SHADOW'),
            evidence = V('evidence', {}),
            connection = V('connection', {}),
        }
    end

    -- Instantané d'environnement (natives FiveM ; nil hors runtime).
    local env = {}
    if type(GetConvar) == 'function' then
        env.onesync = (GetConvar('onesync', 'off') ~= 'off')
        local prov = GetConvar('zshield_client_provisioning_key', '')
        env.provisioning_default = (prov == '' or prov:find('CHANGE') ~= nil or prov:find('CHANGE-MOI') ~= nil)
    end
    if type(GetResourceState) == 'function' then
        env.screenshot_basic = (GetResourceState('screenshot-basic') == 'started')
    end
    env.licensed = (ZShield.licensed ~= false)   -- license.lua pose ZShield.licensed
    env.framework_admin = (ZShield.Framework and ZShield.Framework.isAdmin) and true or false

    local warns = Preflight.analyze(cfg, env)
    if #warns == 0 then
        if Log then Log:info('preflight', 'aucun problème de branchement détecté') end
        return warns
    end
    for _, w in ipairs(warns) do
        if Log then
            if w.level == 'WARN' then Log:warn('preflight', w.msg, { code = w.code })
            else Log:info('preflight', w.msg, { code = w.code }) end
        end
    end
    return warns
end

ZShield.Preflight = Preflight
return Preflight
