--[[
    FILE:         server/reconcile.lua
    PURPOSE:      RÉCONCILIATION SERVEUR-AUTORITATIVE — la couche la plus CORIACE à contourner.
                  Le serveur tient un GRAND LIVRE (ledger) de la vérité pour chaque joueur :
                  santé, armure, argent, munitions par arme. Ces valeurs ne changent QUE par des
                  transitions que le serveur a lui-même enregistrées (dégâts appliqués, soin
                  accordé, achat/paie, tir/recharge). Quand le client RAPPORTE une valeur, on ne
                  la croit pas : on la CONFRONTE au ledger. Une valeur au-dessus de la vérité
                  serveur (santé gonflée, argent injecté, munitions infinies) est REJETÉE et
                  CORRIGÉE à la valeur autoritaire — la triche n'est jamais « acceptée ».

                  Pourquoi c'est coriace : modifier le client ne sert à rien, le serveur ne lit
                  pas la valeur du client comme vérité. Le tricheur devrait falsifier les
                  TRANSITIONS serveur (dégâts/soins/paies), qui passent par les autres détecteurs
                  (provenance, sequence, damage_integrity…). Défense en profondeur.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Reconcile.spawn(source, base)         -- pose la vérité de départ
                  ZShield.Reconcile.applyDamage(source, amount) -- transition serveur
                  ZShield.Reconcile.grantHeal(source, amount)
                  ZShield.Reconcile.grantMoney(source, amount)  -- (source légitime)
                  ZShield.Reconcile.spendMoney(source, amount)
                  ZShield.Reconcile.grantAmmo(source, weapon, n)
                  ZShield.Reconcile.consumeAmmo(source, weapon, n)
                  ZShield.Reconcile.report(source, field, clientValue, extra) -> { ok, corrected, signal }
                  ZShield.Reconcile.state(source) / .forget(source)
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local RC = {}
RC._led = {}   -- source -> { health, armor, money, ammo = { [weapon]=n } }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function ledger(source)
    local l = RC._led[source]
    if not l then
        l = { health = 200, armor = 0, money = 0, ammo = {} }
        RC._led[source] = l
    end
    return l
end

local function clamp(v, lo, hi) if v < lo then return lo elseif v > hi then return hi else return v end end

--- Pose la vérité de départ (au spawn / à la connexion, décidée serveur).
function RC.spawn(source, base)
    base = base or {}
    RC._led[source] = {
        health = tonumber(base.health) or (tonumber(cfg('reconcile.max_health', 200)) or 200),
        armor = tonumber(base.armor) or 0,
        money = tonumber(base.money) or 0,
        ammo = {},
    }
end

-- Transitions AUTORITAIRES (le serveur bouge la vérité lui-même).
function RC.applyDamage(source, amount)
    local l = ledger(source); l.health = clamp(l.health - (tonumber(amount) or 0), 0, 1e9)
end
function RC.grantHeal(source, amount)
    local l = ledger(source)
    local maxH = tonumber(cfg('reconcile.max_health', 200)) or 200
    l.health = clamp(l.health + (tonumber(amount) or 0), 0, maxH)
end
function RC.grantMoney(source, amount) local l = ledger(source); l.money = l.money + (tonumber(amount) or 0) end
function RC.spendMoney(source, amount) local l = ledger(source); l.money = clamp(l.money - (tonumber(amount) or 0), 0, 1e15) end
function RC.grantAmmo(source, weapon, n) local l = ledger(source); l.ammo[weapon] = (l.ammo[weapon] or 0) + (tonumber(n) or 0) end
function RC.consumeAmmo(source, weapon, n)
    local l = ledger(source); l.ammo[weapon] = clamp((l.ammo[weapon] or 0) - (tonumber(n) or 0), 0, 1e9)
end

local function sig(source, field, claimed, truth)
    return {
        detector = 'reconcile', category = C.CATEGORY.STATE,
        severity = C.SEVERITY.HIGH, confidence = 0.75,
        reason = string.format('valeur client « %s » = %s > vérité serveur %s (rejetée/corrigée)',
            field, tostring(claimed), tostring(truth)),
        source = source, metadata = { field = field, claimed = claimed, truth = truth, kind = 'reconcile_reject' },
    }
end

--- Confronte une valeur RAPPORTÉE par le client à la vérité serveur. Retourne toujours la
--- valeur CORRIGÉE (autoritaire) ; `ok=false` + `signal` si le client tentait de dépasser.
--- Le client a le droit d'être EN DESSOUS (dégâts non encore réconciliés) — jamais au-dessus.
function RC.report(source, field, clientValue, extra)
    if cfg('reconcile.enabled', false) ~= true then return { ok = true, corrected = clientValue } end
    local l = ledger(source)
    local cv = tonumber(clientValue)
    if cv == nil then return { ok = true, corrected = clientValue } end
    local tol = tonumber(cfg('reconcile.tolerance', 1)) or 1

    local truth
    if field == 'ammo' then
        local w = extra and extra.weapon
        truth = (l.ammo[w] or 0)
    else
        truth = l[field]
    end
    if truth == nil then return { ok = true, corrected = clientValue } end

    if cv > truth + tol then
        return { ok = false, corrected = truth, signal = sig(source, field, cv, truth) }
    end
    -- Valeur plausible (≤ vérité) : on adopte la valeur client comme nouvelle vérité si elle
    -- est plus basse (ex. dégâts encaissés côté client d'abord), jamais plus haute.
    if field ~= 'ammo' then l[field] = cv else l.ammo[extra.weapon] = cv end
    return { ok = true, corrected = cv }
end

function RC.state(source) return RC._led[source] end
function RC.forget(source) RC._led[source] = nil end

ZShield.Reconcile = RC
return RC
