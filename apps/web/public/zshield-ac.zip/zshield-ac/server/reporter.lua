--[[
    FILE:         server/reporter.lua
    PURPOSE:      Pont incident -> alerte plateforme. Transforme un incident en une
                  alerte au format attendu par l'agent (zshield-agent), et y attache
                  une PROPOSITION DE SANCTION quand l'incident vise un joueur identifié
                  de façon persistante et qu'il est assez grave (MEDIUM et au-dessus).

                  La plateforme décide ensuite : une alerte CRITICAL avec sanction
                  devient un ban ACTIF immédiat ; une MEDIUM/HIGH devient une sanction
                  EN ATTENTE (revue humaine avant application). Le cœur ne bannit pas
                  ici : il PROPOSE. L'exécution reste à l'agent/adaptateur.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua, core/bus
    PUBLIC API:   ZShield.Reporter.setSink(fn)      -- injecté par l'adaptateur
                  ZShield.Reporter.alertOf(incident) -> alert   (pur/testable)
                  ZShield.Reporter.report(incident)  -> ok
                  ZShield.Reporter.attach()

    IDENTITÉ (§ pas de flux, pas de capture) : l'identifiant de sanction est un
    identifiant que le SERVEUR possède déjà sur ses joueurs (license/steam/discord/
    ip/fivem), fourni par l'adaptateur via incident.context.identity. Ce n'est ni
    un flux ni une capture d'écran. Sans identité persistante, on envoie l'alerte
    SANS sanction : on ne propose jamais de bannir « au hasard ».
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Log = ZShield.Log
local Bus = ZShield.Bus
local Util = ZShield.Util

local Reporter = {
    sink = nil,   -- fn(alert) : envoi réel (exports['zshield-agent']:SendSecurityAlert)
    stats = { sent = 0, skipped = 0, errors = 0, sanctions = 0 },
}

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

-- Catégories du cœur -> catégories d'alerte de la plateforme.
local CATEGORY_MAP = {
    [C.CATEGORY.EVENT]    = 'event',
    [C.CATEGORY.MOVEMENT] = 'movement',
    [C.CATEGORY.ENTITY]   = 'entity',
    [C.CATEGORY.ECONOMY]  = 'economy',
    [C.CATEGORY.DAMAGE]   = 'weapon',
    [C.CATEGORY.RESOURCE] = 'resource',
    [C.CATEGORY.STATE]    = 'other',
    [C.CATEGORY.NETWORK]  = 'event',
}

-- Gravités qui justifient une proposition de sanction (en dessous : simple alerte).
local SANCTIONABLE = {
    [C.SEVERITY.MEDIUM] = true, [C.SEVERITY.HIGH] = true, [C.SEVERITY.CRITICAL] = true,
}

local VALID_SCOPE = {
    license = true, discord = true, steam = true, ip = true, fivem = true,
}

function Reporter.setSink(fn)
    Reporter.sink = fn
end

--- Convertit un risque (0..100 ou confiance 0..1) en entier borné 0..100.
local function toRisk(incident)
    local r = incident.risk_after
    if type(r) == 'number' then return math.max(0, math.min(100, math.floor(r + 0.5))) end
    local c = incident.confidence
    if type(c) == 'number' then return math.max(0, math.min(100, math.floor(c * 100 + 0.5))) end
    return nil
end

--- Construit l'alerte (forme filaire pour l'agent) à partir d'un incident. Pur.
function Reporter.alertOf(incident)
    incident = incident or {}
    local severity = incident.severity or C.SEVERITY.LOW
    local category = CATEGORY_MAP[incident.category] or 'other'
    local detector = incident.detector
    local reason = incident.decision and incident.decision.reason

    local summary = string.format('%s%s',
        tostring(detector or 'détection'),
        reason and (' — ' .. tostring(reason)) or '')
    if #summary < 3 then summary = 'détection anticheat' end

    local alert = {
        category = category,
        severity = severity,
        summary = summary:sub(1, 500),
        reference = type(incident.id) == 'string' and incident.id:gsub('[^%w%-_:]', '') or nil,
        metadata = {
            detector = detector,
            confidence = incident.confidence,
            risk = incident.risk_after,
        },
    }
    if detector and incident.source ~= nil then
        alert.dedup_key = (tostring(detector) .. ':' .. tostring(incident.source)):sub(1, 128)
    end

    -- Proposition de sanction : seulement si identité persistante ET gravité
    -- suffisante ET détecteur connu (le schéma l'exige).
    -- L'identité vient d'abord du contexte de l'incident ; à défaut, on la résout
    -- via l'adaptateur de framework (identifiant licence que le serveur possède
    -- déjà). Aucune identité résolvable -> alerte SANS sanction.
    local identity = incident.context and incident.context.identity
    if not identity and ZShield.Framework and incident.source ~= nil then
        local ok, lic = pcall(function() return ZShield.Framework.getIdentifier(incident.source) end)
        if ok and type(lic) == 'string' and #lic > 0 then
            identity = { scope = 'license', identifier = lic }
        end
    end
    if SANCTIONABLE[severity] and detector and identity
        and VALID_SCOPE[identity.scope] and identity.identifier then
        alert.sanction = {
            scope = identity.scope,
            identifier = tostring(identity.identifier):sub(1, 128),
            detector = tostring(detector):sub(1, 64),
        }
        if identity.player_name then
            alert.sanction.player_name = tostring(identity.player_name):sub(1, 64)
        end
        local risk = toRisk(incident)
        if risk then alert.sanction.risk = risk end
        -- Type de preuve : contexte de l'incident d'abord ; sinon réglages opérateur
        -- (« Enregistrement » -> clip ; « Screenshot » -> capture).
        local ev = incident.context and incident.context.evidence_kind
        if ev ~= 'clip' and ev ~= 'screenshot' then
            if cfg('evidence.gameplay_recording', false) == true then ev = 'clip'
            elseif cfg('evidence.screenshot', false) == true then ev = 'screenshot' end
        end
        if ev == 'clip' or ev == 'screenshot' then alert.sanction.evidence_kind = ev end
    end

    return alert
end

--- Envoie l'alerte via le sink injecté. Retourne ok.
function Reporter.report(incident)
    if not Reporter.sink then
        Reporter.stats.skipped = Reporter.stats.skipped + 1
        return false
    end
    local alert = Reporter.alertOf(incident)
    local ok, err = pcall(Reporter.sink, alert)
    if ok then
        Reporter.stats.sent = Reporter.stats.sent + 1
        if alert.sanction then Reporter.stats.sanctions = Reporter.stats.sanctions + 1 end
        return true
    end
    Reporter.stats.errors = Reporter.stats.errors + 1
    if Log then Log:error('reporter', 'sink threw', { err = tostring(err) }) end
    return false
end

--- S'abonne aux incidents ouverts pour les remonter à la plateforme.
function Reporter.attach()
    if not Bus then return end
    Bus:on('incident.opened', function(incident)
        pcall(Reporter.report, incident)
    end)
end

function Reporter.getStats()
    return Util and Util.deepCopy(Reporter.stats) or Reporter.stats
end

ZShield.Reporter = Reporter
return Reporter
