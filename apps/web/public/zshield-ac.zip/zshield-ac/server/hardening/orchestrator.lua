--[[
    FILE:         server/hardening/orchestrator.lua
    PURPOSE:      Native Security Orchestrator (§21). ZShield ne réinvente pas les protections
                  que FXServer offre déjà : il les CENTRALISE et les APPLIQUE. La prévention
                  native (entity lockdown OneSync, population, orphan mode) empêche à la source
                  la majorité des créations d'entités client illégitimes — pour un coût nul,
                  puisque c'est le moteur C++ qui l'applique, pas du Lua par tick.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua, core/config.lua
    PUBLIC API:   ZShield.Orchestrator.plan()   -- pur : liste des actions natives prévues
                  ZShield.Orchestrator.apply()  -- exécute le plan si les natives existent
                  ZShield.Orchestrator.report()

    Défaut SÛR (§31) : lockdown 'inactive' = AUCUN changement. L'opérateur doit choisir
    explicitement 'relaxed' (bloque les entités script créées par un client) ou 'strict'
    (aucune entité créée par un client). On n'altère jamais le serveur par accident.

    Réf : SET_ROUTING_BUCKET_ENTITY_LOCKDOWN_MODE, SET_ROUTING_BUCKET_POPULATION_ENABLED,
    SET_ENTITY_ORPHAN_MODE (OneSync).
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log

local Orchestrator = { applied = {} }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

--- Construit la liste des actions natives à appliquer, sans les exécuter. Testable.
--- Retour : array de { native, args, why }.
function Orchestrator.plan()
    local plan = {}
    if not cfg('onesync.enabled', false) then
        return plan   -- l'opérateur n'a pas activé l'orchestration native
    end

    local bucket = cfg('onesync.bucket', 0)

    local mode = cfg('onesync.lockdown_mode', C.LOCKDOWN.INACTIVE)
    if mode == C.LOCKDOWN.RELAXED or mode == C.LOCKDOWN.STRICT then
        plan[#plan + 1] = {
            native = 'SetRoutingBucketEntityLockdownMode',
            args = { bucket, mode },
            why = 'entity lockdown ' .. mode .. ' — empêche la création d\'entités par le client',
        }
    end

    if cfg('onesync.disable_population', false) then
        plan[#plan + 1] = {
            native = 'SetRoutingBucketPopulationEnabled',
            args = { bucket, false },
            why = 'population native désactivée — PNJ/trafic gérés serveur, réduit la surface',
        }
    end

    if cfg('onesync.orphan_keep', false) then
        -- 1 = KeepEntity (le serveur ne supprime pas l'entité orpheline).
        plan[#plan + 1] = {
            native = 'SetEntityOrphanMode',
            args = { 'KeepEntity' },
            why = 'orphan mode KeepEntity — entités serveur non supprimées à la déco du contrôleur',
        }
    end

    return plan
end

-- Table de dispatch vers les vraies natives. Séparée pour rester testable (on peut
-- injecter des stubs). Chaque appel est isolé : l'échec d'une native n'arrête pas les autres.
local NATIVES = {
    SetRoutingBucketEntityLockdownMode = function(bucket, mode)
        if type(SetRoutingBucketEntityLockdownMode) == 'function' then
            SetRoutingBucketEntityLockdownMode(bucket, mode)
        end
    end,
    SetRoutingBucketPopulationEnabled = function(bucket, enabled)
        if type(SetRoutingBucketPopulationEnabled) == 'function' then
            SetRoutingBucketPopulationEnabled(bucket, enabled)
        end
    end,
    SetEntityOrphanMode = function(mode)
        if type(SetEntityOrphanMode) == 'function' then SetEntityOrphanMode(mode) end
    end,
}
Orchestrator.NATIVES = NATIVES

--- Applique le plan. Retourne le nombre d'actions appliquées. Chaque action est isolée.
function Orchestrator.apply()
    local plan = Orchestrator.plan()
    Orchestrator.applied = {}
    for _, action in ipairs(plan) do
        local fn = NATIVES[action.native]
        if fn then
            local ok, err = pcall(fn, table.unpack(action.args))
            if ok then
                Orchestrator.applied[#Orchestrator.applied + 1] = action
                Log:info('orchestrator', 'native protection applied', {
                    native = action.native, why = action.why })
            else
                Log:error('orchestrator', 'native protection failed', {
                    native = action.native, err = tostring(err) })
            end
        end
    end
    if #plan == 0 then
        Log:info('orchestrator', 'no native orchestration configured (onesync.enabled=false or lockdown inactive)')
    end
    return #Orchestrator.applied
end

function Orchestrator.report()
    return { planned = Orchestrator.plan(), applied = Util.deepCopy(Orchestrator.applied) }
end

ZShield.Orchestrator = Orchestrator
