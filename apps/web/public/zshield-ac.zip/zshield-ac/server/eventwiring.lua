--[[
    FILE:         server/eventwiring.lua
    PURPOSE:      Couche FiveM du câblage : NORMALISE les événements natifs du serveur en events
                  génériques et les passe au répartiteur pur (server/dispatch.lua), avec pour sink
                  ZShield.RouteSignal (bus + corrélation + réputation). C'est la seule partie liée
                  à FXServer ; toute la logique de routage est testée dans dispatch.lua.

    NB : non testé en isolation (natives/events FiveM absents du harnais). Silencieux hors FXServer.

    PUBLIC API:   ZShield.EventWiringAttach()
]]

ZShield = ZShield or {}

function ZShield.EventWiringAttach()
    local D = ZShield.Dispatch
    if not D then return end
    if type(AddEventHandler) ~= 'function' then return end   -- hors FiveM (tests)

    local sink = ZShield.RouteSignal or function() end
    local function feed(ev) pcall(function() D.handle(ev, sink) end) end
    local function now() return (ZShield.Util and ZShield.Util.now()) or (GetGameTimer and GetGameTimer()) or 0 end

    -- Connexion / spawn / déconnexion.
    AddEventHandler('playerJoining', function() local s = source; feed({ type = 'spawn', source = s, now = now() }) end)
    AddEventHandler('playerDropped', function() local s = source; if s and D.forget then D.forget(s) end end)

    -- Chat.
    AddEventHandler('chatMessage', function(src, _, msg) feed({ type = 'chat', source = src, text = msg, now = now() }) end)

    -- Explosions (event natif serveur).
    AddEventHandler('explosionEvent', function(sender, ev)
        local s = tonumber(sender)
        feed({ type = 'explosion', source = s, attrs = {
            x = ev and ev.posX, y = ev and ev.posY, z = ev and ev.posZ, source = s }, now = now() })
    end)

    -- Création d'entités : validation anti-crash + ownership/flood.
    AddEventHandler('entityCreating', function(handle)
        local attrs = {}
        pcall(function()
            if GetEntityCoords then local c = GetEntityCoords(handle); attrs.x, attrs.y, attrs.z = c.x, c.y, c.z end
        end)
        feed({ type = 'entity_create', source = nil, attrs = attrs, now = now() })
    end)

    -- Événements de jeu (dégâts, etc.) : le parsing exact dépend de la version ; on route ce
    -- qui est disponible. Les moteurs qui exigent des champs manquants restent silencieux.
    AddEventHandler('gameEventTriggered', function(name, _, args)
        if name == 'CEventNetworkEntityDamage' then
            -- args : {victimEntity, attackerEntity, ..., isFatal, weaponHash, ...} (version-dép.)
            local attacker = args and args[2] and NetworkGetEntityOwner and NetworkGetEntityOwner(args[2])
            feed({ type = 'damage', source = attacker, weapon = args and args[7], now = now() })
        end
    end)

    -- Auto-protection : arrêt de ressource protégée (déjà géré par le glue autoritatif, mais on
    -- garde le point d'entrée ici si le glue n'est pas actif).
    -- (voir server/glue_authoritative.lua pour le CancelEvent effectif)

    -- Échantillonnage de position serveur-autoritatif : le serveur LIT la position synchronisée
    -- de chaque joueur (il ne fait pas confiance à une valeur brute du client). Alimente
    -- mouvement/vol/téléport/désync/hit-reg/horloge.
    CreateThread(function()
        while true do
            Wait(tonumber(ZShield.Config and ZShield.Config.value('wiring.position_sample_ms', 500)) or 500)
            if type(GetPlayers) == 'function' then
                for _, sid in ipairs(GetPlayers()) do
                    local s = tonumber(sid)
                    local ped = s and GetPlayerPed and GetPlayerPed(s)
                    if ped and ped ~= 0 and GetEntityCoords then
                        local ok, c = pcall(GetEntityCoords, ped)
                        if ok and c then
                            feed({ type = 'position', source = s,
                                pos = { x = c.x, y = c.y, z = c.z },
                                in_air = (IsPedInAnyVehicle and IsPedInAnyVehicle(ped, false)) or false,
                                now = now() })
                        end
                    end
                end
            end
        end
    end)
end

return ZShield.EventWiringAttach
