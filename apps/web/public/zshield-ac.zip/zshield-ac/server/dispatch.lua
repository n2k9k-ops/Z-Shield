--[[
    FILE:         server/dispatch.lua
    PURPOSE:      RÉPARTITEUR CENTRAL (pur, testable). Reçoit un ÉVÉNEMENT NORMALISÉ et le route
                  vers TOUS les moteurs concernés, puis fait remonter chaque signal + sa
                  corrélation (trainer) + sa fusion (cote composite). C'est le « câblage » de la
                  chaîne complète, isolé de FiveM : la couche FiveM (server/eventwiring.lua) se
                  contente de NORMALISER les events natifs et d'appeler D.handle — tout le reste,
                  testable, vit ici.

    Un événement normalisé : { type = '...', source = id, now = ms, ... champs selon le type }.
    Types : 'spawn','death','position','damage','explosion','entity_create','chat','command',
            'give_weapon','ownership','money_gain','trigger','report_value','action'.

    DEPENDENCIES: tous les modules de détection (chargés avant), core/util.lua
    PUBLIC API:   ZShield.Dispatch.handle(ev, sink) -> { signaux... }
                  ZShield.Dispatch.forget(source)
]]

ZShield = ZShield or {}
local Util = ZShield.Util

local D = {}
D._pos = {}   -- source -> { pos, at }  (pour la distance de saut / téléport)

local function Z(name) return ZShield[name] end

function D.forget(source)
    D._pos[source] = nil
    for _, n in ipairs({ 'Aimstats', 'Flight', 'DamageIntegrity', 'Provenance', 'Freecam', 'Sequence',
        'Desync', 'Budget', 'Esp', 'Ownership', 'ChatSpam', 'Teleport', 'Menu', 'Behavior', 'Reconcile',
        'Envelope', 'Sprt', 'Baseline', 'HitReg', 'Fusion', 'Markov', 'ClockSync', 'SpawnProtect' }) do
        local m = Z(n); if m and m.forget then pcall(m.forget, source) end
    end
end

function D.handle(ev, sink)
    local out = {}
    if type(ev) ~= 'table' or not ev.type then return out end
    local now = tonumber(ev.now) or (Util and Util.now()) or 0
    local src = ev.source

    -- Remonte un signal primaire + sa corrélation (trainer) + sa fusion (cote composite).
    local function prim(sig)
        if not sig then return end
        out[#out + 1] = sig
        if sink then pcall(sink, sig) end
        local tr = Z('Trainer')
        if tr and tr.observeSignal and sig.source then
            local m = tr.observeSignal(sig.source, { detector = sig.detector, severity = sig.severity, now = now })
            if m then out[#out + 1] = m; if sink then pcall(sink, m) end end
        end
        local fu = Z('Fusion')
        if fu and fu.observe and sig.source then
            local f = fu.observe(sig.source, sig)
            if f then out[#out + 1] = f; if sink then pcall(sink, f) end end
        end
    end

    local t = ev.type

    if t == 'spawn' then
        if Z('Reconcile') then Z('Reconcile').spawn(src, ev.base) end
        if Z('SpawnProtect') then Z('SpawnProtect').markSpawn(src, now) end
        if Z('Sequence') then prim(Z('Sequence').observe(src, { type = 'spawn' })) end
        D._pos[src] = nil

    elseif t == 'death' then
        if Z('Sequence') then prim(Z('Sequence').observe(src, { type = 'death' })) end

    elseif t == 'position' then
        -- Cinématique verticale / téléport instantané.
        if Z('Flight') then prim(Z('Flight').observe(src, ev.pos, {
            now = now, trusted = ev.trusted, in_air = ev.in_air, falling = ev.falling })) end
        -- Téléport « menu » : saut par rapport à la dernière position connue.
        local prev = D._pos[src]
        if prev and Z('Teleport') then
            local dx, dy, dz = ev.pos.x - prev.pos.x, ev.pos.y - prev.pos.y, (ev.pos.z or 0) - (prev.pos.z or 0)
            local jump = math.sqrt(dx * dx + dy * dy + dz * dz)
            prim(Z('Teleport').observe(src, { jump_m = jump, trusted = ev.trusted, now = now }))
        end
        D._pos[src] = { pos = ev.pos, at = now }
        -- Référence pour désync + historique pour hit-reg + freecam + horloge.
        if Z('Desync') then Z('Desync').observePosition(src, ev.pos, now) end
        if Z('HitReg') then Z('HitReg').record(src, ev.pos, now) end
        if Z('Freecam') then prim(Z('Freecam').observe(src, { pos = ev.pos, active = ev.active, dead = ev.dead, now = now })) end
        if ev.client_ts and Z('ClockSync') then prim(Z('ClockSync').observe(src, { client_ts = ev.client_ts, now = now })) end
        if ev.mode and Z('Invariants') then
            for _, v in ipairs(Z('Invariants').check(src, { speed = ev.speed, mode = ev.mode,
                x = ev.pos.x, y = ev.pos.y, z = ev.pos.z, in_air = ev.in_air })) do prim(v) end
        end

    elseif t == 'damage' then
        local a = src   -- attaquant
        if Z('DamageIntegrity') then prim(Z('DamageIntegrity').observe(a, {
            weapon = ev.weapon, damage = ev.damage, dist = ev.dist, now = now })) end
        if Z('Aimstats') and ev.hit ~= nil then prim(Z('Aimstats').observe(a, {
            hit = ev.hit, headshot = ev.headshot, snap_deg = ev.snap_deg, react_ms = ev.react_ms, dist = ev.dist })) end
        if Z('HitReg') and ev.victim ~= nil then prim(Z('HitReg').validate(a, ev.victim, {
            origin = ev.origin, aim = ev.aim, latency_ms = ev.latency_ms, range = ev.range, now = now })) end
        if Z('Sequence') then prim(Z('Sequence').observe(a, { type = 'fire', weapon = ev.weapon })) end
        if Z('Godmode') and ev.victim ~= nil and ev.hp_before ~= nil then
            prim(Z('Godmode').observeDamage(ev.victim, {
                damage_taken = ev.damage, hp_before = ev.hp_before, hp_after = ev.hp_after })) end
        if Z('SpawnProtect') and ev.victim ~= nil then prim(Z('SpawnProtect').observeDamage(a, ev.victim, now)) end
        if Z('Envelope') then local r = Z('Envelope').observe(a, 'fire', now); if r and r.over then prim(r.signal) end end
        if Z('Budget') and ev.weapon then prim(Z('Budget').shot(a, { weapon = ev.weapon, mag = ev.mag, now = now })) end
        if Z('Sprt') and ev.superhuman ~= nil then prim((Z('Sprt').observe(a, 'superhuman_shot', ev.superhuman and 1 or 0) or {}).signal) end
        if Z('Markov') then prim(Z('Markov').observe(a, 'fire')) end
        if Z('Behavior') then prim(Z('Behavior').observe(a, now)) end

    elseif t == 'explosion' then
        local attrs = ev.attrs or {}; attrs.source = attrs.source or src
        if Z('CrashGuard') then local r = Z('CrashGuard').checkEntity(attrs); if r then prim(r.signal) end end
        if Z('Envelope') then local r = Z('Envelope').observe(src, 'explosion', now); if r and r.over then prim(r.signal) end end

    elseif t == 'entity_create' then
        local attrs = ev.attrs or {}; attrs.source = attrs.source or src
        if Z('CrashGuard') then local r = Z('CrashGuard').checkEntity(attrs); if r then prim(r.signal) end end
        if Z('Ownership') then prim(Z('Ownership').observe(src, { kind = 'create', now = now })) end
        if Z('Envelope') then local r = Z('Envelope').observe(src, 'spawn_entity', now); if r and r.over then prim(r.signal) end end

    elseif t == 'ownership' then
        if Z('Ownership') then prim(Z('Ownership').observe(src, { kind = 'ownership', now = now })) end

    elseif t == 'chat' then
        if Z('ChatSpam') then prim(Z('ChatSpam').observe(src, { kind = 'chat', text = ev.text, now = now })) end
        if Z('Envelope') then local r = Z('Envelope').observe(src, 'chat', now); if r and r.over then prim(r.signal) end end

    elseif t == 'command' then
        if Z('Menu') then prim(Z('Menu').observeTrigger(src, { name = ev.name, power = ev.power, now = now })) end
        if Z('Envelope') then local r = Z('Envelope').observe(src, 'command', now); if r and r.over then prim(r.signal) end end

    elseif t == 'give_weapon' then
        if Z('Sequence') then Z('Sequence').observe(src, { type = 'give_weapon', weapon = ev.weapon }) end
        if Z('Reconcile') and ev.ammo then Z('Reconcile').grantAmmo(src, ev.weapon, ev.ammo) end

    elseif t == 'money_gain' then
        if Z('Provenance') then prim(Z('Provenance').observe(src, { kind = ev.kind or 'money', amount = ev.amount, now = now })) end

    elseif t == 'trigger' then
        if Z('Executor') then prim(Z('Executor').observeEvent(src, { resource = ev.resource, event = ev.event, now = now })) end
        if Z('SelfProtect') then prim(Z('SelfProtect').observeInternalEventFromClient(src, ev.event)) end
        if Z('Menu') then prim(Z('Menu').observeTrigger(src, { name = ev.event, power = ev.power, now = now })) end

    elseif t == 'report_value' then
        if Z('Reconcile') then
            local r = Z('Reconcile').report(src, ev.field, ev.value, ev.extra)
            if r and not r.ok then prim(r.signal) end
        end

    elseif t == 'action' then
        if Z('Envelope') and ev.class then local r = Z('Envelope').observe(src, ev.class, now); if r and r.over then prim(r.signal) end end
        if Z('Behavior') then prim(Z('Behavior').observe(src, now)) end
        if Z('Markov') and ev.class then prim(Z('Markov').observe(src, ev.class)) end
    end

    return out
end

ZShield.Dispatch = D
return D
