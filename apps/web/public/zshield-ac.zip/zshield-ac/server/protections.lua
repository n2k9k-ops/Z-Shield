--[[
    FILE:         server/protections.lua
    PURPOSE:      Réglages de protections pilotés depuis le dashboard. Le client choisit,
                  par protection, si elle est ACTIVE et dans quel MODE :
                    - 'watch'  (Surveiller) : on décide et on alerte, mais aucune sanction
                                              dure (kick/ban) n'est appliquée.
                    - 'block'  (Bloquer)    : comportement normal du moteur de sanction.
                  Une protection désactivée fait ABANDONNER l'incident correspondant.
    DEPENDENCIES: shared/constants.lua, core/log.lua
    PUBLIC API:   ZShield.Protections.set(list)         -- applique les réglages reçus
                  ZShield.Protections.gate(incident)    -- 'drop' | 'watch' | 'block'
                  ZShield.Protections.loaded()          -- des réglages ont-ils été reçus ?
                  ZShield.Protections.snapshot()        -- état courant (pour la télémétrie)

    SÛRETÉ : tant qu'AUCUN réglage n'a été reçu, gate() renvoie toujours 'block' — le
    comportement de l'anticheat est identique à avant. Un réglage ne peut donc jamais
    AFFAIBLIR la protection par accident ; il faut un choix explicite du client.

    GRANULARITÉ : les identifiants du catalogue (mv_teleport, wp_wallbang, …) portent un
    préfixe de catégorie. Un incident précis peut porter `incident.protection = <id>` et
    sera réglé au plus fin ; sinon on retombe sur l'agrégat de sa CATÉGORIE, avec une
    règle conservatrice : on ne cesse de bloquer une catégorie que si TOUTES ses
    protections sont en 'watch', et on ne l'abandonne que si TOUTES sont désactivées.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Log = ZShield.Log

local Protections = {}

-- id (par son préfixe) -> catégorie du moteur de détection.
local PREFIX_CATEGORY = {
    mv_ = C.CATEGORY.MOVEMENT,
    pl_ = C.CATEGORY.STATE,
    wp_ = C.CATEGORY.DAMAGE,
    vh_ = C.CATEGORY.ENTITY,
    nt_ = C.CATEGORY.NETWORK,
    mn_ = C.CATEGORY.ECONOMY,
    ai_ = C.CATEGORY.DAMAGE,
    sp_ = C.CATEGORY.ENTITY,
    -- Protections avancées (catalogue étendu, dashboard) :
    av_ = C.CATEGORY.DAMAGE,    -- visée : ratio HS, snap, réaction, silent-aim, rewind, SPRT
    nw_ = C.CATEGORY.NETWORK,   -- réseau : executor, traces, lag-switch, désync, flood, horloge
    rc_ = C.CATEGORY.STATE,     -- intégrité : réconciliation, god-mode, reach, invariants, débit
    rs_ = C.CATEGORY.RESOURCE,  -- ressources : anti-stop, backdoor, crash-guard
    bh_ = C.CATEGORY.STATE,     -- comportement : macro, trainer, réputation, freecam
    con = C.CATEGORY.NETWORK,   -- connexion : VPN, duplication, pseudo, score de menace
    bl_ = C.CATEGORY.ENTITY,    -- listes : blacklist de peds / objets
    exp = C.CATEGORY.ENTITY,    -- listes : types d'explosion interdits
}

local function categoryOf(id)
    return PREFIX_CATEGORY[string.sub(id, 1, 3)]
end

-- Résolution FINE : chaque détecteur du cœur porte un `incident.detector` ; on le
-- relie à l'identifiant précis du catalogue pour que CHAQUE case du dashboard agisse
-- individuellement (et pas seulement au niveau de sa catégorie). Un détecteur non
-- listé ici retombe proprement sur le gate de sa catégorie.
local DETECTOR_TO_PROTECTION = {
    ['movement.teleport']   = 'mv_teleport',
    ['teleport']            = 'mv_teleport',
    ['movement.speed']      = 'mv_speed',
    ['movement.jitter']     = 'mv_accel',
    ['movement']            = 'mv_pos_no_event',
    ['flight']              = 'mv_fly',
    ['godmode']             = 'rc_godmode',
    ['reach']               = 'rc_reach',
    ['reconcile']           = 'rc_health',
    ['esp']                 = 'ai_walltrack',
    ['freecam']             = 'bh_freecam',
    ['desync']              = 'nw_desync',
    ['clocksync']           = 'nw_clocksync',
    ['executor']            = 'nw_executor',
    ['injection.traces']    = 'nw_injection_traces',
    ['hitreg']              = 'av_silent_aim',
    ['aimstats']            = 'av_snap',
    ['aim.camera']          = 'ai_camera',
    ['damage_integrity']    = 'wp_damage_fake',
    ['weapon.behaviour']    = 'wp_damage_fake',
    ['weapon.firerate']     = 'wp_fire_rate',
    ['projectile.behaviour']= 'wp_projectile',
    ['ownership']           = 'sp_entities',
    ['entity.spam']         = 'sp_entities',
    ['command.flood']       = 'sp_commands',
    ['chatspam']            = 'sp_commands',
    ['envelope']            = 'rc_envelope',
    ['budget']              = 'rc_envelope',
    ['provenance']          = 'mn_create',
    ['spawnprotect']        = 'rc_spawnkill',
    ['crashguard']          = 'rs_crashguard',
    ['selfprotect']         = 'rs_stop_anticheat',
    ['sequence']            = 'bh_trainer',
    ['fusion']              = 'bh_trainer',
    ['menu']                = 'bh_trainer',
    ['trainer']             = 'bh_trainer',
    ['markov']              = 'bh_macro',
    ['behavior']            = 'bh_macro',
}
-- Détecteurs à identifiant préfixé (ex. 'invariant.health', 'sprt.headshot').
local DETECTOR_PREFIX_TO_PROTECTION = {
    ['invariant.'] = 'rc_invariants',
    ['sprt.']      = 'av_sprt',
    ['statebag.']  = 'pl_stat_mod',
    ['baseline.']  = 'av_baseline',
    ['aim.']       = 'ai_camera',
    ['client.']    = 'pl_lua_input',
}

local function protectionOf(incident)
    if incident.protection then return incident.protection end
    local d = incident.detector
    if type(d) ~= 'string' or d == '' then return nil end
    local exact = DETECTOR_TO_PROTECTION[d]
    if exact then return exact end
    for pfx, pid in pairs(DETECTOR_PREFIX_TO_PROTECTION) do
        if string.sub(d, 1, #pfx) == pfx then return pid end
    end
    return nil
end

Protections._byId = {}   -- id -> { enabled = bool, mode = 'watch'|'block' }
Protections._cat = {}    -- category -> { count, anyEnabled, anyBlock }

--- Applique les réglages reçus. `list` peut être un tableau d'entrées
--- { id, enabled, mode } ou une table id -> { enabled, mode }.
function Protections.set(list)
    local byId = {}

    local function put(id, enabled, mode)
        if type(id) ~= 'string' or id == '' then return end
        byId[id] = {
            enabled = enabled ~= false,
            mode = (mode == 'watch') and 'watch' or 'block',
        }
    end

    if type(list) == 'table' then
        if list[1] ~= nil then
            for _, e in ipairs(list) do
                if type(e) == 'table' then put(e.id, e.enabled, e.mode) end
            end
        else
            for id, e in pairs(list) do
                if type(e) == 'table' then put(id, e.enabled, e.mode) end
            end
        end
    end

    Protections._byId = byId

    -- Agrégat par catégorie (conservateur, voir en-tête).
    local cat = {}
    for id, s in pairs(byId) do
        local c = categoryOf(id)
        if c then
            local a = cat[c] or { count = 0, anyEnabled = false, anyBlock = false }
            a.count = a.count + 1
            if s.enabled then
                a.anyEnabled = true
                if s.mode == 'block' then a.anyBlock = true end
            end
            cat[c] = a
        end
    end
    Protections._cat = cat

    local n = 0
    for _ in pairs(byId) do n = n + 1 end
    if Log then Log:info('protections', 'settings applied', { count = n }) end
    return n
end

--- Des réglages ont-ils été reçus au moins une fois ?
function Protections.loaded()
    return next(Protections._byId) ~= nil
end

--- Décide comment traiter un incident vis-à-vis des réglages du client.
--- Retourne 'drop' (protection désactivée), 'watch' (surveiller sans sanction dure)
--- ou 'block' (comportement normal).
function Protections.gate(incident)
    if not incident then return 'block' end

    -- 1) Réglage précis : id porté par l'incident, ou déduit de son détecteur.
    local id = protectionOf(incident)
    if id and Protections._byId[id] then
        local s = Protections._byId[id]
        if not s.enabled then return 'drop' end
        return s.mode
    end

    -- 2) Agrégat de la catégorie (seulement si on a des réglages pour elle).
    local a = Protections._cat[incident.category]
    if a and a.count > 0 then
        if not a.anyEnabled then return 'drop' end
        return a.anyBlock and 'block' or 'watch'
    end

    -- 3) Par défaut : ne rien changer au comportement existant.
    return 'block'
end

--- État courant, pour la télémétrie / le diagnostic.
function Protections.snapshot()
    local enabled, watch, block = 0, 0, 0
    for _, s in pairs(Protections._byId) do
        if s.enabled then
            enabled = enabled + 1
            if s.mode == 'watch' then watch = watch + 1 else block = block + 1 end
        end
    end
    return { total = enabled, watch = watch, block = block, received = Protections.loaded() }
end

ZShield.Protections = Protections
return Protections
