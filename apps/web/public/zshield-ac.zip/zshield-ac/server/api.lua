--[[
    FILE:         server/api.lua
    PURPOSE:      Surface d'API publique (§45). Fonctions stables exposées aux autres
                  ressources via exports. Chaque fonction est une façade sûre au-dessus des
                  moteurs : elle ne donne jamais accès direct à l'état interne mutable.
    DEPENDENCIES: tous les moteurs (chargés avant)
    PUBLIC API (§45) :
        ZShield.GetVersion()
        ZShield.GetRisk(source) -> score, level
        ZShield.GetPlayerState(source) -> state
        ZShield.CreateIncident(spec) -> id
        ZShield.AddSignal(signal)
        ZShield.RegisterTrustedContext(source, key, value)
        ZShield.RegisterProtectedEvent(definition)
        ZShield.RegisterTrustedTeleport(source, opts)

    §45 : documenter chaque API. La doc est dans docs/API.md et générée depuis les
    annotations ci-dessous.
    §54 : chaque fonction répond « what can the client control? » — ici, RIEN : ce sont des
    ressources SERVEUR de confiance qui appellent, mais on valide tout de même les entrées.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Schema = ZShield.Schema
local Log = ZShield.Log

local API = {}

--- Version de la plateforme (§45, §79).
function ZShield.GetVersion()
    return C.VERSION
end

--- Score et niveau de risque d'un joueur (§45). Lecture seule : renvoie une copie.
function ZShield.GetRisk(source)
    if not ZShield.Risk then return 0, C.RISK_LEVEL.NORMAL end
    return math.floor(ZShield.Risk.score(source)), ZShield.Risk.level(source)
end

--- État courant d'un joueur dans la machine à états (§45, §08).
function ZShield.GetPlayerState(source)
    if not ZShield.Context then return nil end
    local ctx = ZShield.Context.get(source)
    return ctx and ctx.state or nil
end

--- Snapshot de risque explicable (§45, §41) : score, niveau, historique récent.
function ZShield.GetRiskSnapshot(source)
    if not ZShield.Risk then return nil end
    return ZShield.Risk.snapshot(source)
end

--- Crée un incident manuellement (§45). Validé avant transmission au moteur.
--- Retourne l'id de l'incident, ou nil + erreur.
local INCIDENT_SPEC_SCHEMA = {
    type = 'table', required = true,
    fields = {
        source = { type = 'any' },
        detector = { type = 'string', required = true, max = 64 },
        category = { type = 'string', max = 32 },
        severity = { type = 'string', required = true, enum = C.SEVERITY_ORDER },
        confidence = { type = 'number', min = 0, max = 1 },
        risk_after = { type = 'number', min = 0, max = 100 },
        reason = { type = 'string', max = 400 },
        metadata = { type = 'table' },
    },
    allowUnknown = true,
}
function ZShield.CreateIncident(spec)
    if not ZShield.Incident then return nil, 'incident engine not loaded' end
    local ok, err = Schema.validate(spec, INCIDENT_SPEC_SCHEMA, 'incident_spec')
    if not ok then
        Log:warn('api', 'CreateIncident: invalid spec', { err = err })
        return nil, err
    end
    local inc = ZShield.Incident.open(spec)
    return inc and inc.id or nil
end

--- Ajoute un signal externe (§45). Une ressource tierce peut alimenter le moteur avec ses
--- propres détections. Validé et normalisé comme tout signal.
local SIGNAL_SCHEMA = {
    type = 'table', required = true,
    fields = {
        source = { type = 'any' },
        detector = { type = 'string', required = true, max = 64 },
        category = { type = 'string', max = 32 },
        severity = { type = 'string', required = true, enum = C.SEVERITY_ORDER },
        confidence = { type = 'number', min = 0, max = 1 },
        reason = { type = 'string', max = 255 },
        metadata = { type = 'table' },
    },
    allowUnknown = true,
}
function ZShield.AddSignal(signal)
    if not ZShield.Detection then return false, 'detection engine not loaded' end
    local ok, err = Schema.validate(signal, SIGNAL_SCHEMA, 'signal')
    if not ok then
        Log:warn('api', 'AddSignal: invalid signal', { err = err })
        return false, err
    end
    ZShield.Detection.emit(signal)
    return true
end

--- Enregistre une valeur de contexte de confiance pour un joueur (§45, §09).
--- Ex : une ressource de job déclare la mission courante.
function ZShield.RegisterTrustedContext(source, key, value)
    if not ZShield.Context then return false end
    if type(key) ~= 'string' then return false end
    return ZShield.Context.set(source, key, value)
end

--- Enregistre un event protégé via le firewall (§45, §05). Façade de Firewall.register.
function ZShield.RegisterProtectedEvent(definition)
    if not ZShield.Firewall then return false, 'firewall not loaded' end
    return ZShield.Firewall.register(definition)
end

--- Enregistre un téléport de confiance (§45, §15). Le serveur déclare qu'il téléporte
--- lui-même un joueur, pour que l'analyse de mouvement ne le signale pas.
function ZShield.RegisterTrustedTeleport(source, opts)
    if not ZShield.Context then return false end
    if type(opts) ~= 'table' or type(opts.to) ~= 'table' then return false end
    return ZShield.Context.registerTeleport(source, opts)
end

--- Applique une transaction économique validée (§45, §20). Le solde est autoritaire serveur.
function ZShield.ApplyTransaction(txn)
    if not ZShield.Economy then return false, 'economy not loaded' end
    return ZShield.Economy.apply(txn)
end

--- Santé globale (§45, §50). Exposée pour les intégrations de monitoring.
function ZShield.GetHealth()
    if ZShield.Health then return ZShield.Health.report() end
    return { overall = C.HEALTH.UNKNOWN }
end

--- Instantané des protections natives (§08/§10/§21/§15/§17/§29), destiné à l'agent
--- puis au dashboard. Lecture seule, valeurs agrégées — aucun identifiant de joueur.
function ZShield.GetProtections()
    local ge = ZShield.GameEvents and ZShield.GameEvents.getStats() or {}
    local sb = ZShield.StateBag and ZShield.StateBag.getStats() or {}
    local perf = ZShield.Perf and ZShield.Perf.report() or {}
    local lockdown = (ZShield.Config and ZShield.Config.value('onesync.lockdown_mode', 'inactive')) or 'inactive'

    -- Réputation : nombre de détecteurs par état.
    local rep = { ACTIVE = 0, DEGRADED = 0, OBSERVATION = 0, DISABLED = 0 }
    if ZShield.Reputation then
        for _, m in pairs(ZShield.Reputation.report()) do
            rep[m.state] = (rep[m.state] or 0) + 1
        end
    end

    local game_blocked = (ge.expl_blocked or 0) + (ge.dmg_blocked or 0) + (ge.ent_blocked or 0)

    -- Surcoût CPU : temps critique mesuré rapporté au budget, borné à 100 %.
    local overhead = 0
    if perf.budget_ms and perf.budget_ms > 0 then
        overhead = math.min(100, (perf.critical_ms or 0) / perf.budget_ms * 100)
    end

    return {
        version = C.VERSION,
        layers = {
            game_events = { blocked = game_blocked, observed = ge.explosions and (ge.explosions + (ge.damage or 0) + (ge.entities or 0)) or 0 },
            statebag    = { blocked = sb.denied or 0, observed = sb.changes or 0 },
            orchestrator = { lockdown = lockdown },
        },
        reputation = rep,
        evidence = ZShield.Evidence and ZShield.Evidence.distribution() or {},
        performance = {
            critical_ms = perf.critical_ms or 0,
            budget_ms = perf.budget_ms or 2,
            overhead_pct = overhead,
        },
        onesync_lockdown = lockdown,
    }
end

--- Change le mode de verrouillage OneSync À CHAUD (§21). Appelé par l'agent quand
--- l'opérateur le règle depuis le dashboard. Met à jour la config courante et
--- ré-applique l'orchestrateur natif. Enum fermé : jamais de valeur arbitraire.
function ZShield.SetLockdown(mode)
    if mode ~= C.LOCKDOWN.INACTIVE and mode ~= C.LOCKDOWN.RELAXED and mode ~= C.LOCKDOWN.STRICT then
        return false, 'invalid lockdown mode'
    end
    local cfg = ZShield.Config and ZShield.Config.get()
    if cfg then
        cfg.onesync = cfg.onesync or {}
        cfg.onesync.enabled = mode ~= C.LOCKDOWN.INACTIVE
        cfg.onesync.lockdown_mode = mode
    end
    local applied = 0
    if ZShield.Orchestrator then applied = ZShield.Orchestrator.apply() end
    Log:info('api', 'lockdown mode set', { mode = mode, native_applied = applied })
    return true, applied
end

--- Reçoit une clé de licence LIVRÉE À CHAUD (par l'agent, qui la récupère du dashboard).
--- Le client n'a rien à coller : la clé est détectée automatiquement. Si elle est valide
--- et que la protection n'était pas armée, on l'arme immédiatement.
function ZShield.SetLicense(token)
    if type(token) ~= 'string' or token == '' then return false, 'MISSING' end
    if not ZShield.License then return false, 'no license module' end

    local cfg = ZShield.Config and ZShield.Config.get()
    if cfg then
        cfg.license = cfg.license or {}
        if cfg.license.key == token then
            -- Déjà appliquée : rien à refaire.
            return ZShield.licensed == true, ZShield.Bootstrap and ZShield.Bootstrap.license
                and ZShield.Bootstrap.license.state or 'VALID'
        end
        cfg.license.key = token
    end

    local r = ZShield.License.check()
    if ZShield.Bootstrap then ZShield.Bootstrap.license = r end

    if r.state == 'VALID' then
        if not ZShield.licensed then
            ZShield.licensed = true
            if ZShield.Health then
                ZShield.Health.markUp('license',
                    'valide · ' .. (r.plan or 'plan') .. ' · ' .. (r.days_left or 0) .. 'j restants')
            end
            if ZShield.Bootstrap and ZShield.Bootstrap.armProtection then
                ZShield.Bootstrap.armProtection()
            end
            Log:info('license', 'licence reçue et validée, protection activée', { plan = r.plan })
        end
        return true, r.state
    end

    Log:warn('license', 'licence reçue mais non valide', { state = r.state, reason = r.reason })
    return false, r.state
end

--- Applique les réglages de protections choisis par le client (depuis le dashboard,
--- relayés par l'agent). `list` : tableau d'entrées { id, enabled, mode } ou table
--- id -> { enabled, mode }. Retourne le nombre de réglages appliqués.
function ZShield.SetProtections(list)
    if not ZShield.Protections then return false, 'no protections module' end
    if type(list) ~= 'table' then return false, 'invalid payload' end
    local n = ZShield.Protections.set(list)
    Log:info('protections', 'réglages reçus du dashboard', { count = n })
    return true, n
end

--- Applique la liste d'interdiction (armes/véhicules) choisie depuis le dashboard.
--- `payload` : { weapons = {...}, vehicles = {...} }.
function ZShield.SetBlacklist(payload)
    if not ZShield.Blacklist then return false, 'no blacklist module' end
    if type(payload) ~= 'table' then return false, 'invalid payload' end
    local n = ZShield.Blacklist.set(payload)
    Log:info('blacklist', 'liste reçue du dashboard', { count = n })
    return true, n
end

ZShield.API = API

-- Exports FiveM (§45). Permettent à l'agent (ressource distincte) de lire les instantanés
-- sans accès à l'état interne. Enregistrés uniquement si le runtime fournit `exports`.
if type(exports) == 'function' then
    exports('GetProtections', function() return ZShield.GetProtections() end)
    exports('GetHealth', function() return ZShield.GetHealth() end)
    exports('GetVersion', function() return ZShield.GetVersion() end)
    exports('SetLockdown', function(mode) return ZShield.SetLockdown(mode) end)
    exports('SetLicense', function(token) return ZShield.SetLicense(token) end)
    exports('SetProtections', function(list) return ZShield.SetProtections(list) end)
    exports('SetBlacklist', function(payload) return ZShield.SetBlacklist(payload) end)
    -- Signaler une trace d'injection CONFIRMÉE (event fantôme, export interdit…).
    -- Ouvre un ban immédiat si le seuil de traces est atteint.
    exports('ReportTrace', function(source, kind, meta)
        if ZShield.Injection then return ZShield.Injection.report(source, kind, meta) ~= nil end
        return false
    end)
    -- Empreinte de ce serveur : l'agent peut la remonter au dashboard pour lier la licence.
    exports('GetServerIdentity', function() return ZShield.License and ZShield.License.identity() end)
    -- Observation serveur-autoritative (Multi-vue) : caméra d'administration DANS
    -- le monde du jeu, jamais une capture de l'écran/machine du joueur.
    exports('RequestSpectate', function(target, admin)
        if ZShield.Spectate then return ZShield.Spectate.request(target, admin) end
        return false, 'spectate unavailable'
    end)
    exports('StopSpectate', function(target)
        if ZShield.Spectate then return ZShield.Spectate.stop(target) end
        return false, 'spectate unavailable'
    end)
    exports('ActiveSpectates', function()
        return ZShield.Spectate and ZShield.Spectate.active() or {}
    end)
end
