--[[
    FILE:         server/clientglue.lua
    PURPOSE:      Câblage FiveM des événements réseau du module client (zshield-client)
                  vers ZShield.ClientGuard. Émet le secret de session à la connexion,
                  reçoit les rapports signés, et lance la surveillance des heartbeats.

    NB : couche FiveM (RegisterNetEvent / TriggerClientEvent) ; non testée en
    isolation. Toute la logique (signature, anti-rejeu, heartbeat, intégrité) vit
    dans server/clientguard.lua, testée à part.
]]

ZShield = ZShield or {}

function ZShield.ClientGlueAttach()
    local CG = ZShield.ClientGuard
    if not CG then return end
    if type(RegisterNetEvent) ~= 'function' then return end   -- hors FiveM (tests)

    -- 1) Handshake : le client envoie SON nonce ; le serveur renvoie les nonces
    --    publics (mode dérivé) ou, à défaut de clé de provisioning, le secret (dev).
    --    Le secret dérivé n'est JAMAIS transmis.
    RegisterNetEvent('zshield:cg:register', function(clientNonce)
        local src = source
        local hs = CG.beginHandshake(src, clientNonce)
        -- Scellé matériel : on LIE le HWID OBSERVÉ serveur (jeton FiveM, source de
        -- vérité non falsifiable par le client) à la session. Le client rapportera
        -- ensuite son propre HWID ; le serveur compare (divergence = signal). Ce
        -- même HWID sert l'anti-évasion de ban (hwid_blocklist).
        local ok, hwid = pcall(function()
            return GetPlayerToken and GetPlayerToken(src, 0) or nil
        end)
        if ok and type(hwid) == 'string' and hwid ~= '' then
            CG.bindHwid(src, hwid)
        end
        TriggerClientEvent('zshield:cg:handshake', src, hs)
    end)

    -- 2) Rapport signé du client -> vérification + ingestion.
    RegisterNetEvent('zshield:cg:report', function(msg)
        CG.ingest(source, msg)
    end)

    -- 3) Réponse d'attestation d'intégrité (défi-réponse).
    RegisterNetEvent('zshield:cg:attest', function(response)
        CG.verifyAttestation(source, response)
    end)

    -- 4) Nettoyage à la déconnexion.
    AddEventHandler('playerDropped', function()
        if source then CG.forget(source) end
    end)

    -- 5) Surveillance des heartbeats.
    CreateThread(function()
        while true do
            Wait(tonumber(ZShield.Config and ZShield.Config.value('client.heartbeat_check_ms', 15000)) or 15000)
            pcall(function() CG.checkMissing() end)
        end
    end)

    -- 6) Défis d'attestation périodiques : un défi frais par joueur, à intervalle.
    CreateThread(function()
        while true do
            Wait(tonumber(ZShield.Config and ZShield.Config.value('client.attest_interval_ms', 60000)) or 60000)
            for _, sid in ipairs(GetPlayers()) do
                local src = tonumber(sid)
                if src and CG.session(src) then
                    local ch = CG.issueChallenge(src)
                    if ch then TriggerClientEvent('zshield:cg:challenge', src, ch) end
                end
            end
        end
    end)
end

return ZShield.ClientGlueAttach
