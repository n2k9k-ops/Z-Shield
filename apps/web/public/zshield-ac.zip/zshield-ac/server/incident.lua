--[[
    FILE:         server/incident.lua
    PURPOSE:      Moteur d'incidents (§28, §29, §102, §151). Transforme un franchissement de
                  seuil de risque ou un signal fort en incident TRAÇABLE : preuve, timeline,
                  chaîne complète event → signal → corrélation → score → incident → décision.
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua, core/config.lua, core/bus
    PUBLIC API:   ZShield.Incident.open(spec) -> incident
                  ZShield.Incident.addObservation(id, observation)
                  ZShield.Incident.setDecision(id, decision)
                  ZShield.Incident.get(id) / list(filter) / forPlayer(source)
                  ZShield.Incident.attach()

    §28 : structure normative (incident_id, player, timestamp, detector, category, severity,
    confidence, risk_before, risk_after, context, observations, decision, action) + timeline.
    §29 : chaîne de preuve remontable par un admin.
    §102, §103 : 100 events identiques en 1s ne produisent PAS 100 incidents. Déduplication
    par clé + fenêtre + compteur d'occurrences.
    §151 : chaque incident référence la version de config active au moment de la détection.
    §147 : les incidents critiques sont protégés contre la modification accidentelle.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log
local Bus = ZShield.Bus

local Incident = {
    incidents = {},        -- id -> incident
    order = {},            -- ordre d'ouverture (ids)
    dedup = {},            -- clé de dédup -> { id, last_at, count }
    byPlayer = {},         -- source -> { ids }
    stats = { opened = 0, deduplicated = 0, decided = 0 },
}

-- Fenêtre de déduplication (§102). Deux incidents de même clé dans cette fenêtre sont
-- fusionnés : le second incrémente le compteur d'occurrences du premier.
local DEDUP_WINDOW_MS = 30000

-- Nombre max d'incidents conservés en mémoire. Au-delà, éviction des plus anciens
-- NON critiques (les critiques sont protégés, §147).
local MAX_INCIDENTS = 2000

--- Construit la clé de déduplication d'un incident (§102).
--- Même joueur + même détecteur + même catégorie = même anomalie.
local function dedupKey(spec)
    return string.format('%s|%s|%s',
        tostring(spec.source), tostring(spec.detector or '?'), tostring(spec.category or '?'))
end

--- Ouvre un incident, ou fusionne avec un incident récent identique (§102).
--- spec = {
---   source, detector, category, severity, confidence,
---   risk_before, risk_after,
---   context = {...},              -- état joueur au moment
---   signals = {...},              -- signaux ayant mené ici (chaîne de preuve §29)
---   correlation = {...},          -- résultat de corrélation, optionnel
---   scope = 'PLAYER'|'RESOURCE'|... (§99)
--- }
function Incident.open(spec)
    if type(spec) ~= 'table' then return nil end
    local now = Util.now()
    local key = dedupKey(spec)

    -- --- Déduplication (§102, §103) ---
    local existing = Incident.dedup[key]
    if existing and (now - existing.last_at) <= DEDUP_WINDOW_MS then
        local inc = Incident.incidents[existing.id]
        if inc then
            inc.occurrences = inc.occurrences + 1
            inc.last_seen_at = now
            existing.last_at = now
            -- La timeline note la répétition sans créer 100 entrées : une entrée
            -- "occurrence" agrégée toutes les N, pour rester lisible (§28).
            if inc.occurrences <= 5 or inc.occurrences % 25 == 0 then
                inc.timeline[#inc.timeline + 1] = {
                    at = now, kind = 'occurrence',
                    note = 'repeat #' .. inc.occurrences,
                }
            end
            -- Le risque le plus élevé observé est conservé.
            if (spec.risk_after or 0) > (inc.risk_after or 0) then
                inc.risk_after = spec.risk_after
            end
            Incident.stats.deduplicated = Incident.stats.deduplicated + 1
            return inc
        end
    end

    -- --- Nouvel incident ---
    local id = Util.uuid('inc')
    local snapshot = ZShield.Config and ZShield.Config.snapshot() or { version = 0 }

    local inc = {
        id = id,
        source = spec.source,
        detector = spec.detector,
        category = spec.category,
        severity = spec.severity,
        confidence = spec.confidence,
        scope = spec.scope or C.ANOMALY_SCOPE.PLAYER,
        risk_before = spec.risk_before,
        risk_after = spec.risk_after,
        -- §151 : version de config active figée à l'ouverture.
        config_version = snapshot.version,
        opened_at = now,
        opened_wallclock = Util.wallclock(),
        last_seen_at = now,
        occurrences = 1,
        -- Chaîne de preuve (§29) : les signaux qui ont mené ici.
        signals = Util.deepCopy(spec.signals or {}),
        correlation = Util.deepCopy(spec.correlation),
        context = Util.deepCopy(spec.context or {}),
        observations = {},
        -- Timeline (§28).
        timeline = {
            { at = now, kind = 'opened', note = 'incident opened',
              severity = spec.severity, risk = spec.risk_after },
        },
        decision = nil,   -- rempli par l'enforcement (§85)
        action = nil,
        -- §147 : les incidents CRITICAL sont protégés en écriture (verrouillés après décision).
        locked = false,
        critical = (spec.severity == C.SEVERITY.CRITICAL or spec.scope == C.ANOMALY_SCOPE.SERVER),
    }

    Incident.incidents[id] = inc
    Incident.order[#Incident.order + 1] = id
    Incident.dedup[key] = { id = id, last_at = now, count = 1 }
    Incident.byPlayer[spec.source] = Incident.byPlayer[spec.source] or {}
    table.insert(Incident.byPlayer[spec.source], id)
    Incident.stats.opened = Incident.stats.opened + 1

    Log:security('incident', 'incident opened', {
        id = id, source = spec.source, detector = spec.detector,
        severity = spec.severity, risk = spec.risk_after, config_version = snapshot.version,
    })
    Bus:emit('incident.opened', inc)

    Incident.evict()
    return inc
end

--- Éviction bornée : retire les plus anciens incidents NON critiques (§147 protège les
--- critiques, qui restent jusqu'à persistance).
function Incident.evict()
    if #Incident.order <= MAX_INCIDENTS then return end
    local toRemove = #Incident.order - MAX_INCIDENTS
    local newOrder, removed = {}, 0
    for i = 1, #Incident.order do
        local id = Incident.order[i]
        local inc = Incident.incidents[id]
        if inc and not inc.critical and removed < toRemove then
            Incident.incidents[id] = nil
            removed = removed + 1
        else
            newOrder[#newOrder + 1] = id
        end
    end
    Incident.order = newOrder
end

--- Ajoute une observation à un incident (§28). Refusé si l'incident est verrouillé (§147).
function Incident.addObservation(id, observation)
    local inc = Incident.incidents[id]
    if not inc then return false, 'not found' end
    if inc.locked then
        Log:warn('incident', 'observation refused: incident locked', { id = id })
        return false, 'locked'
    end
    inc.observations[#inc.observations + 1] = {
        at = Util.now(), note = tostring(observation.note or observation),
        data = observation.data,
    }
    inc.timeline[#inc.timeline + 1] = { at = Util.now(), kind = 'observation', note = observation.note or tostring(observation) }
    return true
end

--- Enregistre la décision/action prise (§85 : explicabilité). Verrouille les incidents
--- critiques une fois décidés (§147).
function Incident.setDecision(id, decision)
    local inc = Incident.incidents[id]
    if not inc then return false, 'not found' end
    if inc.locked then return false, 'locked' end

    inc.decision = {
        action = decision.action,
        policy = decision.policy,       -- §85 : quelle politique a mené à la décision
        reason = decision.reason,
        confidence = decision.confidence,
        threshold = decision.threshold,
        decided_at = Util.now(),
        decided_by = decision.by or 'system',
    }
    inc.action = decision.action
    inc.timeline[#inc.timeline + 1] = {
        at = Util.now(), kind = 'decision',
        note = decision.action, reason = decision.reason,
    }
    Incident.stats.decided = Incident.stats.decided + 1

    -- §147 : un incident critique décidé est verrouillé (protection contre modif accidentelle).
    if inc.critical then
        inc.locked = true
    end

    Log:security('incident', 'decision recorded', {
        id = id, action = decision.action, policy = decision.policy, reason = decision.reason,
    })
    Bus:emit('incident.decided', inc)
    return true
end

--- Chaîne de preuve complète d'un incident (§29). Un admin remonte : signaux -> corrélation
--- -> score -> incident -> décision, avec la version de config active.
function Incident.evidenceChain(id)
    local inc = Incident.incidents[id]
    if not inc then return nil end
    return {
        incident_id = inc.id,
        player = inc.source,
        config_version = inc.config_version,          -- §151
        detector = inc.detector,
        category = inc.category,
        severity = inc.severity,
        confidence = inc.confidence,
        risk_before = inc.risk_before,
        risk_after = inc.risk_after,
        occurrences = inc.occurrences,
        signals = inc.signals,                        -- §29 étape signal
        correlation = inc.correlation,                -- §29 étape corrélation
        context = inc.context,
        observations = inc.observations,
        timeline = inc.timeline,                      -- §28
        decision = inc.decision,                      -- §85
    }
end

function Incident.get(id)
    return Incident.incidents[id]
end

function Incident.forPlayer(source)
    local ids = Incident.byPlayer[source] or {}
    local out = {}
    for _, id in ipairs(ids) do
        if Incident.incidents[id] then out[#out + 1] = Incident.incidents[id] end
    end
    return out
end

--- Liste filtrée (§124, §125). filter = { severity, scope, decided, min_risk }.
function Incident.list(filter)
    filter = filter or {}
    local out = {}
    for i = 1, #Incident.order do
        local inc = Incident.incidents[Incident.order[i]]
        if inc then
            local keep = true
            if filter.severity and inc.severity ~= filter.severity then keep = false end
            if filter.scope and inc.scope ~= filter.scope then keep = false end
            if filter.decided ~= nil and (inc.decision ~= nil) ~= filter.decided then keep = false end
            if filter.min_risk and (inc.risk_after or 0) < filter.min_risk then keep = false end
            if keep then out[#out + 1] = inc end
        end
    end
    return out
end

function Incident.getStats()
    return Util.deepCopy(Incident.stats)
end

--- Nettoyage au départ d'un joueur (§110) : on ne retire PAS les incidents (preuve), on
--- retire seulement l'index transitoire.
function Incident.onPlayerDrop(source)
    -- Les incidents restent (chaîne de preuve). Rien à supprimer ici.
end

-- ---------------------------------------------------------------------------
-- Ouverture automatique sur changement de niveau de risque (§13 -> §28).
-- Quand un joueur franchit vers HIGH_RISK ou CRITICAL, on ouvre un incident avec
-- la chaîne de preuve disponible.
-- ---------------------------------------------------------------------------
function Incident.attach()
    Bus:on('risk.level_changed', function(payload)
        local level = payload.to
        if level ~= C.RISK_LEVEL.HIGH_RISK and level ~= C.RISK_LEVEL.CRITICAL then
            return
        end
        local source = payload.source
        local signal = payload.signal or {}

        -- Récupérer la corrélation courante si le module est présent (chaîne de preuve).
        local correlation
        if ZShield.Correlation then
            correlation = ZShield.Correlation.correlate(source)
        end
        local context
        if ZShield.Context then
            local ctx = ZShield.Context.get(source)
            if ctx then context = { state = ctx.state, state_since = ctx.state_since } end
        end

        Incident.open({
            source = source,
            detector = signal.detector or 'risk.threshold',
            category = signal.category or C.CATEGORY.STATE,
            severity = (level == C.RISK_LEVEL.CRITICAL) and C.SEVERITY.CRITICAL or C.SEVERITY.HIGH,
            confidence = signal.confidence,
            risk_before = nil,
            risk_after = payload.score,
            signals = correlation and correlation.signals or { signal },
            correlation = correlation,
            context = context,
        })
    end)
end

ZShield.Incident = Incident
