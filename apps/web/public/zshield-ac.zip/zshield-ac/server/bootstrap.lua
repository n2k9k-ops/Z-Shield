--[[
    FILE:         server/bootstrap.lua
    PURPOSE:      Séquence de démarrage (§107), d'arrêt (§108) et de branchement FiveM.
                  Câble tous les moteurs entre eux via le bus, branche les handlers d'events
                  serveur, expose les commandes console, et démarre l'auto-surveillance.
    DEPENDENCIES: tous les modules (chargés avant par le fxmanifest)
    PUBLIC API:   ZShield.Bootstrap.start(rawConfig) -> ok
                  ZShield.Bootstrap.stop()

    §107 : load config -> validate -> load database -> check schema -> load rules ->
    load adapters -> init detectors -> init dashboard -> init integrations -> health check.
    §108 : arrêt propre — stop new work, flush queues, save state, close.
    §109 : redémarrage sans perdre la cohérence.
    §110 : nettoyage au départ d'un joueur.

    Ce fichier est le SEUL à toucher les natives FiveM de branchement (AddEventHandler,
    RegisterCommand). Les moteurs restent purs et testables ; le bootstrap les relie au monde.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Log = ZShield.Log
local Util = ZShield.Util

local Bootstrap = { started = false }

-- ---------------------------------------------------------------------------
-- Démarrage (§107)
-- ---------------------------------------------------------------------------
function Bootstrap.start(rawConfig)
    if Bootstrap.started then return true end
    Log:info('bootstrap', 'starting ZShield AC', { version = C.VERSION })

    -- 1. Charger et valider la config (§49, §107).
    local ok, cfgOrErr = ZShield.Config.load(rawConfig)
    if not ok then
        Log:critical('bootstrap', 'configuration invalid, refusing to start', { error = cfgOrErr })
        ZShield.Health.set('configuration', C.HEALTH.FAILED, cfgOrErr)
        return false
    end
    ZShield.Health.markUp('configuration', 'loaded, mode=' .. cfgOrErr.mode)

    -- 1b. LICENCE. Vérifiée AVANT de câbler la protection. Sans licence valide, la
    -- protection n'est pas activée et un message clair s'affiche au démarrage.
    local lic = ZShield.License and ZShield.License.check() or { state = 'VALID' }
    Bootstrap.license = lic
    ZShield.licensed = (lic.state == 'VALID')

    -- Affiche l'empreinte de CE serveur : c'est ce que le client communique au vendeur
    -- pour obtenir une licence liée à son serveur (impossible à réutiliser ailleurs).
    if ZShield.License and type(print) == 'function' then
        print('[Z-Shield] Identifiant de ce serveur : ' .. ZShield.License.identity())
    end

    -- Avertissement anti-vol : un secret de signature par défaut = licences forgeables.
    if ZShield.License and ZShield.License.usingDefaultSecret and ZShield.License.usingDefaultSecret() then
        Log:warn('license', 'SECRET de licence par défaut — définissez `set zshield_license_secret "..."` (voir docs/PROTECTION.md)')
        if type(print) == 'function' then
            print('[Z-Shield] ATTENTION : secret de licence par défaut. Définissez `set zshield_license_secret "<votre secret>"` dans server.cfg (identique au dashboard).')
        end
    end

    local banner = ZShield.License and ZShield.License.banner(lic)
    if banner then
        for _, l in ipairs(banner) do
            Log:warn('license', l)
            if type(print) == 'function' then print('[Z-Shield] ' .. l) end
        end
    end

    Bootstrap.started = true            -- la ressource est chargée dans tous les cas
    Bootstrap.armed = false             -- un (re)démarrage ré-arme proprement

    if not ZShield.licensed then
        Log:critical('license', 'protection NON activée', { state = lic.state, reason = lic.reason })
        ZShield.Health.set('license', C.HEALTH.FAILED, lic.reason or lic.state)
        -- La protection n'est PAS armée. Le rappel re-vérifie et arme dès qu'une
        -- licence valide arrive (ex : livrée automatiquement par l'agent).
        Bootstrap.startLicenseReminder()
        ZShield.Bus:emit('zshield.unlicensed', { state = lic.state })
        return true
    end

    ZShield.Health.markUp('license',
        'valide · ' .. (lic.plan or 'plan') .. ' · ' .. (lic.days_left or 0) .. 'j restants')
    Bootstrap.armProtection(cfgOrErr)
    return true
end

-- Arme TOUTES les couches de protection. Idempotent : ne s'exécute qu'une fois.
-- Appelable au démarrage (licence déjà valide) OU à chaud quand une licence valide
-- est reçue plus tard (livraison automatique par l'agent).
function Bootstrap.armProtection(cfg)
    if Bootstrap.armed then return end
    Bootstrap.armed = true
    cfg = cfg or ZShield.Config.get()

    -- 2. Câbler les moteurs entre eux via le bus (§106). L'ordre respecte les dépendances.
    if ZShield.Correlation then ZShield.Correlation.attach(); ZShield.Health.markUp('correlation') end
    if ZShield.Risk then ZShield.Risk.attach(); ZShield.Health.markUp('risk') end
    if ZShield.Evidence then ZShield.Evidence.attach(); ZShield.Health.markUp('evidence') end
    if ZShield.Incident then ZShield.Incident.attach(); ZShield.Health.markUp('incidents') end
    if ZShield.Enforcement then ZShield.Enforcement.attach(); ZShield.Health.markUp('enforcement') end
    ZShield.Health.markUp('event_firewall')
    ZShield.Health.markUp('detectors')

    -- 3. Persistance (§37).
    if ZShield.Store then ZShield.Store.configure(); ZShield.Health.markUp('storage', 'ready') end

    -- 3b. Moteur de performance (§29).
    if ZShield.Perf then
        ZShield.Perf.configure({
            enabled = ZShield.Config.value('performance.enabled', true),
            budget_ms = ZShield.Config.value('performance.budget_ms', 2.0),
        })
        ZShield.Health.markUp('performance')
    end

    -- 4. Détecteurs métier livrés.
    if ZShield.Movement then ZShield.Movement.register() end
    if ZShield.Entity then ZShield.Entity.registerDetector() end
    if ZShield.Economy then ZShield.Economy.registerDetector() end
    if ZShield.Health2 then ZShield.Health2.register() end
    if ZShield.Vehicle then ZShield.Vehicle.register() end

    -- 4c. Couches natives event-driven (§08, §10, §21).
    if ZShield.Orchestrator then
        local n = ZShield.Orchestrator.apply()
        ZShield.Health.markUp('orchestrator', n .. ' native protection(s)')
    end
    if ZShield.GameEvents then ZShield.GameEvents.attach(); ZShield.Health.markUp('game_firewall') end
    if ZShield.StateBag then ZShield.StateBag.attach(); ZShield.Health.markUp('statebag_firewall') end

    -- 4b. Intégrations sortantes (§39).
    if ZShield.Discord then
        ZShield.Discord.configure({ enabled = ZShield.Config.value('integrations.discord_enabled') == true })
        ZShield.Discord.attach()
        ZShield.Health.markUp('discord', ZShield.Discord.enabled and 'enabled' or 'disabled')
    end

    -- 4d. Pont incident -> alerte plateforme (propositions de sanction). Le sink
    -- réel envoie l'alerte à l'agent (ressource distincte) via export ; absent
    -- en test (pas d'exports FiveM), auquel cas le reporter ne fait rien.
    -- Module client (corrélation + heartbeat signé + intégrité). Silencieux hors FiveM.
    if ZShield.ClientGlueAttach then
        pcall(ZShield.ClientGlueAttach)
        ZShield.Health.markUp('clientguard')
    end

    -- Couche serveur-autoritative (vagues 1→6) : enregistrement des moteurs, routage des
    -- signaux (corrélation + réputation), auto-protection, exports d'intégration.
    if ZShield.AuthoritativeGlueAttach then
        pcall(ZShield.AuthoritativeGlueAttach)
        ZShield.Health.markUp('authoritative_glue')
    end

    -- Câblage des événements natifs FiveM -> répartiteur pur (dispatch).
    if ZShield.EventWiringAttach then
        pcall(ZShield.EventWiringAttach)
        ZShield.Health.markUp('event_wiring')
    end

    if ZShield.Reporter then
        ZShield.Reporter.attach()
        pcall(function()
            if exports and exports['zshield-agent'] then
                ZShield.Reporter.setSink(function(alert)
                    exports['zshield-agent']:SendSecurityAlert(alert)
                end)
            end
        end)
        ZShield.Health.markUp('reporter')
    end

    -- 5-6. Handlers FiveM + boucles périodiques.
    Bootstrap.wireFivem()
    Bootstrap.startLoops()

    -- 7. Health check final (§107).
    local report = ZShield.Health.selfCheck()
    Log:info('bootstrap', 'protection armed', { overall = report.overall,
        mode = (cfg and cfg.mode) or ZShield.Config.value('mode') })
    ZShield.Bus:emit('zshield.started', { version = C.VERSION, mode = (cfg and cfg.mode) })
    return true
end

-- Branche les events serveur FiveM. Ne s'exécute que si les natives existent (pas en test).
function Bootstrap.wireFivem()
    if type(AddEventHandler) ~= 'function' then return end

    -- Cycle de vie joueur -> machine à états (§08) et nettoyage (§110).
    AddEventHandler('playerConnecting', function()
        local src = source
        if src then ZShield.Context.init(src) end
    end)

    AddEventHandler('playerJoining', function()
        local src = source
        if src and ZShield.Context.exists(src) then
            ZShield.Context.forceState(src, C.PLAYER_STATE.CONNECTED)
        end
    end)

    AddEventHandler('playerDropped', function()
        local src = source
        if not src then return end
        -- Nettoyage transitoire (§110), on garde les preuves.
        if ZShield.Context then ZShield.Context.drop(src) end
        if ZShield.Entity then ZShield.Entity.onPlayerDrop(src) end
        if ZShield.Economy then ZShield.Economy.onPlayerDrop(src) end
        if ZShield.Risk then ZShield.Risk.clear(src) end
        if ZShield.Correlation then ZShield.Correlation.clear(src) end
    end)

    -- Note : entityCreating / explosionEvent / weaponDamageEvent sont branchés par le
    -- Game Event Firewall (server/firewall/gameevents.lua), qui peut annuler à la source.

    Log:debug('bootstrap', 'FiveM handlers wired')
end

-- Rappel périodique quand la protection est désactivée faute de licence valide.
-- Le message revient régulièrement dans la console pour que l'opérateur ne l'ignore pas.
function Bootstrap.startLicenseReminder()
    if type(CreateThread) ~= 'function' then return end
    CreateThread(function()
        while Bootstrap.started and not ZShield.licensed do
            -- Re-vérifie : une licence valide a pu arriver entre-temps (agent).
            local r = ZShield.License.check()
            if r.state == 'VALID' then
                ZShield.licensed = true
                ZShield.Health.markUp('license',
                    'valide · ' .. (r.plan or 'plan') .. ' · ' .. (r.days_left or 0) .. 'j restants')
                Bootstrap.armProtection()
                Log:info('license', 'licence valide détectée, protection activée', { plan = r.plan })
                break
            end
            local banner = ZShield.License.banner(r)
            if banner then
                for _, l in ipairs(banner) do
                    if type(print) == 'function' then print('[Z-Shield] ' .. l) end
                end
            end
            Wait(300000) -- toutes les 5 minutes
        end
    end)
end

-- Boucles périodiques. En test, CreateThread est un stub qui n'exécute pas de boucle.
function Bootstrap.startLoops()
    if type(CreateThread) ~= 'function' then return end

    -- Flush de l'event store (§36 : par lots, pas par frame).
    CreateThread(function()
        local interval = (ZShield.Config.value('persistence.flush_interval_ms')) or 5000
        while Bootstrap.started do
            if ZShield.Store then
                pcall(ZShield.Store.drain, 10)
            end
            Wait(interval)
        end
    end)

    -- Auto-surveillance (§51).
    CreateThread(function()
        while Bootstrap.started do
            pcall(ZShield.Health.selfCheck)
            Wait(15000)
        end
    end)

    -- Envoi Discord (§120) : par lots, hors chemin critique. Une panne Discord ne
    -- ralentit jamais la sécurité (§38).
    if ZShield.Discord then
        CreateThread(function()
            while Bootstrap.started do
                pcall(ZShield.Discord.pump)
                Wait(2000)
            end
        end)
    end
end

-- ---------------------------------------------------------------------------
-- Arrêt propre (§108)
-- ---------------------------------------------------------------------------
function Bootstrap.stop()
    if not Bootstrap.started then return end
    Log:info('bootstrap', 'stopping ZShield AC')

    Bootstrap.started = false -- stoppe les boucles

    -- Vider les files vers la persistance autant que possible (§108).
    if ZShield.Store then
        pcall(ZShield.Store.drain, 50)
        local remaining = ZShield.Store.size()
        if remaining > 0 then
            Log:warn('bootstrap', 'events remaining in queue at shutdown', { count = remaining })
        end
    end

    ZShield.Bus:emit('zshield.stopped', {})
    Log:info('bootstrap', 'stopped')
end

-- ---------------------------------------------------------------------------
-- Commandes console (§158). Enregistrées uniquement si le runtime les fournit.
-- ---------------------------------------------------------------------------
function Bootstrap.registerCommands()
    if type(RegisterCommand) ~= 'function' then return end

    RegisterCommand('zshield', function(source, args)
        -- Restreint : commande serveur/console uniquement (§118).
        local sub = args[1] or 'status'
        if sub == 'health' then
            for _, line in ipairs(ZShield.Health.lines()) do print(line) end
        elseif sub == 'version' then
            print('ZShield AC v' .. C.VERSION)
        elseif sub == 'status' then
            local r = ZShield.Health.report()
            print(string.format('ZShield AC v%s — %s (mode %s)',
                C.VERSION, r.overall, ZShield.Config.value('mode')))
        elseif sub == 'diagnostics' then
            -- Rapport sans secrets (§159).
            print(Log.encode(ZShield.Health.selfCheck()))
        elseif sub == 'audit' then
            -- Audit de durcissement FXServer (§73).
            if ZShield.Hardening then
                for _, line in ipairs(ZShield.Hardening.lines()) do print(line) end
            else
                print('hardening module not loaded')
            end
        else
            print('usage: zshield <status|health|version|diagnostics|audit>')
        end
    end, true) -- restricted = true

    Log:debug('bootstrap', 'console commands registered')
end

ZShield.Bootstrap = Bootstrap
