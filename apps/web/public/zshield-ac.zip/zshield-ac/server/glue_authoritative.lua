--[[
    FILE:         server/glue_authoritative.lua
    PURPOSE:      Câblage FiveM des moteurs des vagues 1→6 : enregistrement auprès du moteur de
                  détection, ROUTAGE des signaux (bus + corrélation trainer + réputation
                  persistante), AUTO-PROTECTION (onResourceStopping), nettoyage à la déconnexion,
                  watchdog du cœur, et SURFACE D'EXPORTS pour que les ressources du serveur
                  alimentent l'anticheat (réconciliation, invariants, enveloppes, actions).

    NB : couche FiveM (RegisterNetEvent / AddEventHandler / exports) — non testée en isolation.
    Toute la LOGIQUE vit dans les modules purs, testés à part. Silencieux hors FXServer.

    PUBLIC API:   ZShield.AuthoritativeGlueAttach()
]]

ZShield = ZShield or {}

-- Route un signal partiel vers : le bus de détection, la corrélation « trainer », et la
-- réputation persistante (par identifiant stable). Point d'entrée unique de tous les moteurs.
function ZShield.RouteSignal(sig)
    if type(sig) ~= 'table' then return end
    -- 1) Bus de détection (corrélation/risque/incident en aval).
    if ZShield.Detection and ZShield.Detection.emit then pcall(ZShield.Detection.emit, sig) end
    -- 2) Corrélation méta « signature de menu ».
    if ZShield.Trainer and ZShield.Trainer.observeSignal and sig.source then
        local meta = ZShield.Trainer.observeSignal(sig.source, {
            detector = sig.detector, severity = sig.severity, now = (ZShield.Util and ZShield.Util.now()) })
        if meta and ZShield.Detection and ZShield.Detection.emit then pcall(ZShield.Detection.emit, meta) end
    end
    -- 3) Réputation persistante : un signal sérieux alourdit la réputation de l'identité.
    if ZShield.Reputation and ZShield.Reputation.add and sig.source and ZShield.Context then
        local ctx = ZShield.Context.get and ZShield.Context.get(sig.source)
        local id = ctx and (ctx.identifier or ctx.license)
        if id then
            local weight = (ZShield.Const and ({ LOW = 2, MEDIUM = 5, HIGH = 12, CRITICAL = 25 })[sig.severity]) or 5
            pcall(ZShield.Reputation.add, id, weight)
        end
    end
end

function ZShield.AuthoritativeGlueAttach()
    -- Enregistrement des moteurs auprès du bus (sans effet hors moteur présent).
    for _, name in ipairs({
        'Aimstats', 'Flight', 'DamageIntegrity', 'Provenance', 'Freecam', 'Sequence', 'Desync',
        'Budget', 'Esp', 'Reach', 'Godmode', 'Ownership', 'Trainer', 'Behavior', 'SpawnProtect',
        'ChatSpam', 'Teleport', 'SelfProtect', 'Executor', 'Menu', 'CrashGuard', 'Invariants', 'Envelope',
        'Sprt', 'Baseline', 'HitReg', 'Fusion', 'Markov', 'ClockSync',
    }) do
        local m = ZShield[name]
        if m and m.register then pcall(m.register) end
    end

    if type(RegisterNetEvent) ~= 'function' then return end   -- hors FiveM (tests)

    -- AUTO-PROTECTION : bloque l'arrêt d'une ressource protégée par une source non autorisée.
    AddEventHandler('onResourceStopping', function(res)
        if not (ZShield.SelfProtect and ZShield.SelfProtect.observeResourceStop) then return end
        local by = nil   -- en prod : identité de l'appelant si disponible
        local r = ZShield.SelfProtect.observeResourceStop(res, by)
        if r and r.block then
            if r.signal then ZShield.RouteSignal(r.signal) end
            if type(CancelEvent) == 'function' then CancelEvent() end
        end
    end)

    -- ANTI-BYPASS : un client émettant un event interne réservé.
    if type(AddEventHandler) == 'function' then
        AddEventHandler('__cfx_internal:commandFallback', function() end)   -- no-op garde-place
    end

    -- Nettoyage à la déconnexion : on oublie tous les états par joueur.
    AddEventHandler('playerDropped', function()
        local src = source
        if not src then return end
        for _, name in ipairs({ 'Aimstats', 'Flight', 'DamageIntegrity', 'Provenance', 'Freecam',
            'Sequence', 'Desync', 'Budget', 'Esp', 'Ownership', 'ChatSpam', 'Teleport', 'Menu',
            'Behavior', 'Reconcile', 'Envelope', 'Sprt', 'Baseline', 'HitReg', 'Markov', 'ClockSync', 'Fusion' }) do
            local m = ZShield[name]
            if m and m.forget then pcall(m.forget, src) end
        end
    end)

    -- Watchdog du cœur : bat régulièrement ; l'agent constate l'arrêt si les battements cessent.
    CreateThread(function()
        while true do
            Wait(5000)
            if ZShield.SelfProtect and ZShield.SelfProtect.ping then pcall(ZShield.SelfProtect.ping) end
        end
    end)
end

--[[
    SURFACE D'EXPORTS (intégration serveur). Les ressources du serveur appellent ces exports
    pour alimenter l'anticheat en vérité et en actions. Exemples :
      exports['zshield-ac']:ZS_Spawn(src, {health=200, money=500})
      exports['zshield-ac']:ZS_Damage(src, 40)          -- transition serveur
      exports['zshield-ac']:ZS_GrantMoney(src, 500)     -- source légitime (shop/paie)
      exports['zshield-ac']:ZS_ReportHealth(src, clientHealth)  -> renvoie la valeur corrigée
      exports['zshield-ac']:ZS_Action(src, 'fire')      -- alimente l'enveloppe de débit
]]
if type(exports) ~= 'nil' and type(_G) == 'table' then
    local function reg(name, fn) if type(exports) == 'table' or type(exports) == 'function' then pcall(function() exports(name, fn) end) end end
    reg('ZS_Spawn', function(src, base) if ZShield.Reconcile then ZShield.Reconcile.spawn(src, base) end end)
    reg('ZS_Damage', function(src, n) if ZShield.Reconcile then ZShield.Reconcile.applyDamage(src, n) end end)
    reg('ZS_Heal', function(src, n) if ZShield.Reconcile then ZShield.Reconcile.grantHeal(src, n) end end)
    reg('ZS_GrantMoney', function(src, n)
        if ZShield.Reconcile then ZShield.Reconcile.grantMoney(src, n) end
        if ZShield.Provenance then ZShield.Provenance.registerSource(src, { kind = 'money', amount = n }) end
    end)
    reg('ZS_GrantAmmo', function(src, w, n) if ZShield.Reconcile then ZShield.Reconcile.grantAmmo(src, w, n) end end)
    reg('ZS_ReportHealth', function(src, v)
        if not ZShield.Reconcile then return v end
        local r = ZShield.Reconcile.report(src, 'health', v)
        if not r.ok and r.signal then ZShield.RouteSignal(r.signal) end
        return r.corrected
    end)
    reg('ZS_ReportMoney', function(src, v)
        if not ZShield.Reconcile then return v end
        local r = ZShield.Reconcile.report(src, 'money', v)
        if not r.ok and r.signal then ZShield.RouteSignal(r.signal) end
        return r.corrected
    end)
    reg('ZS_Action', function(src, class)
        if ZShield.Envelope then
            local r = ZShield.Envelope.observe(src, class)
            if r and r.over and r.signal then ZShield.RouteSignal(r.signal) end
            return r ~= nil and r.over or false
        end
        return false
    end)
    reg('ZS_CheckInvariants', function(src, snap)
        if not ZShield.Invariants then return end
        for _, v in ipairs(ZShield.Invariants.check(src, snap)) do ZShield.RouteSignal(v) end
    end)
end

return ZShield.AuthoritativeGlueAttach
