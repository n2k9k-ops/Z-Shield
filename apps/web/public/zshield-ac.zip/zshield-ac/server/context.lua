--[[
    FILE:         server/context.lua
    PURPOSE:      Moteur de contexte joueur (§08, §09) : machine à états gardée, données de
                  contexte (mission, véhicule, zone, permissions, actions récentes) et
                  registre des téléportations de confiance (§15).
    DEPENDENCIES: shared/constants.lua, core/util.lua, core/log.lua, core/config.lua
    PUBLIC API:   ZShield.Context.init(source) / drop(source)
                  ZShield.Context.get(source) -> ctx | nil
                  ZShield.Context.transition(source, newState) -> ok, reason
                  ZShield.Context.set(source, key, value)
                  ZShield.Context.isValidState(source, allowedStates) -> boolean
                  ZShield.Context.registerTeleport(source, opts) -> §15
                  ZShield.Context.consumeTeleport(source) -> teleportContext | nil

    §08 : une action valide en MISSION peut être invalide en DEAD. Le contexte permet aux
    events de déclarer les états autorisés (utilisé par le firewall).
    §15 : le serveur enregistre lui-même les téléports légitimes ; un saut de position qui
    correspond à un téléport enregistré n'est pas une anomalie.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util
local Log = ZShield.Log

local Context = { players = {} }

-- Fenêtre de validité d'un téléport enregistré. Au-delà, il est ignoré : un
-- téléport « de confiance » ne doit pas couvrir un saut survenant 10 minutes plus tard.
local TELEPORT_TTL_MS = 5000

-- Nombre d'actions récentes conservées par joueur (pour la corrélation).
local RECENT_ACTIONS = 32

function Context.init(source)
    Context.players[source] = {
        source = source,
        state = C.PLAYER_STATE.CONNECTING,
        state_since = Util.now(),
        connected_at = Util.wallclock(),
        data = {},              -- mission, vehicle, zone, permissions, routing_bucket…
        recent_actions = {},    -- file circulaire des dernières actions
        pending_teleport = nil, -- téléport de confiance en attente (§15)
        last_position = nil,    -- dernière position connue (reconstruite serveur)
        last_position_at = nil,
    }
    return Context.players[source]
end

function Context.drop(source)
    -- §110 : au départ d'un joueur, on nettoie le contexte transitoire.
    Context.players[source] = nil
end

function Context.get(source)
    return Context.players[source]
end

function Context.exists(source)
    return Context.players[source] ~= nil
end

--- Transition d'état gardée (§08). Retourne ok, reason.
--- Une transition non autorisée est refusée ET signalée : passer de DEAD à ACTIVE sans
--- RESPAWN est en soi un signal exploitable par la détection.
function Context.transition(source, newState)
    local ctx = Context.players[source]
    if not ctx then return false, 'no context' end

    if not C.PLAYER_STATE[newState] and not _isKnownState(newState) then
        return false, 'unknown state ' .. tostring(newState)
    end

    local allowed = C.STATE_TRANSITIONS[ctx.state]
    if not allowed or not allowed[newState] then
        Log:security('context', 'invalid state transition', {
            source = source, from = ctx.state, to = newState,
        })
        return false, string.format('transition %s -> %s not allowed', ctx.state, newState)
    end

    ctx.state = newState
    ctx.state_since = Util.now()
    return true
end

function _isKnownState(state)
    for _, v in pairs(C.PLAYER_STATE) do if v == state then return true end end
    return false
end

--- Force un état sans vérifier la transition. RÉSERVÉ aux évènements serveur de confiance
--- (connexion, déconnexion) où l'état est imposé par le runtime, pas par le client.
function Context.forceState(source, newState)
    local ctx = Context.players[source]
    if not ctx then return false end
    ctx.state = newState
    ctx.state_since = Util.now()
    return true
end

function Context.set(source, key, value)
    local ctx = Context.players[source]
    if not ctx then return false end
    ctx.data[key] = value
    return true
end

function Context.value(source, key)
    local ctx = Context.players[source]
    return ctx and ctx.data[key] or nil
end

--- Un event peut déclarer les états dans lesquels il est valide. Cette aide dit si le
--- joueur est dans l'un d'eux.
function Context.isValidState(source, allowedStates)
    local ctx = Context.players[source]
    if not ctx then return false end
    if not allowedStates then return true end -- pas de restriction
    for i = 1, #allowedStates do
        if allowedStates[i] == ctx.state then return true end
    end
    return false
end

--- Journalise une action dans l'historique récent (pour la corrélation temporelle).
function Context.pushAction(source, action)
    local ctx = Context.players[source]
    if not ctx then return end
    local ra = ctx.recent_actions
    ra[#ra + 1] = { action = action, at = Util.now() }
    -- File bornée : on retire les plus anciennes.
    while #ra > RECENT_ACTIONS do table.remove(ra, 1) end
end

function Context.recentActions(source)
    local ctx = Context.players[source]
    return ctx and ctx.recent_actions or {}
end

-- ---------------------------------------------------------------------------
-- Téléports de confiance — §15
-- Le serveur, lorsqu'il téléporte lui-même un joueur (admin, mission, garage),
-- enregistre le déplacement attendu. L'analyse de mouvement consomme ensuite ce
-- contexte : un saut correspondant n'est pas une anomalie.
-- ---------------------------------------------------------------------------

--- opts = { to = vector3, reason = string, radius = number? }
function Context.registerTeleport(source, opts)
    local ctx = Context.players[source]
    if not ctx then return false end
    ctx.pending_teleport = {
        to = opts.to,
        reason = opts.reason or 'server',
        radius = opts.radius or 50.0, -- tolérance autour de la destination
        at = Util.now(),
    }
    Log:debug('context', 'trusted teleport registered', {
        source = source, reason = ctx.pending_teleport.reason,
    })
    return true
end

--- Consomme le téléport en attente s'il est encore valide (dans la fenêtre TTL).
--- Retourne le contexte de téléport, ou nil.
function Context.consumeTeleport(source)
    local ctx = Context.players[source]
    if not ctx or not ctx.pending_teleport then return nil end
    local tp = ctx.pending_teleport
    if Util.now() - tp.at > TELEPORT_TTL_MS then
        ctx.pending_teleport = nil -- expiré
        return nil
    end
    ctx.pending_teleport = nil
    return tp
end

--- Met à jour la dernière position connue (reconstruite côté serveur, jamais crue du client
--- sans validation). Utilisé par l'analyse de mouvement.
function Context.updatePosition(source, position)
    local ctx = Context.players[source]
    if not ctx then return end
    ctx.last_position = position
    ctx.last_position_at = Util.now()
end

function Context.count()
    return Util.count(Context.players)
end

ZShield.Context = Context
