--[[
    FILE:         server/adapters/framework.lua
    PURPOSE:      Abstraction de framework (§46). Le moteur de sécurité ne dépend d'AUCUN
                  framework directement. Les adaptateurs (standalone/ESX/QBCore/Qbox)
                  fournissent une interface uniforme pour lire l'argent, les permissions,
                  le job — toujours côté serveur (§68).
    DEPENDENCIES: shared/constants.lua, core/log.lua
    PUBLIC API:   ZShield.Framework.register(name, adapter)
                  ZShield.Framework.use(name) -> ok, err
                  ZShield.Framework.active() -> adapter
                  ZShield.Framework.detect() -> name   (auto-détection)

    §46 : le moteur ne doit pas dépendre d'un framework. Un adaptateur implémente :
      getMoney(source) -> number        (solde serveur, jamais la valeur client)
      getJob(source) -> string
      isAdmin(source) -> boolean         (permission calculée serveur, §04)
      getIdentifier(source) -> string
    Toutes les méthodes sont OPTIONNELLES : l'adaptateur standalone renvoie nil/false, et le
    core dégrade proprement (§104) — il ne PLANTE jamais faute d'un framework.

    §69 : avant d'utiliser une native/export d'un framework, vérifier qu'il existe. Un
    adaptateur ne suppose jamais qu'un export est présent.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Log = ZShield.Log

local Framework = {
    adapters = {},
    activeName = nil,
    activeAdapter = nil,
}

-- Adaptateur standalone : aucune dépendance. Renvoie des valeurs neutres. C'est le repli
-- sûr (§46 : "Si le framework est inconnu, compatibility = standalone").
local STANDALONE = {
    name = 'standalone',
    getMoney = function() return nil end,       -- inconnu : le module économie du core fait autorité
    getJob = function() return nil end,
    isAdmin = function() return false end,       -- par défaut personne n'est admin sans framework
    getIdentifier = function(source)
        -- Repli : premier identifiant licence via la native standard, si disponible.
        if type(GetPlayerIdentifiers) == 'function' and source then
            for _, id in ipairs(GetPlayerIdentifiers(source)) do
                if id:sub(1, 8) == 'license:' then return id end
            end
        end
        return nil
    end,
}

function Framework.register(name, adapter)
    if type(name) ~= 'string' or type(adapter) ~= 'table' then
        return false, 'adapter requires a name and a table'
    end
    adapter.name = name
    Framework.adapters[name] = adapter
    Log:debug('framework', 'adapter registered', { name = name })
    return true
end

--- Sélectionne un adaptateur. Retourne ok, err.
function Framework.use(name)
    local adapter = Framework.adapters[name]
    if not adapter then
        return false, 'unknown adapter: ' .. tostring(name)
    end
    Framework.activeName = name
    Framework.activeAdapter = adapter
    Log:info('framework', 'active framework adapter', { name = name })
    return true
end

function Framework.active()
    return Framework.activeAdapter or STANDALONE
end

function Framework.activeName_()
    return Framework.activeName or 'standalone'
end

--- Auto-détection (§46). Vérifie la présence de ressources framework connues, sans supposer.
--- Ne devine JAMAIS : si rien n'est trouvé, retombe sur standalone (§46).
function Framework.detect()
    -- GetResourceState est la native standard ; si absente (test), on reste standalone.
    if type(GetResourceState) ~= 'function' then
        return 'standalone'
    end
    local candidates = {
        { resource = 'es_extended', adapter = 'esx' },
        { resource = 'qb-core', adapter = 'qbcore' },
        { resource = 'qbx_core', adapter = 'qbox' },
    }
    for _, c in ipairs(candidates) do
        if GetResourceState(c.resource) == 'started' then
            -- On ne sélectionne que si l'adaptateur correspondant est effectivement enregistré.
            if Framework.adapters[c.adapter] then
                return c.adapter
            end
            Log:warn('framework', 'framework detected but adapter not loaded', {
                resource = c.resource, adapter = c.adapter })
        end
    end
    return 'standalone'
end

-- --- Accès uniformes, tolérants aux méthodes manquantes (§104) ---
-- Chaque accesseur est protégé : un adaptateur incomplet ou une exception ne fait pas
-- tomber le core. On journalise et on renvoie une valeur neutre.

local function safeCall(method, source)
    local a = Framework.active()
    local fn = a[method]
    if type(fn) ~= 'function' then return nil end
    local ok, result = pcall(fn, source)
    if not ok then
        Log:error('framework', 'adapter method threw', { method = method, adapter = a.name, err = tostring(result) })
        return nil
    end
    return result
end

--- Solde serveur d'un joueur selon le framework. nil si inconnu -> le ledger du core fait foi.
function Framework.getMoney(source) return safeCall('getMoney', source) end
function Framework.getJob(source) return safeCall('getJob', source) end
function Framework.getIdentifier(source) return safeCall('getIdentifier', source) end

--- Statut admin (§04) : calculé SERVEUR par le framework. Défaut false (jamais admin par défaut).
function Framework.isAdmin(source)
    local r = safeCall('isAdmin', source)
    return r == true
end

-- Enregistrer l'adaptateur standalone par défaut.
Framework.register('standalone', STANDALONE)
Framework.use('standalone')

ZShield.Framework = Framework
