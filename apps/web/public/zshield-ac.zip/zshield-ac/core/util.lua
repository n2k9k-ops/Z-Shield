--[[
    FILE:         core/util.lua
    PURPOSE:      Bus d'événements INTERNE et utilitaires partagés. Le bus découple les
                  modules (§105, §106) : un détecteur émet un signal sans connaître le risk
                  engine, le risk engine s'abonne sans connaître le détecteur.
    DEPENDENCIES: core/log.lua
    PUBLIC API:   ZShield.Bus:on(topic, fn) / :emit(topic, payload) / :off(topic, id)
                  ZShield.Util.deepCopy / clamp / now / isArray / count / uuid

    §104 : chaque abonné est appelé sous pcall. L'exception d'un module ne doit jamais
    empêcher les autres de recevoir l'événement, ni faire tomber l'émetteur.
]]

ZShield = ZShield or {}
local Log = ZShield.Log

-- ---------------------------------------------------------------------------
-- Utilitaires
-- ---------------------------------------------------------------------------
local Util = {}

function Util.deepCopy(v, depth)
    depth = depth or 0
    if depth > 12 or type(v) ~= 'table' then return v end
    local out = {}
    for k, val in pairs(v) do out[k] = Util.deepCopy(val, depth + 1) end
    return out
end

function Util.clamp(n, lo, hi)
    if type(n) ~= 'number' then return lo end
    if n < lo then return lo end
    if n > hi then return hi end
    return n
end

--- Temps monotone en millisecondes. Sous FXServer, GetGameTimer() est monotone et
--- convient aux durées/cooldowns. Hors FXServer (tests), on retombe sur os.clock.
--- JAMAIS l'horloge client (§150).
function Util.now()
    if type(GetGameTimer) == 'function' then
        return GetGameTimer()
    end
    return math.floor(os.clock() * 1000)
end

--- Temps mural serveur en secondes, pour les timestamps persistés (§149).
function Util.wallclock()
    return os.time()
end

function Util.isArray(t)
    if type(t) ~= 'table' then return false end
    local n = 0
    for k in pairs(t) do
        if type(k) ~= 'number' or k % 1 ~= 0 or k < 1 then return false end
        n = n + 1
    end
    for i = 1, n do if t[i] == nil then return false end end
    return true
end

function Util.count(t)
    if type(t) ~= 'table' then return 0 end
    local n = 0
    for _ in pairs(t) do n = n + 1 end
    return n
end

-- Identifiant interne. Unicité, pas imprévisibilité : sert de clé d'incident/signal.
local uuidCounter = 0
local seeded = false
function Util.uuid(prefix)
    if not seeded then
        math.randomseed((os.time() * 1000 + math.floor(os.clock() * 1e6)) % 2147483647)
        seeded = true
    end
    uuidCounter = (uuidCounter + 1) % 0x1000000
    return string.format('%s_%08x%06x%06x',
        prefix or 'id', os.time() % 0xFFFFFFFF, math.random(0, 0xFFFFFF), uuidCounter)
end

--- Normalise un entier en 32 bits non signés. Les hash FiveM (armes, modèles) sont
--- parfois signés ; on compare toujours en non signé.
function Util.u32(n)
    n = math.floor(tonumber(n) or 0)
    return n & 0xFFFFFFFF
end

--- Hash Jenkins one-at-a-time (joaat), en minuscules, comme GTA/FiveM. Permet de
--- comparer un nom ("WEAPON_RPG", "adder") au hash renvoyé par le runtime.
function Util.joaat(str)
    if type(str) ~= 'string' then return Util.u32(str) end
    local h = 0
    local s = string.lower(str)
    for i = 1, #s do
        h = (h + string.byte(s, i)) & 0xFFFFFFFF
        h = (h + (h << 10)) & 0xFFFFFFFF
        h = (h ~ (h >> 6)) & 0xFFFFFFFF
    end
    h = (h + (h << 3)) & 0xFFFFFFFF
    h = (h ~ (h >> 11)) & 0xFFFFFFFF
    h = (h + (h << 15)) & 0xFFFFFFFF
    return h & 0xFFFFFFFF
end

ZShield.Util = Util

-- ---------------------------------------------------------------------------
-- Bus d'événements interne
-- ---------------------------------------------------------------------------
local Bus = {
    handlers = {},  -- topic -> { [id] = fn }
    nextId = 0,
}

function Bus:on(topic, fn)
    assert(type(topic) == 'string', 'bus topic must be a string')
    assert(type(fn) == 'function', 'bus handler must be a function')
    self.handlers[topic] = self.handlers[topic] or {}
    self.nextId = self.nextId + 1
    self.handlers[topic][self.nextId] = fn
    return self.nextId
end

function Bus:off(topic, id)
    local h = self.handlers[topic]
    if h then h[id] = nil end
end

--- Émet un événement. Chaque abonné est isolé : son exception est journalisée en ERROR
--- et n'interrompt ni les autres abonnés ni l'émetteur (§104).
function Bus:emit(topic, payload)
    local h = self.handlers[topic]
    if not h then return 0 end
    local delivered = 0
    for id, fn in pairs(h) do
        local ok, err = pcall(fn, payload)
        if ok then
            delivered = delivered + 1
        else
            Log:error('bus', 'handler threw during emit', { topic = topic, id = id, err = tostring(err) })
        end
    end
    return delivered
end

ZShield.Bus = Bus
