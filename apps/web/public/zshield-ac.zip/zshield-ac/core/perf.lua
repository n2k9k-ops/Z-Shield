--[[
    FILE:         core/perf.lua
    PURPOSE:      Performance Engine (§29). « ZShield ne doit pas devenir le problème. »
                  Mesure le temps passé par module et par PALIER de priorité, et expose un
                  garde-budget : si le chemin critique (REALTIME/HIGH) dépasse son budget par
                  tick, les tâches FORENSICS/BACKGROUND doivent céder (backpressure §30).
    DEPENDENCIES: shared/constants.lua, core/util.lua
    PUBLIC API:   ZShield.Perf.measure(tier, name, fn, ...) -> résultat de fn
                  ZShield.Perf.tick()             -- clôt la fenêtre de mesure courante
                  ZShield.Perf.shouldDefer(tier) -> bool  (le palier doit-il se retenir ?)
                  ZShield.Perf.report()

    Le coût de la MESURE elle-même est minime (deux lectures d'horloge par section) et
    n'est activé que si performance.enabled. Hors budget, on n'ARRÊTE jamais le chemin
    critique — on diffère seulement le travail différable.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local Perf = {
    enabled = true,
    budget_ms = 2.0,            -- budget indicatif du chemin critique par fenêtre
    window = { started = 0, critical_ms = 0 },
    totals = {},               -- name -> { calls, ms }
    tiers = {},                -- tier -> ms (fenêtre courante)
}

local CRITICAL_TIERS = { REALTIME = true, HIGH = true }

function Perf.configure(opts)
    opts = opts or {}
    if opts.enabled ~= nil then Perf.enabled = opts.enabled and true or false end
    if opts.budget_ms then Perf.budget_ms = tonumber(opts.budget_ms) or Perf.budget_ms end
end

--- Mesure l'exécution de fn sous un palier. Retourne ce que fn retourne (transparent).
function Perf.measure(tier, name, fn, ...)
    if not Perf.enabled or type(fn) ~= 'function' then
        return fn(...)
    end
    local t0 = Util.now()
    local ok, a, b, cc = pcall(fn, ...)
    local dt = Util.now() - t0
    if dt < 0 then dt = 0 end

    local rec = Perf.totals[name]
    if not rec then rec = { calls = 0, ms = 0 }; Perf.totals[name] = rec end
    rec.calls = rec.calls + 1
    rec.ms = rec.ms + dt

    Perf.tiers[tier] = (Perf.tiers[tier] or 0) + dt
    if CRITICAL_TIERS[tier] then
        Perf.window.critical_ms = Perf.window.critical_ms + dt
    end

    if not ok then error(a, 0) end   -- on re-propage : la mesure n'avale pas l'erreur
    return a, b, cc
end

--- Clôt la fenêtre courante (à appeler une fois par cycle/tick de self-check).
function Perf.tick()
    Perf.window.critical_ms = 0
    Perf.tiers = {}
    Perf.window.started = Util.now()
end

--- Un palier différable doit-il se retenir parce que le chemin critique sature ? (§30)
function Perf.shouldDefer(tier)
    if not Perf.enabled then return false end
    if CRITICAL_TIERS[tier] then return false end   -- on ne diffère jamais le critique
    return Perf.window.critical_ms > Perf.budget_ms
end

function Perf.report()
    local out = { budget_ms = Perf.budget_ms, critical_ms = Perf.window.critical_ms, totals = {} }
    for name, rec in pairs(Perf.totals) do
        out.totals[name] = { calls = rec.calls, ms = rec.ms,
                             avg_ms = rec.calls > 0 and (rec.ms / rec.calls) or 0 }
    end
    return out
end

ZShield.Perf = Perf
