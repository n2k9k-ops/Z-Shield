--[[
    FILE:         core/config.lua
    PURPOSE:      Chargement et validation de la configuration (§48, §49, §156). Une config
                  invalide produit une erreur claire au démarrage plutôt qu'un comportement
                  imprévisible à l'exécution.
    DEPENDENCIES: shared/constants.lua, shared/schema.lua, core/log.lua, core/util.lua
    PUBLIC API:   ZShield.Config.load(raw) -> ok, errorOrConfig
                  ZShield.Config.get() -> table courante (lecture seule par convention)
                  ZShield.Config.snapshot() -> copie figée + version (§151)

    §49 : load -> schema validation -> dependency validation -> compatibility -> start.
    §151 : chaque incident doit pouvoir référencer la version de config active ; on
    expose donc un snapshot versionné.
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Schema = ZShield.Schema
local Log = ZShield.Log
local Util = ZShield.Util

local Config = { current = nil, version = 0 }

-- Schéma complet de la configuration. Tout champ a un défaut : une config vide est
-- valide et sûre (mode shadow, pas de sanction destructive).
local SCHEMA = {
    type = 'table', allowUnknown = false,
    fields = {
        schema_version = { type = 'integer', default = C.CONFIG_SCHEMA_VERSION, min = 1 },

        -- Mode global — §31. Défaut SHADOW : on n'active jamais l'enforcement par accident.
        mode = { type = 'string', default = C.MODE.SHADOW, enum = { 'OFF', 'SHADOW', 'MONITOR', 'ENFORCE' } },

        logging = {
            type = 'table', default = {}, allowUnknown = false,
            fields = {
                level = { type = 'string', default = 'INFO',
                          enum = { 'TRACE', 'DEBUG', 'INFO', 'WARN', 'ERROR', 'SECURITY', 'CRITICAL' } },
                console = { type = 'boolean', default = true },
                buffer_size = { type = 'integer', default = 200, min = 10, max = 2000 },
            },
        },

        -- Scoring / risk — §13, §14.
        scoring = {
            type = 'table', default = {}, allowUnknown = false,
            fields = {
                enabled = { type = 'boolean', default = true },
                decay = { type = 'boolean', default = true },
                -- Demi-vie du score en secondes : un score non alimenté est divisé par deux
                -- après cette durée. Bornée pour rester plausible.
                decay_half_life_s = { type = 'integer', default = 600, min = 30, max = 86400 },
                thresholds = {
                    type = 'table', default = {}, allowUnknown = false,
                    fields = {
                        observe    = { type = 'integer', default = 20,  min = 1, max = 100 },
                        suspicious = { type = 'integer', default = 40,  min = 1, max = 100 },
                        high_risk  = { type = 'integer', default = 65,  min = 1, max = 100 },
                        critical   = { type = 'integer', default = 85,  min = 1, max = 100 },
                    },
                },
            },
        },

        -- Firewall d'events — §05.
        events = {
            type = 'table', default = {}, allowUnknown = false,
            fields = {
                enabled = { type = 'boolean', default = true },
                -- Que faire d'un event NON enregistré : monitor (journalise) ou reject.
                unknown_policy = { type = 'string', default = 'monitor', enum = { 'monitor', 'reject', 'allow' } },
            },
        },

        entities = {
            type = 'table', default = {}, allowUnknown = false,
            fields = {
                enabled = { type = 'boolean', default = true },
                default_quota = { type = 'integer', default = 50, min = 1, max = 10000 },
            },
        },

        movement = {
            type = 'table', default = {}, allowUnknown = false,
            fields = {
                enabled = { type = 'boolean', default = true },
                max_ground_speed_ms = { type = 'number', default = 50.0, min = 5, max = 200 },
                max_tick_distance_m = { type = 'number', default = 75.0, min = 5, max = 1000 },
            },
        },

        -- Game Event Firewall — §08. Blocage natif à la source (explosion/damage/entité).
        game_events = {
            type = 'table', default = {}, allowUnknown = true,  -- blacklists = tables libres
            fields = {
                enabled = { type = 'boolean', default = true },
                block_explosion_flood = { type = 'boolean', default = true },
                explosion_rate = { type = 'integer', default = 6, min = 1, max = 100 },
                explosion_burst = { type = 'integer', default = 10, min = 1, max = 200 },
                max_weapon_damage = { type = 'integer', default = 250, min = 1, max = 100000 },
            },
        },

        -- State Bag Security — §10. Refuse les écritures client de clés serveur.
        statebags = {
            type = 'table', default = {}, allowUnknown = true,   -- protect = table de policies
            fields = {
                enabled = { type = 'boolean', default = true },
                max_writes_10s = { type = 'integer', default = 20, min = 1, max = 1000 },
            },
        },

        -- Native Security Orchestrator — §21. Défaut inactif : aucun changement natif.
        onesync = {
            type = 'table', default = {}, allowUnknown = false,
            fields = {
                enabled = { type = 'boolean', default = false },
                bucket = { type = 'integer', default = 0, min = 0, max = 63 },
                lockdown_mode = { type = 'string', default = 'inactive',
                                  enum = { 'inactive', 'relaxed', 'strict' } },
                disable_population = { type = 'boolean', default = false },
                orphan_keep = { type = 'boolean', default = false },
            },
        },

        -- Performance Engine — §29.
        performance = {
            type = 'table', default = {}, allowUnknown = false,
            fields = {
                enabled = { type = 'boolean', default = true },
                budget_ms = { type = 'number', default = 2.0, min = 0.1, max = 50 },
            },
        },

        -- Licence. La clé signée fournie au client. Vide = pas de licence = protection
        -- désactivée (le message s'affiche au démarrage).
        license = {
            type = 'table', default = {}, allowUnknown = true,
            fields = {
                key = { type = 'string', default = '', max = 1024 },
                -- Kill-switch en ligne (anti-leak). L'agent valide périodiquement la
                -- clé auprès du SaaS ; une clé leakée peut être RÉVOQUÉE à distance.
                online_check       = { type = 'boolean', default = false },
                online_grace_hours = { type = 'number',  default = 72 },
            },
        },

        -- Réglages des nouveaux détecteurs / gardes. Souples (allowUnknown) : les clés
        -- exactes sont documentées dans chaque module et pilotées depuis le dashboard.
        connection = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        injection  = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        health     = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        vehicle    = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        command    = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        entity     = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        weapon     = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        evidence   = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        client     = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        -- Nouveaux moteurs de détection profonds (analyse statistique / provenance).
        aimstats         = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        flight           = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        damage_integrity = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        provenance       = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        freecam          = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        sequence         = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        desync           = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        budget           = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        esp              = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        reach            = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        godmode          = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        ownership        = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        trainer          = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        behavior         = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        spawnprotect     = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        chatspam         = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        teleport         = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        selfprotect      = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        executor         = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        menu             = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        crashguard       = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        reputation       = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        reconcile        = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        invariants       = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        envelope         = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        sprt             = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        baseline         = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        hitreg           = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        fusion           = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        markov           = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        clocksync        = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        antidump         = { type = 'table', default = {}, allowUnknown = true, fields = {} },
        wiring           = { type = 'table', default = {}, allowUnknown = true, fields = {} },

        enforcement = {
            type = 'table', default = {}, allowUnknown = false,
            fields = {
                enabled = { type = 'boolean', default = true },
                -- Deux phases pour les cas non critiques (§87) : observation avant sanction.
                two_phase = { type = 'boolean', default = true },
            },
        },

        persistence = {
            type = 'table', default = {}, allowUnknown = false,
            fields = {
                enabled = { type = 'boolean', default = true },
                -- Taille max de la file mémoire avant persistance (§37).
                event_store_max = { type = 'integer', default = 5000, min = 100, max = 100000 },
                flush_interval_ms = { type = 'integer', default = 5000, min = 500, max = 60000 },
            },
        },

        integrations = {
            type = 'table', default = {}, allowUnknown = false,
            fields = {
                discord_enabled = { type = 'boolean', default = false },
                agent_enabled = { type = 'boolean', default = false },
            },
        },
    },
}

Config.SCHEMA = SCHEMA

--- Charge et valide une config brute (table). Retourne ok, config | ok=false, err.
function Config.load(raw)
    if raw ~= nil and type(raw) ~= 'table' then
        return false, 'configuration must be a table'
    end

    -- 1. Appliquer les défauts, puis valider (§49).
    local coerced = Schema.coerce(raw or {}, SCHEMA)
    local ok, err = Schema.validate(coerced, SCHEMA, 'config')
    if not ok then
        return false, 'invalid configuration: ' .. err
    end

    -- 2. Validation de compatibilité de schéma (§49).
    if coerced.schema_version > C.CONFIG_SCHEMA_VERSION then
        return false, string.format(
            'config schema version %d is newer than supported %d',
            coerced.schema_version, C.CONFIG_SCHEMA_VERSION)
    end

    -- 3. Validation de dépendances entre champs (§49). Les seuils de risque doivent être
    --    strictement croissants, sinon un joueur ne pourrait jamais atteindre un niveau.
    local th = coerced.scoring.thresholds
    if not (th.observe < th.suspicious and th.suspicious < th.high_risk and th.high_risk < th.critical) then
        return false, 'scoring thresholds must be strictly increasing: observe < suspicious < high_risk < critical'
    end

    Config.current = coerced
    Config.version = Config.version + 1

    -- Le logger prend le niveau configuré immédiatement.
    Log:configure(coerced.logging)

    Log:info('config', 'configuration loaded', {
        mode = coerced.mode,
        version = Config.version,
        schema_version = coerced.schema_version,
    })

    -- En mode SHADOW, on le dit clairement : c'est un choix, pas un oubli.
    if coerced.mode == C.MODE.SHADOW then
        Log:info('config', 'running in SHADOW mode: detections logged, NO sanctions applied')
    elseif coerced.mode == C.MODE.OFF then
        Log:warn('config', 'running in OFF mode: ZShield is inert')
    end

    return true, coerced
end

function Config.get()
    return Config.current
end

--- Snapshot figé + numéro de version, pour référence dans les incidents (§151).
function Config.snapshot()
    return { version = Config.version, config = Util.deepCopy(Config.current) }
end

--- Raccourci de lecture d'un chemin pointé, avec défaut. Ex: Config.value('scoring.decay').
function Config.value(path, default)
    local node = Config.current
    if not node then return default end
    for segment in path:gmatch('[^.]+') do
        if type(node) ~= 'table' then return default end
        node = node[segment]
    end
    if node == nil then return default end
    return node
end

ZShield.Config = Config
