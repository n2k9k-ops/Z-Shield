--[[
    FILE:         core/log.lua
    PURPOSE:      Journalisation structurée (§61, §62) avec rédaction obligatoire des
                  secrets. Une seule sortie JSON par ligne, exploitable par un collecteur.
    DEPENDENCIES: shared/constants.lua
    PUBLIC API:   ZShield.Log:trace|debug|info|warn|error|security|critical(module, msg, fields)
                  ZShield.Log:setLevel(name) -> ok, err
                  ZShield.Log:configure(loggingConfig)
                  ZShield.Log:counters() -> { warn, error, security, critical }
                  ZShield.Log:recent(n) -> array (rédigé)

    §61 : SECURITY et CRITICAL ne sont JAMAIS supprimés par le niveau configuré. Un
    opérateur qui monte le niveau pour réduire le bruit ne doit pas masquer un événement
    de sécurité.

    §117 : la rédaction est mécanique, par nom de clé, et non laissée à la discipline de
    chaque appelant. Il suffit d'un champ oublié pour publier un webhook ou un mot de
    passe dans un agrégateur de logs.
]]

ZShield = ZShield or {}
local C = ZShield.Const

local Log = {
    level = C.LOG.INFO,
    console = true,
    bufferSize = 200,
    buffer = {},
    head = 0,
    counts = { warn = 0, error = 0, security = 0, critical = 0 },
}

-- Fragments de clé déclenchant la rédaction. Comparaison en minuscules, par sous-chaîne.
local REDACT = {
    'secret', 'token', 'password', 'passwd', 'apikey', 'api_key', 'authorization',
    'credential', 'webhook', 'private', 'license_key', 'signature', 'cookie', 'dsn',
}
local REDACTED = '[redacted]'

local function sensitive(key)
    if type(key) ~= 'string' then return false end
    local low = key:lower()
    for i = 1, #REDACT do
        if low:find(REDACT[i], 1, true) then return true end
    end
    return false
end

-- Copie profonde rédigée, avec profondeur et longueur bornées (défense contre une
-- structure hostile ou cyclique).
local function redact(value, depth)
    depth = depth or 0
    if depth > 6 then return '[depth]' end
    local t = type(value)
    if t ~= 'table' then
        if t == 'string' and #value > C.LIMITS.MAX_STRING_LEN then
            return value:sub(1, C.LIMITS.MAX_STRING_LEN) .. '…'
        end
        return value
    end
    local out, n = {}, 0
    for k, v in pairs(value) do
        n = n + 1
        if n > C.LIMITS.MAX_TABLE_KEYS then out['…'] = 'truncated' break end
        if sensitive(k) then out[k] = REDACTED else out[k] = redact(v, depth + 1) end
    end
    return out
end
Log.redact = redact

function Log:setLevel(name)
    local value = C.LOG[name]
    if not value then return false, 'unknown log level ' .. tostring(name) end
    self.level = value
    return true
end

function Log:configure(cfg)
    if type(cfg) ~= 'table' then return end
    if cfg.level then self:setLevel(cfg.level) end
    if type(cfg.console) == 'boolean' then self.console = cfg.console end
    if type(cfg.buffer_size) == 'number' then
        self.bufferSize = math.max(10, math.min(cfg.buffer_size, 2000))
    end
end

-- Horodatage serveur (§149). os.time est le temps serveur, jamais le client.
local function isoNow()
    return os.date('!%Y-%m-%dT%H:%M:%SZ')
end

-- Encodeur JSON minimal, sans dépendance : le core ne doit pas exiger une lib externe
-- pour journaliser. FXServer fournit `json`, mais on ne veut pas en dépendre ici.
local escapes = { ['"']='\\"', ['\\']='\\\\', ['\n']='\\n', ['\r']='\\r', ['\t']='\\t' }
local function enc(v)
    local t = type(v)
    if t == 'nil' then return 'null' end
    if t == 'boolean' then return tostring(v) end
    if t == 'number' then
        if v ~= v or v == math.huge or v == -math.huge then return 'null' end
        return tostring(v)
    end
    if t == 'string' then
        return '"' .. v:gsub('[%c"\\]', function(c) return escapes[c] or string.format('\\u%04x', c:byte()) end) .. '"'
    end
    if t == 'table' then
        -- tableau si clés 1..n
        local n = 0
        for _ in pairs(v) do n = n + 1 end
        local isArray = n > 0
        for i = 1, n do if v[i] == nil then isArray = false break end end
        local parts = {}
        if isArray then
            for i = 1, n do parts[i] = enc(v[i]) end
            return '[' .. table.concat(parts, ',') .. ']'
        end
        local keys = {}
        for k in pairs(v) do keys[#keys + 1] = tostring(k) end
        table.sort(keys)
        for i = 1, #keys do parts[i] = enc(keys[i]) .. ':' .. enc(v[keys[i]]) end
        return '{' .. table.concat(parts, ',') .. '}'
    end
    return 'null'
end
Log.encode = enc

function Log:push(entry)
    self.head = self.head + 1
    self.buffer[(self.head - 1) % self.bufferSize + 1] = entry
end

function Log:write(levelValue, module, message, fields)
    -- SECURITY et CRITICAL passent toujours (§61).
    if levelValue < self.level
        and levelValue ~= C.LOG.SECURITY and levelValue ~= C.LOG.CRITICAL then
        return
    end

    local entry = {
        timestamp = isoNow(),
        level = C.LOG_NAME[levelValue],
        module = module,
        message = message,
    }
    if fields ~= nil then entry.fields = redact(fields) end
    self:push(entry)

    if levelValue == C.LOG.WARN then self.counts.warn = self.counts.warn + 1
    elseif levelValue == C.LOG.ERROR then self.counts.error = self.counts.error + 1
    elseif levelValue == C.LOG.SECURITY then self.counts.security = self.counts.security + 1
    elseif levelValue == C.LOG.CRITICAL then self.counts.critical = self.counts.critical + 1 end

    if self.console then
        print('[zshield] ' .. enc(entry))
    end
end

function Log:trace(m, msg, f)    self:write(C.LOG.TRACE, m, msg, f) end
function Log:debug(m, msg, f)    self:write(C.LOG.DEBUG, m, msg, f) end
function Log:info(m, msg, f)     self:write(C.LOG.INFO, m, msg, f) end
function Log:warn(m, msg, f)     self:write(C.LOG.WARN, m, msg, f) end
function Log:error(m, msg, f)    self:write(C.LOG.ERROR, m, msg, f) end
function Log:security(m, msg, f) self:write(C.LOG.SECURITY, m, msg, f) end
function Log:critical(m, msg, f) self:write(C.LOG.CRITICAL, m, msg, f) end

function Log:counters()
    return { warn = self.counts.warn, error = self.counts.error,
             security = self.counts.security, critical = self.counts.critical }
end

function Log:recent(n)
    n = math.min(n or 50, self.bufferSize)
    local out = {}
    local first = math.max(1, self.head - n + 1)
    for i = first, self.head do
        local e = self.buffer[(i - 1) % self.bufferSize + 1]
        if e then out[#out + 1] = e end
    end
    return out
end

ZShield.Log = Log
