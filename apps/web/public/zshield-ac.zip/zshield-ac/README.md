# ZShield AC

Plateforme de sécurité anti-abus pour serveurs FiveM / FXServer. **Autorité
serveur** : elle valide, détecte, corrèle, score, décide et journalise — sans
jamais faire confiance au client.

> ZShield ne promet pas l'impossible. Elle ne prétend pas être « 100 %
> incontournable ». Elle rend les abus **difficiles, détectables, traçables et
> contenables**, tout en gardant performance, stabilité et faible taux de faux
> positifs. C'est la seule promesse honnête pour un anticheat (§02).

## Ce que c'est, et ce que ce n'est pas

ZShield AC est le **cœur côté serveur**. Il fonctionne seul. Il est distinct de :

- `zshield-agent` — la ressource qui remonte l'état au dashboard SaaS (optionnelle) ;
- `zshield-dashboard` — le SaaS multi-tenant de supervision (optionnel).

Le cœur continue de protéger le serveur même si l'agent, le dashboard, la base
de données et Discord sont **tous** indisponibles (§38, §173).

## Principe fondateur

**NEVER TRUST THE CLIENT.** Toute donnée client est une *assertion*, jamais une
preuve. Trois règles gouvernent chaque ligne de code (§178) :

1. Si une protection peut passer du client au serveur → elle passe au serveur.
2. Si une donnée peut être reconstruite côté serveur → elle est reconstruite.
3. Si une décision est incertaine → on augmente la corrélation, on ne bannit pas.

## Installation

1. Placez le dossier `zshield-ac` dans vos `resources`.
2. Ajoutez à votre `server.cfg` :

   ```
   ensure zshield-ac
   ```

3. **Configuration minimale** — copiez `config/config.lua` et ajustez. Par
   défaut, tout est en mode `SHADOW` : ZShield détecte et journalise mais
   n'applique **aucune sanction**. C'est volontaire (§31). Observez d'abord.

4. **Base de données** (optionnelle mais recommandée) — importez la migration :

   ```
   sql/001_initial.sql
   ```

   Sans base, ZShield fonctionne en mémoire ; avec, les incidents et le ledger
   survivent aux redémarrages. Une panne de base ne fait jamais tomber la
   sécurité (§37) : les événements s'accumulent en file et se persistent au
   retour de la base.

5. **Discord** (optionnel) — pour les notifications :

   ```
   set zshield_discord_webhook "https://discord.com/api/webhooks/..."
   ```

   Utilisez `set`, jamais `sets` : `sets` publierait le webhook à tous les
   clients. Le webhook est un secret ; il n'apparaît jamais dans les logs (§117).

## Modes de déploiement (§31)

| Mode | Détection | Sanctions | Usage |
|---|---|---|---|
| `OFF` | non | non | désactivé |
| `SHADOW` | oui | **aucune** | déployer une règle sans risque, mesurer les faux positifs |
| `MONITOR` | oui | non destructives seulement | phase intermédiaire |
| `ENFORCE` | oui | toutes | production |

**Recommandation** : démarrez en `SHADOW` plusieurs jours, examinez les
incidents, puis passez en `ENFORCE`. On n'active jamais l'enforcement en aveugle.

## Protéger un event (SDK)

Un développeur sécurise un event en quelques lignes (§77) :

```lua
ZShield.Security:ProtectEvent("shop:buy", {
    schema    = { type = 'table', fields = { item = { type = 'string', required = true } } },
    rateLimit = 2,                       -- 2 par seconde
    states    = { 'ACTIVE' },            -- états autorisés
    validate  = function(ctx)            -- règle métier serveur
        return ctx.args.item ~= 'forbidden_item'
    end,
    execute   = function(ctx)
        -- le SERVEUR décide de tout ; ctx.args est déjà validé et assaini
    end,
})
```

Voir `docs/API.md` pour l'API complète et les validateurs composables
(permission, distance, état, cooldown).

## Commandes console

```
zshield status        état global et mode
zshield health        santé de chaque composant
zshield version       version
zshield diagnostics   rapport complet sans secrets (§159)
```

## Ce qui est couvert

Zero-trust events, validation de schéma, rate limiting (4 stratégies), machine à
états, contexte joueur, détection multi-signaux, corrélation temporelle, moteur
de risque avec decay, incidents avec chaîne de preuve, enforcement en deux
phases, contrôle d'entités, analyse de mouvement contextuelle, ledger
économique, persistance résiliente, santé/auto-surveillance, adaptateurs de
framework (standalone/ESX/QBCore/Qbox), audit de durcissement FXServer, API,
SDK, notifications Discord.

## Architecture et sécurité

- `docs/ARCHITECTURE.md` — architecture en couches, graphe de dépendances,
  frontières de confiance, **modèle de menace** (13 menaces avec risque
  résiduel).
- `docs/API.md` — API publique et SDK.

## Tests

454 tests exécutés en Lua 5.4, couvrant chaque couche :

```
lua5.4 tests/run_all.lua
```

Chaque suite vérifie non seulement le comportement nominal, mais les propriétés
qui comptent : séparation severity/confidence/risk (anti-faux-positif),
isolation des modules fautifs (un composant qui tombe n'en fait pas tomber
d'autres), et résilience aux pannes (base, Discord, adaptateur).

## Limites assumées (§02, §143)

- **Pas de protection parfaite.** Un cheat qui n'émet aucun signal observable
  côté serveur n'est pas détecté, par définition. ZShield réduit la surface,
  elle ne la supprime pas.
- **Pas de global ban list** partagée entre serveurs comme mécanisme central
  (§65) : risque de bannissements injustifiés.
- **Pas de sécurité par l'obscurité** (§66). La sécurité repose sur l'autorité
  serveur et la validation, pas sur l'obfuscation.
- **Aucun faux positif n'est impossible.** Ils sont mesurés, pas niés. Le mode
  SHADOW existe précisément pour les débusquer avant l'enforcement.
- **Le client ne porte aucune logique critique.** Il fournit des signaux ; s'il
  ment, le serveur reconstruit la vérité ou déclenche une détection.

## Licence et statut

Cœur de sécurité complet et testé. Les intégrations optionnelles (agent,
dashboard) sont des dépôts distincts.
