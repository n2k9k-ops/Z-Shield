# Z-Shield — Performance proche de zéro & protection maximale

Deux objectifs qui, contrairement à l'intuition, vont dans le même sens : la protection
la plus forte est aussi la moins coûteuse, parce qu'elle **empêche** au lieu de **surveiller**.

## Pourquoi le coût peut approcher zéro

Le coût CPU d'un anticheat vient presque toujours de **boucles par tick** qui scrutent tous
les joueurs en permanence (`Citizen.CreateThread` + `Wait(0)`). Z-Shield n'en a aucune sur le
chemin critique. Trois principes :

1. **Event-driven, pas polling.** Toutes les protections fortes s'accrochent à des events
   natifs FXServer (`explosionEvent`, `weaponDamageEvent`, `entityCreating`,
   `AddStateBagChangeHandler`). Le moteur C++ n'appelle le handler **que** lorsque l'action
   se produit réellement. Au repos, zéro travail. Le travail par event est O(1).

2. **Empêcher plutôt que détecter.** Un event natif annulable (`CancelEvent`) coûte moins cher
   qu'une détection *a posteriori* : il n'y a ni corrélation, ni incident, ni persistance à
   déclencher pour une action qui n'a jamais eu lieu. La prévention native OneSync
   (`SetRoutingBucketEntityLockdownMode 'strict'`) déplace même le blocage **dans le moteur**,
   pour un coût Lua nul.

3. **Le lourd est asynchrone et différable.** Persistance, Discord et forensics tournent par
   lots, hors du chemin critique, derrière un disjoncteur. Le moteur de performance
   (`core/perf.lua`) mesure le temps du chemin critique et fait **céder** (`shouldDefer`) les
   paliers FORENSICS/BACKGROUND quand le budget par tick est dépassé (backpressure §30). Le
   temps réel n'est jamais ralenti par le travail différable.

### Réglages opérateur pour viser le coût minimal
- Activer l'**entity lockdown** natif (`onesync.lockdown_mode = 'relaxed'` ou `'strict'`) :
  la majorité des spawns illégitimes n'atteignent jamais le Lua.
- Garder `performance.enabled = true` et un `budget_ms` bas (2 ms) : le différable s'efface
  sous charge.
- Laisser la persistance par lots (`flush_interval_ms` 5000) plutôt que par event.
- Ne protéger en state bag que les **clés sensibles** (liste par défaut) : les autres clés
  sont ignorées en O(1).

## Pourquoi la protection est déjà forte

- **Autorité serveur totale** : le client n'est jamais cru sur une valeur importante (§01).
- **Prévention native à la source** : explosions/dégâts/entités/state bags bloqués avant effet
  (§08, §10), création d'entités verrouillée par OneSync (§21).
- **Multi-signaux corrélés** : aucune détection seule ne sanctionne ; il faut ≥2 catégories
  corrélées et un niveau de preuve suffisant (E0–E5, §15, §16, §38).
- **Anti-faux-positif de premier rang** : gravité/confiance/risque séparés, décroissance,
  deux phases, mode SHADOW, réputation des détecteurs (§11, §17, §28).
- **Réponse proportionnée et réversible** : containment avant sanction, sanction dure seulement
  sur preuve E4/E5 (§37, §38).
- **Résilience** : la panne d'un module n'est jamais la panne du serveur (§31).

## Ce qui reste à gagner (raffinements, pas trous)

Behavior baselines (§12) pour des seuils par joueur ; autorité d'entité fine et control
security (§04, §06) ; sync integrity et détecteur de crash (§07, §24) ; replay et labo de
régression (§34, §35). Ce sont des gains de **précision de détection**, pas de prévention :
la surface d'attaque principale est déjà fermée à la source.
