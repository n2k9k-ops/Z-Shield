# ZSHIELD AC — API & SDK

Référence des fonctions exposées aux ressources tierces (§45, §76-77). Toutes
sont **serveur uniquement**. Chaque entrée est validée : une ressource de
confiance appelle, mais on ne fait confiance à rien en aveugle (§54).

## API publique (§45)

| Fonction | Rôle | Retour |
|---|---|---|
| `ZShield.GetVersion()` | Version de la plateforme | string |
| `ZShield.GetRisk(source)` | Score et niveau de risque d'un joueur | score, level |
| `ZShield.GetRiskSnapshot(source)` | Snapshot explicable (historique des signaux) | table |
| `ZShield.GetPlayerState(source)` | État dans la machine à états | string\|nil |
| `ZShield.CreateIncident(spec)` | Ouvre un incident (validé) | id\|nil, err |
| `ZShield.AddSignal(signal)` | Injecte un signal externe (validé) | ok, err |
| `ZShield.RegisterTrustedContext(source, key, value)` | Déclare un contexte de confiance | ok |
| `ZShield.RegisterProtectedEvent(def)` | Enregistre un event au firewall | ok, err |
| `ZShield.RegisterTrustedTeleport(source, opts)` | Déclare un téléport serveur légitime (§15) | ok |
| `ZShield.ApplyTransaction(txn)` | Applique une transaction économique (§20) | ok, result |
| `ZShield.GetHealth()` | Santé globale (§50) | table |

## SDK de sécurité (§76-77)

Protéger un event en quelques lignes. L'exemple de la spec fonctionne tel quel :

```lua
ZShield.Security:ProtectEvent("shop:buy", {
    schema    = { type = 'table', fields = { item = { type = 'string', required = true } } },
    rateLimit = 2,                       -- 2 par seconde
    states    = { 'ACTIVE' },            -- états autorisés (optionnel)
    validate  = function(ctx)            -- règle métier serveur
        return ctx.args.item ~= 'forbidden_item'
    end,
    execute   = function(ctx)            -- exécution, args déjà assainis
        -- le SERVEUR décide de tout ; ctx.args est validé, jamais la valeur brute du client
    end,
})
```

### Validateurs composables

| Helper | Rôle |
|---|---|
| `Security:ValidatePlayer(source)` | Le joueur existe et est dans un état exploitable |
| `Security:RequirePermission(perm)` | Exige une permission (calculée serveur, jamais crue du client §04) |
| `Security:RequireContext(states)` | Exige un état de la machine à états (§08) |
| `Security:RequireDistance(getTarget, maxDist)` | Interdit une action à distance impossible |
| `Security:Cooldown(ms)` | Spec de cooldown pour `rateLimit` |
| `Security:RegisterContract(contract)` | Déclare le contrat de sécurité d'une ressource (§75) |

### Principe

Chaque helper retourne une fonction `validate(ctx)` compatible avec le firewall.
Le développeur **compose** ; le firewall **exécute** dans son pipeline
zéro-confiance (source → schéma → rate limit → permission → état → métier).
`ctx.args` est toujours la version **assainie** des arguments — jamais l'objet
brut envoyé par le client (§04, §06).

### Ce que le SDK ne permet pas

Aucun helper ne donne au client le pouvoir de décider d'une permission, d'un
solde, d'une récompense ou d'un état. Ces valeurs sont toujours reconstruites ou
vérifiées côté serveur (§68). Le SDK facilite la protection ; il ne crée aucune
porte vers l'autorité serveur.
