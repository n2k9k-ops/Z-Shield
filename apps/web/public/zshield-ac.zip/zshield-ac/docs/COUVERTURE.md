# Z-Shield — Couverture du plan de sécurité (§36 Threat Coverage Matrix)

Statut de chaque point du plan directeur (49 sections) face au code réel.
`COUVERT` = implémenté · `PARTIEL` = socle présent, périmètre limité · `À VENIR` = non implémenté.

La règle d'or (§48) guide les priorités : **empêcher à la source** d'abord (couches natives,
coût ~0), **détecter** ensuite, **corréler**, **répondre proportionnellement**, **conserver la preuve**.

## Prévention (empêcher à la source)

| # | Section | Statut | Où / pourquoi |
|---|---------|--------|---------------|
| 01 | Validation serveur des valeurs importantes | COUVERT | `economy.lua` (ledger autoritatif), `movement.lua`, `sdk.lua`. XP/inventaire par item : à étendre |
| 02 | Event Firewall (source/args/types/rate/state) | PARTIEL | `firewall/firewall.lua` (7 étapes). Manque : direction, bucket, entité. S'applique via le SDK, pas encore auto-branché sur tous les net-events |
| 05 | OneSync Security (lockdown/population/scope) | PARTIEL | `hardening/orchestrator.lua` applique lockdown/population/orphan natifs |
| 08 | Game Event Firewall (damage/explosion/entité) | COUVERT | `firewall/gameevents.lua` — blocage natif `CancelEvent` à la source |
| 10 | State Bag Security | COUVERT | `firewall/statebag.lua` — refuse l'écriture client de clés serveur |
| 21 | Native Security Orchestrator | COUVERT | `hardening/orchestrator.lua` — applique, ne fait plus que recommander |
| 22 | Rate Limiting (4 stratégies) | PARTIEL | `firewall/ratelimit.lua`. Scopes joueur+event ; resource/bucket/global à étendre |
| 20 | Configuration Integrity | PARTIEL | `core/config.lua` + `hardening.lua` (audit convars) |
| 03 | Security Contracts par resource | PARTIEL | `sdk.lua` (déclaratif, non contraignant) |
| 04 | Entity Authority Engine | PARTIEL | `entity.lua` (ownership/quota). Autorité contrôleur/migration : à venir |
| 06 | Control Security | À VENIR | recommandé via `sv_filterRequestControl` |
| 07 | Sync Integrity Engine | À VENIR | — |

## Détection & évaluation

| # | Section | Statut | Où / pourquoi |
|---|---------|--------|---------------|
| 09 | State Integrity (transitions) | PARTIEL | `context.lua` (machine à états joueur) |
| 11 | Spatial Consistency | PARTIEL | `movement.lua` (position/vitesse/latence/téléport). Accélération/trajectoire : à venir |
| 12 | Behavior Engine (baselines) | À VENIR | seuils statiques pour l'instant |
| 13 | Authorized Action Ledger | PARTIEL | téléports de confiance + audit enforcement |
| 14 | Risk Engine multi-axes | COUVERT | `risk.lua` — severity ≠ confidence ≠ score, avec décroissance |
| 15 | Evidence Levels E0–E5 | COUVERT | `detection/evidence.lua` — conditionne la sanction |
| 16 | Correlation Engine | COUVERT | `correlation.lua` — ≥2 catégories, fenêtre temporelle |
| 17 | Detector Reputation | COUVERT | `detection/reputation.lua` — ACTIVE/DEGRADED/OBSERVATION/DISABLED |
| 25 | Threat Intelligence (capacités) | À VENIR | philosophie présente, base de données à construire |
| 26 | Client Integrity (heartbeat) | À VENIR | principe respecté par omission |
| 27 | Menu Detection (comportement) | À VENIR | — |
| 28 | False Positive Protection | COUVERT | transverse : séparation 3 axes, SHADOW, décroissance, deux phases, dédup |

## Performance & résilience

| # | Section | Statut | Où / pourquoi |
|---|---------|--------|---------------|
| 29 | Performance Engine (paliers) | COUVERT | `core/perf.lua` — REALTIME/HIGH/NORMAL/BACKGROUND/FORENSICS + budget |
| 30 | Backpressure | COUVERT | `store.lua` (éviction par priorité) + `perf.shouldDefer` |
| 31 | Fail-safe par module | COUVERT | bus sous pcall, détecteurs dégradables, disjoncteur |
| 23 | Build Compatibility | À VENIR | `sv_enforceGameBuild` recommandé |
| 24 | Crash/Sync Resilience | À VENIR | résilience système présente, détecteur crash à venir |

## Réponse & preuve

| # | Section | Statut | Où / pourquoi |
|---|---------|--------|---------------|
| 37 | Incident Response (machine à états) | PARTIEL | observe→contain→notify→enforce ; REVIEW à ajouter |
| 38 | Sanctions par niveau de preuve | COUVERT | `policy.lua` (score+confiance) renforcé par E0–E5 (§15) |
| 32 | Forensics Engine | PARTIEL | `incident.lua` (preuve/timeline/évolution du risque) |
| 33 | Incident Timeline | PARTIEL | timeline ordonnée ; fenêtre T-10s..T+10s à ajouter |
| 34 | Replay / Reproduction | À VENIR | — |
| 35 | Security Regression Lab | À VENIR | suite de tests unitaires présente, labo scénario à venir |
| 39 | Audit | COUVERT | `enforcement.lua` — qui/quoi/pourquoi/règle/version/confiance |
| 40 | Review / Appeal | À VENIR | preuve conservée, workflow d'appel à ajouter |
| 41 | SOC Dashboard | COUVERT | dépôt `zshield-dashboard` (séparé) |

## Bilan

Le socle **zero-trust** (event → firewall → signal → corrélation → risque → incident → enforcement)
est solide et testé. Les ajouts récents ferment les manques **les plus rentables** : tout ce qui
**empêche à la source** via les hooks natifs FiveM (§08, §10, §21) — coût processeur quasi nul car
piloté par le moteur C++, pas par des boucles Lua. Les couches restantes « à venir » (autorité
d'entité fine, behavior baselines, replay, labo de régression) sont des raffinements de détection,
pas des trous de prévention.
