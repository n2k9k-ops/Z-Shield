# Z-Shield — Gérer les licences

Ce guide explique comment fonctionnent les licences et comment tu les gères au quotidien.

## En une phrase

Une **licence** est une clé signée qui contient une **date d'expiration**. Le cœur
(`zshield-ac`) la vérifie **au démarrage du serveur**. Si elle manque ou est **expirée**,
la **protection ne s'active pas** et un message clair s'affiche dans la console.

## 1. Le secret de signature (à faire UNE fois)

Les clés sont signées avec un **secret** que toi seul connais. Il doit être **identique**
à deux endroits, et **jamais public** (sinon n'importe qui fabrique des licences gratuites).

Génère un secret (une seule fois) :

```bash
openssl rand -hex 32
```

Colle **la même valeur** aux deux endroits :

1. **Le cœur** — `zshield-ac/server/license.lua`, ligne `SECRET = '...'` :
   ```lua
   SECRET = 'TON_SECRET_ICI',
   ```
2. **Le dashboard** — variable d'environnement du serveur API :
   ```
   LICENSE_SIGNING_SECRET=TON_SECRET_ICI
   ```

> Important : si tu changes le secret plus tard, **toutes les licences déjà émises
> deviennent invalides**. Choisis-le une fois et garde-le.

## 2. Émettre une licence (à chaque client)

Deux endroits :

- **Panel admin** — `dashboard → Administration → Licences`. Un générateur : offre,
  durée, et (optionnel) l'empreinte du serveur du client. C'est l'outil pour vendre à
  des clients externes qui n'ont qu'à coller la clé.
- **Fiche d'un serveur → Licence** — pour tes propres serveurs enregistrés.

### Livraison automatique (recommandé)

Pour un serveur **enregistré dans le dashboard** (avec l'agent installé), tu n'as
**rien à faire coller au client** : tu génères la licence depuis la **fiche du serveur →
Licence**, et l'**agent la récupère et la transmet au cœur tout seul**. La protection
s'active automatiquement, sans redémarrage manuel côté client.

- Le client n'a jamais à toucher `config.lua`.
- Tu renouvelles → l'agent livre la nouvelle clé au prochain relevé.
- Si l'essai expire, la protection se coupe ; dès que tu émets une nouvelle clé, elle
  se réactive automatiquement.

### Collage manuel (clients externes)

Pour un client **sans agent** (ou une clé émise depuis le panel admin `Licences`), il
colle la clé dans `zshield-ac/config/config.lua` puis redémarre :

```lua
license = { key = 'v1|a1b2c3d4e5f60718|pro|1699999999|1702591999~a1b2c3...' },
```

### Lier une clé à UN seul serveur (anti-partage)

Une clé liée ne marche **que sur le serveur pour lequel elle a été émise**. Utilisée
ailleurs → refusée (« licence émise pour un autre serveur »), protection coupée.

**Automatique (serveurs avec agent).** L'agent remonte l'**empreinte** du serveur au
dashboard. Quand tu émets une licence depuis la **fiche du serveur**, elle est **liée
automatiquement** à ce serveur — tu n'as rien à saisir. Le client ne peut pas la partager.

**Manuel (panel admin / clients externes).** Le client te donne son empreinte (le cœur
l'affiche au démarrage : `[Z-Shield] Identifiant de ce serveur : a1b2c3…`), et tu la colles
dans le champ « Empreinte du serveur » du panel `Licences`. Champ vide = clé passe-partout.

## 3. Ce qui se passe à l'expiration

Quand la date est dépassée (fin d'essai ou d'abonnement), au **prochain démarrage** :

```
==========================================================
Z-Shield — PROTECTION DÉSACTIVÉE
Raison : licence expirée (essai/abonnement terminé).
Votre serveur n'est PAS protégé. Renouvelez sur https://z-shield.gg
puis collez votre clé dans config/config.lua (license.key).
==========================================================
```

- **Aucun détecteur n'est armé** : le serveur tourne, mais Z-Shield ne protège plus.
- Le message **revient toutes les 5 minutes** dans la console, pour qu'on ne l'ignore pas.

## 4. Renouveler

1. Le client paie (ou tu prolonges).
2. Tu regénères une clé depuis le dashboard (même bouton).
3. Le client remplace la valeur de `license.key` par la nouvelle et redémarre.

## 5. Le flux de vente, résumé

```
Client teste → tu émets une clé d'essai 7 j → il colle, il démarre → protégé
   ↓ 7 jours plus tard
Essai expiré → protection coupée + message → il paie → tu émets une clé payante → protégé
```

## Bon à savoir

- **La clé est un texte, pas un fichier.** Elle se copie-colle.
- **Infalsifiable** : changer la date d'expiration sans le secret casse la signature ;
  le cœur refuse la clé (état `INVALID`).
- **Hors-ligne** : la vérification ne dépend pas d'un serveur joignable. Même si ton
  dashboard est down, une clé valide reste valide jusqu'à sa date.
- **Anti-partage** : une clé peut être **liée à un seul serveur** via son empreinte
  (voir §2). Une clé liée refusée ailleurs = protection coupée. Une clé « passe-partout »
  (empreinte vide) impose seulement l'expiration.
