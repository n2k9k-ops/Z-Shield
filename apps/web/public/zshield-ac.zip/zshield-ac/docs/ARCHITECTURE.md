# ZSHIELD AC — Architecture & modèle de menace

Document de conception. Il précède le code et le contraint. Il couvre les étapes
1 (architecture) et 2 (threat model) de l'ordre d'implémentation de la
spécification (§177), et fixe les principes que chaque module devra respecter.

Ce dépôt est le **core côté serveur FiveM** : le moteur d'autorité qui observe,
valide, détecte, corrèle, score, décide et journalise. Il est distinct de
`zshield-agent` (qui remonte l'état au dashboard) et de `zshield-dashboard`
(le SaaS). Le core peut fonctionner seul ; l'agent est optionnel.

---

## 1. Principe fondateur — §00, §178

**NEVER TRUST THE CLIENT.** Toute donnée venant du client est une *assertion*,
jamais une preuve. Elle sert de signal, de télémétrie, de contexte — pas
d'autorité quand le serveur peut reconstruire l'état lui-même.

Les trois règles de §178 qui commandent chaque décision de code :

1. Si une protection peut passer du client au serveur → elle passe au serveur.
2. Si une donnée peut être reconstruite côté serveur → elle est reconstruite.
3. Si une décision est incertaine → on augmente la télémétrie et la
   corrélation, on ne bannit pas en aveugle.

Et la promesse produit (§02) : **jamais « 100 % incontournable »**. On démontre
réduction de surface, validation serveur, détection multi-signaux, traçabilité,
faible taux de faux positifs, explicabilité. Rien de plus, rien de faux.

---

## 2. Architecture en couches — §03

Le flux d'une requête réseau, de son arrivée à la décision :

```
Event réseau (client, hostile par défaut)
   │
   ▼
GATEWAY ............ source, rate limit, auth, forme
   │
   ▼
SECURITY CORE ...... firewall d'events, validation de schéma, état, contexte
   │
   ▼
DETECTION ENGINE ... détecteurs → signaux {severity, confidence, score}
   │
   ▼
CORRELATION ........ mémoire temporelle des signaux, fenêtres
   │
   ▼
RISK ENGINE ........ score dynamique par joueur, decay, niveaux
   │
   ├──────────────┬───────────────┐
   ▼              ▼               ▼
INCIDENT       ENFORCEMENT     OBSERVABILITY
(preuve,       (log→warn→      (SQL, métriques,
 timeline)      restrict→        logs, dashboard)
                kick→ban)
```

Chaque couche ne connaît que la précédente et la suivante. Un module tombe
(§104, §105) → il est marqué dégradé, les autres continuent. C'est le contrat de
résilience : **la panne d'un composant n'est pas la panne de la plateforme**
(§173, §174).

### Graphe de dépendances — §106

```
Core (bus, log, config, util)
 ├── Schema  (validation générique)
 ├── Events  (firewall)  ── dépend de Schema, RateLimit, Context
 ├── Context (état joueur, state machine)
 ├── RateLimit (token bucket, sliding window, cooldown)
 ├── Detection ── dépend de Context
 │    └── Correlation ── dépend de Detection
 ├── Risk ── dépend de Correlation
 ├── Incident ── dépend de Risk
 ├── Enforcement ── dépend de Incident, Risk
 ├── Persistence (event store + SQL, best-effort)
 └── Integrations (Discord, agent) — jamais dans le chemin critique
```

Une flèche = « appelle ». Aucune flèche ne remonte : pas de cycle. Le cœur ne
dépend d'aucun module métier ; les modules métier dépendent du cœur.

---

## 3. Frontières de confiance — §142, §143, §144

| Frontière | À l'intérieur | Confiance |
|---|---|---|
| Client FiveM | position, input, télémétrie locale | **aucune** — assertion |
| FXServer | events reçus, natives serveur, state bags | partielle — le transport est sûr, le contenu non |
| Core ZShield | état reconstruit, ledger, registre d'entités | **autorité** |
| Base SQL | incidents, bans, transactions | fiable mais **faillible** (peut tomber) |
| Dashboard / API centrale | analytics, config, reporting | jamais dans une décision critique (§131) |
| Discord | notification sortante | jamais une source de décision (§39) |

La règle qui traverse tout : le serveur FiveM reste l'autorité même si la base,
le dashboard, Discord et la plateforme centrale sont tous indisponibles
(§38, §130, §173).

---

## 4. Modèle de menace — §142, §143

Pour chaque menace : l'actif visé, la vraisemblance, l'impact, la mitigation, et
le **risque résiduel** — qu'on n'affiche jamais comme nul sous prétexte qu'une
protection existe (§143).

| # | Menace | Actif | Vraisemb. | Impact | Mitigation | Risque résiduel |
|---|---|---|---|---|---|---|
| T1 | Event forgé / rejoué | logique métier | haute | élevé | firewall + schéma + rate limit + auth + état (§04-08) | un event *valide en tout point* passe : c'est voulu, on le corrèle |
| T2 | Argument hors bornes | économie, inventaire | haute | élevé | validation de schéma stricte, bornes serveur (§06, §19, §20) | valeurs dans les bornes mais absurdes en contexte → détection |
| T3 | Money/item/reward falsifié | économie | haute | critique | serveur-authoritative, ledger, jamais la valeur client (§19, §20, §68) | bug de logique métier du serveur lui-même (hors périmètre) |
| T4 | Téléportation / speed / noclip | intégrité de jeu | moyenne | moyen | analyse contextuelle du mouvement, téléports de confiance (§15) | latence extrême imite un saut → confiance basse, pas de ban direct |
| T5 | Spawn d'entités abusif | perf, gameplay | moyenne | moyen | registre + quotas + ownership + lifecycle (§16-18) | quota légitime en mission → contexte augmente le quota |
| T6 | Godmode / dégâts truqués | PvP | moyenne | moyen | validation serveur des dégâts + fréquence + distance (§21) | event de dégât isolé jamais un ban (§21) |
| T7 | Explosion spam | serveur | basse | moyen | quotas, safe zones, allowlist (§22) | explosion scénarisée légitime → exception mission |
| T8 | Ressource cassée (maj tierce) | disponibilité | moyenne | moyen | distinction anomalie joueur / ressource / serveur (§96-100) | faux diagnostic → présenté comme hypothèse, pas fait |
| T9 | SQL indisponible | persistance | moyenne | moyen | event store mémoire + retry + circuit breaker (§37, §52) | perte des events les plus anciens si la file déborde (borné, compté) |
| T10 | Discord / dashboard down | notification | moyenne | faible | intégrations hors chemin critique (§38, §39) | notifications retardées, jamais perdues silencieusement |
| T11 | Admin malveillant | preuves, règles | basse | élevé | RBAC serveur, audit immuable, moindre privilège (§43-44, §145-147) | un owner reste tout-puissant : borné par l'audit append-only |
| T12 | Horloge client | décisions temporelles | basse | moyen | timestamps serveur exclusivement (§149, §150) | dérive d'horloge *serveur* → hors périmètre du client |
| T13 | Faux positif | joueur légitime | **haute** | élevé (réputation produit) | severity≠confidence≠risk, shadow mode, review admin (§11, §31, §89) | aucun système n'a zéro faux positif : on les mesure (§90, §168) |

**T13 est traité comme une menace de premier rang.** Un anticheat qui bannit des
joueurs honnêtes détruit le serveur qu'il protège. D'où la séparation
severity/confidence/risk (§11), le shadow mode (§31), et le fait qu'une décision
incertaine augmente la corrélation au lieu de sanctionner (§178).

---

## 5. Ce que le système ne fait pas — limites assumées

À dire au client plutôt qu'à lui laisser découvrir :

- **Pas de protection parfaite** (§02, §179). Un cheat qui n'émet aucun signal
  observable côté serveur n'est pas détecté par définition. On réduit la
  surface, on ne la supprime pas.
- **Pas de global ban list** partagée entre serveurs comme mécanisme central
  (§65) : risque de bannissements injustifiés. Une réputation éventuelle serait
  opt-in, explicable, réversible.
- **Pas de sécurité par l'obscurité** (§66). L'obfuscation n'est pas une
  protection ; la sécurité repose sur l'autorité serveur et la validation.
- **Pas d'exécution de code distant** (§80). Une mise à jour se vérifie, se
  sauvegarde, se migre — jamais un `load()` de code téléchargé.
- **Le client ne porte aucune logique critique** (§67). Il fournit des signaux.
  S'il ment, le serveur reconstruit la vérité ou déclenche une détection.

---

## 6. Ordre de construction de ce dépôt

Suivant §177, et ce qui est réellement testable en isolation d'abord :

| Étape | Contenu | État |
|---|---|---|
| 1-2 | Architecture, threat model (ce document) | **fait** |
| 3-4 | Core : bus, log, config + validation de config | en cours |
| 5-6 | Event firewall + schéma + rate limit | **fait** |
| 7 | Context engine + state machine | **fait** |
| 8-10 | Detection, correlation, risk | **fait** |
| 11 | Incident engine | **fait** |
| 12 | Enforcement + sanction policy | **fait** |
| 13,15 | Movement analysis, entity security | **fait** |
| 14,19,20 | Economy/inventory ledger | **fait** |
| 18,21 | Vehicle, damage security | à venir |
| 16-17 | Persistence, event store, migrations | **fait** |
| 19 | API publique, SDK de sécurité | **fait** |
| 18 | Telemetry, adapters | à venir |
| 50-51,107 | Health, self-monitoring, bootstrap | **fait** |
| 46 | Framework abstraction (standalone/ESX/QBCore) | **fait** |
| 24,71-73 | FXServer hardening audit | **fait** |
| 18,39 | Discord integration (outbound) | **fait** |
| 161 | README d installation | **fait** |

Chaque couche est livrée avec ses tests Lua exécutés pour de vrai (§55, §176),
son traitement de panne (§104, §178), et sa documentation. Une couche n'est
« faite » que quand ces trois existent — c'est la condition de §180.

Rien ici ne dépend du client pour une décision. C'est la seule invariante qui ne
se négocie pas.
