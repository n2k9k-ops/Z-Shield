-- =============================================================================
-- 001_initial.sql — schéma initial ZSHIELD AC (§36, §60)
--
-- §60 : ne JAMAIS demander de supprimer la base. Migrations numérotées, additives,
-- avec version de schéma. Compatible oxmysql / MySQL 5.7+ / MariaDB.
--
-- §36 : indexes sur les colonnes de recherche (player, created_at, severity, status).
-- Les écritures se font par LOTS (event store), jamais à chaque frame.
-- =============================================================================

CREATE TABLE IF NOT EXISTS zshield_schema_version (
    version     INT NOT NULL,
    applied_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (version)
);

-- Joueurs suivis (§36).
CREATE TABLE IF NOT EXISTS zshield_players (
    identifier      VARCHAR(128) NOT NULL,
    name            VARCHAR(64),
    first_seen      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    risk_score      INT NOT NULL DEFAULT 0,
    risk_level      VARCHAR(16) NOT NULL DEFAULT 'NORMAL',
    PRIMARY KEY (identifier),
    INDEX idx_players_last_seen (last_seen),
    INDEX idx_players_risk (risk_score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Incidents (§28, §36).
CREATE TABLE IF NOT EXISTS zshield_incidents (
    id              VARCHAR(48) NOT NULL,
    player          VARCHAR(128),
    detector        VARCHAR(64),
    category        VARCHAR(32),
    severity        VARCHAR(16) NOT NULL,
    confidence      FLOAT,
    risk_before     INT,
    risk_after      INT,
    scope           VARCHAR(16) NOT NULL DEFAULT 'PLAYER',
    occurrences     INT NOT NULL DEFAULT 1,
    config_version  INT,
    action          VARCHAR(16),
    reason          VARCHAR(400),
    -- Chaîne de preuve sérialisée (signaux, corrélation, timeline).
    evidence        JSON,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_incidents_player (player, created_at),
    INDEX idx_incidents_severity (severity, created_at),
    INDEX idx_incidents_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Signaux (§36). Volumineux : rétention courte configurée applicativement (§64).
CREATE TABLE IF NOT EXISTS zshield_signals (
    id              BIGINT NOT NULL AUTO_INCREMENT,
    player          VARCHAR(128),
    detector        VARCHAR(64),
    category        VARCHAR(32),
    severity        VARCHAR(16),
    confidence      FLOAT,
    score           FLOAT,
    reason          VARCHAR(255),
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_signals_player (player, created_at),
    INDEX idx_signals_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Bannissements (§36). Rétention administrative (§64).
CREATE TABLE IF NOT EXISTS zshield_bans (
    id              VARCHAR(48) NOT NULL,
    identifier      VARCHAR(128) NOT NULL,
    scope           VARCHAR(16) NOT NULL DEFAULT 'identifier',
    reason          VARCHAR(400),
    incident_id     VARCHAR(48),
    issued_by       VARCHAR(128),
    issued_auto     TINYINT(1) NOT NULL DEFAULT 0,
    expires_at      TIMESTAMP NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    lifted_at       TIMESTAMP NULL,
    PRIMARY KEY (id),
    INDEX idx_bans_identifier (identifier),
    INDEX idx_bans_active (identifier, lifted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Ledger économique (§20, §36).
CREATE TABLE IF NOT EXISTS zshield_transactions (
    transaction_id  VARCHAR(48) NOT NULL,
    account         VARCHAR(128) NOT NULL,
    before_amount   BIGINT NOT NULL,
    delta           BIGINT NOT NULL,
    after_amount    BIGINT NOT NULL,
    reason          VARCHAR(64),
    source          VARCHAR(32),
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (transaction_id),
    INDEX idx_txn_account (account, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Actions administratives (§43). Append-only par convention applicative.
CREATE TABLE IF NOT EXISTS zshield_admin_actions (
    id              BIGINT NOT NULL AUTO_INCREMENT,
    actor           VARCHAR(128),
    target          VARCHAR(128),
    action          VARCHAR(32),
    reason          VARCHAR(400),
    incident_id     VARCHAR(48),
    result          VARCHAR(32),
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_admin_actor (actor, created_at),
    INDEX idx_admin_target (target, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Versions de règles (§33, §151).
CREATE TABLE IF NOT EXISTS zshield_rule_versions (
    detector        VARCHAR(64) NOT NULL,
    version         INT NOT NULL,
    enabled         TINYINT(1) NOT NULL DEFAULT 1,
    severity        VARCHAR(16),
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (detector, version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Métriques agrégées (§94, §122). Jamais par tick : agrégées.
CREATE TABLE IF NOT EXISTS zshield_metrics (
    id              BIGINT NOT NULL AUTO_INCREMENT,
    metric          VARCHAR(64) NOT NULL,
    value           DOUBLE NOT NULL,
    window_start    TIMESTAMP NOT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_metrics_name (metric, window_start)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO zshield_schema_version (version) VALUES (1)
    ON DUPLICATE KEY UPDATE applied_at = applied_at;
