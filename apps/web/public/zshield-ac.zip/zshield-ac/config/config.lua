--[[
    config/config.lua — configuration opérateur de ZSHIELD AC.

    Ce fichier retourne (via la globale) les réglages du serveur. Il est validé au
    démarrage contre le schéma (core/config.lua) : une valeur invalide produit une
    erreur claire, pas un comportement imprévisible.

    Par défaut, TOUT est en mode SHADOW : ZShield détecte et journalise mais n'applique
    AUCUNE sanction. C'est volontaire (§31) — on n'active jamais l'enforcement par accident.
    Passez en 'ENFORCE' seulement après avoir observé les détections en shadow.
]]

-- ---------------------------------------------------------------------------
-- TABLE DÉGÂTS/ARME (weaponDamageEvent). On confronte chaque tir aux dégâts de
-- BASE connus de l'arme (+ tolérance) et à sa portée : un pistolet qui inflige
-- 500 de dégâts ou touche à 400 m = modded/silent-aim, coupé au tick zéro.
-- Clés = HASH FiveM de l'arme (joaat du nom en minuscule, == GetHashKey). On
-- ajoute la variante SIGNÉE (négative) car weaponDamageEvent peut donner l'un ou
-- l'autre selon le contexte. Valeurs de base GTA V approximatives mais prudentes
-- (la tolérance de 25 % évite les faux positifs sur un tir légitime).
-- ---------------------------------------------------------------------------
local function zsJoaat(s)
    s = string.lower(s)
    local h = 0
    for i = 1, #s do
        h = (h + s:byte(i)) & 0xFFFFFFFF
        h = (h + (h << 10)) & 0xFFFFFFFF
        h = (h ~ (h >> 6)) & 0xFFFFFFFF
    end
    h = (h + (h << 3)) & 0xFFFFFFFF
    h = (h ~ (h >> 11)) & 0xFFFFFFFF
    h = (h + (h << 15)) & 0xFFFFFFFF
    return h
end

-- name -> { base = dégâts/coup, range = portée max (m) }
local ZS_WEAPON_SPECS = {
    WEAPON_PISTOL={base=26,range=80}, WEAPON_COMBATPISTOL={base=27,range=90},
    WEAPON_APPISTOL={base=20,range=80}, WEAPON_PISTOL50={base=51,range=90},
    WEAPON_HEAVYPISTOL={base=40,range=90}, WEAPON_VINTAGEPISTOL={base=34,range=80},
    WEAPON_SNSPISTOL={base=24,range=60}, WEAPON_SNSPISTOL_MK2={base=24,range=60},
    WEAPON_PISTOL_MK2={base=26,range=90}, WEAPON_REVOLVER={base=97,range=120},
    WEAPON_REVOLVER_MK2={base=97,range=120}, WEAPON_DOUBLEACTION={base=63,range=110},
    WEAPON_MARKSMANPISTOL={base=143,range=120}, WEAPON_CERAMICPISTOL={base=32,range=70},
    WEAPON_NAVYREVOLVER={base=92,range=120},
    WEAPON_MICROSMG={base=21,range=90}, WEAPON_SMG={base=22,range=110},
    WEAPON_SMG_MK2={base=22,range=110}, WEAPON_ASSAULTSMG={base=23,range=110},
    WEAPON_COMBATPDW={base=24,range=120}, WEAPON_MACHINEPISTOL={base=20,range=80},
    WEAPON_MINISMG={base=21,range=90}, WEAPON_GUSENBERG={base=34,range=120},
    WEAPON_ASSAULTRIFLE={base=30,range=160}, WEAPON_ASSAULTRIFLE_MK2={base=32,range=170},
    WEAPON_CARBINERIFLE={base=32,range=170}, WEAPON_CARBINERIFLE_MK2={base=34,range=180},
    WEAPON_ADVANCEDRIFLE={base=34,range=160}, WEAPON_SPECIALCARBINE={base=33,range=170},
    WEAPON_SPECIALCARBINE_MK2={base=34,range=180}, WEAPON_BULLPUPRIFLE={base=32,range=160},
    WEAPON_BULLPUPRIFLE_MK2={base=33,range=170}, WEAPON_COMPACTRIFLE={base=30,range=140},
    WEAPON_MILITARYRIFLE={base=34,range=170}, WEAPON_HEAVYRIFLE={base=34,range=170},
    WEAPON_MG={base=43,range=180}, WEAPON_COMBATMG={base=45,range=180},
    WEAPON_COMBATMG_MK2={base=46,range=190},
    WEAPON_PUMPSHOTGUN={base=48,range=45}, WEAPON_PUMPSHOTGUN_MK2={base=50,range=50},
    WEAPON_SAWNOFFSHOTGUN={base=48,range=35}, WEAPON_ASSAULTSHOTGUN={base=34,range=45},
    WEAPON_BULLPUPSHOTGUN={base=28,range=45}, WEAPON_HEAVYSHOTGUN={base=42,range=50},
    WEAPON_DBSHOTGUN={base=68,range=40}, WEAPON_COMBATSHOTGUN={base=40,range=50},
    WEAPON_SNIPERRIFLE={base=101,range=800}, WEAPON_HEAVYSNIPER={base=216,range=1000},
    WEAPON_HEAVYSNIPER_MK2={base=216,range=1200}, WEAPON_MARKSMANRIFLE={base=65,range=400},
    WEAPON_MARKSMANRIFLE_MK2={base=66,range=420},
    WEAPON_MINIGUN={base=19,range=150}, WEAPON_COMBATMG_EXTENDED={base=45,range=180},
}

local function zsBuildWeaponTable()
    local t = {}
    for name, spec in pairs(ZS_WEAPON_SPECS) do
        local u = zsJoaat(name)                 -- hash non signé
        local model = { base = spec.base, range = spec.range, min_ms = 60 }
        t[u] = model
        if u >= 0x80000000 then t[u - 0x100000000] = model end  -- variante signée
    end
    return t
end
local ZS_WEAPONS = zsBuildWeaponTable()

ZShieldConfig = {
    mode = 'SHADOW', -- OFF | SHADOW | MONITOR | ENFORCE

    logging = {
        level = 'INFO',
        console = true,
    },

    scoring = {
        enabled = true,
        decay = true,
        decay_half_life_s = 600,
        thresholds = {
            observe = 15, suspicious = 32, high_risk = 52, critical = 72,
        },
    },

    events = { enabled = true, unknown_policy = 'monitor' },
    entities = { enabled = true, default_quota = 50 },
    movement = { enabled = true, max_ground_speed_ms = 40.0, max_tick_distance_m = 55.0 },

    -- Game Event Firewall (§08) : blocage natif explosion/damage/entité à la source.
    game_events = {
        enabled = true,
        block_explosion_flood = true,
        explosion_rate = 4,      -- explosions/s tolérées par joueur (cran max)
        explosion_burst = 7,
        max_weapon_damage = 200, -- plafond dur de dégâts d'arme (au-delà = modifié)
        -- Explosion à dégâts sans propriétaire réseau = explosionEvent falsifié.
        -- Signalée par défaut ; passe block_* à true pour l'annuler à la source.
        -- Filet de sécurité : supprimer l'entité si elle existe malgré le blocage (§16).
        delete_on_block = true,
        flag_spoofed_owner_explosion = true,
        block_spoofed_owner_explosion = true,
        spoofed_owner_min_damage = 0.1,
        -- entity_model_blacklist = { [hash] = true },  -- optionnel
    },

    -- State Bag Security (§10) : les clés serveur ci-dessous ne peuvent être fixées par
    -- un client. Complète la liste par défaut (godmode, money, isAdmin, …).
    statebags = {
        enabled = true,
        max_writes_10s = 14,
        -- Détecteur d'exploit de state bags (server/detection/statebag.lua) :
        window_ms = 10000,        -- fenêtre de mesure du flood
        max_changes = 45,         -- changements/joueur/fenêtre au-delà = flood (crash)
        max_value_bytes = 65536,  -- charge au-delà = tentative de crash mémoire
        -- Clés PROTÉGÉES : seul le serveur peut les écrire. Une écriture cliente = incident.
        -- Ajoute ici tes drapeaux sensibles (admin, godmode, job, cuffed…).
        protect = {
            -- ['zshield:trust'] = { writer = 'server' },
            -- ['isAdmin']       = { writer = 'server' },
            -- ['godmode']       = { writer = 'server' },
        },
    },

    -- Native Security Orchestrator (§21). INACTIF par défaut : n'altère rien.
    -- Passez lockdown_mode à 'relaxed' (recommandé) ou 'strict' pour empêcher, côté moteur,
    -- la création d'entités par les clients — la protection la plus puissante à coût nul.
    onesync = {
        enabled = false,
        bucket = 0,
        lockdown_mode = 'inactive',  -- inactive | relaxed | strict
        disable_population = false,
        orphan_keep = false,
    },

    performance = { enabled = true, budget_ms = 2.0 },

    -- Licence : collez ici la clé fournie à l'achat (ou à l'essai gratuit).
    -- Vide = protection désactivée, avec un message au démarrage du serveur.
    -- >>> Clé de test AUTO-SIGNÉE (propriétaire, ~10 ans, tous serveurs). Elle est valide
    --     avec le secret de signature PAR DÉFAUT du dépôt. En production, changez le secret
    --     (server/license.lua) ET réémettez vos clés — sinon n'importe qui peut en forger.
    license = { key = 'v1|any|owner|1790343926|2105703926~5fbf23a125a88bcc90fa0a108b1bd1ea6d94b36063e92dc532a11a7e72a19eea' },

    -- graduated = true : sanctions ESCALADANTES à la récidive (kick -> ban temp -> ban perm).
    -- Protection « au niveau au-dessus » — sûr car le staff est exempté (bloc staff ci-dessus).
    enforcement = { enabled = true, two_phase = true, graduated = true },
    persistence = { enabled = true, event_store_max = 5000, flush_interval_ms = 5000 },
    integrations = { discord_enabled = false, agent_enabled = false },

    -- =====================================================================
    -- DÉTECTEURS AVANCÉS (vagues 1→8). Activés ici, mais le mode global reste
    -- SHADOW : ils DÉTECTENT et JOURNALISENT sans jamais sanctionner tant que
    -- vous n'êtes pas passé en MONITOR puis ENFORCE. Sûr par défaut.
    -- Ceux qui exigent une intégration (exports depuis votre framework) sont
    -- notés « [intégration] » — ils restent silencieux tant que non alimentés.
    -- =====================================================================

    -- Actifs dès l'installation (events natifs serveur / échantillonnage position) :
    flight     = { enabled = true, blink_distance_m = 60, max_climb_speed_ms = 15, max_altitude_m = 1200 },
    teleport   = { enabled = true, min_jump_m = 90, window_ms = 30000, min_repeats = 2 },

    -- STAFF / ADMIN : jamais sanctionné ni contenu par l'anticheat (freecam, noclip,
    -- spectate, teleport = leur travail). Autorité : permission framework (isAdmin),
    -- permissions ACE (txAdmin/vMenu/custom), ou liste d'identifiants. On enregistre quand
    -- même pour la traçabilité. Mets exempt=false pour désactiver (déconseillé).
    staff = {
        exempt = true,
        -- Permissions ACE reconnues comme staff. Ajoute celles de ton menu admin.
        -- txAdmin : 'txadmin.menu.viewids' ; vMenu : 'vMenu.Staff.*' ; custom : 'zshield.exempt'.
        ace_perms = { 'zshield.exempt', 'txadmin.menu.viewids', 'command' },
        -- Identifiants staff explicites (en plus des ACE), ex. 'license:xxxxx', 'discord:123'.
        identifiers = {},
    },

    -- Anti-faux-positif : honorer les exemptions (intérieur/instance/mission/spectateur)
    -- posées par l'adaptateur framework. true = un joueur exempté n'est pas analysé en
    -- mouvement/téléport (ses déplacements « impossibles » y sont légitimes).
    false_positive = { exempt_states = true },

    -- Whitelist de commandes (optionnelle). whitelist_enabled=true => une commande hors
    -- liste est signalée (corroborant, pas un ban sec).
    command    = { detector = true, max_per_sec = 6, whitelist_enabled = false, whitelist = {} },

    -- Vol de véhicule : véhicule NON aérien maintenu en l'air (durée + hauteur mini).
    vehicle    = { detector = true, fly_min_airborne_ms = 3000, fly_min_altitude_m = 6 },
    freecam    = { enabled = true, hold_ms = 3000, min_activity = 4 },
    crashguard = { enabled = true, max_coord = 1e6, max_scale = 100 },
    ownership  = { enabled = true, window_ms = 3000, max_ownership = 18, max_create = 14 },
    chatspam   = { enabled = true, window_ms = 10000, max_messages = 6, max_duplicates = 2 },
    envelope   = { enabled = true, window_ms = 10000, default_quota = 45 },
    invariants = { enabled = true },
    selfprotect = { enabled = true, protected_resources = { 'zshield-ac', 'zshield-agent', 'zshield-client' },
                    watchdog_timeout_ms = 20000 },
    -- Anti-executor + signatures de MENUS DE TRICHE connus (Lapsus & confrères). Le
    -- match est par sous-chaîne (insensible à la casse) sur le nom de ressource/event
    -- émetteur. Renommable par le tricheur -> l'allowlist reste la défense principale,
    -- mais ces signatures attrapent les setups paresseux/non modifiés. L'opérateur peut
    -- allonger la liste. (Défensif : détection uniquement, aucune aide à l'usage.)
    -- Signatures de MENUS DE TRICHE connus (recherche 26/09). Match par sous-chaîne sur
    -- ressource/event émetteur. HONNÊTE : renommables -> signal FAIBLE (score), jamais un
    -- ban sec ; la vraie défense est comportementale (serveur-autoritative) + honeypots.
    executor   = { enabled = true, blocklist_patterns = {
        'executor', 'injectlua', 'runcode', 'lua_exec',
        'eulen', 'redengine', 'red_engine', 'unex', 'lapsus',
        'susano', 'susanoo', 'tzx', 'tsunami', 'skript', 'hydrogen',
        'brutan', 'absolute menu', 'lumia menu', 'impaught', 'desudo',
    } },
    -- Traces d'injection : seuil de ban + signatures d'exports/globals de triche.
    -- Capture d'écran à la demande (preuve d'incident, via zshield-client).
    -- Désactivé par défaut : nécessite screenshot-basic côté client + une URL d'upload.
    evidence   = { enabled = false, upload_url = '' },

    injection  = { trace_threshold = 5, stop_on_backdoor = false,
        -- Types de trace qui BANNISSENT au premier coup (signaux non ambigus). Ajoute
        -- des types ici pour être plus agressif (au prix d'un risque de faux positif
        -- accru si tu ajoutes des signaux ambigus).
        instant_ban_kinds = { 'phantom_event', 'forbidden_export', 'server_dump',
                              'protected_event_from_client', 'exec_outside_resource', 'crash_attempt' },
        -- Bannir l'auteur d'une tentative de crash (valeurs impossibles), en plus de
        -- bloquer l'event. true = ban immédiat (le crash est non ambigu).
        ban_on_crash = true,
        cheat_signatures = {
        'eulen', 'redengine', 'unex', 'lapsus', 'susano', 'susanoo',
        'brutan', 'skript', 'hydrogen', 'tzx', 'tsunami',
    } },
    -- Gestion des connexions : lockdown (whitelist-only) + anti-raid.
    connection = {
        max_threat_score = 100,
        anti_duplication = true,
        -- LOCKDOWN : ferme le serveur aux identifiants non whitelistés. Active à la main
        -- (lockdown=true) ou par la convar `set zshield_lockdown "true"`, ou auto sur raid.
        lockdown = false,
        whitelist = {},            -- identifiants autorisés en lockdown (license:..., etc.)
        -- ANTI-RAID : rafale de connexions dans la fenêtre -> alerte (+ lockdown auto).
        raid_window_ms = 15000,
        raid_max = 6,
        auto_lockdown = false,     -- true = déclenche le lockdown automatiquement sur raid
        auto_lockdown_seconds = 120,
    },
    -- Honeypots : events APPÂTS qu'aucun client légitime ne déclenche (tricheur confirmé).
    -- events = nil -> liste par défaut (voir honeypot.lua). Zéro faux positif si les noms
    -- n'existent pas ailleurs sur ton serveur ; complète/retire selon ton framework.
    honeypot   = { enabled = true, events = nil },
    -- Anti server-dumper : énumération/dump d'events en rafale (vol de logique serveur).
    antidump   = { enabled = true, window_ms = 8000, max_distinct = 18, max_unknown = 6, reject = false },
    menu       = { enabled = true, burst_window_ms = 4000, burst_max = 4 },
    reputation = { enabled = true, decay_per_hour = 5, max = 100, join_threshold = 50 },
    behavior   = { enabled = true, min_actions = 10, max_cv = 0.05 },
    clocksync  = { enabled = true, min_samples = 8, max_ratio = 1.10 },
    fusion     = { enabled = true, threshold = 3.2, decay_per_sec = 0.02 },
    trainer    = { enabled = true, window_ms = 15000, min_distinct = 2 },

    -- [intégration] — nécessitent des appels d'exports depuis votre framework (voir
    -- docs/DEPLOIEMENT.md § Intégration). Activés mais silencieux tant que non alimentés :
    damage_integrity = { enabled = true, default_base = 60, default_min_ms = 80, default_range_m = 120, tolerance_pct = 0.18,
                         weapons = ZS_WEAPONS },   -- table dégâts/portée par arme (hashes)
    aimstats   = { enabled = true, min_samples = 24, headshot_ratio_max = 0.62, snap_deg_mean_max = 40, reaction_ms_min = 110,
                   react_cv_min = 0.12 },  -- CV de réaction sous ce seuil = timing machine (triggerbot)
    hitreg     = { enabled = true, max_rewind_ms = 1000, default_range = 120, angle_tol_deg = 9 },
    sequence   = { enabled = true, check_dead = true, check_weapon_provenance = false, check_spawn = true },
    provenance = { enabled = true, window_ms = 8000, min_amount = 100, tolerance_pct = 0.04 },
    reconcile  = { enabled = true, max_health = 200, tolerance = 1 },
    budget     = { enabled = true, default_magazine = 30, max_sprint_ms = 45000, roll_window_ms = 10000, roll_max = 5 },
    spawnprotect = { enabled = true, protect_ms = 5000 },
    desync     = { enabled = true, max_origin_m = 6, lagswitch_enabled = true, min_gap_ms = 1500 },
    esp        = { enabled = true, stream_range_m = 300, window_ms = 5000, max_far_requests = 9 },
    reach      = { enabled = true, max_melee_m = 3.5, max_interact_m = 5 },
    godmode    = { enabled = true, min_damage = 3, veh_enabled = true, veh_repair_delta = 200 },
    markov     = { enabled = true, min_events = 30, min_entropy = 0.25 },
    sprt       = { enabled = true, alpha = 0.01, beta = 0.05, p0 = 0.15, p1 = 0.55 },
    baseline   = { enabled = true, min_samples = 20, z_max = 3.0, consecutive = 3, direction = 'both' },

    -- Échantillonnage de position serveur (alimente flight/teleport/freecam).
    wiring = { position_sample_ms = 500 },
}
