--[[
    config/config.lua — configuration opérateur de ZSHIELD AC.

    Ce fichier retourne (via la globale) les réglages du serveur. Il est validé au
    démarrage contre le schéma (core/config.lua) : une valeur invalide produit une
    erreur claire, pas un comportement imprévisible.

    Par défaut, TOUT est en mode SHADOW : ZShield détecte et journalise mais n'applique
    AUCUNE sanction. C'est volontaire (§31) — on n'active jamais l'enforcement par accident.
    Passez en 'ENFORCE' seulement après avoir observé les détections en shadow.
]]

ZShieldConfig = {
    mode = 'SHADOW', -- OFF | SHADOW | MONITOR | ENFORCE

    logging = {
        level = 'INFO',
        console = true,
    },

    scoring = {
        enabled = true,
        decay = true,
        decay_half_life_s = 600,
        thresholds = {
            observe = 20, suspicious = 40, high_risk = 65, critical = 85,
        },
    },

    events = { enabled = true, unknown_policy = 'monitor' },
    entities = { enabled = true, default_quota = 50 },
    movement = { enabled = true, max_ground_speed_ms = 50.0, max_tick_distance_m = 75.0 },

    -- Game Event Firewall (§08) : blocage natif explosion/damage/entité à la source.
    game_events = {
        enabled = true,
        block_explosion_flood = true,
        explosion_rate = 6,      -- explosions/s tolérées par joueur
        explosion_burst = 10,
        max_weapon_damage = 250, -- plafond dur de dégâts d'arme (au-delà = modifié)
        -- entity_model_blacklist = { [hash] = true },  -- optionnel
    },

    -- State Bag Security (§10) : les clés serveur ci-dessous ne peuvent être fixées par
    -- un client. Complète la liste par défaut (godmode, money, isAdmin, …).
    statebags = {
        enabled = true,
        max_writes_10s = 20,
        -- Détecteur d'exploit de state bags (server/detection/statebag.lua) :
        window_ms = 10000,        -- fenêtre de mesure du flood
        max_changes = 60,         -- changements/joueur/fenêtre au-delà = flood (crash)
        max_value_bytes = 65536,  -- charge au-delà = tentative de crash mémoire
        -- Clés PROTÉGÉES : seul le serveur peut les écrire. Une écriture cliente = incident.
        -- Ajoute ici tes drapeaux sensibles (admin, godmode, job, cuffed…).
        protect = {
            -- ['zshield:trust'] = { writer = 'server' },
            -- ['isAdmin']       = { writer = 'server' },
            -- ['godmode']       = { writer = 'server' },
        },
    },

    -- Native Security Orchestrator (§21). INACTIF par défaut : n'altère rien.
    -- Passez lockdown_mode à 'relaxed' (recommandé) ou 'strict' pour empêcher, côté moteur,
    -- la création d'entités par les clients — la protection la plus puissante à coût nul.
    onesync = {
        enabled = false,
        bucket = 0,
        lockdown_mode = 'inactive',  -- inactive | relaxed | strict
        disable_population = false,
        orphan_keep = false,
    },

    performance = { enabled = true, budget_ms = 2.0 },

    -- Licence : collez ici la clé fournie à l'achat (ou à l'essai gratuit).
    -- Vide = protection désactivée, avec un message au démarrage du serveur.
    -- >>> Clé de test AUTO-SIGNÉE (propriétaire, ~10 ans, tous serveurs). Elle est valide
    --     avec le secret de signature PAR DÉFAUT du dépôt. En production, changez le secret
    --     (server/license.lua) ET réémettez vos clés — sinon n'importe qui peut en forger.
    license = { key = 'v1|any|owner|1790343926|2105703926~5fbf23a125a88bcc90fa0a108b1bd1ea6d94b36063e92dc532a11a7e72a19eea' },

    enforcement = { enabled = true, two_phase = true },
    persistence = { enabled = true, event_store_max = 5000, flush_interval_ms = 5000 },
    integrations = { discord_enabled = false, agent_enabled = false },

    -- =====================================================================
    -- DÉTECTEURS AVANCÉS (vagues 1→8). Activés ici, mais le mode global reste
    -- SHADOW : ils DÉTECTENT et JOURNALISENT sans jamais sanctionner tant que
    -- vous n'êtes pas passé en MONITOR puis ENFORCE. Sûr par défaut.
    -- Ceux qui exigent une intégration (exports depuis votre framework) sont
    -- notés « [intégration] » — ils restent silencieux tant que non alimentés.
    -- =====================================================================

    -- Actifs dès l'installation (events natifs serveur / échantillonnage position) :
    flight     = { enabled = true, blink_distance_m = 75, max_climb_speed_ms = 20, max_altitude_m = 1500 },
    teleport   = { enabled = true, min_jump_m = 120, window_ms = 30000, min_repeats = 3 },
    freecam    = { enabled = true, hold_ms = 4000, min_activity = 5 },
    crashguard = { enabled = true, max_coord = 1e6, max_scale = 100 },
    ownership  = { enabled = true, window_ms = 3000, max_ownership = 25, max_create = 20 },
    chatspam   = { enabled = true, window_ms = 10000, max_messages = 8, max_duplicates = 3 },
    envelope   = { enabled = true, window_ms = 10000, default_quota = 60 },
    invariants = { enabled = true },
    selfprotect = { enabled = true, protected_resources = { 'zshield-ac', 'zshield-agent', 'zshield-client' },
                    watchdog_timeout_ms = 20000 },
    -- Anti-executor + signatures de MENUS DE TRICHE connus (Lapsus & confrères). Le
    -- match est par sous-chaîne (insensible à la casse) sur le nom de ressource/event
    -- émetteur. Renommable par le tricheur -> l'allowlist reste la défense principale,
    -- mais ces signatures attrapent les setups paresseux/non modifiés. L'opérateur peut
    -- allonger la liste. (Défensif : détection uniquement, aucune aide à l'usage.)
    executor   = { enabled = true, blocklist_patterns = {
        'executor', 'injectlua', 'runcode', 'lua_exec',
        'lapsus', 'eulen', 'redengine', 'red_engine', 'susano',
        'impaught', 'brutan', 'skript', 'tzx', 'hydrogen', 'desudo',
    } },
    -- Traces d'injection : seuil de ban + signatures d'exports/globals de triche.
    injection  = { trace_threshold = 5, stop_on_backdoor = false, cheat_signatures = {
        'lapsus', 'eulen', 'redengine', 'susano', 'impaught', 'brutan',
    } },
    -- Anti server-dumper : énumération/dump d'events en rafale (vol de logique serveur).
    antidump   = { enabled = true, window_ms = 8000, max_distinct = 25, max_unknown = 8, reject = false },
    menu       = { enabled = true, burst_window_ms = 4000, burst_max = 5 },
    reputation = { enabled = true, decay_per_hour = 5, max = 100, join_threshold = 60 },
    behavior   = { enabled = true, min_actions = 12, max_cv = 0.06 },
    clocksync  = { enabled = true, min_samples = 8, max_ratio = 1.15 },
    fusion     = { enabled = true, threshold = 4.0, decay_per_sec = 0.02 },
    trainer    = { enabled = true, window_ms = 15000, min_distinct = 3 },

    -- [intégration] — nécessitent des appels d'exports depuis votre framework (voir
    -- docs/DEPLOIEMENT.md § Intégration). Activés mais silencieux tant que non alimentés :
    damage_integrity = { enabled = true, default_base = 60, default_min_ms = 80, default_range_m = 120, tolerance_pct = 0.25 },
    aimstats   = { enabled = true, min_samples = 30, headshot_ratio_max = 0.70, snap_deg_mean_max = 45, reaction_ms_min = 90 },
    hitreg     = { enabled = true, max_rewind_ms = 1000, default_range = 120, angle_tol_deg = 12 },
    sequence   = { enabled = true, check_dead = true, check_weapon_provenance = false, check_spawn = true },
    provenance = { enabled = true, window_ms = 8000, min_amount = 100, tolerance_pct = 0.05 },
    reconcile  = { enabled = true, max_health = 200, tolerance = 1 },
    budget     = { enabled = true, default_magazine = 30, max_sprint_ms = 45000, roll_window_ms = 10000, roll_max = 6 },
    spawnprotect = { enabled = true, protect_ms = 5000 },
    desync     = { enabled = true, max_origin_m = 8, lagswitch_enabled = true, min_gap_ms = 1500 },
    esp        = { enabled = true, stream_range_m = 300, window_ms = 5000, max_far_requests = 12 },
    reach      = { enabled = true, max_melee_m = 4, max_interact_m = 6 },
    godmode    = { enabled = true, min_damage = 5, veh_enabled = true, veh_repair_delta = 200 },
    markov     = { enabled = true, min_events = 30, min_entropy = 0.25 },
    sprt       = { enabled = true, alpha = 0.01, beta = 0.05, p0 = 0.15, p1 = 0.55 },
    baseline   = { enabled = true, min_samples = 20, z_max = 3.5, consecutive = 4, direction = 'both' },

    -- Échantillonnage de position serveur (alimente flight/teleport/freecam).
    wiring = { position_sample_ms = 500 },
}
