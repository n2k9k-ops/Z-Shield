--[[
    FILE:         shared/schema.lua
    PURPOSE:      Validation de schéma générique (§06). Toute structure franchissant une
                  frontière de confiance — argument d'event, patch de config, payload — est
                  validée ici avant qu'un seul champ ne soit lu par la logique.
    DEPENDENCIES: shared/constants.lua, core/util.lua
    PUBLIC API:   ZShield.Schema.validate(value, schema, path) -> ok, errorString
                  ZShield.Schema.coerce(value, schema) -> value assaini (défauts appliqués)

    §06 impose les types : string, number, integer, float, boolean, table, array, enum,
    vector3, playerId, entityId. Et les contraintes : required, optional, min, max,
    length, pattern, enum, custom.

    DESIGN : un champ inconnu est REJETÉ par défaut (strict). Ignorer un champ inattendu,
    c'est accepter qu'un client d'une version future — ou un attaquant — injecte des
    données qu'on stocke sans les comprendre. Ne lève jamais sur donnée invalide :
    retourne false + raison, pour que le firewall en fasse un signal (§06).
]]

ZShield = ZShield or {}
local Util = ZShield.Util

local Schema = {}

local function fail(path, msg)
    return false, string.format('%s: %s', path ~= '' and path or '<root>', msg)
end

-- Vérificateurs de type de base.
local checkers = {
    string  = function(v) return type(v) == 'string' end,
    number  = function(v) return type(v) == 'number' and v == v end, -- rejette NaN
    integer = function(v) return type(v) == 'number' and v % 1 == 0 end,
    float   = function(v) return type(v) == 'number' and v == v end,
    boolean = function(v) return type(v) == 'boolean' end,
    table   = function(v) return type(v) == 'table' end,
    array   = function(v) return Util.isArray(v) end,
    any     = function() return true end,
    -- Types spécifiques FiveM. Un playerId/entityId est un entier positif ; on ne
    -- vérifie pas ici son EXISTENCE (c'est le rôle du contexte serveur), seulement la forme.
    playerId = function(v) return type(v) == 'number' and v % 1 == 0 and v >= 0 end,
    entityId = function(v) return type(v) == 'number' and v % 1 == 0 and v >= 0 end,
    vector3 = function(v)
        -- Accepte soit un vector3 natif (champs x/y/z) soit une table {x,y,z}.
        return type(v) == 'table'
            and type(v.x) == 'number' and type(v.y) == 'number' and type(v.z) == 'number'
    end,
}

--- Valide `value` contre `schema`.
--- Schéma : { type, required, default, min, max, length, pattern, enum, fields,
---            items, allowUnknown, custom }
function Schema.validate(value, schema, path)
    path = path or ''

    if value == nil then
        if schema.required then return fail(path, 'is required') end
        return true
    end

    local checker = checkers[schema.type or 'any']
    if not checker then return fail(path, 'schema declares unknown type ' .. tostring(schema.type)) end
    if not checker(value) then
        return fail(path, string.format('expected %s, got %s', schema.type, type(value)))
    end

    -- Bornes numériques OU longueur (string/array).
    if schema.min or schema.max then
        local measure
        if schema.type == 'string' or schema.type == 'array' then measure = #value else measure = value end
        if schema.min and measure < schema.min then
            return fail(path, string.format('below minimum %s', schema.min))
        end
        if schema.max and measure > schema.max then
            return fail(path, string.format('exceeds maximum %s', schema.max))
        end
    end

    -- Longueur exacte / bornée pour string et array.
    if schema.length and (schema.type == 'string' or schema.type == 'array') and #value ~= schema.length then
        return fail(path, string.format('length must be %s', schema.length))
    end

    if schema.pattern and schema.type == 'string' and not value:match(schema.pattern) then
        return fail(path, 'does not match required format')
    end

    if schema.enum then
        local ok = false
        for i = 1, #schema.enum do if schema.enum[i] == value then ok = true break end end
        if not ok then return fail(path, 'not an accepted value') end
    end

    if schema.type == 'array' and schema.items then
        for i = 1, #value do
            local ok, err = Schema.validate(value[i], schema.items, string.format('%s[%d]', path, i))
            if not ok then return false, err end
        end
    end

    if schema.type == 'table' and schema.fields then
        for key, sub in pairs(schema.fields) do
            local child = path == '' and key or (path .. '.' .. key)
            local ok, err = Schema.validate(value[key], sub, child)
            if not ok then return false, err end
        end
        if not schema.allowUnknown then
            for key in pairs(value) do
                if schema.fields[key] == nil then
                    return fail(path, string.format('unknown field %q', tostring(key)))
                end
            end
        end
    end

    if schema.custom then
        local ok, err = schema.custom(value)
        if not ok then return fail(path, err or 'failed custom validation') end
    end

    return true
end

--- Applique les défauts d'un schéma table à une copie, puis retourne cette copie.
--- N'échoue pas ; c'est validate() qui décide de la validité.
---
--- Descend récursivement dans les champs table, MÊME absents : sans cela, une config
--- vide laisse `scoring.thresholds` à nil au lieu d'appliquer ses défauts imbriqués.
function Schema.coerce(value, schema)
    if schema.type ~= 'table' or not schema.fields then return value end
    local out = Util.deepCopy(value or {})
    for key, sub in pairs(schema.fields) do
        if sub.type == 'table' and sub.fields then
            -- Champ table : on descend toujours, en partant de {} s'il est absent, pour
            -- que ses propres défauts (et ceux de ses sous-tables) s'appliquent.
            out[key] = Schema.coerce(out[key] or (sub.default ~= nil and Util.deepCopy(sub.default)) or {}, sub)
        elseif out[key] == nil and sub.default ~= nil then
            out[key] = Util.deepCopy(sub.default)
        end
    end
    return out
end

ZShield.Schema = Schema
