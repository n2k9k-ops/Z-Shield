--[[
    FILE:         shared/constants.lua
    PURPOSE:      Source unique des versions, énumérations et bornes du core. Rien ici
                  n'est configurable à l'exécution ; ce qu'un opérateur peut légitimement
                  régler vit dans config/config.lua.
    DEPENDENCIES: aucune (doit charger en premier)
    PUBLIC API:   ZShield.Const (lecture seule par convention)

    NOTE §175 : pas de magic number ailleurs dans le code. Toute constante métier est
    nommée ici ou dérivée de la configuration.
]]

ZShield = ZShield or {}

local C = {}

C.VERSION = '1.0.0'
C.CONFIG_SCHEMA_VERSION = 1
C.DB_SCHEMA_VERSION = 1

-- ---------------------------------------------------------------------------
-- Modes de fonctionnement — §31
-- OFF     : le core est chargé mais inerte (aucune détection, aucune sanction)
-- SHADOW  : détecte et journalise, AUCUNE sanction. Pour déployer une règle sans risque.
-- MONITOR : détecte, journalise, notifie ; sanctions non destructives seulement.
-- ENFORCE : chaîne complète, sanctions actives.
-- ---------------------------------------------------------------------------
C.MODE = {
    OFF     = 'OFF',
    SHADOW  = 'SHADOW',
    MONITOR = 'MONITOR',
    ENFORCE = 'ENFORCE',
}

-- ---------------------------------------------------------------------------
-- Gravité, confiance, risque — §11
-- Trois axes SÉPARÉS. Une anomalie peut être spectaculaire (severity HIGH) mais
-- incertaine (confidence 0.2), ce qui doit donner un risque faible. Les mélanger
-- est la cause n°1 des faux positifs.
-- ---------------------------------------------------------------------------
C.SEVERITY = { LOW = 'LOW', MEDIUM = 'MEDIUM', HIGH = 'HIGH', CRITICAL = 'CRITICAL' }

-- Poids de gravité, utilisés par le risk engine. Volontairement non linéaires :
-- un CRITICAL pèse bien plus qu'un LOW, mais reste borné.
C.SEVERITY_WEIGHT = { LOW = 5, MEDIUM = 15, HIGH = 35, CRITICAL = 70 }

C.SEVERITY_ORDER = { 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL' }

-- Niveaux de risque joueur — §13. Seuils par défaut ; l'opérateur peut les ajuster.
C.RISK_LEVEL = {
    NORMAL     = 'NORMAL',
    OBSERVE    = 'OBSERVE',
    SUSPICIOUS = 'SUSPICIOUS',
    HIGH_RISK  = 'HIGH_RISK',
    CRITICAL   = 'CRITICAL',
}
C.RISK_LEVEL_ORDER = { 'NORMAL', 'OBSERVE', 'SUSPICIOUS', 'HIGH_RISK', 'CRITICAL' }

-- ---------------------------------------------------------------------------
-- Machine à états du joueur — §08
-- ---------------------------------------------------------------------------
C.PLAYER_STATE = {
    CONNECTING = 'CONNECTING',
    CONNECTED  = 'CONNECTED',
    SPAWNING   = 'SPAWNING',
    ACTIVE     = 'ACTIVE',
    MISSION    = 'MISSION',
    VEHICLE    = 'VEHICLE',
    DEAD       = 'DEAD',
    RESPAWN    = 'RESPAWN',
    DISCONNECTED = 'DISCONNECTED',
}

-- Transitions autorisées. Une transition absente d'ici est refusée et journalisée :
-- passer de DEAD à MISSION sans RESPAWN est en soi un signal.
C.STATE_TRANSITIONS = {
    CONNECTING = { CONNECTED = true, DISCONNECTED = true },
    CONNECTED  = { SPAWNING = true, DISCONNECTED = true },
    SPAWNING   = { ACTIVE = true, DISCONNECTED = true },
    ACTIVE     = { MISSION = true, VEHICLE = true, DEAD = true, DISCONNECTED = true },
    MISSION    = { ACTIVE = true, VEHICLE = true, DEAD = true, DISCONNECTED = true },
    VEHICLE    = { ACTIVE = true, MISSION = true, DEAD = true, DISCONNECTED = true },
    DEAD       = { RESPAWN = true, DISCONNECTED = true },
    RESPAWN    = { SPAWNING = true, ACTIVE = true, DISCONNECTED = true },
    DISCONNECTED = {},
}

-- ---------------------------------------------------------------------------
-- Catégories de détecteurs — §10
-- ---------------------------------------------------------------------------
C.CATEGORY = {
    EVENT     = 'event',
    MOVEMENT  = 'movement',
    ENTITY    = 'entity',
    ECONOMY   = 'economy',
    DAMAGE    = 'damage',
    RESOURCE  = 'resource',
    STATE     = 'state',
    NETWORK   = 'network',
}

-- Classification d'anomalie — §99. Un pic n'est pas forcément un joueur.
C.ANOMALY_SCOPE = {
    PLAYER        = 'PLAYER',
    RESOURCE      = 'RESOURCE',
    SERVER        = 'SERVER',
    NETWORK       = 'NETWORK',
    CONFIGURATION = 'CONFIGURATION',
    UNKNOWN       = 'UNKNOWN',
}

-- ---------------------------------------------------------------------------
-- Actions de sanction — §86. Ordonnées du plus doux au plus dur.
-- ---------------------------------------------------------------------------
C.ACTION = {
    LOG      = 'LOG',
    WARN     = 'WARN',
    RESTRICT = 'RESTRICT',
    KICK     = 'KICK',
    TEMP_BAN = 'TEMP_BAN',
    PERM_BAN = 'PERM_BAN',
}
C.ACTION_ORDER = { 'LOG', 'WARN', 'RESTRICT', 'KICK', 'TEMP_BAN', 'PERM_BAN' }

-- Actions de containment réversibles — §88. Distinctes des sanctions.
C.CONTAINMENT = {
    BLOCK_ACTION      = 'BLOCK_ACTION',
    REMOVE_ENTITY     = 'REMOVE_ENTITY',
    INVALIDATE_TXN    = 'INVALIDATE_TXN',
    FREEZE_OPERATION  = 'FREEZE_OPERATION',
}

-- ---------------------------------------------------------------------------
-- Niveaux de log — §61. SECURITY et CRITICAL ne sont jamais supprimés par le niveau.
-- ---------------------------------------------------------------------------
C.LOG = {
    TRACE = 10, DEBUG = 20, INFO = 30, WARN = 40, ERROR = 50, SECURITY = 60, CRITICAL = 70,
}
C.LOG_NAME = {
    [10]='TRACE', [20]='DEBUG', [30]='INFO', [40]='WARN',
    [50]='ERROR', [60]='SECURITY', [70]='CRITICAL',
}

-- Santé d'un composant — §50.
C.HEALTH = { HEALTHY = 'HEALTHY', DEGRADED = 'DEGRADED', FAILED = 'FAILED', UNKNOWN = 'UNKNOWN' }

-- ---------------------------------------------------------------------------
-- Niveaux de preuve — §15. Une preuve n'est pas binaire ; elle se raffine.
-- Une sanction dure exige un niveau de preuve suffisant (§38, §48).
-- E0 télémétrie brute · E1 signal normalisé · E2 anomalie validée ·
-- E3 anomalie corrélée · E4 preuve forte · E5 violation serveur confirmée.
-- ---------------------------------------------------------------------------
C.EVIDENCE = { E0 = 0, E1 = 1, E2 = 2, E3 = 3, E4 = 4, E5 = 5 }
C.EVIDENCE_NAME = { [0]='E0', [1]='E1', [2]='E2', [3]='E3', [4]='E4', [5]='E5' }

-- Niveau de preuve minimal exigé par action de sanction — §38.
-- Une action serveur bloquante (containment) n'exige pas E5 : elle est réversible.
-- Un ban définitif, si.
C.ACTION_MIN_EVIDENCE = {
    LOG = 0, WARN = 1, RESTRICT = 2, KICK = 3, TEMP_BAN = 4, PERM_BAN = 5,
}

-- État de réputation d'un détecteur — §17. Distinct de HEALTH (panne technique) :
-- un détecteur peut être sain mais peu fiable (trop de faux positifs) → OBSERVATION.
C.DETECTOR_STATE = {
    ACTIVE      = 'ACTIVE',      -- fiable, ses signaux comptent plein pot
    DEGRADED    = 'DEGRADED',    -- fiabilité en baisse, poids réduit
    OBSERVATION = 'OBSERVATION', -- signaux journalisés mais ne sanctionnent plus
    DISABLED    = 'DISABLED',    -- retiré de la chaîne
}

-- Niveaux de priorité du moteur de performance — §29. Les tâches lourdes
-- (forensics, replay) cèdent le pas aux vérifications temps réel.
C.PERF_TIER = {
    REALTIME   = 'REALTIME',   -- pare-feu d'events, damage : sur le chemin critique
    HIGH       = 'HIGH',       -- corrélation, risque
    NORMAL     = 'NORMAL',     -- incidents, enforcement
    BACKGROUND = 'BACKGROUND', -- persistance, Discord
    FORENSICS  = 'FORENSICS',  -- reconstruction, exports : jamais sur le chemin critique
}

-- Modes de verrouillage OneSync — §05, §21. 'inactive' = aucun changement (défaut sûr).
C.LOCKDOWN = { INACTIVE = 'inactive', RELAXED = 'relaxed', STRICT = 'strict' }

-- Rôles RBAC — §44.
C.ROLE = {
    OWNER          = 'owner',
    SECURITY_ADMIN = 'security_admin',
    ADMIN          = 'admin',
    MODERATOR      = 'moderator',
    SUPPORT        = 'support',
    VIEWER         = 'viewer',
}

-- Résultats de verdict du firewall — §05.
C.VERDICT = {
    ALLOW      = 'ALLOW',       -- event valide, exécuté
    REJECT     = 'REJECT',      -- event connu mais invalide
    UNKNOWN    = 'UNKNOWN',     -- event non enregistré
    RATE_LIMIT = 'RATE_LIMIT',  -- valide mais trop fréquent
    UNAUTHORIZED = 'UNAUTHORIZED', -- valide mais permission refusée
    BAD_STATE  = 'BAD_STATE',   -- valide mais interdit dans l'état courant
}

-- ---------------------------------------------------------------------------
-- Bornes dures. Plafonds, jamais des défauts : les valeurs de config sont
-- ramenées dans ces bornes.
-- ---------------------------------------------------------------------------
C.LIMITS = {
    MAX_SIGNAL_AGE_MS      = 30 * 60 * 1000,  -- 30 min : durée de vie max d'un signal (§14)
    MAX_SIGNALS_PER_PLAYER = 256,             -- au-delà, éviction du plus ancien
    MAX_RISK_SCORE         = 100,
    MAX_EVENT_STORE        = 5000,            -- file mémoire avant persistance (§37)
    MAX_INCIDENT_DEDUP_WINDOW_MS = 1000,      -- §102 : 100 events identiques ≠ 100 alertes
    MAX_STRING_LEN         = 512,
    MAX_TABLE_KEYS         = 64,
    NONCE_BYTES            = 16,
}

ZShield.Const = C
