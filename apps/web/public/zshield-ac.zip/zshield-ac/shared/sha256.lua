--[[
    FILE:         shared/sha256.lua
    PURPOSE:      SHA-256 et HMAC-SHA256 en Lua pur (Lua 5.4, entiers 64 bits + opérateurs
                  binaires natifs). Sert à VÉRIFIER une licence signée hors-ligne (§ licence) :
                  la protection ne dépend pas d'un serveur joignable au démarrage.
    DEPENDENCIES: aucune. Autonome et déterministe.
    PUBLIC API:   ZShield.Sha256.hash(message) -> hex string (64 chars)
                  ZShield.Sha256.hmac(key, message) -> hex string

    Implémentation de référence FIPS 180-4. Vérifiée par vecteurs de test connus
    (tests/run_license.lua) : sha256("abc") = ba7816bf…f20015ad.
]]

ZShield = ZShield or {}

local band, bor, bxor, bnot = function(a, b) return a & b end, function(a, b) return a | b end,
    function(a, b) return a ~ b end, function(a) return (~a) & 0xFFFFFFFF end
local MASK = 0xFFFFFFFF

local function rrot(x, n)   -- rotation droite 32 bits
    return ((x >> n) | (x << (32 - n))) & MASK
end

local K = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2,
}

local function toBytes(s) return { string.byte(s, 1, #s) } end

local function preprocess(msg)
    local len = #msg
    local bitLen = len * 8
    msg = msg .. '\128'
    while (#msg % 64) ~= 56 do msg = msg .. '\0' end
    -- Longueur sur 64 bits big-endian.
    for i = 7, 0, -1 do
        msg = msg .. string.char((bitLen >> (i * 8)) & 0xFF)
    end
    return msg
end

--- SHA-256 d'une chaîne d'octets. Retourne 64 caractères hexadécimaux.
local function sha256(message)
    local H = { 0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
                0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19 }
    local msg = preprocess(message)
    local bytes = toBytes(msg)

    for chunk = 1, #bytes, 64 do
        local w = {}
        for i = 0, 15 do
            local b = chunk + i * 4
            w[i] = ((bytes[b] << 24) | (bytes[b + 1] << 16) | (bytes[b + 2] << 8) | bytes[b + 3]) & MASK
        end
        for i = 16, 63 do
            local s0 = rrot(w[i - 15], 7) ~ rrot(w[i - 15], 18) ~ (w[i - 15] >> 3)
            local s1 = rrot(w[i - 2], 17) ~ rrot(w[i - 2], 19) ~ (w[i - 2] >> 10)
            w[i] = (w[i - 16] + s0 + w[i - 7] + s1) & MASK
        end

        local a, b, c, d, e, f, g, h = H[1], H[2], H[3], H[4], H[5], H[6], H[7], H[8]
        for i = 0, 63 do
            local S1 = rrot(e, 6) ~ rrot(e, 11) ~ rrot(e, 25)
            local ch = (e & f) ~ ((~e & MASK) & g)
            local t1 = (h + S1 + ch + K[i + 1] + w[i]) & MASK
            local S0 = rrot(a, 2) ~ rrot(a, 13) ~ rrot(a, 22)
            local maj = (a & b) ~ (a & c) ~ (b & c)
            local t2 = (S0 + maj) & MASK
            h = g; g = f; f = e; e = (d + t1) & MASK
            d = c; c = b; b = a; a = (t1 + t2) & MASK
        end

        H[1] = (H[1] + a) & MASK; H[2] = (H[2] + b) & MASK
        H[3] = (H[3] + c) & MASK; H[4] = (H[4] + d) & MASK
        H[5] = (H[5] + e) & MASK; H[6] = (H[6] + f) & MASK
        H[7] = (H[7] + g) & MASK; H[8] = (H[8] + h) & MASK
    end

    local out = {}
    for i = 1, 8 do out[i] = string.format('%08x', H[i]) end
    return table.concat(out)
end

--- HMAC-SHA256(key, message) -> hex. Bloc de 64 octets (§ RFC 2104).
local function hmac(key, message)
    if #key > 64 then
        -- Clé trop longue : on la hache d'abord (retour hex -> octets).
        local hk = sha256(key)
        local raw = {}
        for i = 1, #hk, 2 do raw[#raw + 1] = string.char(tonumber(hk:sub(i, i + 1), 16)) end
        key = table.concat(raw)
    end
    key = key .. string.rep('\0', 64 - #key)

    local okey, ikey = {}, {}
    for i = 1, 64 do
        local kb = string.byte(key, i)
        okey[i] = string.char(kb ~ 0x5c)
        ikey[i] = string.char(kb ~ 0x36)
    end
    local inner = sha256(table.concat(ikey) .. message)
    -- inner est hex ; on le repasse en octets pour le hachage externe.
    local rawInner = {}
    for i = 1, #inner, 2 do rawInner[#rawInner + 1] = string.char(tonumber(inner:sub(i, i + 1), 16)) end
    return sha256(table.concat(okey) .. table.concat(rawInner))
end

ZShield.Sha256 = { hash = sha256, hmac = hmac }
