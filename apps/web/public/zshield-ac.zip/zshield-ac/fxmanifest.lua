--[[
    fxmanifest.lua — ZSHIELD AC core (côté serveur)
    §116 : minimal et correct. Aucun fichier déclaré ici n'est absent du dépôt.
    Chargement dans l'ordre de dépendance (§106, §107).
]]
fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'zshield-ac'
author 'ZShield'
version '1.0.0'
description 'Plateforme de sécurité anti-abus FiveM. Autorité serveur : validation, détection multi-signaux, corrélation, risque, incidents, enforcement.'

server_only 'yes'

server_scripts {
    -- Cœur (ordre de dépendance)
    'shared/constants.lua',
    'core/log.lua',
    'core/util.lua',
    'core/perf.lua',
    'shared/sha256.lua',
    'shared/schema.lua',
    'core/config.lua',
    -- Configuration opérateur (lue après le schéma, avant les modules)
    'config/config.lua',

    -- Licence (vérifiée au démarrage, avant de câbler la protection)
    'server/license.lua',
    'server/license_online.lua',
    'server/license_poll.lua',

    -- Réglages de protections pilotés par le dashboard (choix Surveiller/Bloquer)
    'server/protections.lua',
    -- Liste d'interdiction armes/véhicules pilotée par le dashboard
    'server/blacklist.lua',
    -- Contrôle à la connexion (score de menace : VPN, nom, Discord, duplication)
    'server/connection.lua',
    -- Règles d'événements pilotées (liste noire, débit par event, exceptions)
    'server/triggers.lua',
    -- Vérifs d'événements armes/véhicules pilotées par config (give/remove, hijack…)
    'server/events_extra.lua',

    -- Couche firewall (§04-08) : rate limiting, contexte/état, pare-feu d''events
    'server/firewall/ratelimit.lua',
    'server/context.lua',
    'server/firewall/firewall.lua',

    -- Chaîne de détection (§10-14) : moteur, corrélation temporelle, risque
    'server/detection/engine.lua',
    'server/detection/reputation.lua',
    'server/detection/evidence.lua',
    'server/detection/correlation.lua',
    'server/detection/risk.lua',

    -- Moteur d''incidents (§28-29) : preuve, timeline, déduplication
    'server/incident.lua',

    -- Enforcement (§86-88) : politique de sanction, exécution, containment
    'server/enforcement/policy.lua',
    'server/enforcement/enforcement.lua',

    -- Détecteurs métier (§15-17) : analyse de mouvement, sécurité des entités
    'server/detection/movement.lua',
    'server/detection/entity.lua',
    'server/detection/economy.lua',
    'server/detection/weapon.lua',
    'server/detection/projectile.lua',
    'server/detection/health.lua',
    'server/detection/vehicle.lua',
    'server/detection/command.lua',
    'server/detection/injection.lua',
    'server/detection/antidump.lua',
    'server/detection/statebag.lua',
    -- Moteurs profonds : statistique de visée, cinématique vol/noclip, intégrité
    -- dégâts/portée par arme, provenance des gains (anti-dupe/injection éco).
    'server/detection/aimstats.lua',
    'server/detection/flight.lua',
    'server/detection/damage.lua',
    'server/detection/provenance.lua',
    -- Vague 2 : freecam serveur, séquences causales, désync/lag-switch, budgets serveur.
    'server/detection/freecam.lua',
    'server/detection/sequence.lua',
    'server/detection/desync.lua',
    'server/detection/budget.lua',
    -- Vague 3 : ESP indirect, reach, god mode serveur, ownership/flood.
    'server/detection/esp.lua',
    'server/detection/reach.lua',
    'server/detection/godmode.lua',
    'server/detection/ownership.lua',
    -- Vague 4 : signature trainer (corrélation), bot/macro, spawn-kill, spam, téléport menu.
    'server/detection/trainer.lua',
    'server/detection/behavior.lua',
    'server/detection/spawnprotect.lua',
    'server/detection/chatspam.lua',
    'server/detection/teleport.lua',
    -- Vague 5 : auto-protection (anti-stop/bypass), anti-executor, anti-menu, anti-crash.
    'server/detection/selfprotect.lua',
    'server/detection/executor.lua',
    'server/detection/menu.lua',
    'server/detection/crashguard.lua',
    'server/reputation.lua',
    -- Vague 6 : couche serveur-autoritative (la plus coriace à contourner).
    'server/reconcile.lua',
    'server/detection/invariants.lua',
    'server/detection/envelope.lua',
    -- Vague 7 : techniques statistiques avancées (SPRT de Wald, z-score Welford, hit-reg rewind).
    'server/detection/sprt.lua',
    'server/detection/baseline.lua',
    'server/detection/hitreg.lua',
    -- Vague 8 : fusion bayésienne multi-signaux, séquences (Markov/entropie), horloge (speedhack).
    'server/detection/fusion.lua',
    'server/detection/markov.lua',
    'server/detection/clocksync.lua',
    'server/glue_authoritative.lua',
    -- Câblage : répartiteur pur (testé) + normalisation des events natifs FiveM.
    'server/dispatch.lua',
    'server/eventwiring.lua',

    -- Couches natives event-driven (§08, §10, §21) : blocage à la source, coût ~0.
    -- Chargées après les détecteurs métier dont elles réutilisent le quota d''entités.
    'server/firewall/gameevents.lua',
    'server/firewall/statebag.lua',
    'server/hardening/orchestrator.lua',

    -- Persistance (§36-37, §52) : disjoncteur, event store résilient
    'server/persistence/circuit.lua',
    'server/persistence/store.lua',

    -- API publique et SDK de sécurité (§45, §76-77)
    'server/api.lua',
    'server/sdk.lua',

    -- Pont incident -> alerte plateforme (propositions de sanction)
    'server/reporter.lua',
    -- Observation serveur-autoritative (Multi-vue)
    'server/spectate.lua',
    -- Réception des rapports du module client (heartbeat signé, intégrité, corrélation)
    'server/clientguard.lua',
    'server/clientglue.lua',

    -- Santé, auto-surveillance et bootstrap (§50-51, §107-109)
    'server/adapters/framework.lua',
    'server/hardening.lua',
    'server/integrations/discord.lua',
    'server/health.lua',
    'server/bootstrap.lua',
}
