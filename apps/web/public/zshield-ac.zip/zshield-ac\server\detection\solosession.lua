--[[
    FILE:         server/detection/solosession.lua
    PURPOSE:      ANTI PASSAGE EN SESSION SOLO. Certains exploits isolent le joueur du reste du
                  réseau (routing/OneSync) pour dupliquer des objets ou griefer sans témoins :
                  le joueur ne « voit » plus personne alors que le serveur a d'autres joueurs
                  connectés à proximité. Si le nombre de pairs perçus tombe et reste à ~0 pendant
                  une durée, alors que le serveur est peuplé, c'est une isolation suspecte.

    100 % serveur : le serveur connaît le vrai nombre de joueurs et la présence attendue.
    Corrélant (§26) : un serveur réellement vide n'est pas un exploit — on n'alerte que si
    d'AUTRES joueurs devraient être visibles.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.SoloSession.observe(source, ev) -> signal|nil
                  ZShield.SoloSession.forget(source) / .register()

    ev = { peers = number (pairs perçus par le client), others_online = number (vrais autres
           joueurs attendus à portée, connu serveur), now = ms }
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local S = {}
S._since = {}   -- source -> timestamp du début d'isolation (ms) ou nil

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

function S.observe(source, ev)
    if cfg('solo_session.enabled', false) ~= true then return nil end
    if type(ev) ~= 'table' then return nil end
    local now = tonumber(ev.now) or Util.now()
    local peers = tonumber(ev.peers)
    local others = tonumber(ev.others_online) or 0

    -- Nombre minimal d'autres joueurs attendus pour que l'isolation soit anormale.
    local minOthers = tonumber(cfg('solo_session.min_others', 2)) or 2
    local minMs = tonumber(cfg('solo_session.min_ms', 8000)) or 8000

    -- Isolation = le client ne perçoit (quasi) personne alors qu'il devrait.
    local isolated = peers ~= nil and peers <= 0 and others >= minOthers
    if not isolated then
        S._since[source] = nil
        return nil
    end

    local since = S._since[source]
    if not since then S._since[source] = now; return nil end   -- démarre le chrono

    local dur = now - since
    if dur >= minMs then
        S._since[source] = now   -- réarme pour ne pas spammer
        local severity, confidence
        if dur >= minMs * 2 then severity, confidence = C.SEVERITY.HIGH, 0.72
        else                     severity, confidence = C.SEVERITY.MEDIUM, 0.55
        end
        return {
            detector = 'solosession', category = C.CATEGORY.NETWORK,
            severity = severity, confidence = confidence,
            reason = string.format('isolation réseau %.0f s (0 pair perçu, %d autres attendus) — session solo', dur / 1000, others),
            source = source,
            metadata = { peers = peers, others_online = others, dur_ms = dur, kind = 'solo_isolation' },
        }
    end
    return nil
end

function S.forget(source) S._since[source] = nil end

function S.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'solosession', category = C.CATEGORY.NETWORK,
            evaluate = function() return {} end })
    end
end

ZShield.SoloSession = S
return S
