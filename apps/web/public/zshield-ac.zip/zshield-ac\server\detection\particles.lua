--[[
    FILE:         server/detection/particles.lua
    PURPOSE:      PARTICULES (ptFX) ABUSIVES. Les griefers spamment des effets de particules
                  (feu, explosions visuelles, fumée) à échelle démesurée pour aveugler l'écran,
                  faire ramer les clients, ou masquer d'autres actions. Le serveur voit les
                  demandes d'effet réseau : au-delà d'un débit par fenêtre (flood) ou d'une
                  échelle absurde, c'est un abus.

    100 % serveur, corrélant (§26). L'échelle légitime d'un ptFX reste petite ; un joueur qui
    demande scale=50 n'est pas un effet de jeu normal.

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.Particles.observe(source, ev) -> signal|nil
                  ZShield.Particles.forget(source) / .register()

    ev = { scale = number?, now = ms }
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local P = {}
P._ev = {}   -- source -> { ts... }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

local function slide(list, now, windowMs)
    local kept = {}
    for _, t in ipairs(list) do if (now - t) <= windowMs then kept[#kept + 1] = t end end
    return kept
end

function P.observe(source, ev)
    if cfg('particles.enabled', false) ~= true then return nil end
    if type(ev) ~= 'table' then return nil end
    local now = tonumber(ev.now) or Util.now()

    -- 1) Échelle absurde : un seul effet démesuré suffit (aveuglement/écran blanc).
    local maxScale = tonumber(cfg('particles.max_scale', 10)) or 10
    local scale = tonumber(ev.scale)
    if scale and scale > maxScale then
        local ratio = (maxScale > 0) and (scale / maxScale) or 99
        local severity, confidence
        if ratio >= 5 then       severity, confidence = C.SEVERITY.HIGH, 0.8
        elseif ratio >= 2 then   severity, confidence = C.SEVERITY.MEDIUM, 0.6
        else                     severity, confidence = C.SEVERITY.LOW, 0.45
        end
        return {
            detector = 'particles', category = C.CATEGORY.EVENT,
            severity = severity, confidence = confidence,
            reason = string.format('particule à échelle %.1f (max %.0f, x%.1f) — ptFX abusif', scale, maxScale, ratio),
            source = source, metadata = { scale = scale, max = maxScale, ratio = ratio, kind = 'scale' },
        }
    end

    -- 2) Flood : trop de ptFX par fenêtre.
    local windowMs = tonumber(cfg('particles.window_ms', 10000)) or 10000
    local maxCount = tonumber(cfg('particles.mass_value', 20)) or 20
    local list = slide(P._ev[source] or {}, now, windowMs)
    list[#list + 1] = now
    P._ev[source] = list
    if #list > maxCount then
        local ratio = (maxCount > 0) and (#list / maxCount) or 99
        local severity, confidence
        if ratio >= 2.5 then     severity, confidence = C.SEVERITY.HIGH, 0.78
        elseif ratio >= 1.5 then severity, confidence = C.SEVERITY.MEDIUM, 0.6
        else                     severity, confidence = C.SEVERITY.LOW, 0.45
        end
        return {
            detector = 'particles', category = C.CATEGORY.EVENT,
            severity = severity, confidence = confidence,
            reason = string.format('%d particules en %.0f s (max %d, x%.1f) — flood ptFX', #list, windowMs / 1000, maxCount, ratio),
            source = source, metadata = { count = #list, max = maxCount, ratio = ratio, kind = 'mass' },
        }
    end
    return nil
end

function P.forget(source) P._ev[source] = nil end

function P.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'particles', category = C.CATEGORY.EVENT,
            evaluate = function() return {} end })
    end
end

ZShield.Particles = P
return P
