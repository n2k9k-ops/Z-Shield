--[[
    FILE:         server/evidence.lua
    PURPOSE:      Capture d'écran À LA DEMANDE comme preuve d'incident. Le serveur
                  DEMANDE une capture au client (module zshield-client) ; le client
                  capture la FENÊTRE DE JEU via screenshot-basic et l'upload vers une
                  URL configurée ; le serveur rattache l'URL à l'incident.

    HONNÊTETÉ : on ne capture QUE le rendu du jeu (screenshot-basic), jamais le bureau
    ni une autre fenêtre. La capture nécessite (1) la ressource `screenshot-basic`
    côté client, (2) une URL d'upload (`evidence.upload_url`, ex. endpoint dashboard
    ou webhook). Sans l'une ou l'autre, la demande est simplement ignorée (no-op sûr).

    DEPENDENCIES: core/config.lua, core/log.lua, (optionnel) server/incident.lua
    PUBLIC API:   ZShield.EvidenceCapture.request(source, incidentId) -> bool (demande émise)
                  ZShield.EvidenceCapture.get(incidentId) -> { urls... }
                  ZShield.EvidenceCapture.attach()   (branche le retour client)
]]

ZShield = ZShield or {}
local Log = ZShield.Log

local Evidence = {}  -- exposé comme ZShield.EvidenceCapture
Evidence._byIncident = {}   -- incidentId -> { urls }

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

--- Demande une capture au client `source` pour l'incident `incidentId`. Retourne
--- false (sans rien faire) si la capture est désactivée, sans URL d'upload, ou hors
--- runtime FiveM (tests). Ne bannit ni ne bloque : c'est de la collecte de preuve.
function Evidence.request(source, incidentId)
    if cfg('evidence.enabled', false) ~= true then return false end
    local url = tostring(cfg('evidence.upload_url', '') or '')
    if url == '' then return false end
    if type(TriggerClientEvent) ~= 'function' then return false end
    if not source then return false end
    TriggerClientEvent('zshield:evidence:capture', source, {
        upload_url = url, incident = incidentId,
    })
    if Log then Log:info('evidence', 'capture demandée', { source = source, incident = incidentId }) end
    return true
end

--- Capture à la demande d'un membre du staff (dashboard) : l'URL d'upload et
--- l'identifiant de capture sont fournis par la plateforme (via l'agent, qui a
--- déjà vérifié que l'URL appartient à l'API configurée). `target` : slot serveur.
--- Retourne true (demande émise) ou false, raison. C'est de la collecte de
--- preuve : ne bannit ni ne bloque, et ne capture que le RENDU DU JEU.
function Evidence.requestExplicit(target, info)
    local src = tonumber(target)
    if not src then return false, 'invalid target' end
    if type(info) ~= 'table' or type(info.upload_url) ~= 'string' or info.upload_url == '' then
        return false, 'missing upload_url'
    end
    if type(TriggerClientEvent) ~= 'function' then return false, 'not in runtime' end
    -- Le joueur doit être connecté : sinon on le dit, on ne fait pas semblant.
    if type(GetPlayerName) == 'function' and GetPlayerName(tostring(src)) == nil then
        return false, 'target not connected'
    end
    TriggerClientEvent('zshield:evidence:capture', src, {
        upload_url = info.upload_url, incident = info.capture_id,
    })
    if Log then Log:security('evidence', 'capture demandée par le staff', {
        source = src, capture = info.capture_id }) end
    return true
end

--- Enregistre une URL de capture retournée par le client, et la rattache à l'incident.
function Evidence.record(incidentId, url)
    if type(url) ~= 'string' or url == '' then return end
    local key = incidentId or '_unbound'
    local bucket = Evidence._byIncident[key]
    if not bucket then bucket = {}; Evidence._byIncident[key] = bucket end
    bucket[#bucket + 1] = url
    -- Rattache à l'incident si l'API est là (observation horodatée).
    if incidentId and ZShield.Incident and ZShield.Incident.addObservation then
        pcall(ZShield.Incident.addObservation, incidentId, {
            kind = 'screenshot', url = url, at = (ZShield.Util and ZShield.Util.now()) or os.time(),
        })
    end
    if Log then Log:security('evidence', 'capture reçue', { incident = incidentId, url = url }) end
end

function Evidence.get(incidentId)
    return Evidence._byIncident[incidentId or '_unbound'] or {}
end

--- Branche le retour du client (hors runtime : no-op).
function Evidence.attach()
    if type(RegisterNetEvent) ~= 'function' then return false end
    RegisterNetEvent('zshield:evidence:captured', function(payload)
        -- `source` est l'expéditeur réel (FiveM), non falsifiable ici.
        local src = source
        if type(payload) ~= 'table' then return end
        if payload.ok and type(payload.url) == 'string' then
            Evidence.record(payload.incident, payload.url)
        elseif payload.ok then
            -- Capture envoyée directement à la plateforme (pas d'URL en retour).
            if Log then Log:info('evidence', 'capture envoyée à la plateforme', { source = src, capture = payload.incident }) end
        elseif Log then
            Log:warn('evidence', 'capture échouée côté client', { source = src, incident = payload.incident })
        end
    end)
    return true
end

ZShield.EvidenceCapture = Evidence
return Evidence
