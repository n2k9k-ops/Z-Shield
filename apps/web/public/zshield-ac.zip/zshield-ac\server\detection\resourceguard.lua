--[[
    FILE:         server/detection/resourceguard.lua
    PURPOSE:      ANTI STOP/START DE RESSOURCES. Aucun CLIENT ne doit pouvoir démarrer ou
                  arrêter une ressource serveur (couper l'anticheat, relancer une ressource
                  pour la contourner). Le contrôle des ressources est une prérogative console/
                  serveur. Donc TOUTE demande stop/start dont l'origine est un joueur est
                  illégitime par construction.

    100 % serveur-autoritatif, signal FORT. Cibler l'anticheat lui-même = CRITICAL.

    DEPENDENCIES: shared/constants.lua, core/config.lua
    PUBLIC API:   ZShield.ResourceGuard.observe(source, ev) -> signal|nil
                  ZShield.ResourceGuard.register()

    ev = { action = 'stop'|'start'|'restart', resource = string, from_client = bool }
]]

ZShield = ZShield or {}
local C = ZShield.Const

local RG = {}

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

-- Ressources sensibles dont l'arrêt = tentative de neutralisation de la protection.
local function isProtected(res)
    res = tostring(res or ''):lower()
    return res:find('zshield', 1, true) ~= nil
end

function RG.observe(source, ev)
    if cfg('resource_guard.enabled', true) ~= true then return nil end
    if type(ev) ~= 'table' then return nil end
    -- Seule une origine CLIENT est illégitime. Les appels console/serveur passent from_client=false.
    if ev.from_client == false then return nil end

    local action = tostring(ev.action or 'stop')
    local res = tostring(ev.resource or '?')
    local targetsAC = isProtected(res)

    local severity, confidence
    if targetsAC then severity, confidence = C.SEVERITY.CRITICAL, 0.95   -- vise l'anticheat
    else              severity, confidence = C.SEVERITY.HIGH, 0.85
    end
    return {
        detector = 'resourceguard', category = C.CATEGORY.RESOURCE,
        severity = severity, confidence = confidence,
        reason = string.format('%s de ressource « %s » demandé depuis un client%s',
            action, res, targetsAC and ' — CIBLE L\'ANTICHEAT' or ''),
        source = source,
        metadata = { action = action, resource = res, targets_ac = targetsAC, kind = 'resource_control' },
    }
end

function RG.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'resourceguard', category = C.CATEGORY.RESOURCE,
            evaluate = function() return {} end })
    end
end

ZShield.ResourceGuard = RG
return RG
