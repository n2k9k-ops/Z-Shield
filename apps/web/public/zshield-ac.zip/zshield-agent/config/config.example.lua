--[[
    zshield-agent / config/config.example.lua

    Copiez ce fichier vers `config/config.lua` puis adaptez-le.
    `config/config.lua` est ignoré par git (voir .gitignore) : aucune vraie
    credential ne doit jamais être commitée.

    Ce fichier retourne une table. Il est chargé dans un environnement Lua
    restreint (aucun accès aux globales du serveur), il ne peut donc pas
    exécuter de logique utile : décrivez seulement des valeurs.

    SECRET
        Ne mettez PAS le secret ici en production. Déclarez-le comme convar
        dans server.cfg, en dehors de tout fichier de ressource :

            set zshield_agent_secret "le-secret-fourni-par-le-dashboard"

        `set` (et non `setr`/`sets`) garde la valeur côté serveur uniquement.
        La convar a priorité sur la valeur de ce fichier.
]]

return {
    -- =======================================================================
    -- IDENTITÉ
    -- =======================================================================

    -- Identifiants fournis par le dashboard lors de la création du serveur.
    -- Format attendu : caractères alphanumériques, tiret et underscore.
    server_id = 'srv_00000000000000000000',
    agent_id  = 'agt_00000000000000000000',

    -- Identifiant de la clé de signature active. Le dashboard le renvoie lors
    -- du handshake et lors d'une rotation ; laissez la valeur par défaut au
    -- premier démarrage.
    key_id = 'k1',

    -- Secret partagé de signature HMAC. Laissez la chaîne vide et utilisez la
    -- convar `zshield_agent_secret` (recommandé).
    secret = '',

    -- Nom lisible du serveur et environnement. Purement descriptif : le
    -- dashboard s'appuie sur server_id, jamais sur ce nom.
    server_name = 'Mon serveur FiveM',
    environment = 'production', -- production | staging | development

    -- =======================================================================
    -- TRANSPORT
    -- =======================================================================

    -- Racine de l'API SaaS. HTTPS obligatoire hors développement local :
    -- l'agent refuse de démarrer sur une URL http:// si
    -- allow_insecure_endpoint n'est pas explicitement à true.
    api_endpoint = 'https://api.example.com',

    -- Autorise http:// et les hôtes locaux. À n'utiliser que pour un
    -- dashboard tournant sur la même machine pendant le développement.
    allow_insecure_endpoint = false,

    -- Délai maximal d'une requête HTTP, en secondes.
    request_timeout = 10,

    -- =======================================================================
    -- CADENCES
    -- =======================================================================
    -- Ces valeurs sont les valeurs par défaut locales. Le dashboard peut les
    -- ajuster à distance dans les bornes définies par le schema du protocole.

    heartbeat_interval   = 30,  -- secondes entre deux heartbeats
    telemetry_interval   = 60,  -- secondes entre deux envois de télémétrie
    alert_flush_interval = 5,   -- secondes entre deux vidages de la file d'alertes
    alert_batch_size     = 50,  -- alertes maximum par requête

    -- =======================================================================
    -- TÉLÉMÉTRIE
    -- =======================================================================

    telemetry_enabled = true,

    -- Chaque métrique peut être désactivée individuellement. Aucune de ces
    -- métriques ne contient d'identifiant de joueur.
    metrics = {
        players      = true,  -- nombre de joueurs connectés (compteur seul)
        performance  = true,  -- mémoire Lua, latence des requêtes
        errors       = true,  -- compteurs d'erreurs par catégorie
        dependencies = true,  -- état des ressources dont l'agent dépend
        resources    = false, -- nombre de ressources démarrées
    },

    -- =======================================================================
    -- FILE D'ATTENTE LOCALE
    -- =======================================================================

    queue = {
        -- Nombre maximum d'éléments conservés hors ligne. Au-delà, les
        -- éléments les moins graves et les plus anciens sont supprimés en
        -- premier, et une alerte interne est émise.
        max_size = 2000,

        -- Durée de vie d'un élément en file, en secondes. Au-delà, il est
        -- abandonné : une alerte vieille de plusieurs heures n'a plus de
        -- valeur opérationnelle.
        ttl = 6 * 3600,

        -- Persistance de la file sur disque (data/queue.json) afin de
        -- survivre à un redémarrage de la ressource.
        persist = true,
    },

    -- =======================================================================
    -- COMMANDES DISTANTES
    -- =======================================================================

    commands = {
        -- Interrupteur global. À false, l'agent n'interroge jamais la file de
        -- commandes : télémétrie et alertes continuent de fonctionner.
        enabled = true,

        -- Allowlist explicite. Une commande absente de cette liste est
        -- rejetée même si le dashboard la demande et même si elle est connue
        -- du protocole. Retirez ce que vous ne voulez pas autoriser.
        allowed = {
            'request_status',
            'request_health_check',
            'refresh_configuration',
            'reload_safe_configuration',
            'ping',
            'flush_queue',
            -- 'rotate_credential', -- décommentez pour autoriser la rotation à distance
        },
    },

    -- =======================================================================
    -- CONFIGURATION DISTANTE
    -- =======================================================================

    remote_config = {
        -- À false, l'agent ignore toute configuration poussée par le
        -- dashboard et n'utilise que ce fichier.
        enabled = true,
    },

    -- =======================================================================
    -- JOURNALISATION
    -- =======================================================================

    log_level = 'INFO', -- DEBUG | INFO | WARN | ERROR

    -- Les logs SECURITY sont toujours émis, indépendamment de log_level.
    -- Sortie console structurée en JSON (utile si vous collectez les logs).
    log_json = false,
}
