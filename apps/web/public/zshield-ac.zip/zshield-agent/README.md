# zshield-agent

Agent FiveM défensif. Il transmet à un dashboard ZShield l'état d'un serveur
FXServer et les alertes produites par un anti-cheat, et exécute un petit
ensemble fermé de commandes de supervision.

Il ne contient aucune logique de contournement, aucun téléchargement de code,
aucune exécution distante. Serveur uniquement : aucun script client n'est
livré, puisque la ressource détient un secret.

- **Agent** : 1.0.0
- **Protocole** : 1
- **Prérequis** : FXServer build ≥ 7290, `lua54` (imposé par le manifest)
- **Dépendances** : aucune. Pas de base de données, pas d'oxmysql, pas de
  framework.

---

## 1. Installation

```
# 1. Déposer la ressource
cd resources
git clone <votre-dépôt> zshield-agent    # ou copier le dossier

# 2. Créer la configuration
cd zshield-agent
cp config/config.example.lua config/config.lua
```

Renseigner `server_id`, `agent_id` et `api_endpoint` avec les valeurs données
par le dashboard à la création du serveur.

Dans `server.cfg` :

```cfg
# Le secret reste hors des fichiers de ressource.
# `set` (et non setr/sets) : la valeur ne quitte jamais le serveur.
set zshield_agent_secret "le-secret-affiché-par-le-dashboard"

ensure zshield-agent
```

Puis redémarrer et vérifier :

```
zshield status
zshield health
```

Un démarrage réussi ressemble à :

```
[zshield-agent] [INFO] starting zshield-agent 1.0.0 (protocol 1)
[zshield-agent] [INFO] configuration loaded server_id=srv_... endpoint=https://...
[zshield-agent] [INFO] handshake complete organization=... api_version=1
[zshield-agent] [INFO] zshield-agent operational
```

### Génération des credentials

Les credentials sont émises par le dashboard, jamais par l'agent :

1. créer le serveur dans le dashboard ;
2. générer la credential d'agent (affichée une seule fois) ;
3. la poser dans `zshield_agent_secret` ;
4. attendre le handshake ; le serveur passe `connected` côté dashboard.

Le secret doit faire au moins 32 caractères, sinon l'agent refuse de démarrer.
Rotation : voir §6.

## 2. Configuration

`config/config.example.lua` documente chaque option. Points importants :

- Le fichier est lu à l'exécution dans un environnement Lua **vide** : il ne
  peut décrire que des valeurs, pas appeler de natives. Une erreur de syntaxe
  ne fait pas tomber la ressource, elle produit un message clair.
- Une clé inconnue fait **refuser** la configuration. Pas de tolérance
  silencieuse : une option mal orthographiée serait sinon ignorée sans bruit.
- Une configuration invalide met l'agent en `MISCONFIGURED`. Dans cet état il
  n'émet **aucune** requête réseau, mais `zshield status` et
  `zshield diagnostics` restent disponibles pour comprendre pourquoi.
- HTTPS obligatoire, sauf `allow_insecure_endpoint = true` pour un dashboard
  local en développement.
- `commands.allowed` est votre veto. Une commande absente de cette liste est
  refusée même si le dashboard la demande et même si le protocole la connaît.
  `rotate_credential` est commentée par défaut.
- `remote_config.enabled = false` ignore toute configuration poussée à
  distance.

## 3. Architecture

```
       Anti-cheat / autres ressources
                    │  exports:SendSecurityAlert
                    ▼
        ┌───────────────────────────┐
        │ alerts.lua                │  validation, déduplication, batch
        └─────────────┬─────────────┘
                      ▼
        ┌───────────────────────────┐
        │ queue.lua                 │  borné, TTL, éviction par gravité,
        └─────────────┬─────────────┘  persistance disque
                      ▼
 ┌────────────────────────────────────────┐
 │ agent.lua                              │  config, état, backoff,
 │   └── authentication.lua               │  disjoncteur, transport signé
 │         └── shared/crypto.lua          │  HMAC-SHA256
 │         └── shared/protocol.lua        │  chaînes canoniques, schémas
 │         └── shared/validation.lua      │  validateur strict
 └────────────────────┬───────────────────┘
                      ▼ HTTPS, requêtes et réponses signées
              Dashboard SaaS

 heartbeat.lua   liveness + notification de changement
 telemetry.lua   métriques opérationnelles, groupes désactivables
 commands.lua    allowlist fermée, idempotence, audit
 config_sync.lua configuration distante bornée par schéma
 health.lua      santé par composant, diagnostics, commande console
 logger.lua      logs structurés, rédaction obligatoire des secrets
```

Ordre de chargement dans `fxmanifest.lua`. Chaque module publie son API sous
la table globale `ZShield`.

### Principes

1. **Le serveur initie tout.** Aucun port ouvert, aucune connexion entrante.
   Les commandes sont récupérées par l'agent, jamais poussées.
2. **Une réponse de l'API n'est pas une autorité.** Signature vérifiée, puis
   schéma validé, avant de lire un champ. Y compris sur les erreurs.
3. **Échec fermé sur l'identité, échec ouvert sur le reporting.** Une
   configuration douteuse arrête le réseau ; une plateforme injoignable dégrade
   seulement la remontée d'information.
4. **Une panne de la plateforme n'est pas un incident de gameplay.** Alertes
   mises en file locale, bornées, persistées, réessayées avec backoff.
5. **Pas d'erreur fatale.** Chaque boucle est sous `pcall` : un bug dans la
   télémétrie ne doit pas tuer le heartbeat.

## 4. API interne pour les autres ressources

```lua
-- Remonter une alerte de sécurité
local ok, id = exports['zshield-agent']:SendSecurityAlert({
    category  = 'movement',          -- event|entity|movement|economy|weapon|
                                     -- resource|admin|agent|other
    severity  = 'HIGH',              -- INFO|LOW|MEDIUM|HIGH|CRITICAL
    summary   = 'position delta inconsistent with vehicle state',
    metadata  = { detector = 'movement.anomaly', confidence = 0.62 },
    dedup_key = 'movement.anomaly:1234',   -- optionnel, regroupe sur 30 s
    reference = 'inc_123',                 -- optionnel, votre id d'incident
})
-- ok = false et id = raison si l'alerte est refusée

-- État de l'agent (table complète : état, requêtes, file, latence, santé)
local status = exports['zshield-agent']:GetAgentStatus()

-- Versions
local v = exports['zshield-agent']:GetAgentVersion()
-- { agent = '1.0.0', protocol = 1, min_supported_api = 1 }

-- Forcer une resynchronisation de configuration
exports['zshield-agent']:RequestConfigRefresh()
```

Contraintes sur les alertes : `summary` ≤ 512 caractères ; `metadata` ≤ 32
clés, valeurs scalaires uniquement (string, number, boolean), ≤ 1024
caractères par valeur ; caractères de contrôle refusés ; champ inconnu
refusé. Une alerte invalide est rejetée avec une raison, pas silencieusement
tronquée.

**Ne mettez pas de secret, de token ou de log de chat dans `metadata`.**
L'agent ne rédige que les secrets qu'il connaît (le sien) ; la plateforme
stocke ce qu'elle reçoit.

Une alerte est un rapport de détection, pas un verdict. `severity` dit combien
d'attention un humain doit y porter ; mettez la confiance du détecteur dans
`metadata` et laissez le relecteur voir les deux.

## 5. Commandes console

Console serveur ou principal ACE autorisé uniquement (`restricted = true`) :
un joueur ne peut pas les exécuter.

| Commande | Effet |
|---|---|
| `zshield status` | état, compteurs de requêtes, file, dernière erreur |
| `zshield health` | santé par composant |
| `zshield version` | versions agent / protocole / API |
| `zshield queue` | contenu et compteurs de la file locale |
| `zshield flush` | force l'envoi de ce qui est en file |
| `zshield diagnostics` | rapport JSON complet, sans secret |

`zshield diagnostics` est le rapport à joindre à une demande de support. Il ne
contient pas le secret (la credential n'apparaît que par son `key_id`), et une
rédaction est appliquée une seconde fois à la sortie. Relisez-le quand même
avant de le transmettre.

## 6. Rotation des credentials

Activer `'rotate_credential'` dans `commands.allowed`, puis déclencher la
rotation depuis le dashboard. L'agent :

1. demande le nouveau matériel avec la clé courante ;
2. le met en attente sans l'activer ;
3. prouve qu'il fonctionne par un handshake signé avec la nouvelle clé ;
4. ne commit et ne persiste qu'en cas de succès.

En cas d'échec à l'étape 3, l'ancienne clé reste active et la commande rapporte
un échec. Une rotation ne peut pas enfermer l'agent dehors.

La clé rotée est écrite dans `data/credential.json` **en clair**, car l'agent
doit survivre à un redémarrage. Protégez ce fichier par les permissions du
système de fichiers. C'est la raison pour laquelle la rotation est opt-in.

## 7. Données et vie privée

Ce que l'agent envoie :

- identité du serveur, versions, uptime, état OneSync, max players ;
- **nombre** de joueurs connectés (désactivable) ;
- mémoire Lua, latences de requête, compteurs d'erreurs ;
- état des ressources surveillées ;
- alertes soumises par vos ressources.

Ce qu'il n'envoie pas : aucun identifiant de joueur (nom, licence, Steam id,
IP), aucune position, aucun contenu de chat. La télémétrie ne contient pas de
donnée personnelle, sauf si vous en mettez vous-même dans `metadata` d'une
alerte.

Chaque groupe de métriques est désactivable dans la configuration et à
distance. `telemetry_enabled = false` coupe la télémétrie sans toucher au
heartbeat ni aux alertes.

## 8. Performance

- Aucune boucle par frame, aucun handler d'événement réseau.
- Threads : heartbeat (30 s), télémétrie (60 s), flush d'alertes (5 s),
  commandes (60 s), config (300 s). Tous les intervalles sont configurables.
- Une signature HMAC coûte environ 0,3 ms sur un corps de 512 octets
  (mesuré sous Lua 5.4.6), soit quelques millisecondes par minute.
- La déduplication est le mécanisme de protection contre un détecteur qui
  s'emballe : 500 détections identiques en une seconde produisent une alerte
  et un compteur, pas 500 requêtes.
- La file est bornée en nombre **et** en durée. Une plateforme injoignable
  plafonne la mémoire consommée puis abandonne le plus ancien et le moins
  grave, en le comptant.

## 9. Dépannage

| Symptôme | Cause probable | Action |
|---|---|---|
| `MISCONFIGURED` au démarrage | config invalide | `zshield status` affiche la raison exacte |
| `config/config.lua not found` | fichier non copié | `cp config/config.example.lua config/config.lua` |
| `still contains the example identifiers` | `server_id`/`agent_id` non remplacés | valeurs du dashboard |
| `api_endpoint must use https` | endpoint en http | corriger, ou `allow_insecure_endpoint` en dev |
| `missing or too short signing secret` | convar absente ou secret < 32 car. | `set zshield_agent_secret "..."` |
| `E_AUTH_INVALID_SIGNATURE` | mauvais secret ou mauvais `key_id` | régénérer la credential |
| `E_AUTH_CLOCK_SKEW` | horloge serveur décalée > 300 s | NTP sur la machine hôte |
| `rejected an unverified response` | la plateforme ne signe pas ses réponses, ou proxy TLS interposé | vérifier l'implémentation côté plateforme (`docs/PROTOCOL.md` §4) |
| `OFFLINE`, file qui grossit | plateforme injoignable | normal et attendu ; rien à faire, l'agent réessaie |
| `rejected a remote configuration` | la plateforme pousse un champ inconnu | désaccord de version ; comparer au schéma §7 du protocole |
| `queue is full` dans `zshield health` | panne longue ou détecteur emballé | vérifier les `dedup_key` de vos détecteurs |

Pour un diagnostic complet : `zshield diagnostics`.

## 10. Tests

```
cd resources/zshield-agent
lua5.4 tests/run_tests.lua
```

103 assertions. Les tests exécutent le vrai code de la ressource contre une
fausse plateforme qui **vérifie réellement** les signatures de l'agent et
**signe réellement** ses réponses ; les natives FXServer sont stubbées et le
temps est virtuel (`tests/harness.lua`). Couverture : validation, crypto
(vecteurs NIST / RFC 4231), refus de configuration, rejet de réponse
falsifiée / non signée / périmée / rejouée, bornes de la configuration
distante, allowlist et idempotence des commandes, rotation avec échec de
vérification, plafond et persistance de la file, rédaction des secrets dans
les logs.

`tests/` n'est pas chargé par `fxmanifest.lua`.

## 11. Limites de sécurité

Aucun de ces points n'est un défaut à corriger : ce sont les hypothèses sous
lesquelles l'agent fonctionne. Les connaître vaut mieux que les ignorer.

- **Le secret est une credential porteuse.** Tout ce qui peut lire la
  configuration ou la mémoire du serveur peut usurper l'agent auprès de la
  plateforme. FXServer n'offre pas de stockage de clé matériel.
- **La signature des réponses ne prouve pas que la plateforme est saine**,
  seulement qu'elle détient le secret partagé. D'où l'allowlist de commandes :
  même un dashboard compromis ne peut exécuter que ce que vous avez autorisé.
- **L'anti-rejeu dépend de l'horloge du serveur.** Décalage > 300 s =
  authentification impossible.
- **`Crypto.equals` n'est pas garanti en temps constant.** Lua ne le permet
  pas ; c'est une défense en profondeur.
- **Le cache de nonces est en mémoire** (512 entrées). Un redémarrage le vide.
  La fenêtre d'horloge reste la protection principale.
- **La rédaction des logs est par sous-chaîne.** Elle attrape le secret exact,
  pas une forme transformée. La vraie défense est qu'aucun module ne passe le
  secret en champ de log.
- **La disponibilité n'est pas une preuve.** Un heartbeat manquant signifie
  « injoignable », pas « compromis » : ressource arrêtée, serveur redémarré et
  règle de pare-feu sont indistinguables vu de la plateforme.
- **L'agent ne détecte rien par lui-même.** Il transporte et met en forme ce
  que votre anti-cheat lui donne. La qualité des détections n'est pas de son
  ressort.

Aucun système n'est invulnérable, et celui-ci ne l'est pas. Ce qu'il apporte
est une surface d'attaque réduite (serveur uniquement, pas de code distant, pas
de port ouvert), une authentification mutuelle, un périmètre d'action distant
fermé et sous contrôle de l'opérateur, et un comportement prévisible en panne.

## 12. Licence et divulgation

Pour signaler une vulnérabilité dans cet agent, contactez le mainteneur en
privé avec un moyen de reproduction plutôt que d'ouvrir un ticket public.
