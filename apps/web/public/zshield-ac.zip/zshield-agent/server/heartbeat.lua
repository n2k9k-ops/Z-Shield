--[[
    zshield-agent / server/heartbeat.lua

    PURPOSE
        Periodic liveness signal. The heartbeat is what lets the dashboard
        distinguish ONLINE / DEGRADED / OFFLINE / UNKNOWN, so it carries the
        minimum needed for that judgement and nothing else.

        It is also the cheapest place to learn that work is waiting: the
        response tells the agent how many commands are pending and which
        configuration version the platform expects, so the agent polls those
        endpoints only when something actually changed.

    DEPENDENCIES
        shared/constants.lua, server/logger.lua, server/agent.lua

    PUBLIC API
        ZShield.Heartbeat.start()
        ZShield.Heartbeat.stats()  -> table
        ZShield.Heartbeat.beat()   -> ok, errCode  (manual, used by commands)

    NOTES ON SEMANTICS
        A missing heartbeat means the agent could not be reached. It does not
        mean the server is compromised, and the dashboard must not treat it as
        evidence of anything beyond a connectivity problem: a crashed resource,
        a restarted server and a firewall change all look identical from the
        platform side.
]]

ZShield = ZShield or {}

local Const = ZShield.Const
local Log = ZShield.Log
local Queue = ZShield.Queue

local Heartbeat = {}

-- Empreinte du serveur, lue une fois du cœur anticheat via son export. Cachée.
-- nil si le cœur n'est pas présent, ou si le format n'est pas 16 hex (on ne remonte
-- alors rien, pour ne pas faire rejeter le heartbeat par le schéma strict).
local cachedFingerprint = nil
local fingerprintResolved = false
function Heartbeat.serverFingerprint()
    if fingerprintResolved then return cachedFingerprint end
    fingerprintResolved = true
    for _, name in ipairs({ 'zshield_ac', 'zshield-ac' }) do
        local ok, id = pcall(function()
            local api = exports and exports[name]
            if api and api.GetServerIdentity then return api:GetServerIdentity() end
            return nil
        end)
        if ok and type(id) == 'string' and id:match('^%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x$') then
            cachedFingerprint = id
            return cachedFingerprint
        end
    end
    return nil
end

local stats = {
    sent = 0,
    failed = 0,
    consecutive_failures = 0,
    last_sent_at = nil,
    last_success_at = nil,
    last_interval = nil,
    suggested_interval = nil,
}

local running = false

--- Send one heartbeat. Safe to call from any thread context.
function Heartbeat.beat()
    local Agent = ZShield.Agent
    local cfg = Agent.config()
    if not cfg then
        return false, Const.ERROR.MISCONFIGURED
    end

    stats.sent = stats.sent + 1
    stats.last_sent_at = os.time()

    local info = Agent.info()

    local ok, data, errCode, reason = Agent.request('POST', Const.ENDPOINT.HEARTBEAT, {
        state            = Agent.state(),
        agent_version    = Const.AGENT_VERSION,
        protocol_version = Const.PROTOCOL_VERSION,
        uptime_seconds   = info.uptime_seconds,
        players_online   = cfg.metrics.players and info.players_online or nil,
        config_version   = Agent.configVersion(),
        queue_size       = Queue.size(),
        health           = ZShield.Health and ZShield.Health.summary().status or Const.HEALTH.UNKNOWN,
        last_error       = Agent.status().last_error,
        -- Empreinte du serveur (lue du cœur), pour lier les licences automatiquement.
        server_fingerprint = Heartbeat.serverFingerprint(),
    }, { kind = 'heartbeat' })

    if not ok then
        stats.failed = stats.failed + 1
        stats.consecutive_failures = stats.consecutive_failures + 1
        Log.debug('heartbeat failed', { error = errCode, reason = reason })
        return false, errCode, reason
    end

    stats.consecutive_failures = 0
    stats.last_success_at = os.time()

    -- Honour a platform-requested interval, within the schema's bounds.
    if data.suggested_interval and data.suggested_interval ~= stats.suggested_interval then
        stats.suggested_interval = data.suggested_interval
        Log.debug('platform suggested a heartbeat interval', { seconds = data.suggested_interval })
    end

    -- React to the two things the heartbeat can tell us.
    if data.config_version and data.config_version > Agent.configVersion()
        and ZShield.ConfigSync then
        Log.debug('configuration version changed, refreshing', {
            local_version = Agent.configVersion(), platform_version = data.config_version,
        })
        ZShield.ConfigSync.refresh('heartbeat')
    end

    if (data.commands_pending or 0) > 0 and ZShield.Commands then
        ZShield.Commands.poll('heartbeat')
    end

    return true
end

local function effectiveInterval()
    local cfg = ZShield.Agent.config()
    local base = (cfg and cfg.heartbeat_interval) or 30

    if stats.suggested_interval then
        base = stats.suggested_interval
    end

    -- Back off while offline instead of hammering an unreachable platform.
    if stats.consecutive_failures > 0 then
        local factor = math.min(2 ^ math.min(stats.consecutive_failures, 5), 10)
        base = math.min(base * factor, Const.LIMIT.MAX_BACKOFF_SECONDS)
    end

    stats.last_interval = base
    return base
end

function Heartbeat.start()
    if running then
        return
    end
    running = true

    CreateThread(function()
        while running do
            if ZShield.Agent.state() ~= Const.AGENT_STATE.MISCONFIGURED
                and ZShield.Agent.state() ~= Const.AGENT_STATE.STOPPING then
                local ok, err = pcall(Heartbeat.beat)
                if not ok then
                    -- A bug in the heartbeat must not kill the thread; every
                    -- other loop depends on this one staying alive.
                    Log.error('heartbeat raised an error', { error = tostring(err) })
                end
            end

            Wait(effectiveInterval() * 1000)
        end
    end)

    Log.debug('heartbeat loop started')
end

function Heartbeat.stop()
    running = false
end

function Heartbeat.stats()
    local copy = {}
    for k, v in pairs(stats) do
        copy[k] = v
    end
    copy.interval = stats.last_interval
    return copy
end

ZShield.Heartbeat = Heartbeat

return Heartbeat
