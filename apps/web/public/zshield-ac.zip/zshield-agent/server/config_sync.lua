--[[
    zshield-agent / server/config_sync.lua

    PURPOSE
        Pull remote configuration from the platform and hand it to the agent
        after validation.

        The rule this module exists to enforce: the dashboard can adjust
        *behaviour within bounds*, and nothing else. It can ask the agent to
        report less often, to log more verbosely, or to stop collecting a
        metric. It cannot change who the agent is, where it connects, what
        commands are permitted, or how large the local queue may grow.

        Anything outside Protocol.REMOTE_CONFIG_SCHEMA is rejected, including
        fields that merely look harmless. A new remotely-tunable setting is a
        deliberate protocol change on both sides, not something the platform
        can introduce unilaterally.

    DEPENDENCIES
        shared/constants.lua, shared/protocol.lua
        server/logger.lua, server/agent.lua

    PUBLIC API
        ZShield.ConfigSync.refresh(trigger) -> ok, errOrVersion
        ZShield.ConfigSync.start()
        ZShield.ConfigSync.stats()
]]

ZShield = ZShield or {}

local Const = ZShield.Const
local Log = ZShield.Log

local ConfigSync = {}

local REFRESH_INTERVAL <const> = 300 -- seconds; heartbeat triggers earlier refreshes

local running = false
local refreshing = false

local stats = {
    refreshes = 0,
    applied = 0,
    rejected = 0,
    failed = 0,
    last_refresh_at = nil,
    last_applied_at = nil,
    last_rejection = nil,
}

local lastLicense = nil

--- Transmet une clé de licence au cœur anticheat via son export. Idempotent :
--- on ne rappelle pas l'export pour une clé déjà transmise. Défensif : si le cœur
--- n'est pas présent (export absent), on n'échoue pas.
function ConfigSync.applyLicense(token)
    if type(token) ~= 'string' or token == '' then return false end
    if token == lastLicense then return true end

    local delivered = false
    for _, name in ipairs({ 'zshield_ac', 'zshield-ac' }) do
        local ok = pcall(function()
            local api = exports and exports[name]
            if api and api.SetLicense then
                api:SetLicense(token)
                delivered = true
            end
        end)
        if ok and delivered then break end
    end

    if delivered then
        lastLicense = token
        Log.info('license delivered to anti-cheat core')
    end
    return delivered
end

--- Transmet les réglages de protections (choix Surveiller/Bloquer du client) au
--- cœur anticheat via son export. Défensif : si le cœur n'est pas présent, on
--- n'échoue pas. Non idempotent volontairement — la liste est petite et l'appel
--- côté cœur est un simple remplacement de table.
function ConfigSync.applyProtections(list)
    if type(list) ~= 'table' then return false end

    local delivered = false
    for _, name in ipairs({ 'zshield_ac', 'zshield-ac' }) do
        local ok = pcall(function()
            local api = exports and exports[name]
            if api and api.SetProtections then
                api:SetProtections(list)
                delivered = true
            end
        end)
        if ok and delivered then break end
    end

    if delivered then
        Log.debug('protection settings delivered to anti-cheat core', { count = #list })
    end
    return delivered
end

--- Fetch and apply remote configuration. Returns ok, versionOrError.
function ConfigSync.refresh(trigger)
    local Agent = ZShield.Agent
    local cfg = Agent.config()

    if not cfg then
        return false, 'agent not configured'
    end
    if not cfg.remote_config.enabled then
        return false, 'remote configuration is disabled locally'
    end
    if refreshing then
        return false, 'a refresh is already in flight'
    end

    refreshing = true
    stats.refreshes = stats.refreshes + 1
    stats.last_refresh_at = os.time()

    local ok, data, errCode, reason = Agent.request('GET', Const.ENDPOINT.CONFIG, nil, {
        kind = 'config',
        query = 'version=' .. tostring(Agent.configVersion()),
    })

    refreshing = false

    if not ok then
        -- A schema failure here is a security-relevant event: the platform
        -- tried to push something this agent will not accept.
        if errCode == Const.ERROR.VALIDATION then
            stats.rejected = stats.rejected + 1
            stats.last_rejection = { at = os.time(), reason = reason }
            Log.security('rejected a remote configuration that failed validation', {
                trigger = trigger, reason = reason,
            })
        else
            stats.failed = stats.failed + 1
            Log.debug('config refresh failed', {
                trigger = trigger, error = errCode, reason = reason,
            })
        end
        return false, reason or errCode
    end

    if not data.config then
        Log.debug('config refresh returned no configuration', { trigger = trigger })
        return true, Agent.configVersion()
    end

    -- Livraison automatique de la licence : la plateforme joint la clé du serveur.
    -- On la transmet au cœur anticheat, qui l'applique tout seul (le client n'a rien
    -- à coller). Traité à part du reste de la config.
    if data.config.license then
        pcall(ConfigSync.applyLicense, data.config.license)
    end

    -- Réglages de protections (choix Surveiller/Bloquer). Joints par la plateforme
    -- hors du schéma strict, comme la licence, et transmis tels quels au cœur.
    if data.config.protections then
        pcall(ConfigSync.applyProtections, data.config.protections)
    end

    local applied = Agent.applyRemoteConfig(data.config)
    if applied then
        stats.applied = stats.applied + 1
        stats.last_applied_at = os.time()
    end

    return true, Agent.configVersion()
end

function ConfigSync.start()
    if running then
        return
    end
    running = true

    -- Initial pull, then a slow safety-net loop. The heartbeat handles the
    -- common case by reporting a version change, so this loop only exists to
    -- recover from a missed notification.
    CreateThread(function()
        local cfg = ZShield.Agent.config()
        if cfg and cfg.remote_config.enabled then
            pcall(ConfigSync.refresh, 'startup')
        end

        while running do
            Wait(REFRESH_INTERVAL * 1000)
            if ZShield.Agent.isOperational() then
                local ok, err = pcall(ConfigSync.refresh, 'interval')
                if not ok then
                    Log.error('config refresh raised an error', { error = tostring(err) })
                end
            end
        end
    end)

    Log.debug('config sync loop started')
end

function ConfigSync.stop()
    running = false
end

function ConfigSync.stats()
    local cfg = ZShield.Agent.config()
    return {
        enabled = cfg and cfg.remote_config.enabled or false,
        version = ZShield.Agent.configVersion(),
        refreshes = stats.refreshes,
        applied = stats.applied,
        rejected = stats.rejected,
        failed = stats.failed,
        last_refresh_at = stats.last_refresh_at,
        last_applied_at = stats.last_applied_at,
        last_rejection = stats.last_rejection,
    }
end

ZShield.ConfigSync = ConfigSync

return ConfigSync
