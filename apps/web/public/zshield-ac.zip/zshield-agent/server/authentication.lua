--[[
    zshield-agent / server/authentication.lua

    PURPOSE
        Owns the shared secret and everything derived from it:
          - signing outbound requests (HMAC-SHA256 over a canonical string);
          - verifying that responses were produced by the platform;
          - replay protection in both directions;
          - credential rotation with a confirm-before-commit handshake.

    DEPENDENCIES
        shared/constants.lua, shared/crypto.lua, shared/protocol.lua
        server/logger.lua

    PUBLIC API
        ZShield.Auth.init(cfg)                       -> ok, err
        ZShield.Auth.isReady()                       -> boolean
        ZShield.Auth.sign(method, path, query, body) -> headers, requestId
        ZShield.Auth.verifyResponse(ctx)             -> ok, errCode, reason
        ZShield.Auth.beginRotation(keyId, secret)    -> token
        ZShield.Auth.commitRotation(token)           -> ok
        ZShield.Auth.abortRotation(token)
        ZShield.Auth.describe()                      -> safe metadata (no secret)

    SECURITY NOTES / ASSUMPTIONS
        - The secret is a bearer credential. Anything able to read the server's
          configuration or memory can impersonate the agent to the platform.
          There is no hardware-backed key storage in FXServer; this is an
          accepted limitation, not something the agent can fix.
        - Replay protection relies on the agent clock being roughly correct. A
          server whose clock is more than CLOCK_SKEW_TOLERANCE off will fail to
          authenticate. That is intentional: silently widening the window to
          accommodate a broken clock would weaken every request.
        - Response verification proves the platform holds the shared secret. It
          does not prove the platform has not been compromised. Commands are
          still restricted to an allowlist for exactly that reason.
        - A rotated secret is written to data/credential.json in plaintext,
          because the agent must survive a restart. Protect that file with
          filesystem permissions. Rotation is opt-in for this reason.
]]

ZShield = ZShield or {}

local Const = ZShield.Const
local Crypto = ZShield.Crypto
local Protocol = ZShield.Protocol
local Log = ZShield.Log

local Auth = {}

local RESOURCE <const> = GetCurrentResourceName and GetCurrentResourceName() or 'zshield-agent'
local CREDENTIAL_FILE <const> = 'data/credential.json'
local NONCE_CACHE_LIMIT <const> = 512

local state = {
    ready = false,
    agentId = nil,
    serverId = nil,
    keyId = nil,
    secret = nil,
    rotatedAt = nil,
    -- nonces of responses already accepted, used to reject a replayed response
    seenNonces = {},
    seenOrder = {},
    -- pending rotation, keyed by an opaque local token
    pendingRotation = nil,
    signedRequests = 0,
    rejectedResponses = 0,
}

-- ---------------------------------------------------------------------------
-- Credential loading
-- ---------------------------------------------------------------------------

--- A rotated credential takes precedence over the configured one.
local function loadRotatedCredential()
    if not LoadResourceFile then
        return nil
    end
    local raw = LoadResourceFile(RESOURCE, CREDENTIAL_FILE)
    if not raw or raw == '' then
        return nil
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= 'table' then
        Log.warn('stored credential file is unreadable, falling back to configured credential')
        return nil
    end
    if type(decoded.key_id) ~= 'string' or type(decoded.secret) ~= 'string' then
        Log.warn('stored credential file is incomplete, falling back to configured credential')
        return nil
    end

    return decoded
end

local function persistCredential(keyId, secret)
    if not SaveResourceFile then
        return false
    end
    local payload = json.encode({
        key_id = keyId,
        secret = secret,
        rotated_at = os.time(),
        note = 'Rotated agent credential. Treat this file as a secret.',
    })
    return SaveResourceFile(RESOURCE, CREDENTIAL_FILE, payload, -1) and true or false
end

--- Initialise from validated configuration. Returns ok, err.
function Auth.init(cfg)
    local secret = cfg.secret

    -- A convar always wins: it keeps the secret out of resource files.
    if GetConvar then
        local fromConvar = GetConvar('zshield_agent_secret', '')
        if fromConvar ~= '' then
            secret = fromConvar
        end
    end

    local keyId = cfg.key_id

    local rotated = loadRotatedCredential()
    if rotated then
        keyId = rotated.key_id
        secret = rotated.secret
        state.rotatedAt = rotated.rotated_at
        Log.info('using rotated credential from local store', { key_id = keyId })
    end

    if type(secret) ~= 'string' or #secret < 32 then
        return false, 'missing or too short signing secret (need at least 32 characters, '
            .. 'set the zshield_agent_secret convar or config.secret)'
    end

    state.agentId = cfg.agent_id
    state.serverId = cfg.server_id
    state.keyId = keyId
    state.secret = secret
    state.ready = true

    -- From this point the secret can never appear in output.
    Log.protect(secret)

    return true
end

function Auth.isReady()
    return state.ready
end

-- ---------------------------------------------------------------------------
-- Outbound signing
-- ---------------------------------------------------------------------------

--- Sign a request. Returns the header table and the generated request id.
--- `body` must be the exact string that will be transmitted.
function Auth.sign(method, path, query, body)
    if not state.ready then
        error('authentication.sign called before init', 2)
    end

    local timestamp = os.time()
    local nonce = Crypto.nonce(16)
    local requestId = Crypto.nonce(12)
    local bodyHash = Crypto.sha256hex(body or '')

    local canonical = Protocol.canonicalRequest({
        method = method,
        path = path,
        query = query or '',
        agentId = state.agentId,
        serverId = state.serverId,
        keyId = state.keyId,
        timestamp = timestamp,
        nonce = nonce,
        bodyHash = bodyHash,
    })

    local signature = Crypto.hmachex(state.secret, canonical)
    state.signedRequests = state.signedRequests + 1

    local H = Const.HEADER
    return {
        ['Content-Type'] = 'application/json; charset=utf-8',
        ['Accept'] = 'application/json',
        ['User-Agent'] = ('zshield-agent/%s'):format(Const.AGENT_VERSION),
        [H.AGENT_ID] = state.agentId,
        [H.SERVER_ID] = state.serverId,
        [H.KEY_ID] = state.keyId,
        [H.TIMESTAMP] = tostring(timestamp),
        [H.NONCE] = nonce,
        [H.SIGNATURE] = signature,
        [H.PROTOCOL] = tostring(Const.PROTOCOL_VERSION),
        [H.AGENT_VER] = Const.AGENT_VERSION,
        [H.REQUEST_ID] = requestId,
    }, requestId
end

--- Sign with an explicit credential instead of the active one.
--- Used during rotation to prove the new secret works before committing.
function Auth.signWith(keyId, secret, method, path, query, body)
    local timestamp = os.time()
    local nonce = Crypto.nonce(16)
    local requestId = Crypto.nonce(12)
    local bodyHash = Crypto.sha256hex(body or '')

    local canonical = Protocol.canonicalRequest({
        method = method,
        path = path,
        query = query or '',
        agentId = state.agentId,
        serverId = state.serverId,
        keyId = keyId,
        timestamp = timestamp,
        nonce = nonce,
        bodyHash = bodyHash,
    })

    local H = Const.HEADER
    return {
        ['Content-Type'] = 'application/json; charset=utf-8',
        ['Accept'] = 'application/json',
        ['User-Agent'] = ('zshield-agent/%s'):format(Const.AGENT_VERSION),
        [H.AGENT_ID] = state.agentId,
        [H.SERVER_ID] = state.serverId,
        [H.KEY_ID] = keyId,
        [H.TIMESTAMP] = tostring(timestamp),
        [H.NONCE] = nonce,
        [H.SIGNATURE] = Crypto.hmachex(secret, canonical),
        [H.PROTOCOL] = tostring(Const.PROTOCOL_VERSION),
        [H.AGENT_VER] = Const.AGENT_VERSION,
        [H.REQUEST_ID] = requestId,
    }, requestId
end

-- ---------------------------------------------------------------------------
-- Inbound verification
-- ---------------------------------------------------------------------------

local function lowercaseHeaders(headers)
    local out = {}
    if type(headers) == 'table' then
        for k, v in pairs(headers) do
            if type(k) == 'string' then
                -- FXServer may return a table when a header repeats.
                out[k:lower()] = type(v) == 'table' and v[1] or v
            end
        end
    end
    return out
end

local function rememberNonce(nonce)
    state.seenNonces[nonce] = os.time()
    state.seenOrder[#state.seenOrder + 1] = nonce

    while #state.seenOrder > NONCE_CACHE_LIMIT do
        local oldest = table.remove(state.seenOrder, 1)
        state.seenNonces[oldest] = nil
    end
end

--- Verify a platform response.
--- ctx = { status, body, headers, requestId, keyId? , secret? }
--- Returns ok, errorCode, reason.
function Auth.verifyResponse(ctx)
    local headers = lowercaseHeaders(ctx.headers)
    local H = Const.HEADER

    local signature = headers[H.SIGNATURE:lower()]
    local timestamp = tonumber(headers[H.TIMESTAMP:lower()])
    local nonce = headers[H.NONCE:lower()]

    if type(signature) ~= 'string' or not timestamp or type(nonce) ~= 'string' then
        state.rejectedResponses = state.rejectedResponses + 1
        return false, Const.ERROR.BAD_RESPONSE, 'response is missing signature headers'
    end

    local skew = math.abs(os.time() - timestamp)
    if skew > Const.CLOCK_SKEW_TOLERANCE then
        state.rejectedResponses = state.rejectedResponses + 1
        return false, Const.ERROR.CLOCK_SKEW,
            ('response timestamp is %d seconds away from local time'):format(skew)
    end

    if state.seenNonces[nonce] then
        state.rejectedResponses = state.rejectedResponses + 1
        return false, Const.ERROR.REPLAY, 'response nonce already seen'
    end

    local canonical = Protocol.canonicalResponse({
        status = ctx.status,
        requestId = ctx.requestId,
        timestamp = timestamp,
        nonce = nonce,
        bodyHash = Crypto.sha256hex(ctx.body or ''),
    })

    local expected = Crypto.hmachex(ctx.secret or state.secret, canonical)
    if not Crypto.equals(expected, signature:lower()) then
        state.rejectedResponses = state.rejectedResponses + 1
        return false, Const.ERROR.INVALID_SIGNATURE, 'response signature mismatch'
    end

    rememberNonce(nonce)
    return true
end

-- ---------------------------------------------------------------------------
-- Rotation
-- ---------------------------------------------------------------------------

--- Stage a new credential. It is not used for signing until committed.
function Auth.beginRotation(keyId, secret)
    if type(keyId) ~= 'string' or type(secret) ~= 'string' or #secret < 32 then
        return nil, 'invalid rotation material'
    end

    local token = Crypto.nonce(8)
    state.pendingRotation = {
        token = token,
        keyId = keyId,
        secret = secret,
        startedAt = os.time(),
    }

    Log.security('credential rotation staged, awaiting confirmation', { key_id = keyId })
    return token
end

function Auth.pendingRotation()
    local p = state.pendingRotation
    if not p then
        return nil
    end
    return { token = p.token, keyId = p.keyId, secret = p.secret }
end

--- Promote the staged credential to active and persist it.
function Auth.commitRotation(token)
    local pending = state.pendingRotation
    if not pending or pending.token ~= token then
        return false, 'no matching pending rotation'
    end

    local previousKeyId = state.keyId

    state.keyId = pending.keyId
    state.secret = pending.secret
    state.rotatedAt = os.time()
    state.pendingRotation = nil
    Log.protect(pending.secret)

    local persisted = persistCredential(state.keyId, state.secret)
    if not persisted then
        Log.warn('rotated credential could not be persisted; a restart will fall back to the configured credential')
    end

    Log.security('credential rotation committed', {
        previous_key_id = previousKeyId,
        key_id = state.keyId,
        persisted = persisted,
    })

    return true
end

function Auth.abortRotation(token, reason)
    local pending = state.pendingRotation
    if pending and (token == nil or pending.token == token) then
        state.pendingRotation = nil
        Log.security('credential rotation aborted, keeping current credential', { reason = reason })
    end
end

-- ---------------------------------------------------------------------------
-- Introspection
-- ---------------------------------------------------------------------------

--- Metadata safe to log, expose to other resources, or send to the platform.
function Auth.describe()
    return {
        ready = state.ready,
        agent_id = state.agentId,
        server_id = state.serverId,
        key_id = state.keyId,
        rotated_at = state.rotatedAt,
        signed_requests = state.signedRequests,
        rejected_responses = state.rejectedResponses,
        rotation_pending = state.pendingRotation ~= nil,
    }
end

ZShield.Auth = Auth

return Auth
