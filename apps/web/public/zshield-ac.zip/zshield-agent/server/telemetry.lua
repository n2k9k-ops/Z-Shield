--[[
    zshield-agent / server/telemetry.lua

    PURPOSE
        Collect a small, fixed set of operational metrics and ship them in
        batches. Telemetry exists to answer "is this server and this agent
        healthy", not to profile players.

    DEPENDENCIES
        shared/constants.lua, server/logger.lua, server/queue.lua,
        server/agent.lua

    PUBLIC API
        ZShield.Telemetry.start()
        ZShield.Telemetry.collect()      -> sample table
        ZShield.Telemetry.flush()        -> ok, sentCount
        ZShield.Telemetry.record(name, value)   -- custom counter
        ZShield.Telemetry.increment(name, by)
        ZShield.Telemetry.stats()

    PRIVACY
        No identifier of any individual player is collected here: player
        activity is reported as a count only. There is no name, licence,
        Steam id, IP, position or chat content in a telemetry sample, and the
        schema on the platform side should reject one if a future change tries
        to add it. Each metric group can be switched off in configuration and
        remotely, and turning telemetry off entirely leaves alerts and
        heartbeat working.

    PERFORMANCE
        One sample per interval (60s by default), collected with native calls
        that are already cheap, plus counters other resources have incremented.
        Nothing here runs per frame or per event.
]]

ZShield = ZShield or {}

local Const = ZShield.Const
local Log = ZShield.Log
local Queue = ZShield.Queue

local Telemetry = {}

local running = false
local counters = {}
local stats = {
    collected = 0,
    sent = 0,
    failed = 0,
    last_collect_at = nil,
    last_flush_at = nil,
}

--- Increment a named counter. Other resources reach this through the alert
--- export or their own bookkeeping; it is deliberately not exported, because
--- an unbounded metric namespace is a memory leak waiting to happen.
function Telemetry.increment(name, by)
    if type(name) ~= 'string' or #name > 48 then
        return false
    end
    if counters[name] == nil then
        local count = 0
        for _ in pairs(counters) do count = count + 1 end
        if count >= 32 then
            return false
        end
    end
    counters[name] = (counters[name] or 0) + (tonumber(by) or 1)
    return true
end

function Telemetry.record(name, value)
    if type(name) ~= 'string' or type(value) ~= 'number' then
        return false
    end
    counters[name] = value
    return true
end

local function dependencyState()
    -- Report only on resources the agent itself cares about. GetResourceState
    -- is a cheap native and this runs once per interval.
    local watched = { 'zshield-agent' }
    local out = {}

    if GetNumResources and GetResourceByFindIndex then
        -- Report the anti-cheat side if it is present, without assuming it is.
        for _, name in ipairs({ 'zshield_ac', 'zshield-ac' }) do
            watched[#watched + 1] = name
        end
    end

    for _, name in ipairs(watched) do
        local ok, resourceState = pcall(GetResourceState, name)
        out[name] = ok and resourceState or 'unknown'
    end

    return out
end

--- Read the anti-cheat protections snapshot through its export, if the AC
--- resource is present. Defensive: the export may be absent (AC not installed)
--- or raise; either way telemetry keeps working without it. No player data —
--- the snapshot is aggregate counters only.
function Telemetry.protections()
    if type(exports) ~= 'table' and type(exports) ~= 'function' then
        return nil
    end
    for _, name in ipairs({ 'zshield_ac', 'zshield-ac' }) do
        local ok, snapshot = pcall(function()
            local api = exports[name]
            if api and api.GetProtections then
                return api:GetProtections()
            end
            return nil
        end)
        if ok and type(snapshot) == 'table' then
            return snapshot
        end
    end
    return nil
end

local function resourceCount()
    if not GetNumResources then
        return nil
    end
    local total, started = GetNumResources(), 0
    for i = 0, total - 1 do
        local name = GetResourceByFindIndex(i)
        if name and GetResourceState(name) == 'started' then
            started = started + 1
        end
    end
    return { total = total, started = started }
end

--- Build one telemetry sample from the currently enabled metric groups.
function Telemetry.collect()
    local Agent = ZShield.Agent
    local cfg = Agent.config()
    if not cfg then
        return nil
    end

    local status = Agent.status()
    local sample = {
        at = os.time(),
        agent_state = status.state,
        uptime_seconds = status.uptime_seconds,
    }

    if cfg.metrics.players then
        sample.players_online = Agent.info().players_online
    end

    if cfg.metrics.performance then
        sample.performance = {
            lua_memory_kb = math.floor(collectgarbage('count')),
            request_latency_ms = status.latency_ms.last,
            request_latency_mean_ms = status.latency_ms.mean,
            request_latency_max_ms = status.latency_ms.max,
        }
    end

    if cfg.metrics.errors then
        local logCounters = Log.counters()
        sample.errors = {
            warn = logCounters.WARN,
            error = logCounters.ERROR,
            security = logCounters.SECURITY,
            requests_failed = status.requests.failed,
            responses_rejected = status.requests.rejected,
        }
    end

    if cfg.metrics.dependencies then
        sample.dependencies = dependencyState()
    end

    if cfg.metrics.resources then
        sample.resources = resourceCount()
    end

    if cfg.metrics.protections then
        -- Aggregate snapshot of the native protection layers. Nil when the AC
        -- resource is not present; the platform treats it as optional.
        local protections = Telemetry.protections()
        if protections then
            sample.protections = protections
        end
    end

    local queueStats = Queue.stats()
    sample.queue = {
        total = queueStats.total,
        alerts = queueStats.alerts,
        dropped_full = queueStats.dropped_full,
        dropped_expired = queueStats.dropped_expired,
    }

    if next(counters) then
        sample.counters = {}
        for k, v in pairs(counters) do
            sample.counters[k] = v
        end
    end

    stats.collected = stats.collected + 1
    stats.last_collect_at = os.time()

    return sample
end

--- Map an internal sample to the platform's telemetry wire contract. The
--- collector's shape is convenient for the agent; the gateway has its own,
--- stricter schema (sampled_at, memory_mb, bounded dependency states…). We
--- translate at the send boundary so `collect()` stays stable and the platform
--- receives exactly what its schema accepts. Only fields with a real
--- correspondence are mapped — we never invent a value to fill a column.
local DEP_ALLOWED = { started = 'started', missing = 'missing', stopped = 'stopped' }
function Telemetry.toWire(sample)
    local wire = { sampled_at = sample.at }

    if sample.players_online ~= nil then wire.players_online = sample.players_online end
    if sample.uptime_seconds ~= nil then wire.uptime_seconds = sample.uptime_seconds end

    if sample.performance and sample.performance.lua_memory_kb then
        wire.memory_mb = math.floor(sample.performance.lua_memory_kb / 1024 + 0.5)
    end
    if sample.resources and sample.resources.started ~= nil then
        wire.resource_count = sample.resources.started
    end
    if sample.errors and sample.errors.error ~= nil then
        wire.error_count = sample.errors.error
    end
    if sample.queue and sample.queue.total ~= nil then
        wire.queue_size = sample.queue.total
    end

    if sample.dependencies then
        local deps = {}
        for name, state in pairs(sample.dependencies) do
            -- The gateway only accepts started/stopped/missing; anything else
            -- (starting, uninitialized, unknown…) is reported as stopped.
            deps[name] = DEP_ALLOWED[state] or 'stopped'
        end
        wire.dependencies = deps
    end

    -- Aggregate protections snapshot passes through unchanged (bounded by the
    -- gateway schema on arrival).
    if sample.protections then wire.protections = sample.protections end

    return wire
end

--- Queue a sample for delivery. Telemetry is the first thing evicted when the
--- queue fills, which is the correct priority: alerts matter more.
local function enqueue(sample)
    Queue.push(Const.QUEUE_KIND.TELEMETRY, {
        kind = Const.QUEUE_KIND.TELEMETRY,
        severity = Const.SEVERITY.INFO,
        created_at = sample.at,
        sample = sample,
    })
end

--- Send everything buffered. Returns ok, count.
function Telemetry.flush()
    local Agent = ZShield.Agent
    if Queue.size(Const.QUEUE_KIND.TELEMETRY) == 0 then
        return true, 0
    end

    local batch = Queue.take(Const.QUEUE_KIND.TELEMETRY, 60)
    if #batch == 0 then
        return true, 0
    end

    local samples = {}
    for i = 1, #batch do
        samples[i] = Telemetry.toWire(batch[i].sample)
    end

    local ok, _, errCode, reason = Agent.request('POST', Const.ENDPOINT.TELEMETRY, {
        samples = samples,
    }, { kind = 'telemetry' })

    if not ok then
        stats.failed = stats.failed + 1
        -- Only requeue if retrying could succeed. Telemetry rejected as
        -- invalid will be rejected again forever, so it is dropped.
        if ZShield.Protocol.isRetryable(errCode) then
            Queue.requeue(batch)
        else
            Log.warn('dropping telemetry batch permanently', {
                count = #batch, error = errCode, reason = reason,
            })
        end
        return false, 0
    end

    Queue.markDelivered(#batch)
    stats.sent = stats.sent + #batch
    stats.last_flush_at = os.time()

    return true, #batch
end

function Telemetry.start()
    if running then
        return
    end
    running = true

    CreateThread(function()
        while running do
            local cfg = ZShield.Agent.config()
            local interval = (cfg and cfg.telemetry_interval) or 60

            if cfg and cfg.telemetry_enabled then
                local ok, err = pcall(function()
                    local sample = Telemetry.collect()
                    if sample then
                        enqueue(sample)
                        Telemetry.flush()
                    end
                end)
                if not ok then
                    Log.error('telemetry cycle raised an error', { error = tostring(err) })
                end
            end

            Wait(interval * 1000)
        end
    end)

    Log.debug('telemetry loop started')
end

function Telemetry.stop()
    running = false
end

function Telemetry.stats()
    return {
        collected = stats.collected,
        sent = stats.sent,
        failed = stats.failed,
        last_collect_at = stats.last_collect_at,
        last_flush_at = stats.last_flush_at,
        buffered = Queue.size(Const.QUEUE_KIND.TELEMETRY),
        counters = counters,
    }
end

ZShield.Telemetry = Telemetry

return Telemetry
