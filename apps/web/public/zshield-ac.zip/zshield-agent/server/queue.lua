--[[
    zshield-agent / server/queue.lua

    PURPOSE
        Local buffer for anything that must survive the platform being
        unreachable. Bounded in size and in time, persisted across resource
        restarts, and biased towards keeping the most severe items.

        Failure behaviour is the whole point of this module: the platform being
        down must degrade reporting, never gameplay. So the queue has a hard
        ceiling, drops the least useful items first, and reports what it
        dropped instead of dropping silently.

    DEPENDENCIES
        shared/constants.lua, server/logger.lua

    PUBLIC API
        ZShield.Queue.init(cfg)
        ZShield.Queue.push(kind, item)      -> ok, err
        ZShield.Queue.take(kind, max)       -> items
        ZShield.Queue.requeue(items)        -> count
        ZShield.Queue.prune()               -> expiredCount
        ZShield.Queue.size(kind)            -> number
        ZShield.Queue.stats()               -> table
        ZShield.Queue.persist()             -> ok
        ZShield.Queue.restore()             -> count
        ZShield.Queue.clear(kind)           -> count

    PERFORMANCE
        Items are held in a plain array per kind. Eviction is O(n) but only
        runs when the queue is full, which means the platform is already down
        and the agent has nothing better to do. Persistence writes one JSON
        file and is called on flush milestones and on resource stop, never per
        item.
]]

ZShield = ZShield or {}

local Const = ZShield.Const
local Log = ZShield.Log

local Queue = {}

local RESOURCE <const> = GetCurrentResourceName and GetCurrentResourceName() or 'zshield-agent'

local cfg = {
    maxSize = 2000,
    ttl = 6 * 3600,
    persist = true,
}

local store = {
    [Const.QUEUE_KIND.ALERT] = {},
    [Const.QUEUE_KIND.TELEMETRY] = {},
}

local stats = {
    pushed = 0,
    dropped_full = 0,
    dropped_expired = 0,
    requeued = 0,
    delivered = 0,
    persist_failures = 0,
    last_persist_at = nil,
}

local dirty = false

local function weightOf(item)
    return Const.SEVERITY_WEIGHT[item.severity or Const.SEVERITY.INFO] or 1
end

function Queue.init(options)
    options = options or {}
    cfg.maxSize = options.max_size or cfg.maxSize
    cfg.ttl = options.ttl or cfg.ttl
    cfg.persist = options.persist ~= false

    if cfg.persist then
        local restored = Queue.restore()
        if restored > 0 then
            Log.info('restored buffered items from disk', { count = restored })
        end
    end
end

local function totalSize()
    return #store[Const.QUEUE_KIND.ALERT] + #store[Const.QUEUE_KIND.TELEMETRY]
end

--- Remove one item: the lowest severity, and among those the oldest.
--- Telemetry is sacrificed before alerts at equal weight.
local function evictOne()
    local worstKind, worstIndex, worstWeight, worstAge

    for kind, items in pairs(store) do
        local kindPenalty = (kind == Const.QUEUE_KIND.TELEMETRY) and 0 or 1
        for i = 1, #items do
            local w = weightOf(items[i]) * 10 + kindPenalty
            local age = items[i].created_at or 0
            if worstWeight == nil or w < worstWeight or (w == worstWeight and age < worstAge) then
                worstKind, worstIndex, worstWeight, worstAge = kind, i, w, age
            end
        end
    end

    if worstKind then
        table.remove(store[worstKind], worstIndex)
        stats.dropped_full = stats.dropped_full + 1
        return true
    end

    return false
end

--- Add an item. `item` must already be a validated, serialisable table.
--- Returns ok, err.
function Queue.push(kind, item)
    local bucket = store[kind]
    if not bucket then
        return false, 'unknown queue kind: ' .. tostring(kind)
    end
    if type(item) ~= 'table' then
        return false, 'queue item must be a table'
    end

    item.created_at = item.created_at or os.time()
    item.attempts = item.attempts or 0

    while totalSize() >= cfg.maxSize do
        if not evictOne() then
            return false, Const.ERROR.QUEUE_FULL
        end
    end

    bucket[#bucket + 1] = item
    stats.pushed = stats.pushed + 1
    dirty = true

    return true
end

--- Remove and return up to `max` items, oldest first. Callers own the items
--- until they either confirm delivery or requeue them.
function Queue.take(kind, max)
    local bucket = store[kind]
    if not bucket or #bucket == 0 then
        return {}
    end

    max = math.max(1, math.min(max or 50, #bucket))
    local batch = {}

    for i = 1, max do
        batch[i] = bucket[i]
    end
    for _ = 1, max do
        table.remove(bucket, 1)
    end

    dirty = true
    return batch
end

--- Put items back after a failed delivery attempt.
function Queue.requeue(items)
    if type(items) ~= 'table' then
        return 0
    end

    local count = 0
    for i = 1, #items do
        local item = items[i]
        item.attempts = (item.attempts or 0) + 1
        local kind = item.kind or Const.QUEUE_KIND.ALERT
        local bucket = store[kind]
        if bucket then
            -- Reinsert at the front so ordering stays roughly chronological.
            table.insert(bucket, 1, item)
            count = count + 1
            stats.requeued = stats.requeued + 1
        end
    end

    -- Reinserting can exceed the ceiling; trim back down.
    while totalSize() > cfg.maxSize do
        if not evictOne() then
            break
        end
    end

    dirty = true
    return count
end

function Queue.markDelivered(count)
    stats.delivered = stats.delivered + (count or 0)
    dirty = true
end

--- Drop items older than the configured TTL.
function Queue.prune()
    local cutoff = os.time() - cfg.ttl
    local removed = 0

    for _, items in pairs(store) do
        for i = #items, 1, -1 do
            if (items[i].created_at or 0) < cutoff then
                table.remove(items, i)
                removed = removed + 1
            end
        end
    end

    if removed > 0 then
        stats.dropped_expired = stats.dropped_expired + removed
        dirty = true
        Log.warn('dropped expired buffered items', { count = removed, ttl_seconds = cfg.ttl })
    end

    return removed
end

function Queue.size(kind)
    if kind then
        return store[kind] and #store[kind] or 0
    end
    return totalSize()
end

function Queue.stats()
    return {
        alerts = #store[Const.QUEUE_KIND.ALERT],
        telemetry = #store[Const.QUEUE_KIND.TELEMETRY],
        total = totalSize(),
        max_size = cfg.maxSize,
        utilisation = totalSize() / cfg.maxSize,
        pushed = stats.pushed,
        delivered = stats.delivered,
        requeued = stats.requeued,
        dropped_full = stats.dropped_full,
        dropped_expired = stats.dropped_expired,
        persist_failures = stats.persist_failures,
        last_persist_at = stats.last_persist_at,
    }
end

function Queue.clear(kind)
    if kind then
        local n = #(store[kind] or {})
        store[kind] = {}
        dirty = true
        return n
    end

    local n = totalSize()
    for k in pairs(store) do
        store[k] = {}
    end
    dirty = true
    return n
end

-- ---------------------------------------------------------------------------
-- Persistence
-- ---------------------------------------------------------------------------

function Queue.persist(force)
    if not cfg.persist or not SaveResourceFile then
        return false
    end
    if not dirty and not force then
        return true
    end

    local ok, encoded = pcall(json.encode, {
        version = 1,
        saved_at = os.time(),
        items = store,
    })

    if not ok then
        stats.persist_failures = stats.persist_failures + 1
        Log.error('failed to encode queue for persistence')
        return false
    end

    local written = SaveResourceFile(RESOURCE, Const.STORAGE.QUEUE, encoded, -1)
    if not written then
        stats.persist_failures = stats.persist_failures + 1
        Log.error('failed to write queue file', { path = Const.STORAGE.QUEUE })
        return false
    end

    stats.last_persist_at = os.time()
    dirty = false
    return true
end

function Queue.restore()
    if not LoadResourceFile then
        return 0
    end

    local raw = LoadResourceFile(RESOURCE, Const.STORAGE.QUEUE)
    if not raw or raw == '' then
        return 0
    end

    local ok, decoded = pcall(json.decode, raw)
    if not ok or type(decoded) ~= 'table' or type(decoded.items) ~= 'table' then
        Log.warn('queue file is unreadable, starting with an empty queue')
        return 0
    end

    local restored = 0
    local cutoff = os.time() - cfg.ttl

    for kind, items in pairs(decoded.items) do
        if store[kind] and type(items) == 'table' then
            for i = 1, #items do
                local item = items[i]
                if type(item) == 'table' and (item.created_at or 0) >= cutoff then
                    if totalSize() < cfg.maxSize then
                        store[kind][#store[kind] + 1] = item
                        restored = restored + 1
                    end
                end
            end
        end
    end

    return restored
end

ZShield.Queue = Queue

return Queue
