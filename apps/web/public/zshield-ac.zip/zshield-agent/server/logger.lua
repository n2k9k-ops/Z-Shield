--[[
    zshield-agent / server/logger.lua

    PURPOSE
        Structured logging with mandatory secret redaction.

        The redaction is not a convenience: the agent holds a shared secret and
        talks to a remote API, and a log line is the most common way a secret
        escapes a server. Any value registered with `Log.protect` is replaced
        everywhere it appears in a message or field, including inside nested
        tables, before anything is printed.

    DEPENDENCIES
        shared/constants.lua

    PUBLIC API
        ZShield.Log.setLevel(name)
        ZShield.Log.protect(secret)            -- register a value to redact
        ZShield.Log.debug(msg, fields)
        ZShield.Log.info(msg, fields)
        ZShield.Log.warn(msg, fields)
        ZShield.Log.error(msg, fields)
        ZShield.Log.security(msg, fields)      -- never suppressed
        ZShield.Log.counters()                 -- { WARN = n, ERROR = n, ... }

    SECURITY NOTES
        - Redaction is substring based and case-sensitive. It catches the exact
          secret, which is what matters for a token accidentally interpolated
          into a URL or an error string. It cannot catch a secret that has been
          transformed (base64, truncated). The real defence is that no module
          ever passes the secret as a log field.
        - Field values are stringified with a depth limit so a cyclic table
          from a caller cannot hang the resource.
]]

ZShield = ZShield or {}

local Const = ZShield.Const
local Log = {}

local PREFIX <const> = '[zshield-agent]'
local MAX_DEPTH <const> = 4
local MAX_FIELD_LENGTH <const> = 2048
local REDACTED <const> = '[redacted]'

local currentLevel = Const.LOG_LEVEL.INFO
local jsonOutput = false
local secrets = {}
local counters = { DEBUG = 0, INFO = 0, WARN = 0, ERROR = 0, SECURITY = 0 }
local lastError = nil

--- Set the minimum level emitted. SECURITY always bypasses this.
function Log.setLevel(name)
    local level = Const.LOG_LEVEL[string.upper(tostring(name or ''))]
    if level then
        currentLevel = level
        return true
    end
    return false
end

function Log.getLevel()
    return Const.LOG_LEVEL_NAME[currentLevel]
end

function Log.setJson(enabled)
    jsonOutput = enabled and true or false
end

--- Register a value that must never appear in output.
function Log.protect(secret)
    if type(secret) == 'string' and #secret >= 6 then
        secrets[#secrets + 1] = secret
    end
end

function Log.clearProtected()
    secrets = {}
end

local function redact(text)
    if type(text) ~= 'string' then
        return text
    end
    for i = 1, #secrets do
        -- plain=true: the secret is literal text, not a Lua pattern.
        local at = text:find(secrets[i], 1, true)
        while at do
            text = text:sub(1, at - 1) .. REDACTED .. text:sub(at + #secrets[i])
            at = text:find(secrets[i], at + #REDACTED, true)
        end
    end
    return text
end

Log.redact = redact

local function stringify(value, depth)
    depth = depth or 0
    local t = type(value)

    if t == 'string' then
        local s = redact(value)
        if #s > MAX_FIELD_LENGTH then
            s = s:sub(1, MAX_FIELD_LENGTH) .. '...'
        end
        return s
    elseif t == 'number' or t == 'boolean' or t == 'nil' then
        return tostring(value)
    elseif t == 'table' then
        if depth >= MAX_DEPTH then
            return '<depth limit>'
        end
        local parts, n = {}, 0
        for k, v in pairs(value) do
            n = n + 1
            if n > 24 then
                parts[#parts + 1] = '...'
                break
            end
            parts[#parts + 1] = tostring(k) .. '=' .. stringify(v, depth + 1)
        end
        table.sort(parts)
        return '{' .. table.concat(parts, ' ') .. '}'
    end

    return '<' .. t .. '>'
end

local function formatFields(fields)
    if type(fields) ~= 'table' then
        return ''
    end
    local parts = {}
    for k, v in pairs(fields) do
        parts[#parts + 1] = ('%s=%s'):format(tostring(k), stringify(v, 1))
    end
    table.sort(parts)
    if #parts == 0 then
        return ''
    end
    return ' ' .. table.concat(parts, ' ')
end

local function emit(levelValue, message, fields)
    local levelName = Const.LOG_LEVEL_NAME[levelValue]
    counters[levelName] = (counters[levelName] or 0) + 1

    if levelValue >= Const.LOG_LEVEL.ERROR then
        lastError = {
            at = os.time(),
            level = levelName,
            message = redact(tostring(message)),
        }
    end

    if levelValue < currentLevel and levelValue ~= Const.LOG_LEVEL.SECURITY then
        return
    end

    local safeMessage = redact(tostring(message))

    if jsonOutput then
        local record = {
            timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ'),
            level = levelName,
            module = 'zshield-agent',
            message = safeMessage,
        }
        if type(fields) == 'table' then
            local safeFields = {}
            for k, v in pairs(fields) do
                safeFields[tostring(k)] = stringify(v, 1)
            end
            record.fields = safeFields
        end
        print(('%s %s'):format(PREFIX, json.encode(record)))
    else
        print(('%s [%s] %s%s'):format(PREFIX, levelName, safeMessage, formatFields(fields)))
    end
end

function Log.debug(msg, fields) emit(Const.LOG_LEVEL.DEBUG, msg, fields) end
function Log.info(msg, fields) emit(Const.LOG_LEVEL.INFO, msg, fields) end
function Log.warn(msg, fields) emit(Const.LOG_LEVEL.WARN, msg, fields) end
function Log.error(msg, fields) emit(Const.LOG_LEVEL.ERROR, msg, fields) end

--- Security-relevant event. Always emitted, whatever the configured level.
function Log.security(msg, fields) emit(Const.LOG_LEVEL.SECURITY, msg, fields) end

function Log.counters()
    return {
        DEBUG = counters.DEBUG,
        INFO = counters.INFO,
        WARN = counters.WARN,
        ERROR = counters.ERROR,
        SECURITY = counters.SECURITY,
    }
end

function Log.lastError()
    return lastError
end

ZShield.Log = Log

return Log
