--[[
    zshield-agent / server/alerts.lua

    PURPOSE
        The ingest point for security alerts produced by other resources
        (typically an anti-cheat) and the only path by which they reach the
        platform.

        Three jobs:
          1. Validate. An alert from another resource is untrusted input, even
             though it comes from the same server. A malformed alert must not
             be able to break the transport or poison the dashboard.
          2. Deduplicate. One anomaly repeated 500 times in a second is one
             alert with a count, not 500 rows and 500 notifications.
          3. Buffer and batch. Alerts survive the platform being down.

    DEPENDENCIES
        shared/constants.lua, shared/validation.lua
        server/logger.lua, server/queue.lua, server/agent.lua

    PUBLIC API
        ZShield.Alerts.submit(alert, origin)  -> ok, idOrError
        ZShield.Alerts.flush()                -> ok, count
        ZShield.Alerts.start()
        ZShield.Alerts.stats()

    EXPORT
        exports['zshield-agent']:SendSecurityAlert({
            category = 'movement',
            severity = 'HIGH',
            summary  = 'position delta inconsistent with vehicle state',
            metadata = { detector = 'movement.anomaly', confidence = 0.62 },
            dedup_key = 'movement.anomaly:1234',   -- optional
        })

    WHAT AN ALERT IS NOT
        An alert is a report that a detector fired. It is not a verdict, and
        the agent attaches no enforcement semantics to it. Severity describes
        how much attention a human should give it, not how certain anyone is
        that abuse occurred. Keep confidence in metadata and let the reviewer
        see both.

    SECURITY NOTES
        - Metadata is bounded (key count, value length, scalar values only) and
          control characters are rejected, so an alert cannot smuggle a log
          injection or an oversized payload through the agent.
        - The agent does not redact caller-supplied metadata beyond registered
          secrets. Do not put credentials, tokens or full chat logs in an
          alert; the platform stores what it receives.
]]

ZShield = ZShield or {}

local Const = ZShield.Const
local Validation = ZShield.Validation
local Crypto = ZShield.Crypto
local Log = ZShield.Log
local Queue = ZShield.Queue

local Alerts = {}

local DEDUP_WINDOW <const> = 30 -- seconds

local ALERT_SCHEMA <const> = {
    type = 'table',
    strict = true,
    fields = {
        category = { type = 'string', required = true, max = 32, enum = Const.ALERT_CATEGORY },
        severity = { type = 'string', required = true, enum = {
            Const.SEVERITY.INFO, Const.SEVERITY.LOW, Const.SEVERITY.MEDIUM,
            Const.SEVERITY.HIGH, Const.SEVERITY.CRITICAL,
        } },
        summary  = { type = 'string', required = true, min = 3,
                     max = Const.LIMIT.MAX_SUMMARY_LENGTH },
        metadata = { type = 'table', maxKeys = Const.LIMIT.MAX_METADATA_KEYS,
                     maxValueLength = Const.LIMIT.MAX_METADATA_STRING },
        dedup_key   = { type = 'string', max = 128, pattern = '^[%w%.%-_:]+$' },
        occurred_at = { type = 'integer', min = 0 },
        -- Opaque reference to whatever produced the alert (an incident id in
        -- the anti-cheat, for example). Never a player identifier.
        reference   = { type = 'string', max = 64, pattern = '^[%w%-_:]+$' },
        -- Optional sanction proposal. When present, the platform records a ban:
        -- ACTIVE when the alert is CRITICAL (the core is certain), otherwise
        -- PENDING (queued for human review). The agent never enforces; it only
        -- forwards the proposal. The identifier here is a player identifier the
        -- server already owns (license/steam/discord/ip/fivem), used to sanction
        -- the right person — it is not a stream or a capture.
        sanction = { type = 'table', strict = true, fields = {
            scope         = { type = 'string', required = true,
                              enum = { 'license', 'discord', 'steam', 'ip', 'fivem' } },
            identifier    = { type = 'string', required = true, min = 1, max = 128 },
            player_name   = { type = 'string', max = 64 },
            detector      = { type = 'string', required = true, min = 1, max = 64 },
            risk          = { type = 'integer', min = 0, max = 100 },
            evidence_kind = { type = 'string', enum = { 'clip', 'screenshot' } },
        } },
    },
}

local stats = {
    submitted = 0,
    rejected = 0,
    deduplicated = 0,
    sent = 0,
    dropped = 0,
    by_severity = { INFO = 0, LOW = 0, MEDIUM = 0, HIGH = 0, CRITICAL = 0 },
    last_submit_at = nil,
    last_flush_at = nil,
}

local running = false

-- dedup_key -> { id, count, firstAt, lastAt, queued }
local dedupWindow = {}

local function pruneDedup()
    local cutoff = os.time() - DEDUP_WINDOW
    for key, entry in pairs(dedupWindow) do
        if entry.lastAt < cutoff then
            dedupWindow[key] = nil
        end
    end
end

--- Submit an alert. `origin` is a free-form label for the caller, used for
--- logging only. Returns ok, alertId (or false, reason).
function Alerts.submit(alert, origin)
    origin = type(origin) == 'string' and origin:sub(1, 64) or 'unknown'

    local ok, validated = Validation.check(alert, ALERT_SCHEMA)
    if not ok then
        stats.rejected = stats.rejected + 1
        Log.warn('rejected a malformed alert', { origin = origin, reason = validated })
        return false, validated
    end

    stats.submitted = stats.submitted + 1
    stats.last_submit_at = os.time()
    stats.by_severity[validated.severity] = (stats.by_severity[validated.severity] or 0) + 1

    local now = os.time()
    validated.occurred_at = validated.occurred_at or now

    -- Deduplication: within the window, an identical key increments a counter
    -- on the already-queued alert instead of creating a new one.
    local key = validated.dedup_key
    if key then
        pruneDedup()
        local entry = dedupWindow[key]
        if entry and entry.queued then
            entry.count = entry.count + 1
            entry.lastAt = now
            entry.queued.occurrences = entry.count
            entry.queued.last_occurrence_at = now
            stats.deduplicated = stats.deduplicated + 1
            return true, entry.id
        end
    end

    local id = 'al_' .. Crypto.nonce(10)

    local item = {
        kind = Const.QUEUE_KIND.ALERT,
        id = id,
        severity = validated.severity,
        created_at = now,
        occurrences = 1,
        category = validated.category,
        summary = validated.summary,
        metadata = validated.metadata,
        reference = validated.reference,
        sanction = validated.sanction,
        dedup_key = key,
        occurred_at = validated.occurred_at,
        last_occurrence_at = now,
        origin = origin,
    }

    local pushed, pushError = Queue.push(Const.QUEUE_KIND.ALERT, item)
    if not pushed then
        stats.dropped = stats.dropped + 1
        Log.error('could not buffer an alert', { origin = origin, reason = pushError })
        return false, pushError
    end

    if key then
        dedupWindow[key] = { id = id, count = 1, firstAt = now, lastAt = now, queued = item }
    end

    -- CRITICAL alerts do not wait for the next flush tick.
    if validated.severity == Const.SEVERITY.CRITICAL then
        CreateThread(function()
            Alerts.flush()
        end)
    end

    return true, id
end

--- Build the wire representation. The queue item carries local bookkeeping
--- (origin, dedup state) that the platform has no use for.
local function toWire(item)
    return {
        id = item.id,
        category = item.category,
        severity = item.severity,
        summary = item.summary,
        metadata = item.metadata,
        reference = item.reference,
        sanction = item.sanction,
        occurrences = item.occurrences,
        occurred_at = item.occurred_at,
        last_occurrence_at = item.last_occurrence_at,
        origin = item.origin,
    }
end

--- Send buffered alerts, highest severity first. Returns ok, count.
function Alerts.flush()
    local Agent = ZShield.Agent
    local cfg = Agent.config()
    if not cfg then
        return false, 0
    end
    if Queue.size(Const.QUEUE_KIND.ALERT) == 0 then
        return true, 0
    end

    local batch = Queue.take(Const.QUEUE_KIND.ALERT, cfg.alert_batch_size)
    if #batch == 0 then
        return true, 0
    end

    table.sort(batch, function(a, b)
        local wa = Const.SEVERITY_WEIGHT[a.severity] or 1
        local wb = Const.SEVERITY_WEIGHT[b.severity] or 1
        if wa ~= wb then
            return wa > wb
        end
        return (a.created_at or 0) < (b.created_at or 0)
    end)

    local wire = {}
    for i = 1, #batch do
        wire[i] = toWire(batch[i])
        -- Once sent, the item must no longer be mutated by deduplication.
        if batch[i].dedup_key and dedupWindow[batch[i].dedup_key] then
            dedupWindow[batch[i].dedup_key].queued = nil
        end
    end

    local ok, data, errCode, reason = Agent.request('POST', Const.ENDPOINT.ALERTS, {
        alerts = wire,
    }, { kind = 'alerts' })

    if not ok then
        if ZShield.Protocol.isRetryable(errCode) then
            local requeued = Queue.requeue(batch)
            Log.debug('alert batch requeued', { count = requeued, error = errCode })
        else
            stats.dropped = stats.dropped + #batch
            Log.error('dropping alert batch permanently', {
                count = #batch, error = errCode, reason = reason,
            })
        end
        return false, 0
    end

    -- The platform may reject individual alerts. Those are a contract bug on
    -- our side, so they are logged loudly and never retried in a loop.
    if data.rejected and #data.rejected > 0 then
        Log.warn('platform rejected individual alerts', { count = #data.rejected,
            first_reason = data.rejected[1] and data.rejected[1].reason })
    end

    Queue.markDelivered(#batch)
    stats.sent = stats.sent + #batch
    stats.last_flush_at = os.time()

    return true, #batch
end

function Alerts.start()
    if running then
        return
    end
    running = true

    CreateThread(function()
        while running do
            local cfg = ZShield.Agent.config()
            local interval = (cfg and cfg.alert_flush_interval) or 5

            if Queue.size(Const.QUEUE_KIND.ALERT) > 0 then
                local ok, err = pcall(Alerts.flush)
                if not ok then
                    Log.error('alert flush raised an error', { error = tostring(err) })
                end
            end

            -- Housekeeping runs on the same tick to avoid a second thread.
            pruneDedup()
            Queue.prune()
            Queue.persist()

            Wait(interval * 1000)
        end
    end)

    Log.debug('alert loop started')
end

function Alerts.stop()
    running = false
end

function Alerts.stats()
    return {
        submitted = stats.submitted,
        rejected = stats.rejected,
        deduplicated = stats.deduplicated,
        sent = stats.sent,
        dropped = stats.dropped,
        buffered = Queue.size(Const.QUEUE_KIND.ALERT),
        by_severity = stats.by_severity,
        last_submit_at = stats.last_submit_at,
        last_flush_at = stats.last_flush_at,
    }
end

-- ---------------------------------------------------------------------------
-- Export for other resources
-- ---------------------------------------------------------------------------

exports('SendSecurityAlert', function(alert)
    local origin = GetInvokingResource and GetInvokingResource() or 'unknown'
    return Alerts.submit(alert, origin)
end)

ZShield.Alerts = Alerts

return Alerts
