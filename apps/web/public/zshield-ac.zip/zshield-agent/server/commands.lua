--[[
    zshield-agent / server/commands.lua

    PURPOSE
        Executes the small, fixed set of instructions the platform is allowed
        to send, and reports the result.

        This is the most security-sensitive module in the resource, because it
        is the only place where something remote causes something local to
        happen. The design is therefore deliberately boring:

          - Commands are a closed registry of named handlers. There is no
            generic "execute" and no handler takes code, a file path, a native
            name, a command line or a URL as a parameter.
          - A command must pass three independent gates: the protocol schema
            (is it a known type?), the local allowlist (did the operator
            permit it?), and the handler (is it valid right now?).
          - Execution is idempotent by command id. Replaying a command id
            returns the first result instead of running it twice.
          - Every command is logged at SECURITY level with its outcome,
            whether it succeeded, was rejected or failed.

    DEPENDENCIES
        shared/constants.lua, shared/protocol.lua
        server/logger.lua, server/agent.lua, server/authentication.lua

    PUBLIC API
        ZShield.Commands.poll(trigger)   -> ok, executedCount
        ZShield.Commands.start()
        ZShield.Commands.stats()

    WHAT IS DELIBERATELY ABSENT
        No command can: evaluate Lua, run a shell command, read or write a
        file outside the agent's own data directory, read the signing secret,
        ban or kick a player, start or stop a resource, or change the API
        endpoint. Enforcement belongs to the anti-cheat on the server, under
        the server operator's configuration, not to a remote dashboard.
]]

ZShield = ZShield or {}

local Const = ZShield.Const
local Protocol = ZShield.Protocol
local Log = ZShield.Log
local Queue = ZShield.Queue
local Auth = ZShield.Auth

local Commands = {}

local POLL_INTERVAL <const> = 60 -- seconds; the heartbeat triggers earlier polls

local running = false

local stats = {
    polled = 0,
    received = 0,
    executed = 0,
    rejected = 0,
    failed = 0,
    duplicates = 0,
    expired = 0,
    last_poll_at = nil,
    last_command_at = nil,
}

-- Bounded history for idempotency: id -> { status, result, at }
local history = {}
local historyOrder = {}

local function remember(id, entry)
    history[id] = entry
    historyOrder[#historyOrder + 1] = id
    while #historyOrder > Const.LIMIT.COMMAND_HISTORY_SIZE do
        local oldest = table.remove(historyOrder, 1)
        history[oldest] = nil
    end
end

-- ---------------------------------------------------------------------------
-- Handlers
-- ---------------------------------------------------------------------------
-- A handler receives the validated command and returns:
--   ok (boolean), result (table, serialisable), reason (string on failure)

local handlers = {}

-- Pont vers le cœur (zshield-ac), qui est une ressource DISTINCTE : on l'atteint
-- par export. Injectable pour les tests. Retourne nil si le cœur est injoignable.
local coreBridge = function(action, target, admin)
    local ac
    local ok = pcall(function() ac = exports and exports['zshield-ac'] end)
    if not ok or not ac then return nil end
    if action == 'start' then return ac:RequestSpectate(target, admin) end
    if action == 'stop' then return ac:StopSpectate(target) end
    return nil
end

--- Réservé aux tests / à l'intégration : remplace le pont vers le cœur.
function Commands.setCoreBridge(fn)
    coreBridge = fn
end

handlers[Const.COMMAND.PING] = function(command)
    return true, {
        pong = true,
        agent_time = os.time(),
        correlation = command.payload and command.payload.correlation or nil,
    }
end

handlers[Const.COMMAND.REQUEST_STATUS] = function()
    return true, { status = ZShield.Agent.status() }
end

handlers[Const.COMMAND.REQUEST_HEALTH_CHECK] = function()
    if not ZShield.Health then
        return false, nil, 'health module unavailable'
    end
    return true, { health = ZShield.Health.check() }
end

handlers[Const.COMMAND.REFRESH_CONFIGURATION] = function()
    if not ZShield.ConfigSync then
        return false, nil, 'config sync module unavailable'
    end
    local ok, err = ZShield.ConfigSync.refresh('command')
    if not ok then
        return false, nil, tostring(err)
    end
    return true, { config_version = ZShield.Agent.configVersion() }
end

handlers[Const.COMMAND.RELOAD_SAFE_CONFIGURATION] = function()
    local ok, result = ZShield.Agent.reloadSafeLocalConfig()
    if not ok then
        return false, nil, tostring(result)
    end
    return true, result
end

handlers[Const.COMMAND.FLUSH_QUEUE] = function()
    local alertsSent, telemetrySent = 0, 0

    if ZShield.Alerts then
        local _, count = ZShield.Alerts.flush()
        alertsSent = count or 0
    end
    if ZShield.Telemetry then
        local _, count = ZShield.Telemetry.flush()
        telemetrySent = count or 0
    end

    return true, {
        alerts_sent = alertsSent,
        telemetry_sent = telemetrySent,
        remaining = Queue.size(),
    }
end

--- Credential rotation, confirm before commit.
---
--- 1. Ask the platform for new material (signed with the current key).
--- 2. Stage it locally without activating it.
--- 3. Prove the new key works by handshaking with it.
--- 4. Only then commit and persist.
---
--- If step 3 fails, the old credential stays active. A rotation must never be
--- able to lock the agent out of its own platform.
handlers[Const.COMMAND.ROTATE_CREDENTIAL] = function()
    local Agent = ZShield.Agent

    local ok, data, errCode, reason = Agent.request('POST', Const.ENDPOINT.ROTATE, {
        reason = 'command',
        current_key_id = Auth.describe().key_id,
    }, { kind = 'rotate' })

    if not ok then
        return false, nil, ('rotation request failed: %s (%s)'):format(
            tostring(errCode), tostring(reason))
    end

    local token, stageError = Auth.beginRotation(data.key_id, data.secret)
    if not token then
        return false, nil, tostring(stageError)
    end

    -- Verification exchange signed with the new credential only.
    local verifyOk, _, verifyError = Agent.request('POST', Const.ENDPOINT.HANDSHAKE, {
        server = Agent.info(),
        capabilities = { rotation_verification = true },
    }, {
        kind = 'rotation_verify',
        bypassCircuit = true,
        credential = { keyId = data.key_id, secret = data.secret },
    })

    if not verifyOk then
        Auth.abortRotation(token, 'verification handshake failed: ' .. tostring(verifyError))
        return false, nil, 'new credential failed verification, kept the previous one'
    end

    local committed, commitError = Auth.commitRotation(token)
    if not committed then
        return false, nil, tostring(commitError)
    end

    return true, { key_id = data.key_id, rotated_at = os.time() }
end

--- Observation serveur-autoritative (Multi-vue). Relaie au cœur, qui met en place
--- une caméra d'administration DANS le monde du jeu. Jamais une capture de l'écran
--- ou de la machine du joueur : l'agent ne transporte aucun flux d'image.
handlers[Const.COMMAND.SPECTATE_REQUEST] = function(command)
    local target = command.payload and command.payload.target
    if not target or target == '' then
        return false, nil, 'spectate_request requires a target'
    end
    local admin = command.payload and command.payload.admin
    local ok, res = pcall(coreBridge, 'start', tostring(target), admin and tostring(admin) or nil)
    if not ok or res == nil then
        return false, nil, 'anticheat core not reachable'
    end
    return true, { spectate = 'started', target = tostring(target) }
end

handlers[Const.COMMAND.SPECTATE_STOP] = function(command)
    local target = command.payload and command.payload.target
    if not target or target == '' then
        return false, nil, 'spectate_stop requires a target'
    end
    local ok, res = pcall(coreBridge, 'stop', tostring(target))
    if not ok or res == nil then
        return false, nil, 'anticheat core not reachable'
    end
    return true, { spectate = 'stopped', target = tostring(target) }
end

-- ---------------------------------------------------------------------------
-- Gates
-- ---------------------------------------------------------------------------

local function isAllowedLocally(commandType)
    local cfg = ZShield.Agent.config()
    if not cfg or not cfg.commands.enabled then
        return false, 'remote commands are disabled in local configuration'
    end

    for _, allowed in ipairs(cfg.commands.allowed) do
        if allowed == commandType then
            return true
        end
    end

    return false, 'command type is not in the local allowlist'
end

local function execute(command)
    -- Gate 1: idempotency.
    local previous = history[command.id]
    if previous then
        stats.duplicates = stats.duplicates + 1
        Log.security('command replayed, returning the original result', {
            id = command.id, type = command.type, original_status = previous.status,
        })
        return {
            id = command.id,
            status = Const.COMMAND_STATUS.DUPLICATE,
            result = previous.result,
            executed_at = previous.at,
        }
    end

    -- Gate 2: expiry.
    if command.expires_at and command.expires_at > 0 and os.time() > command.expires_at then
        stats.expired = stats.expired + 1
        Log.warn('ignoring expired command', { id = command.id, type = command.type })
        local entry = { status = Const.COMMAND_STATUS.REJECTED, at = os.time(),
                        result = { reason = 'expired' } }
        remember(command.id, entry)
        return { id = command.id, status = entry.status, reason = 'command expired', executed_at = entry.at }
    end

    -- Gate 3: local allowlist.
    local allowed, denyReason = isAllowedLocally(command.type)
    if not allowed then
        stats.rejected = stats.rejected + 1
        Log.security('rejected a command not permitted by local configuration', {
            id = command.id, type = command.type, reason = denyReason,
        })
        local entry = { status = Const.COMMAND_STATUS.REJECTED, at = os.time(),
                        result = { reason = denyReason } }
        remember(command.id, entry)
        return { id = command.id, status = entry.status, reason = denyReason, executed_at = entry.at }
    end

    -- Gate 4: a handler must exist. The schema should have caught this, so
    -- reaching here means agent and protocol are out of sync.
    local handler = handlers[command.type]
    if not handler then
        stats.rejected = stats.rejected + 1
        Log.security('no handler for an allowlisted command type', {
            id = command.id, type = command.type,
        })
        local entry = { status = Const.COMMAND_STATUS.REJECTED, at = os.time(),
                        result = { reason = 'unimplemented' } }
        remember(command.id, entry)
        return { id = command.id, status = entry.status, reason = Const.ERROR.UNKNOWN_COMMAND,
                 executed_at = entry.at }
    end

    -- Execute under pcall: a failing command must never take down the loop.
    local startedAt = GetGameTimer and GetGameTimer() or 0
    local pcallOk, ok, result, reason = pcall(handler, command)

    if not pcallOk then
        stats.failed = stats.failed + 1
        Log.error('command handler raised an error', {
            id = command.id, type = command.type, error = tostring(ok),
        })
        local entry = { status = Const.COMMAND_STATUS.FAILED, at = os.time(),
                        result = { reason = 'handler error' } }
        remember(command.id, entry)
        return { id = command.id, status = entry.status, reason = 'handler error',
                 executed_at = entry.at }
    end

    local duration = (GetGameTimer and GetGameTimer() or 0) - startedAt

    if not ok then
        stats.failed = stats.failed + 1
        Log.security('command failed', { id = command.id, type = command.type, reason = reason })
        local entry = { status = Const.COMMAND_STATUS.FAILED, at = os.time(),
                        result = { reason = reason } }
        remember(command.id, entry)
        return { id = command.id, status = entry.status, reason = tostring(reason),
                 executed_at = entry.at, duration_ms = duration }
    end

    stats.executed = stats.executed + 1
    stats.last_command_at = os.time()

    Log.security('command executed', { id = command.id, type = command.type,
        duration_ms = duration })

    local entry = { status = Const.COMMAND_STATUS.COMPLETED, at = os.time(), result = result }
    remember(command.id, entry)

    return { id = command.id, status = entry.status, result = result,
             executed_at = entry.at, duration_ms = duration }
end

-- ---------------------------------------------------------------------------
-- Poll loop
-- ---------------------------------------------------------------------------

local polling = false

--- Fetch and execute pending commands. Returns ok, executedCount.
function Commands.poll(trigger)
    if polling then
        return false, 0 -- a poll is already in flight
    end

    local cfg = ZShield.Agent.config()
    if not cfg or not cfg.commands.enabled then
        return false, 0
    end

    polling = true
    stats.polled = stats.polled + 1
    stats.last_poll_at = os.time()

    local ok, data, errCode, reason = ZShield.Agent.request('GET', Const.ENDPOINT.COMMANDS, nil, {
        kind = 'commands',
        query = 'limit=' .. Const.LIMIT.MAX_COMMANDS_PER_POLL,
    })

    if not ok then
        polling = false
        Log.debug('command poll failed', { trigger = trigger, error = errCode, reason = reason })
        return false, 0
    end

    local commands = data.commands or {}
    stats.received = stats.received + #commands

    if #commands == 0 then
        polling = false
        return true, 0
    end

    Log.debug('received commands', { count = #commands, trigger = trigger })

    local results = {}
    for i = 1, #commands do
        results[i] = execute(commands[i])
    end

    -- Report outcomes. If this fails the platform will re-send, and
    -- idempotency makes that safe.
    local reported = ZShield.Agent.request('POST', Const.ENDPOINT.COMMAND_RESULT, {
        results = results,
    }, { kind = 'command_results' })

    if not reported then
        Log.warn('could not report command results, the platform may resend', {
            count = #results,
        })
    end

    polling = false
    return true, #results
end

function Commands.start()
    if running then
        return
    end
    running = true

    CreateThread(function()
        while running do
            Wait(POLL_INTERVAL * 1000)

            local cfg = ZShield.Agent.config()
            if cfg and cfg.commands.enabled and ZShield.Agent.isOperational() then
                local ok, err = pcall(Commands.poll, 'interval')
                if not ok then
                    Log.error('command poll raised an error', { error = tostring(err) })
                end
            end
        end
    end)

    local cfg = ZShield.Agent.config()
    Log.info('command module ready', {
        enabled = cfg and cfg.commands.enabled,
        allowed = cfg and table.concat(cfg.commands.allowed, ',') or '',
    })
end

function Commands.stop()
    running = false
end

function Commands.stats()
    local cfg = ZShield.Agent.config()
    return {
        enabled = cfg and cfg.commands.enabled or false,
        allowed = cfg and cfg.commands.allowed or {},
        polled = stats.polled,
        received = stats.received,
        executed = stats.executed,
        rejected = stats.rejected,
        failed = stats.failed,
        duplicates = stats.duplicates,
        expired = stats.expired,
        last_poll_at = stats.last_poll_at,
        last_command_at = stats.last_command_at,
        history_size = #historyOrder,
    }
end

ZShield.Commands = Commands

return Commands
