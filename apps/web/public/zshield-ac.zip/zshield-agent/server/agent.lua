--[[
    zshield-agent / server/agent.lua

    PURPOSE
        The core of the resource:
          - loads and validates local configuration (fails closed);
          - owns the signed HTTP transport, backoff and circuit breaker;
          - performs the handshake and negotiates protocol compatibility;
          - owns the agent state machine;
          - exposes the internal API other resources use.

    DEPENDENCIES
        shared/*  (constants, crypto, validation, protocol)
        server/logger.lua, server/queue.lua, server/authentication.lua

    PUBLIC API (Lua, same-server resources use exports instead)
        ZShield.Agent.request(method, endpoint, payload, opts) -> ok, data, errCode, reason
        ZShield.Agent.state()          -> AGENT_STATE value
        ZShield.Agent.config()         -> effective configuration (no secret)
        ZShield.Agent.info()           -> server facts
        ZShield.Agent.status()         -> summary table
        ZShield.Agent.isOperational()  -> boolean
        ZShield.Agent.applyRemoteConfig(cfg)

    EXPORTS (for other resources, e.g. an anti-cheat)
        exports['zshield-agent']:SendSecurityAlert(alert)
        exports['zshield-agent']:GetAgentStatus()
        exports['zshield-agent']:GetAgentVersion()
        exports['zshield-agent']:RequestConfigRefresh()

    SECURITY NOTES
        - Configuration is loaded with `load` into an empty environment. The
          config file can therefore only describe values; it cannot call
          natives, read files or reach the secret.
        - An invalid configuration puts the agent in MISCONFIGURED and it
          performs no network activity at all. Failing closed is preferred to
          guessing identity or endpoint.
        - Nothing in this file evaluates data received from the platform.
          Responses are schema-validated tables; there is no code path from a
          response to `load`, `RunString`, a native call by name, or the
          filesystem outside the agent's own data directory.
]]

ZShield = ZShield or {}

local Const = ZShield.Const
local Crypto = ZShield.Crypto
local Validation = ZShield.Validation
local Protocol = ZShield.Protocol
local Log = ZShield.Log
local Queue = ZShield.Queue
local Auth = ZShield.Auth

local Agent = {}

local RESOURCE <const> = GetCurrentResourceName()

-- ---------------------------------------------------------------------------
-- Configuration schema
-- ---------------------------------------------------------------------------

local ID_PATTERN <const> = '^[%w%-_]+$'

local CONFIG_SCHEMA <const> = {
    type = 'table',
    strict = true,
    fields = {
        server_id   = { type = 'string', required = true, min = 3, max = 64, pattern = ID_PATTERN },
        agent_id    = { type = 'string', required = true, min = 3, max = 64, pattern = ID_PATTERN },
        key_id      = { type = 'string', default = 'k1', min = 1, max = 64, pattern = ID_PATTERN },
        secret      = { type = 'string', default = '', max = 256 },
        server_name = { type = 'string', default = 'FiveM server', max = 128 },
        environment = { type = 'string', default = 'production',
                        enum = { 'production', 'staging', 'development' } },

        api_endpoint = { type = 'string', required = true, min = 8, max = 512 },
        allow_insecure_endpoint = { type = 'boolean', default = false },
        request_timeout = { type = 'integer', default = 10, min = 2, max = 60 },

        heartbeat_interval   = { type = 'integer', default = 30, min = 15, max = 900 },
        telemetry_interval   = { type = 'integer', default = 60, min = 30, max = 3600 },
        alert_flush_interval = { type = 'integer', default = 5, min = 1, max = 300 },
        alert_batch_size     = { type = 'integer', default = 50, min = 1, max = 200 },

        telemetry_enabled = { type = 'boolean', default = true },
        metrics = {
            type = 'table', strict = true,
            default = { players = true, performance = true, errors = true,
                        dependencies = true, resources = false, protections = true },
            fields = {
                players      = { type = 'boolean', default = true },
                performance  = { type = 'boolean', default = true },
                errors       = { type = 'boolean', default = true },
                dependencies = { type = 'boolean', default = true },
                resources    = { type = 'boolean', default = false },
                -- Instantané des protections natives du cœur anticheat (§08/§10/§21…).
                protections  = { type = 'boolean', default = true },
            },
        },

        queue = {
            type = 'table', strict = true,
            default = { max_size = 2000, ttl = 21600, persist = true },
            fields = {
                max_size = { type = 'integer', default = 2000, min = 50, max = 50000 },
                ttl      = { type = 'integer', default = 21600, min = 60, max = 604800 },
                persist  = { type = 'boolean', default = true },
            },
        },

        commands = {
            type = 'table', strict = true,
            default = { enabled = true, allowed = {} },
            fields = {
                enabled = { type = 'boolean', default = true },
                allowed = { type = 'array', max = 32, default = {},
                            items = { type = 'string', max = 64, pattern = '^[%l_]+$' } },
            },
        },

        remote_config = {
            type = 'table', strict = true,
            default = { enabled = true },
            fields = { enabled = { type = 'boolean', default = true } },
        },

        log_level = { type = 'string', default = 'INFO',
                      enum = { 'DEBUG', 'INFO', 'WARN', 'ERROR' } },
        log_json  = { type = 'boolean', default = false },
    },
}

-- ---------------------------------------------------------------------------
-- Internal state
-- ---------------------------------------------------------------------------

local state = {
    status = Const.AGENT_STATE.BOOTING,
    statusSince = os.time(),
    startedAt = os.time(),
    config = nil,
    endpoint = nil,
    misconfiguration = nil,
    handshakeAt = nil,
    organization = nil,
    apiVersion = nil,
    configVersion = 0,
    lastSuccessAt = nil,
    lastFailureAt = nil,
    lastError = nil,
    consecutiveFailures = 0,
    circuitOpenUntil = 0,
    requests = { sent = 0, ok = 0, failed = 0, rejected = 0 },
    latency = { last = nil, count = 0, sum = 0, max = 0 },
}

-- ---------------------------------------------------------------------------
-- State machine
-- ---------------------------------------------------------------------------

local function setState(next, reason)
    if state.status == next then
        return
    end

    local previous = state.status
    state.status = next
    state.statusSince = os.time()

    local fields = { from = previous, to = next, reason = reason }
    if next == Const.AGENT_STATE.MISCONFIGURED then
        Log.security('agent state changed', fields)
    elseif next == Const.AGENT_STATE.OFFLINE or next == Const.AGENT_STATE.DEGRADED then
        Log.warn('agent state changed', fields)
    else
        Log.info('agent state changed', fields)
    end
end

Agent.setState = setState

function Agent.state()
    return state.status
end

function Agent.isOperational()
    return state.status == Const.AGENT_STATE.ONLINE
        or state.status == Const.AGENT_STATE.DEGRADED
end

-- ---------------------------------------------------------------------------
-- Configuration
-- ---------------------------------------------------------------------------

local function normaliseEndpoint(url, allowInsecure)
    url = url:gsub('%s+', ''):gsub('/+$', '')

    local scheme = url:match('^(%a[%w+.-]*)://')
    if not scheme then
        return nil, 'api_endpoint must include a scheme (https://...)'
    end

    scheme = scheme:lower()
    if scheme ~= 'https' and not allowInsecure then
        return nil, 'api_endpoint must use https (set allow_insecure_endpoint = true '
            .. 'only for a local development dashboard)'
    end
    if scheme ~= 'https' and scheme ~= 'http' then
        return nil, 'api_endpoint scheme must be http or https'
    end

    return url
end

local function loadConfigFile()
    local raw = LoadResourceFile(RESOURCE, 'config/config.lua')
    if not raw or raw == '' then
        return nil, 'config/config.lua not found. Copy config/config.example.lua to '
            .. 'config/config.lua and fill in the identifiers from the dashboard.'
    end

    -- Empty environment: the config file cannot reach natives or globals.
    local chunk, compileError = load(raw, '@zshield-agent/config/config.lua', 't', {})
    if not chunk then
        return nil, 'config/config.lua has a syntax error: ' .. tostring(compileError)
    end

    local ok, result = pcall(chunk)
    if not ok then
        return nil, 'config/config.lua raised an error: ' .. tostring(result)
    end
    if type(result) ~= 'table' then
        return nil, 'config/config.lua must return a table'
    end

    return result
end

local function bootstrapConfig()
    local raw, loadError = loadConfigFile()
    if not raw then
        return nil, loadError
    end

    local ok, validated = Validation.check(raw, CONFIG_SCHEMA)
    if not ok then
        return nil, 'invalid configuration: ' .. tostring(validated)
    end

    local endpoint, endpointError = normaliseEndpoint(validated.api_endpoint,
        validated.allow_insecure_endpoint)
    if not endpoint then
        return nil, endpointError
    end

    if validated.server_id == 'srv_00000000000000000000'
        or validated.agent_id == 'agt_00000000000000000000' then
        return nil, 'configuration still contains the example identifiers; '
            .. 'replace server_id and agent_id with the values from the dashboard'
    end

    validated.api_endpoint = endpoint
    return validated
end

function Agent.config()
    if not state.config then
        return nil
    end

    -- Never hand out the secret, including to other resources.
    local copy = {}
    for k, v in pairs(state.config) do
        if k ~= 'secret' then
            copy[k] = v
        end
    end
    copy.secret = state.config.secret ~= '' and '[configured]' or '[from convar]'
    return copy
end

--- Apply a validated remote configuration. Only the fields the protocol
--- schema allows can ever reach this function.
function Agent.applyRemoteConfig(remote)
    if not state.config then
        return false
    end
    if not state.config.remote_config.enabled then
        Log.info('ignoring remote configuration, disabled locally')
        return false
    end

    local changed = {}

    local function apply(key, value)
        if value ~= nil and state.config[key] ~= value then
            changed[key] = { from = state.config[key], to = value }
            state.config[key] = value
        end
    end

    apply('telemetry_enabled', remote.telemetry_enabled)
    apply('heartbeat_interval', remote.heartbeat_interval)
    apply('telemetry_interval', remote.telemetry_interval)
    apply('alert_batch_size', remote.alert_batch_size)
    apply('alert_flush_interval', remote.alert_flush_interval)

    if remote.log_level and remote.log_level ~= state.config.log_level then
        if Log.setLevel(remote.log_level) then
            changed.log_level = { from = state.config.log_level, to = remote.log_level }
            state.config.log_level = remote.log_level
        end
    end

    if type(remote.metrics) == 'table' then
        for key, value in pairs(remote.metrics) do
            if state.config.metrics[key] ~= nil and state.config.metrics[key] ~= value then
                changed['metrics.' .. key] = { from = state.config.metrics[key], to = value }
                state.config.metrics[key] = value
            end
        end
    end

    if remote.config_version then
        state.configVersion = remote.config_version
    end

    if next(changed) then
        Log.info('applied remote configuration', { version = state.configVersion, changes = changed })
    else
        Log.debug('remote configuration received, nothing to change',
            { version = state.configVersion })
    end

    return true
end

function Agent.configVersion()
    return state.configVersion
end

--- Keys that may be changed by re-reading config/config.lua at runtime.
--- Identity, endpoint, secret, queue sizing and the command allowlist are
--- deliberately excluded: changing those without a restart would let a
--- runtime action repoint the agent or widen its permissions.
local SAFE_RELOAD_KEYS <const> = {
    'heartbeat_interval', 'telemetry_interval', 'alert_flush_interval',
    'alert_batch_size', 'telemetry_enabled', 'log_level', 'log_json',
}

--- Re-read the local configuration file and apply only the safe subset.
--- Returns ok, changesOrError.
function Agent.reloadSafeLocalConfig()
    if not state.config then
        return false, 'agent has no configuration loaded'
    end

    local fresh, err = bootstrapConfig()
    if not fresh then
        return false, err
    end

    local refused = {}
    for _, key in ipairs({ 'server_id', 'agent_id', 'api_endpoint' }) do
        if fresh[key] ~= state.config[key] then
            refused[#refused + 1] = key
        end
    end

    local changed = {}
    for _, key in ipairs(SAFE_RELOAD_KEYS) do
        if fresh[key] ~= nil and fresh[key] ~= state.config[key] then
            changed[key] = { from = state.config[key], to = fresh[key] }
            state.config[key] = fresh[key]
        end
    end

    for key, value in pairs(fresh.metrics or {}) do
        if state.config.metrics[key] ~= nil and state.config.metrics[key] ~= value then
            changed['metrics.' .. key] = { from = state.config.metrics[key], to = value }
            state.config.metrics[key] = value
        end
    end

    Log.setLevel(state.config.log_level)
    Log.setJson(state.config.log_json)

    if #refused > 0 then
        Log.security('refused to apply identity or endpoint changes at runtime', {
            keys = table.concat(refused, ','),
        })
    end

    if next(changed) then
        Log.info('reloaded safe configuration from disk', { changes = changed })
    end

    return true, { changed = changed, requires_restart = refused }
end

-- ---------------------------------------------------------------------------
-- Server facts
-- ---------------------------------------------------------------------------

local function convar(name, default)
    if GetConvar then
        return GetConvar(name, default)
    end
    return default
end

function Agent.info()
    local players = 0
    if GetPlayers then
        players = #GetPlayers()
    end

    return {
        agent_version    = Const.AGENT_VERSION,
        protocol_version = Const.PROTOCOL_VERSION,
        resource_version = GetResourceMetadata
            and GetResourceMetadata(RESOURCE, 'version', 0) or nil,
        fxserver_version = convar('version', 'unknown'),
        onesync          = convar('onesync', 'off'),
        max_players      = tonumber(convar('sv_maxclients', '0')) or 0,
        players_online   = players,
        server_name      = state.config and state.config.server_name or nil,
        environment      = state.config and state.config.environment or nil,
        uptime_seconds   = os.time() - state.startedAt,
    }
end

-- ---------------------------------------------------------------------------
-- Transport
-- ---------------------------------------------------------------------------

local function circuitIsOpen()
    return os.time() < state.circuitOpenUntil
end

local function recordFailure(errCode, reason)
    state.consecutiveFailures = state.consecutiveFailures + 1
    state.lastFailureAt = os.time()
    state.lastError = { code = errCode, reason = reason, at = os.time() }
    state.requests.failed = state.requests.failed + 1

    if state.consecutiveFailures >= Const.LIMIT.CIRCUIT_FAILURE_THRESHOLD
        and not circuitIsOpen() then
        state.circuitOpenUntil = os.time() + Const.LIMIT.CIRCUIT_OPEN_SECONDS
        Log.warn('circuit breaker opened, pausing outbound requests', {
            failures = state.consecutiveFailures,
            seconds = Const.LIMIT.CIRCUIT_OPEN_SECONDS,
            last_error = errCode,
        })
    end

    if state.status == Const.AGENT_STATE.ONLINE then
        setState(Const.AGENT_STATE.DEGRADED, errCode)
    end
    if state.consecutiveFailures >= Const.LIMIT.CIRCUIT_FAILURE_THRESHOLD then
        setState(Const.AGENT_STATE.OFFLINE, errCode)
    end
end

local function recordSuccess(latencyMs)
    local wasFailing = state.consecutiveFailures > 0
    state.consecutiveFailures = 0
    state.circuitOpenUntil = 0
    state.lastSuccessAt = os.time()
    state.requests.ok = state.requests.ok + 1

    if latencyMs then
        state.latency.last = latencyMs
        state.latency.count = state.latency.count + 1
        state.latency.sum = state.latency.sum + latencyMs
        state.latency.max = math.max(state.latency.max, latencyMs)
    end

    if state.status ~= Const.AGENT_STATE.STOPPING
        and state.status ~= Const.AGENT_STATE.MISCONFIGURED then
        if wasFailing then
            Log.info('platform reachable again')
        end
        setState(Const.AGENT_STATE.ONLINE, 'exchange succeeded')
    end
end

--- Blocking HTTP call. Must be invoked from inside a thread (CreateThread).
local function httpRequest(url, method, body, headers, timeoutSeconds)
    local done, result = false, nil
    local startedAt = GetGameTimer and GetGameTimer() or 0

    PerformHttpRequest(url, function(status, responseBody, responseHeaders, errorData)
        result = {
            status = status,
            body = responseBody,
            headers = responseHeaders,
            errorData = errorData,
        }
        done = true
    end, method, body or '', headers)

    local deadline = (GetGameTimer and GetGameTimer() or 0) + (timeoutSeconds * 1000)
    while not done do
        if GetGameTimer and GetGameTimer() > deadline then
            return nil, Const.ERROR.TIMEOUT, 'request exceeded local timeout'
        end
        Wait(25)
    end

    local latency = (GetGameTimer and GetGameTimer() or 0) - startedAt
    return result, nil, nil, latency
end

--- Perform a signed, verified, schema-validated exchange with the platform.
--- Returns ok, data, errorCode, reason.
function Agent.request(method, endpoint, payload, opts)
    opts = opts or {}

    if state.status == Const.AGENT_STATE.MISCONFIGURED then
        return false, nil, Const.ERROR.MISCONFIGURED, state.misconfiguration
    end
    if not Auth.isReady() then
        return false, nil, Const.ERROR.MISCONFIGURED, 'authentication not initialised'
    end
    if circuitIsOpen() and not opts.bypassCircuit then
        return false, nil, Const.ERROR.NETWORK_UNREACHABLE, 'circuit breaker open'
    end

    local bodyTable = payload and Protocol.envelope(opts.kind or endpoint, payload, {
        serverId = state.config.server_id,
        agentId = state.config.agent_id,
        environment = state.config.environment,
    }) or nil

    local body = ''
    if bodyTable then
        local okEncode, encoded = pcall(json.encode, bodyTable)
        if not okEncode or type(encoded) ~= 'string' then
            return false, nil, Const.ERROR.VALIDATION, 'payload is not serialisable: '
                .. tostring(encoded)
        end
        body = encoded
    end

    if #body > Const.MAX_PAYLOAD_BYTES then
        return false, nil, Const.ERROR.PAYLOAD_TOO_LARGE,
            ('payload is %d bytes, ceiling is %d'):format(#body, Const.MAX_PAYLOAD_BYTES)
    end

    local headers, requestId
    if opts.credential then
        headers, requestId = Auth.signWith(opts.credential.keyId, opts.credential.secret,
            method, endpoint, opts.query, body)
    else
        headers, requestId = Auth.sign(method, endpoint, opts.query, body)
    end

    local url = state.endpoint .. endpoint .. (opts.query and ('?' .. opts.query) or '')
    state.requests.sent = state.requests.sent + 1

    local response, transportError, transportReason, latency = httpRequest(
        url, method, body, headers, state.config.request_timeout)

    if not response then
        recordFailure(transportError, transportReason)
        return false, nil, transportError, transportReason
    end

    local errCode = Protocol.errorFromStatus(response.status)

    -- Verify the signature before reading the body, including on errors: an
    -- unsigned 401 could otherwise be used to push the agent into a
    -- credential-revoked state by anyone on the path.
    local verified, verifyError, verifyReason = Auth.verifyResponse({
        status = response.status,
        body = response.body,
        headers = response.headers,
        requestId = requestId,
        secret = opts.credential and opts.credential.secret or nil,
    })

    if not verified then
        state.requests.rejected = state.requests.rejected + 1
        Log.security('rejected an unverified response from the platform', {
            endpoint = endpoint,
            status = response.status,
            error = verifyError,
            reason = verifyReason,
        })
        recordFailure(verifyError, verifyReason)
        return false, nil, verifyError, verifyReason
    end

    local decoded
    if response.body and response.body ~= '' then
        local okDecode, result = pcall(json.decode, response.body)
        if not okDecode or type(result) ~= 'table' then
            recordFailure(Const.ERROR.BAD_RESPONSE, 'response body is not a JSON object')
            return false, nil, Const.ERROR.BAD_RESPONSE, 'response body is not a JSON object'
        end
        decoded = result
    end

    if errCode then
        local reason = errCode
        if decoded then
            local okErr, errBody = Validation.check(decoded, Protocol.ERROR_RESPONSE)
            if okErr then
                -- Trust the platform's own error code only to refine, never to
                -- widen: a fatal HTTP status stays fatal.
                reason = errBody.message or errBody.error or errCode
                if errBody.error and Const.FATAL_ERRORS[errBody.error] then
                    errCode = errBody.error
                end
            end
        end
        recordFailure(errCode, reason)
        Log.warn('platform rejected a request', {
            endpoint = endpoint, status = response.status, error = errCode, reason = reason,
        })
        return false, nil, errCode, reason
    end

    local schema = opts.schema or Protocol.RESPONSE[endpoint]
    local data = decoded

    if schema then
        local okSchema, validated = Validation.check(decoded, schema)
        if not okSchema then
            state.requests.rejected = state.requests.rejected + 1
            Log.security('platform response failed schema validation', {
                endpoint = endpoint, reason = validated,
            })
            recordFailure(Const.ERROR.VALIDATION, validated)
            return false, nil, Const.ERROR.VALIDATION, validated
        end
        data = validated
    end

    if data and data.ok == false then
        recordFailure(Const.ERROR.BAD_RESPONSE, 'platform reported ok=false on a 2xx response')
        return false, nil, Const.ERROR.BAD_RESPONSE, 'platform reported ok=false'
    end

    recordSuccess(latency)
    return true, data
end

-- ---------------------------------------------------------------------------
-- Handshake
-- ---------------------------------------------------------------------------

local function performHandshake()
    setState(Const.AGENT_STATE.HANDSHAKING, 'handshake attempt')

    local ok, data, errCode, reason = Agent.request('POST', Const.ENDPOINT.HANDSHAKE, {
        server = Agent.info(),
        capabilities = {
            commands = state.config.commands.enabled,
            remote_config = state.config.remote_config.enabled,
            telemetry = state.config.telemetry_enabled,
            allowed_commands = state.config.commands.allowed,
        },
        queue = Queue.stats(),
    }, { kind = 'handshake', bypassCircuit = true })

    if not ok then
        return false, errCode, reason
    end

    -- Protocol compatibility is negotiated once, and it fails closed.
    if data.min_agent_protocol > Const.PROTOCOL_VERSION then
        local message = ('platform requires agent protocol %d, this agent speaks %d. Update the agent.')
            :format(data.min_agent_protocol, Const.PROTOCOL_VERSION)
        state.misconfiguration = message
        setState(Const.AGENT_STATE.MISCONFIGURED, 'protocol too old')
        Log.security('handshake refused: agent protocol is too old', {
            required = data.min_agent_protocol, supported = Const.PROTOCOL_VERSION,
        })
        return false, Const.ERROR.PROTOCOL_UNSUPPORTED, message
    end

    if data.api_version < Const.MIN_SUPPORTED_API_VERSION then
        local message = ('platform API version %d is older than the minimum supported %d')
            :format(data.api_version, Const.MIN_SUPPORTED_API_VERSION)
        state.misconfiguration = message
        setState(Const.AGENT_STATE.MISCONFIGURED, 'platform api too old')
        return false, Const.ERROR.PROTOCOL_UNSUPPORTED, message
    end

    if data.api_version > Const.MAX_SUPPORTED_API_VERSION then
        Log.warn('platform API is newer than this agent understands; continuing with our own version', {
            platform = data.api_version, agent = Const.MAX_SUPPORTED_API_VERSION,
        })
    end

    state.handshakeAt = os.time()
    state.apiVersion = data.api_version
    state.organization = data.organization

    -- The platform may hand back the canonical key id (for example after an
    -- out-of-band rotation on the dashboard side).
    if data.key_id and data.key_id ~= state.config.key_id then
        Log.info('platform reported a different key id', { key_id = data.key_id })
    end

    if data.config then
        Agent.applyRemoteConfig(data.config)
    end

    Log.info('handshake complete', {
        organization = data.organization,
        api_version = data.api_version,
        config_version = state.configVersion,
        server_time_skew = math.abs(os.time() - data.server_time),
    })

    return true
end

Agent.performHandshake = performHandshake

-- ---------------------------------------------------------------------------
-- Status
-- ---------------------------------------------------------------------------

function Agent.status()
    return {
        state = state.status,
        state_since = state.statusSince,
        started_at = state.startedAt,
        uptime_seconds = os.time() - state.startedAt,
        agent_version = Const.AGENT_VERSION,
        protocol_version = Const.PROTOCOL_VERSION,
        api_version = state.apiVersion,
        organization = state.organization,
        config_version = state.configVersion,
        handshake_at = state.handshakeAt,
        last_success_at = state.lastSuccessAt,
        last_failure_at = state.lastFailureAt,
        last_error = state.lastError,
        consecutive_failures = state.consecutiveFailures,
        circuit_open = circuitIsOpen(),
        circuit_open_until = circuitIsOpen() and state.circuitOpenUntil or nil,
        requests = state.requests,
        latency_ms = {
            last = state.latency.last,
            max = state.latency.max,
            mean = state.latency.count > 0
                and math.floor(state.latency.sum / state.latency.count) or nil,
        },
        misconfiguration = state.misconfiguration,
        queue = Queue.stats(),
        credential = Auth.describe(),
        log = Log.counters(),
    }
end

-- ---------------------------------------------------------------------------
-- Bootstrap
-- ---------------------------------------------------------------------------

local function fatalMisconfiguration(message)
    state.misconfiguration = message
    setState(Const.AGENT_STATE.MISCONFIGURED, 'configuration rejected')
    Log.security('agent disabled: configuration is not usable', { reason = message })
    Log.error('zshield-agent will not contact the platform until this is fixed. '
        .. 'Diagnostics remain available with: zshield status')
end

CreateThread(function()
    Log.info(('starting zshield-agent %s (protocol %d)')
        :format(Const.AGENT_VERSION, Const.PROTOCOL_VERSION))

    local cfg, configError = bootstrapConfig()
    if not cfg then
        fatalMisconfiguration(configError)
        return
    end

    state.config = cfg
    state.endpoint = cfg.api_endpoint

    Log.setLevel(cfg.log_level)
    Log.setJson(cfg.log_json)

    local authOk, authError = Auth.init(cfg)
    if not authOk then
        fatalMisconfiguration(authError)
        return
    end

    Queue.init(cfg.queue)

    Log.info('configuration loaded', {
        server_id = cfg.server_id,
        environment = cfg.environment,
        endpoint = cfg.api_endpoint,
        telemetry = cfg.telemetry_enabled,
        commands = cfg.commands.enabled,
        queue_max = cfg.queue.max_size,
    })

    -- Handshake with bounded exponential backoff. The agent never gives up:
    -- a platform outage must not require an operator to restart a resource.
    local attempt = 0
    while state.status ~= Const.AGENT_STATE.MISCONFIGURED
        and state.status ~= Const.AGENT_STATE.STOPPING do
        local ok, errCode, reason = performHandshake()
        if ok then
            break
        end

        if state.status == Const.AGENT_STATE.MISCONFIGURED then
            return
        end

        attempt = attempt + 1
        local delay = math.min(Const.LIMIT.MIN_BACKOFF_SECONDS * (2 ^ math.min(attempt, 8)),
            Const.LIMIT.MAX_BACKOFF_SECONDS)
        delay = delay + math.random(0, math.floor(delay * 0.2)) -- jitter

        setState(Const.AGENT_STATE.OFFLINE, errCode)
        Log.warn('handshake failed, retrying', {
            attempt = attempt, error = errCode, reason = reason, retry_in_seconds = delay,
        })

        Wait(delay * 1000)
    end

    -- Submodules start only after a successful handshake so they never send
    -- against an unverified platform.
    if ZShield.Heartbeat then ZShield.Heartbeat.start() end
    if ZShield.Telemetry then ZShield.Telemetry.start() end
    if ZShield.Alerts then ZShield.Alerts.start() end
    if ZShield.Commands then ZShield.Commands.start() end
    if ZShield.ConfigSync then ZShield.ConfigSync.start() end

    Log.info('zshield-agent operational')
end)

-- ---------------------------------------------------------------------------
-- Shutdown
-- ---------------------------------------------------------------------------

AddEventHandler('onResourceStop', function(resource)
    if resource ~= RESOURCE then
        return
    end

    setState(Const.AGENT_STATE.STOPPING, 'resource stopping')

    -- Best effort: persist whatever is still buffered. No network call here,
    -- because the resource is being torn down and a blocking HTTP request
    -- would delay the stop.
    local persisted = Queue.persist(true)
    Log.info('zshield-agent stopped', {
        buffered = Queue.size(),
        persisted = persisted,
    })
end)

-- ---------------------------------------------------------------------------
-- Internal API for other resources
-- ---------------------------------------------------------------------------

exports('GetAgentVersion', function()
    return {
        agent = Const.AGENT_VERSION,
        protocol = Const.PROTOCOL_VERSION,
        min_supported_api = Const.MIN_SUPPORTED_API_VERSION,
    }
end)

exports('GetAgentStatus', function()
    return Agent.status()
end)

exports('RequestConfigRefresh', function()
    if not ZShield.ConfigSync then
        return false, 'config sync module unavailable'
    end
    return ZShield.ConfigSync.refresh('export')
end)

ZShield.Agent = Agent

return Agent
