--[[
    zshield-agent / server/health.lua

    PURPOSE
        Answers "is this agent working, and if not, which part is broken" for
        three audiences: the dashboard (through heartbeat and commands), the
        server operator (through the console command), and support (through a
        diagnostics dump that contains no secrets).

        Health checks are passive. They read state that other modules already
        maintain; they never make a network call, so asking for health can
        never make things worse.

    DEPENDENCIES
        shared/constants.lua, server/logger.lua, server/agent.lua,
        server/queue.lua, server/authentication.lua

    PUBLIC API
        ZShield.Health.check()       -> full report
        ZShield.Health.summary()     -> { status, failed, degraded }
        ZShield.Health.diagnostics() -> report safe to send to support

    CONSOLE (server console or an ACE-authorised principal only)
        zshield status
        zshield health
        zshield version
        zshield queue
        zshield flush
        zshield diagnostics
]]

ZShield = ZShield or {}

local Const = ZShield.Const
local Log = ZShield.Log
local Queue = ZShield.Queue
local Auth = ZShield.Auth

local Health = {}

local H <const> = Const.HEALTH

local function component(status, detail, fields)
    local c = { status = status, detail = detail }
    if fields then
        for k, v in pairs(fields) do
            c[k] = v
        end
    end
    return c
end

local function checkConfiguration()
    local Agent = ZShield.Agent
    local cfg = Agent.config()

    if Agent.state() == Const.AGENT_STATE.MISCONFIGURED then
        return component(H.FAILED, Agent.status().misconfiguration or 'configuration rejected')
    end
    if not cfg then
        return component(H.UNKNOWN, 'configuration not loaded yet')
    end

    return component(H.HEALTHY, 'loaded', {
        environment = cfg.environment,
        config_version = Agent.configVersion(),
        log_level = Log.getLevel(),
    })
end

local function checkCredential()
    local described = Auth.describe()

    if not described.ready then
        return component(H.FAILED, 'no usable signing credential')
    end
    if described.rejected_responses > 0 then
        return component(H.DEGRADED,
            'some platform responses failed verification', {
                key_id = described.key_id,
                rejected_responses = described.rejected_responses,
            })
    end

    return component(H.HEALTHY, 'active', {
        key_id = described.key_id,
        rotated_at = described.rotated_at,
        rotation_pending = described.rotation_pending,
    })
end

local function checkTransport()
    local status = ZShield.Agent.status()

    local detail
    local level = H.HEALTHY

    if status.state == Const.AGENT_STATE.MISCONFIGURED then
        level, detail = H.FAILED, 'agent is misconfigured, no requests are sent'
    elseif status.state == Const.AGENT_STATE.OFFLINE then
        level, detail = H.FAILED, 'platform unreachable, buffering locally'
    elseif status.state == Const.AGENT_STATE.DEGRADED or status.circuit_open then
        level, detail = H.DEGRADED, 'platform reachable but erroring'
    elseif status.state == Const.AGENT_STATE.ONLINE then
        level, detail = H.HEALTHY, 'connected'
    else
        level, detail = H.UNKNOWN, 'not connected yet'
    end

    return component(level, detail, {
        last_success_at = status.last_success_at,
        last_error = status.last_error,
        consecutive_failures = status.consecutive_failures,
        circuit_open = status.circuit_open,
        latency_ms = status.latency_ms,
        api_version = status.api_version,
    })
end

local function checkHeartbeat()
    if not ZShield.Heartbeat then
        return component(H.UNKNOWN, 'module not loaded')
    end

    local hb = ZShield.Heartbeat.stats()
    local cfg = ZShield.Agent.config()
    local interval = (cfg and cfg.heartbeat_interval) or 30

    if not hb.last_success_at then
        return component(H.UNKNOWN, 'no successful heartbeat yet', hb)
    end

    local age = os.time() - hb.last_success_at
    if age > interval * 4 then
        return component(H.FAILED, ('last successful heartbeat was %ds ago'):format(age), hb)
    elseif age > interval * 2 then
        return component(H.DEGRADED, ('last successful heartbeat was %ds ago'):format(age), hb)
    end

    return component(H.HEALTHY, ('last heartbeat %ds ago'):format(age), hb)
end

local function checkQueue()
    local q = Queue.stats()

    local level = H.HEALTHY
    local detail = ('%d/%d buffered'):format(q.total, q.max_size)

    if q.utilisation >= 0.95 then
        level, detail = H.FAILED, 'queue is full, items are being dropped'
    elseif q.utilisation >= 0.7 then
        level, detail = H.DEGRADED, 'queue is filling up'
    elseif q.persist_failures > 0 then
        level, detail = H.DEGRADED, 'queue cannot be persisted to disk'
    end

    return component(level, detail, q)
end

local function checkTelemetry()
    if not ZShield.Telemetry then
        return component(H.UNKNOWN, 'module not loaded')
    end

    local cfg = ZShield.Agent.config()
    if cfg and not cfg.telemetry_enabled then
        return component(H.HEALTHY, 'disabled by configuration',
            { enabled = false })
    end

    local t = ZShield.Telemetry.stats()
    if t.collected > 0 and t.sent == 0 and t.buffered > 0 then
        return component(H.DEGRADED, 'collecting but not delivering', t)
    end

    return component(H.HEALTHY, 'collecting', t)
end

local function checkCommands()
    if not ZShield.Commands then
        return component(H.UNKNOWN, 'module not loaded')
    end

    local c = ZShield.Commands.stats()
    if not c.enabled then
        return component(H.HEALTHY, 'disabled by configuration', { enabled = false })
    end
    if c.failed > 0 and c.executed == 0 then
        return component(H.DEGRADED, 'every command attempted has failed', c)
    end

    return component(H.HEALTHY, 'accepting allowlisted commands', c)
end

local function checkConfigSync()
    if not ZShield.ConfigSync then
        return component(H.UNKNOWN, 'module not loaded')
    end

    local s = ZShield.ConfigSync.stats()
    if not s.enabled then
        return component(H.HEALTHY, 'disabled by configuration', { enabled = false })
    end
    if s.rejected > 0 then
        return component(H.DEGRADED, 'the platform pushed configuration this agent refused', s)
    end

    return component(H.HEALTHY, 'in sync', s)
end

local CHECKS <const> = {
    { name = 'configuration', fn = checkConfiguration },
    { name = 'credential',    fn = checkCredential },
    { name = 'transport',     fn = checkTransport },
    { name = 'heartbeat',     fn = checkHeartbeat },
    { name = 'queue',         fn = checkQueue },
    { name = 'telemetry',     fn = checkTelemetry },
    { name = 'commands',      fn = checkCommands },
    { name = 'config_sync',   fn = checkConfigSync },
}

--- Run every component check. A check that raises is reported as FAILED for
--- that component only; one broken check never breaks the report.
function Health.check()
    local components = {}
    local failed, degraded = {}, {}

    for _, entry in ipairs(CHECKS) do
        local ok, result = pcall(entry.fn)
        if not ok then
            result = component(H.FAILED, 'health check raised an error: ' .. tostring(result))
        end

        components[entry.name] = result

        if result.status == H.FAILED then
            failed[#failed + 1] = entry.name
        elseif result.status == H.DEGRADED then
            degraded[#degraded + 1] = entry.name
        end
    end

    local overall = H.HEALTHY
    if #failed > 0 then
        overall = H.FAILED
    elseif #degraded > 0 then
        overall = H.DEGRADED
    end

    return {
        status = overall,
        checked_at = os.time(),
        agent_version = Const.AGENT_VERSION,
        protocol_version = Const.PROTOCOL_VERSION,
        state = ZShield.Agent.state(),
        failed = failed,
        degraded = degraded,
        components = components,
    }
end

--- Cheap summary for the heartbeat payload.
function Health.summary()
    local report = Health.check()
    return {
        status = report.status,
        failed = report.failed,
        degraded = report.degraded,
    }
end

--- Support bundle. Contains no secret: the credential is described by key id
--- only, and the configuration copy has the secret stripped by Agent.config().
function Health.diagnostics()
    return {
        generated_at = os.date('!%Y-%m-%dT%H:%M:%SZ'),
        agent = {
            version = Const.AGENT_VERSION,
            protocol_version = Const.PROTOCOL_VERSION,
            min_supported_api_version = Const.MIN_SUPPORTED_API_VERSION,
        },
        server = ZShield.Agent.info(),
        status = ZShield.Agent.status(),
        configuration = ZShield.Agent.config(),
        health = Health.check(),
        alerts = ZShield.Alerts and ZShield.Alerts.stats() or nil,
        telemetry = ZShield.Telemetry and ZShield.Telemetry.stats() or nil,
        commands = ZShield.Commands and ZShield.Commands.stats() or nil,
        config_sync = ZShield.ConfigSync and ZShield.ConfigSync.stats() or nil,
        last_error = Log.lastError(),
    }
end

-- ---------------------------------------------------------------------------
-- Console command
-- ---------------------------------------------------------------------------

local function line(text)
    print('[zshield-agent] ' .. text)
end

local function printReport(report)
    line(('overall: %s  state: %s'):format(report.status, report.state))
    local names = {}
    for name in pairs(report.components) do
        names[#names + 1] = name
    end
    table.sort(names)
    for _, name in ipairs(names) do
        local c = report.components[name]
        line(('  %-14s %-9s %s'):format(name, c.status, c.detail or ''))
    end
end

--- `restricted = true` means the console and ACE-authorised principals only.
--- A player cannot run this, so status output cannot leak to clients.
RegisterCommand('zshield', function(source, args)
    local sub = (args[1] or 'status'):lower()

    if sub == 'version' then
        line(('agent %s, protocol %d, api %d..%d'):format(
            Const.AGENT_VERSION, Const.PROTOCOL_VERSION,
            Const.MIN_SUPPORTED_API_VERSION, Const.MAX_SUPPORTED_API_VERSION))

    elseif sub == 'status' then
        local s = ZShield.Agent.status()
        line(('state=%s uptime=%ds requests ok=%d failed=%d rejected=%d'):format(
            s.state, s.uptime_seconds, s.requests.ok, s.requests.failed, s.requests.rejected))
        line(('queue=%d/%d  config_version=%d  key_id=%s'):format(
            s.queue.total, s.queue.max_size, s.config_version, tostring(s.credential.key_id)))
        if s.misconfiguration then
            line('misconfiguration: ' .. s.misconfiguration)
        end
        if s.last_error then
            line(('last error: %s (%s)'):format(tostring(s.last_error.code),
                tostring(s.last_error.reason)))
        end

    elseif sub == 'health' then
        printReport(Health.check())

    elseif sub == 'queue' then
        local q = Queue.stats()
        line(('alerts=%d telemetry=%d total=%d/%d dropped_full=%d dropped_expired=%d'):format(
            q.alerts, q.telemetry, q.total, q.max_size, q.dropped_full, q.dropped_expired))

    elseif sub == 'flush' then
        CreateThread(function()
            local alerts, telemetry = 0, 0
            if ZShield.Alerts then
                local _, count = ZShield.Alerts.flush()
                alerts = count or 0
            end
            if ZShield.Telemetry then
                local _, count = ZShield.Telemetry.flush()
                telemetry = count or 0
            end
            line(('flushed: alerts=%d telemetry=%d remaining=%d'):format(
                alerts, telemetry, Queue.size()))
        end)

    elseif sub == 'diagnostics' then
        local ok, encoded = pcall(json.encode, Health.diagnostics())
        if ok then
            -- Redaction is applied on the way out as a second line of defence.
            print(Log.redact(encoded))
            line('diagnostics printed above. It contains no secret, but review before sharing.')
        else
            line('could not encode diagnostics')
        end

    else
        line('usage: zshield <status|health|version|queue|flush|diagnostics>')
    end
end, true)

ZShield.Health = Health

return Health
