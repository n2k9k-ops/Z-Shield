# Checklist de déploiement

À parcourir dans l'ordre. Les cases marquées **bloquant** doivent être vertes
avant d'ouvrir le serveur aux joueurs.

## Avant installation

- [ ] FXServer build ≥ 7290 (`version` en console).
- [ ] Horloge de la machine hôte synchronisée par NTP. **Bloquant** : un
      décalage supérieur à 300 s rend l'authentification impossible.
- [ ] Sortie HTTPS autorisée vers le domaine du dashboard depuis la machine du
      serveur (pare-feu sortant, proxy d'entreprise).
- [ ] Serveur créé dans le dashboard, `server_id` et `agent_id` notés.
- [ ] Credential générée et copiée (elle n'est affichée qu'une fois).

## Installation

- [ ] Ressource déposée dans `resources/zshield-agent`.
- [ ] `config/config.example.lua` copié vers `config/config.lua`.
- [ ] `server_id`, `agent_id`, `api_endpoint` renseignés.
- [ ] Le répertoire `data/` existe et est accessible en écriture par le
      processus FXServer. **Bloquant** : sans lui, ni la file ni la credential
      rotée ne peuvent être persistées.
- [ ] `set zshield_agent_secret "..."` présent dans `server.cfg`, avec `set`
      et non `setr`/`sets`. **Bloquant**.
- [ ] `config/config.lua` ne contient **pas** le secret en production.
- [ ] `ensure zshield-agent` placé après vos ressources de base, avant ou
      après l'anti-cheat indifféremment.

## Durcissement de la configuration

- [ ] `environment` correspond à la réalité (`production` / `staging` /
      `development`).
- [ ] `allow_insecure_endpoint = false` en production. **Bloquant**.
- [ ] `commands.allowed` réduite au strict nécessaire. Retirer tout ce dont
      vous n'avez pas besoin.
- [ ] `rotate_credential` laissée commentée si vous ne prévoyez pas de
      rotation pilotée par le dashboard.
- [ ] `commands.enabled = false` si vous ne voulez aucune commande distante
      (heartbeat, télémétrie et alertes continuent de fonctionner).
- [ ] `remote_config.enabled` décidé consciemment : à `false`, seul votre
      fichier local fait loi.
- [ ] `log_level = 'INFO'` ou `'WARN'` en production ; `DEBUG` est verbeux et
      inutile hors diagnostic.
- [ ] `queue.max_size` compatible avec la mémoire disponible (2000 éléments ≈
      quelques mégaoctets selon la taille des métadonnées).

## Premier démarrage

- [ ] `ensure zshield-agent` ne produit aucune ligne `[SECURITY]` ni
      `[ERROR]`.
- [ ] `zshield status` affiche `state=ONLINE`. **Bloquant**.
- [ ] `zshield health` : tous les composants `HEALTHY` (`telemetry`,
      `commands` ou `config_sync` peuvent être `HEALTHY / disabled by
      configuration`, c'est normal).
- [ ] Le dashboard affiche le serveur comme connecté, avec la bonne version
      d'agent.
- [ ] `zshield version` correspond à ce qu'attend le dashboard.

## Vérifications fonctionnelles

- [ ] Alerte de test depuis une console ou une ressource :
      `exports['zshield-agent']:SendSecurityAlert({ category = 'agent',
      severity = 'INFO', summary = 'deployment smoke test' })` puis
      `zshield flush` → l'alerte apparaît dans le dashboard.
- [ ] Une alerte invalide est bien refusée (catégorie inventée) et journalisée
      en `WARN`, sans casser quoi que ce soit.
- [ ] Commande `ping` déclenchée depuis le dashboard → résultat `COMPLETED`.
- [ ] Commande non autorisée localement → résultat `REJECTED` côté dashboard.
      C'est le comportement attendu, pas une panne.
- [ ] Coupure simulée : bloquer la sortie vers le dashboard 2 minutes.
      Attendu : passage `DEGRADED` puis `OFFLINE`, file qui grossit, **aucun
      impact sur le gameplay**, puis livraison du retard au rétablissement.
- [ ] Redémarrage de la ressource avec des alertes en file
      (`ensure zshield-agent`) → les éléments sont restaurés depuis
      `data/queue.json`.

## Sécurité

- [ ] `data/credential.json` et `data/queue.json` ne sont pas servis par un
      serveur web et ne sont pas dans une sauvegarde publique.
- [ ] `config/config.lua` est dans `.gitignore` (déjà le cas) et n'a jamais été
      commité. Si un secret a fui dans l'historique git, le considérer comme
      compromis et le faire tourner.
- [ ] Permissions du répertoire de la ressource restreintes au compte qui fait
      tourner FXServer.
- [ ] Accès `zshield` console réservé : ne pas accorder la commande à des
      principals ACE joueurs.
- [ ] `zshield diagnostics` relu avant transmission à un tiers.
- [ ] Procédure de rotation connue de l'équipe (README §6).

## Exploitation courante

- [ ] Surveillance mise en place sur : agent `OFFLINE` > 15 min, composant
      `queue` en `DEGRADED`/`FAILED`, apparition de lignes `[SECURITY]`.
- [ ] Une ligne `rejected an unverified response` est traitée comme un
      incident : soit la plateforme ne respecte pas le protocole, soit
      quelqu'un se trouve sur le chemin TLS.
- [ ] Une ligne `rejected a remote configuration` signale un désaccord de
      version entre agent et plateforme, à corriger côté plateforme.
- [ ] Mise à jour de l'agent : lire le changelog du protocole. Si
      `min_agent_protocol` de la plateforme dépasse le protocole de l'agent,
      celui-ci passe `MISCONFIGURED` et cesse d'émettre — mettre à jour avant
      que la plateforme ne relève son minimum.

## Rollback

- [ ] `stop zshield-agent` suffit : aucune autre ressource n'en dépend, aucun
      schéma de base de données n'est modifié, aucun fichier hors
      `resources/zshield-agent/data/` n'est touché.
- [ ] Les alertes produites pendant l'arrêt ne sont pas conservées : l'export
      `SendSecurityAlert` échoue proprement si la ressource est arrêtée, ce que
      vos détecteurs doivent tolérer.
