# Protocole Agent ↔ SaaS — v1

Référence normative pour implémenter le côté plateforme. Tout ce qui suit est
appliqué par le code de l'agent : `shared/protocol.lua` et
`server/authentication.lua`. En cas de divergence entre ce document et ces
deux fichiers, les fichiers font foi.

- `protocol_version` courant : **1**
- `AGENT_VERSION` courant : **1.0.0**
- API minimale acceptée par l'agent : **1**

---

## 1. Transport

- HTTPS uniquement. L'agent refuse de démarrer sur une URL `http://` sauf si
  `allow_insecure_endpoint = true` (développement local uniquement).
- `Content-Type: application/json; charset=utf-8`.
- Corps maximal : **256 KiB**. Au-delà, l'agent n'envoie rien et journalise
  `E_PAYLOAD_TOO_LARGE`.
- Timeout local par requête : 2 à 60 s (10 s par défaut).
- L'agent n'ouvre aucun port et n'accepte aucune connexion entrante. Tout est
  initié par l'agent, y compris la récupération des commandes.

## 2. En-têtes

Chaque requête de l'agent porte :

| En-tête | Contenu |
|---|---|
| `X-ZShield-Agent-Id` | identifiant d'agent |
| `X-ZShield-Server-Id` | identifiant de serveur |
| `X-ZShield-Key-Id` | identifiant de la clé de signature active |
| `X-ZShield-Timestamp` | unix epoch, secondes |
| `X-ZShield-Nonce` | 32 caractères hex, unique par requête |
| `X-ZShield-Signature` | HMAC-SHA256 hex minuscule |
| `X-ZShield-Protocol` | `1` |
| `X-ZShield-Agent-Version` | ex. `1.0.0` |
| `X-ZShield-Request-Id` | 24 caractères hex, à renvoyer dans la réponse |

Chaque réponse de la plateforme doit porter :

| En-tête | Contenu |
|---|---|
| `X-ZShield-Timestamp` | unix epoch, secondes |
| `X-ZShield-Nonce` | nonce unique par réponse |
| `X-ZShield-Signature` | HMAC-SHA256 hex minuscule |

**Une réponse non signée est rejetée**, y compris une réponse d'erreur, y
compris un `401`. C'est volontaire : sans cela, quiconque se trouve sur le
chemin réseau pourrait pousser l'agent dans un état « credential révoquée ».

## 3. Signature des requêtes

Chaîne canonique signée par l'agent, séparateur `\n`, sans saut de ligne
final :

```
ZSHIELD-AGENT-V1
<MÉTHODE HTTP en majuscules>
<chemin sans query string>
<query string, ou chaîne vide>
<agent_id>
<server_id>
<key_id>
<timestamp>
<nonce>
<sha256 hex du corps brut, ou sha256 de la chaîne vide>
```

`signature = hex(HMAC-SHA256(secret, chaîne_canonique))`

La plateforme doit, dans cet ordre :

1. retrouver le secret par `agent_id` + `key_id` ;
2. vérifier l'écart d'horloge (**±300 s** ; hors fenêtre → `401`
   `E_AUTH_CLOCK_SKEW`) ;
3. vérifier l'unicité du nonce sur une fenêtre au moins égale à la tolérance
   d'horloge (déjà vu → `401` `E_AUTH_REPLAY`) ;
4. recalculer la signature et comparer en temps constant (différent → `401`
   `E_AUTH_INVALID_SIGNATURE`) ;
5. seulement ensuite parser le corps.

La méthode, le chemin et la query étant signés, une requête capturée ne peut
pas être rejouée contre un autre endpoint.

## 4. Signature des réponses

```
ZSHIELD-PLATFORM-V1
<code HTTP>
<request_id repris de la requête>
<timestamp>
<nonce>
<sha256 hex du corps de réponse>
```

Même secret, même algorithme. L'agent vérifie l'écart d'horloge, l'unicité du
nonce (cache des 512 derniers) et la signature avant de lire un seul champ.

## 5. Enveloppe de requête

Tout corps envoyé par l'agent a cette forme :

```json
{
  "protocol_version": 1,
  "agent_version": "1.0.0",
  "kind": "heartbeat",
  "server_id": "srv_...",
  "agent_id": "agt_...",
  "environment": "production",
  "sent_at": 1767225600,
  "payload": { }
}
```

Les identifiants sont présents à la fois dans l'enveloppe et dans les
en-têtes. **L'autorité est l'en-tête signé**, jamais l'enveloppe : la
plateforme doit rejeter la requête si les deux diffèrent.

## 6. Réponses en succès

Tout `2xx` doit contenir au minimum :

```json
{ "ok": true, "server_time": 1767225600, "request_id": "..." }
```

`ok: false` sur un `2xx` est traité comme une réponse invalide.

## 7. Endpoints

### `POST /v1/agents/handshake`

Premier échange, et revérification après rotation. Payload : `server` (faits
serveur : version FXServer, état OneSync, max players, uptime), `capabilities`,
`queue`.

Réponse :

```json
{
  "ok": true, "server_time": 1767225600, "request_id": "...",
  "api_version": 1,
  "min_agent_protocol": 1,
  "organization": "Nom de l'organisation",
  "server_name": "Nom du serveur",
  "key_id": "k1",
  "config": { }
}
```

`api_version` et `min_agent_protocol` sont obligatoires. Si
`min_agent_protocol` dépasse le protocole de l'agent, celui-ci passe en
`MISCONFIGURED` et **cesse toute activité réseau** jusqu'à mise à jour : la
négociation échoue fermée.

### `POST /v1/agents/heartbeat`

Payload : `state`, `agent_version`, `protocol_version`, `uptime_seconds`,
`players_online` (absent si la métrique est désactivée), `config_version`,
`queue_size`, `health`, `last_error`.

Réponse : `commands_pending` (entier), `config_version` (entier),
`suggested_interval` (15 à 900 s, optionnel).

C'est le seul mécanisme de notification : l'agent ne récupère la configuration
et les commandes que si le heartbeat annonce un changement. Pas de push, donc
pas de connexion entrante à sécuriser.

### `POST /v1/agents/telemetry`

Payload : `samples` (tableau d'échantillons). Réponse : `accepted`.

### `POST /v1/agents/alerts`

Payload : `alerts`, tableau dont chaque élément est :

```json
{
  "id": "al_...",
  "category": "movement",
  "severity": "HIGH",
  "summary": "texte court, 512 caractères maximum",
  "metadata": { "detector": "movement.anomaly", "confidence": 0.62 },
  "reference": "inc_123",
  "occurrences": 50,
  "occurred_at": 1767225600,
  "last_occurrence_at": 1767225630,
  "origin": "zshield_ac"
}
```

`severity` ∈ `INFO | LOW | MEDIUM | HIGH | CRITICAL`.
`category` ∈ `event | entity | movement | economy | weapon | resource | admin | agent | other`.
`metadata` : 32 clés maximum, valeurs scalaires seulement, 1024 caractères par
valeur.

`occurrences` porte la déduplication faite côté agent : 50 détections
identiques en 30 s arrivent comme **une** alerte avec `occurrences: 50`. La
plateforme doit afficher le compteur, pas créer 50 lignes.

Réponse : `accepted` (entier), `rejected` (tableau de `{id, reason}`,
optionnel). Un rejet individuel est traité côté agent comme un bug de contrat
et journalisé, pas réessayé en boucle.

### `GET /v1/agents/config?version=<n>`

Réponse : `config`, validée contre un schéma strict. **Tout champ inconnu fait
rejeter le document entier**, pas seulement le champ. Champs autorisés et
bornes :

| Champ | Type | Bornes |
|---|---|---|
| `config_version` | entier | requis, ≥ 0 |
| `telemetry_enabled` | booléen | |
| `heartbeat_interval` | entier | 15 à 900 |
| `telemetry_interval` | entier | 30 à 3600 |
| `alert_batch_size` | entier | 1 à 200 |
| `alert_flush_interval` | entier | 1 à 300 |
| `log_level` | chaîne | `DEBUG` `INFO` `WARN` `ERROR` |
| `metrics.players` | booléen | |
| `metrics.performance` | booléen | |
| `metrics.errors` | booléen | |
| `metrics.dependencies` | booléen | |
| `metrics.resources` | booléen | |

La plateforme ne peut donc pas modifier : identité, endpoint, secret, taille de
file, allowlist de commandes, persistance. Ajouter un réglage télécommandable
est un changement de protocole des deux côtés, pas une décision unilatérale de
la plateforme.

### `GET /v1/agents/commands?limit=25`

Réponse : `commands`, 25 éléments maximum, chacun :

```json
{
  "id": "cmd_...",
  "type": "request_health_check",
  "issued_at": 1767225600,
  "expires_at": 1767225900,
  "payload": { "correlation": "abc" }
}
```

`type` doit appartenir à l'allowlist du protocole :
`ping`, `request_status`, `request_health_check`, `refresh_configuration`,
`reload_safe_configuration`, `flush_queue`, `rotate_credential`.

Un `type` inconnu fait **rejeter tout le lot** par le schéma : aucune commande
du lot n'est exécutée. `id` doit être stable et unique (8 à 64 caractères,
`[A-Za-z0-9_-]`) car il sert de clé d'idempotence côté agent.

`payload` n'est pas un vecteur d'exécution : 8 clés maximum, valeurs scalaires
de 256 caractères. Aucun handler n'accepte de code, de chemin de fichier, de
nom de native, de ligne de commande ni d'URL.

### `POST /v1/agents/commands/results`

Payload : `results`, chacun `{id, status, result?, reason?, executed_at, duration_ms?}`.
`status` ∈ `COMPLETED | FAILED | REJECTED | DUPLICATE`.

`REJECTED` signifie que l'opérateur du serveur n'autorise pas cette commande
localement. Ce n'est pas une erreur à réessayer : c'est une décision. La
plateforme doit l'afficher comme telle.

Si l'agent n'arrive pas à rapporter, la plateforme peut renvoyer la commande :
l'idempotence par `id` garantit qu'elle ne sera pas réexécutée, et l'agent
renverra le résultat d'origine avec `status: DUPLICATE`.

### `POST /v1/agents/credentials/rotate`

Payload : `reason`, `current_key_id`.
Réponse : `key_id` (requis), `secret` (requis, 32 à 256 caractères),
`expires_at` (optionnel).

Séquence de rotation, côté agent :

1. demande signée avec la clé **courante** ;
2. nouveau matériel mis en attente, **non activé** ;
3. handshake de vérification signé avec la **nouvelle** clé seulement ;
4. commit et persistance uniquement si l'étape 3 réussit.

La plateforme doit donc accepter les deux clés entre l'étape 1 et l'étape 4.
Si l'étape 3 échoue, l'agent conserve l'ancienne clé et rapporte un échec :
une rotation ne doit jamais pouvoir enfermer l'agent dehors.

## 8. Erreurs

| HTTP | Code agent | Réessayé |
|---|---|---|
| 0 / réseau | `E_NETWORK_UNREACHABLE` | oui |
| 408, 504 | `E_TIMEOUT` | oui |
| 429 | `E_RATE_LIMITED` | oui |
| 5xx | `E_INTERNAL` | oui |
| 400 | `E_VALIDATION` | non |
| 401, 403 | `E_AUTH_CREDENTIAL_REVOKED` | non |
| 409, 426 | `E_PROTOCOL_UNSUPPORTED` | non |
| 413 | `E_PAYLOAD_TOO_LARGE` | non |

Corps d'erreur attendu (signé lui aussi) :

```json
{ "ok": false, "error": "E_VALIDATION", "message": "texte court", "retry_after": 30 }
```

Le code renvoyé par la plateforme ne peut que **préciser** l'erreur, jamais
l'élargir : un statut HTTP fatal reste fatal même si le corps annonce un code
réessayable.

Comportement de l'agent en échec : backoff exponentiel avec jitter (2 s à
300 s), puis disjoncteur ouvert après 6 échecs consécutifs pendant 60 s. Les
éléments réessayables retournent en file locale ; les éléments fatals sont
abandonnés et journalisés.

## 9. Ce que le protocole ne permet pas

À implémenter côté plateforme en le sachant : il n'existe aucun endpoint et
aucune commande permettant à la plateforme de faire exécuter du Lua, lancer un
shell, lire ou écrire un fichier hors du répertoire `data/` de l'agent, lire le
secret de signature, bannir ou expulser un joueur, démarrer ou arrêter une
ressource, ou changer l'endpoint API. C'est une limite de conception : la
sanction appartient à l'anti-cheat sur le serveur, sous la configuration de
l'opérateur, pas à un dashboard distant.

## 10. Hypothèses et limites

- Le secret est une credential porteuse. Ce qui peut lire la configuration ou
  la mémoire du serveur peut usurper l'agent auprès de la plateforme. FXServer
  n'offre pas de stockage de clé matériel : c'est une limite acceptée, pas un
  problème que l'agent peut résoudre.
- La signature des réponses prouve que la plateforme détient le secret
  partagé. Elle ne prouve pas que la plateforme n'est pas compromise — d'où
  l'allowlist de commandes.
- La protection anti-rejeu suppose une horloge serveur à peu près juste. Un
  serveur déréglé de plus de 300 s ne s'authentifiera pas. Élargir
  silencieusement la fenêtre affaiblirait chaque requête.
- HMAC-SHA256 est implémenté en Lua pur (`shared/crypto.lua`), faute de native
  cryptographique dans FXServer. Il est vérifié contre les vecteurs NIST et
  RFC 4231, mais il n'est pas durci contre une attaque par canal auxiliaire
  locale.
- `Crypto.equals` évite la sortie anticipée au premier octet différent. Lua ne
  garantit pas le temps constant : c'est une défense en profondeur.
