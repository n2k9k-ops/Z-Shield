fx_version 'cerulean'
game 'gta5'

name 'zshield-agent'
author 'ZShield'
description 'Defensive monitoring agent: reports FiveM server and anti-cheat telemetry to a ZShield dashboard.'
version '1.0.0'
repository ''

-- Required: the signing code uses Lua 5.4 bitwise operators and string.pack.
lua54 'yes'

-- Server only. The agent holds a shared secret and must never ship code to
-- clients; there is deliberately no client_script here.
server_scripts {
    'shared/constants.lua',
    'shared/crypto.lua',
    'shared/validation.lua',
    'shared/protocol.lua',
    'server/logger.lua',
    'server/queue.lua',
    'server/authentication.lua',
    'server/agent.lua',
    'server/heartbeat.lua',
    'server/telemetry.lua',
    'server/alerts.lua',
    'server/commands.lua',
    'server/config_sync.lua',
    'server/health.lua',
}

-- config/config.lua is not declared here on purpose: it is read at runtime
-- with LoadResourceFile into an empty Lua environment, so a syntax error in
-- an operator's configuration cannot take the resource down, and the file
-- cannot call natives. Copy config/config.example.lua to config/config.lua.
files {
    'config/config.example.lua',
}

dependency '/server:7290'
