--[[
    zshield-agent / shared/validation.lua

    PURPOSE
        A small, strict, dependency-free schema validator. Every inbound
        payload (platform responses, remote configuration, commands) and every
        outbound payload (alerts pushed by other resources) goes through it.

        Design rules:
          - Unknown fields are rejected by default, not ignored. A field we do
            not understand from the platform is a protocol mismatch or an
            attack, never something to silently accept.
          - Validation never raises on bad data; it returns (false, reason).
            Only programmer error (a malformed schema) raises.
          - Validation is total: it does not mutate the input, it returns a
            sanitised copy so callers cannot accidentally forward extra keys.

    DEPENDENCIES
        None.

    PUBLIC API
        ZShield.Validation.check(value, schema)     -> ok, errOrValue
        ZShield.Validation.schema(def)              -> normalised schema
        ZShield.Validation.isSafeString(s)          -> boolean

    SCHEMA REFERENCE
        {
            type     = 'string' | 'number' | 'integer' | 'boolean'
                       | 'table' | 'array' | 'any',
            required = boolean,          -- default false
            default  = <value>,          -- applied when field is absent
            min      = number,           -- numbers: value; strings/arrays: length
            max      = number,
            pattern  = string,           -- Lua pattern, strings only
            enum     = { ... },          -- allowed scalar values
            fields   = { name = schema },-- tables
            items    = schema,           -- arrays
            strict   = boolean,          -- tables: reject unknown keys (default true)
            custom   = function(v) -> ok, err
        }
]]

ZShield = ZShield or {}

local Validation = {}

local TYPES <const> = {
    string = true, number = true, integer = true, boolean = true,
    table = true, array = true, any = true,
}

-- Characters we refuse in any string that may end up in a log line, a header
-- or a JSON document forwarded to the platform.
local CONTROL_PATTERN <const> = '[%c]'

--- True when a string contains no control characters and is not absurdly long.
function Validation.isSafeString(s, maxLen)
    if type(s) ~= 'string' then
        return false
    end
    if #s > (maxLen or 4096) then
        return false
    end
    return s:find(CONTROL_PATTERN) == nil
end

local function isArray(t)
    local n = 0
    for k in pairs(t) do
        if type(k) ~= 'number' or k % 1 ~= 0 or k < 1 then
            return false
        end
        n = n + 1
    end
    return n == #t
end

local function typeName(schema)
    return schema.type or 'any'
end

local function assertSchema(schema, path)
    if type(schema) ~= 'table' then
        error(('validation: schema at %s is not a table'):format(path), 0)
    end
    local t = typeName(schema)
    if not TYPES[t] then
        error(('validation: unknown type %q at %s'):format(tostring(t), path), 0)
    end
end

local check -- forward declaration

local function checkScalarConstraints(value, schema, path)
    if schema.enum then
        local found = false
        for _, allowed in ipairs(schema.enum) do
            if value == allowed then
                found = true
                break
            end
        end
        if not found then
            return false, ('%s: value not in allowed set'):format(path)
        end
    end

    if schema.custom then
        local ok, err = schema.custom(value)
        if not ok then
            return false, ('%s: %s'):format(path, err or 'rejected by custom validator')
        end
    end

    return true
end

local function checkString(value, schema, path)
    if type(value) ~= 'string' then
        return false, ('%s: expected string, got %s'):format(path, type(value))
    end
    if schema.min and #value < schema.min then
        return false, ('%s: shorter than %d characters'):format(path, schema.min)
    end
    if schema.max and #value > schema.max then
        return false, ('%s: longer than %d characters'):format(path, schema.max)
    end
    if schema.pattern and not value:match(schema.pattern) then
        return false, ('%s: does not match required format'):format(path)
    end
    if not schema.allowControl and value:find(CONTROL_PATTERN) then
        return false, ('%s: contains control characters'):format(path)
    end

    local ok, err = checkScalarConstraints(value, schema, path)
    if not ok then
        return false, err
    end
    return true, value
end

local function checkNumber(value, schema, path, integerOnly)
    if type(value) ~= 'number' then
        return false, ('%s: expected number, got %s'):format(path, type(value))
    end
    if value ~= value or value == math.huge or value == -math.huge then
        return false, ('%s: not a finite number'):format(path)
    end
    if integerOnly and value % 1 ~= 0 then
        return false, ('%s: expected integer'):format(path)
    end
    if schema.min and value < schema.min then
        return false, ('%s: below minimum %s'):format(path, schema.min)
    end
    if schema.max and value > schema.max then
        return false, ('%s: above maximum %s'):format(path, schema.max)
    end

    local ok, err = checkScalarConstraints(value, schema, path)
    if not ok then
        return false, err
    end
    return true, value
end

local function checkArray(value, schema, path)
    if type(value) ~= 'table' or not isArray(value) then
        return false, ('%s: expected array'):format(path)
    end
    if schema.min and #value < schema.min then
        return false, ('%s: fewer than %d items'):format(path, schema.min)
    end
    if schema.max and #value > schema.max then
        return false, ('%s: more than %d items'):format(path, schema.max)
    end

    local out = {}
    if schema.items then
        for i = 1, #value do
            local ok, res = check(value[i], schema.items, ('%s[%d]'):format(path, i))
            if not ok then
                return false, res
            end
            out[i] = res
        end
    else
        for i = 1, #value do
            out[i] = value[i]
        end
    end

    local ok, err = checkScalarConstraints(value, schema, path)
    if not ok then
        return false, err
    end
    return true, out
end

local function checkTable(value, schema, path)
    if type(value) ~= 'table' then
        return false, ('%s: expected object, got %s'):format(path, type(value))
    end

    local strict = schema.strict
    if strict == nil then
        strict = true
    end

    local out = {}

    if schema.fields then
        for name, fieldSchema in pairs(schema.fields) do
            local fieldPath = path == '' and name or (path .. '.' .. name)
            local raw = value[name]

            if raw == nil then
                if fieldSchema.required then
                    return false, ('%s: required field missing'):format(fieldPath)
                end
                if fieldSchema.default ~= nil then
                    out[name] = fieldSchema.default
                end
            else
                local ok, res = check(raw, fieldSchema, fieldPath)
                if not ok then
                    return false, res
                end
                out[name] = res
            end
        end

        if strict then
            for name in pairs(value) do
                if type(name) ~= 'string' then
                    return false, ('%s: non-string key in object'):format(path)
                end
                if schema.fields[name] == nil then
                    return false, ('%s.%s: unknown field'):format(path, name)
                end
            end
        end
    else
        -- Free-form object (for example alert metadata). Still bounded.
        local count = 0
        for k, v in pairs(value) do
            if type(k) ~= 'string' then
                return false, ('%s: non-string key in object'):format(path)
            end
            count = count + 1
            if schema.maxKeys and count > schema.maxKeys then
                return false, ('%s: more than %d keys'):format(path, schema.maxKeys)
            end
            local vt = type(v)
            if vt == 'string' then
                if #v > (schema.maxValueLength or 1024) then
                    return false, ('%s.%s: value too long'):format(path, k)
                end
            elseif vt ~= 'number' and vt ~= 'boolean' then
                return false, ('%s.%s: only string, number and boolean values allowed'):format(path, k)
            end
            out[k] = v
        end
    end

    local ok, err = checkScalarConstraints(value, schema, path)
    if not ok then
        return false, err
    end
    return true, out
end

--- Validate `value` against `schema`.
--- Returns (true, sanitisedValue) or (false, humanReadableReason).
function check(value, schema, path)
    path = path or ''
    assertSchema(schema, path == '' and '<root>' or path)

    local t = typeName(schema)

    if t == 'any' then
        local ok, err = checkScalarConstraints(value, schema, path)
        if not ok then
            return false, err
        end
        return true, value
    elseif t == 'string' then
        return checkString(value, schema, path)
    elseif t == 'number' then
        return checkNumber(value, schema, path, false)
    elseif t == 'integer' then
        return checkNumber(value, schema, path, true)
    elseif t == 'boolean' then
        if type(value) ~= 'boolean' then
            return false, ('%s: expected boolean, got %s'):format(path, type(value))
        end
        return true, value
    elseif t == 'array' then
        return checkArray(value, schema, path)
    elseif t == 'table' then
        return checkTable(value, schema, path)
    end

    return false, ('%s: unhandled type'):format(path)
end

Validation.check = check

--- Convenience wrapper that returns nil plus an error instead of false.
function Validation.parse(value, schema)
    local ok, res = check(value, schema)
    if not ok then
        return nil, res
    end
    return res
end

ZShield.Validation = Validation

return Validation
