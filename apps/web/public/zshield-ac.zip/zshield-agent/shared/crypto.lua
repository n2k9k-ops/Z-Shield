--[[
    zshield-agent / shared/crypto.lua

    PURPOSE
        Pure-Lua SHA-256 and HMAC-SHA256. FXServer exposes no cryptographic
        native, so request signing is implemented here.

    DEPENDENCIES
        Lua 5.4 only (native bitwise operators, string.pack/unpack).
        Requires `lua54 'yes'` in fxmanifest.lua.

    PUBLIC API
        ZShield.Crypto.sha256(str)        -> raw 32-byte digest
        ZShield.Crypto.sha256hex(str)     -> lowercase hex digest
        ZShield.Crypto.hmac(key, msg)     -> raw 32-byte HMAC
        ZShield.Crypto.hmachex(key, msg)  -> lowercase hex HMAC
        ZShield.Crypto.equals(a, b)       -> length-independent comparison
        ZShield.Crypto.nonce([bytes])     -> hex nonce string
        ZShield.Crypto.tohex(raw)         -> hex encoding

    SECURITY NOTES
        - This is a correctness-focused implementation, not a hardened one.
          It is fast enough for a few signatures per second, which is the
          entire workload of this agent. Do not use it to hash large blobs.
        - `equals` avoids early-exit on the first differing byte. Lua gives no
          guarantee of constant time, so treat it as defence in depth only.
        - Nonce entropy derives from os.time + os.clock + math.random + a
          monotonic counter. It is sufficient for replay windows, and must not
          be repurposed as a key generator.
]]

ZShield = ZShield or {}

local Crypto = {}

local K <const> = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
}

local MASK <const> = 0xFFFFFFFF
local BLOCK_SIZE <const> = 64

local sunpack <const> = string.unpack
local spack <const> = string.pack
local srep <const> = string.rep
local sbyte <const> = string.byte
local schar <const> = string.char
local sformat <const> = string.format

local function rotr(x, n)
    return ((x >> n) | (x << (32 - n))) & MASK
end

--- SHA-256 over a byte string. Returns the raw 32-byte digest.
function Crypto.sha256(msg)
    if type(msg) ~= 'string' then
        error('crypto.sha256: expected string, got ' .. type(msg), 2)
    end

    local len = #msg
    -- Padding: 0x80, then zeros until len % 64 == 56, then 64-bit bit length.
    msg = msg .. '\128' .. srep('\0', (55 - len) % BLOCK_SIZE) .. spack('>I8', len * 8)

    local h1, h2, h3, h4 = 0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a
    local h5, h6, h7, h8 = 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19

    local w = {}

    for chunk = 1, #msg, BLOCK_SIZE do
        for j = 0, 15 do
            w[j + 1] = sunpack('>I4', msg, chunk + j * 4)
        end

        for j = 17, 64 do
            local a15, a2 = w[j - 15], w[j - 2]
            local s0 = rotr(a15, 7) ~ rotr(a15, 18) ~ (a15 >> 3)
            local s1 = rotr(a2, 17) ~ rotr(a2, 19) ~ (a2 >> 10)
            w[j] = (w[j - 16] + s0 + w[j - 7] + s1) & MASK
        end

        local a, b, c, d = h1, h2, h3, h4
        local e, f, g, hh = h5, h6, h7, h8

        for j = 1, 64 do
            local S1 = rotr(e, 6) ~ rotr(e, 11) ~ rotr(e, 25)
            local ch = (e & f) ~ ((~e & MASK) & g)
            local t1 = (hh + S1 + ch + K[j] + w[j]) & MASK
            local S0 = rotr(a, 2) ~ rotr(a, 13) ~ rotr(a, 22)
            local maj = (a & b) ~ (a & c) ~ (b & c)
            local t2 = (S0 + maj) & MASK

            hh = g
            g = f
            f = e
            e = (d + t1) & MASK
            d = c
            c = b
            b = a
            a = (t1 + t2) & MASK
        end

        h1 = (h1 + a) & MASK
        h2 = (h2 + b) & MASK
        h3 = (h3 + c) & MASK
        h4 = (h4 + d) & MASK
        h5 = (h5 + e) & MASK
        h6 = (h6 + f) & MASK
        h7 = (h7 + g) & MASK
        h8 = (h8 + hh) & MASK
    end

    return spack('>I4I4I4I4I4I4I4I4', h1, h2, h3, h4, h5, h6, h7, h8)
end

--- Hex-encode a byte string.
function Crypto.tohex(raw)
    return (raw:gsub('.', function(c)
        return sformat('%02x', sbyte(c))
    end))
end

--- SHA-256 as lowercase hex.
function Crypto.sha256hex(msg)
    return Crypto.tohex(Crypto.sha256(msg))
end

--- HMAC-SHA256. Returns the raw 32-byte MAC.
function Crypto.hmac(key, msg)
    if type(key) ~= 'string' or type(msg) ~= 'string' then
        error('crypto.hmac: key and msg must be strings', 2)
    end

    if #key > BLOCK_SIZE then
        key = Crypto.sha256(key)
    end
    if #key < BLOCK_SIZE then
        key = key .. srep('\0', BLOCK_SIZE - #key)
    end

    local inner, outer = {}, {}
    for i = 1, BLOCK_SIZE do
        local byte = sbyte(key, i)
        inner[i] = schar(byte ~ 0x36)
        outer[i] = schar(byte ~ 0x5c)
    end

    local innerHash = Crypto.sha256(table.concat(inner) .. msg)
    return Crypto.sha256(table.concat(outer) .. innerHash)
end

--- HMAC-SHA256 as lowercase hex.
function Crypto.hmachex(key, msg)
    return Crypto.tohex(Crypto.hmac(key, msg))
end

--- Comparison that does not short-circuit on the first differing byte.
function Crypto.equals(a, b)
    if type(a) ~= 'string' or type(b) ~= 'string' then
        return false
    end

    -- Compare digests of both inputs so that length itself is not a fast path.
    local da, db = Crypto.sha256(a), Crypto.sha256(b)
    local diff = 0
    for i = 1, 32 do
        diff = diff | (sbyte(da, i) ~ sbyte(db, i))
    end

    return diff == 0
end

local nonceCounter = 0

--- Hex nonce. `bytes` defaults to 16 (32 hex characters).
function Crypto.nonce(bytes)
    bytes = bytes or 16
    nonceCounter = nonceCounter + 1

    local seed = table.concat({
        tostring(os.time()),
        sformat('%.9f', os.clock()),
        tostring(nonceCounter),
        tostring(math.random(0, 2 ^ 30)),
        tostring(math.random(0, 2 ^ 30)),
    }, ':')

    local raw = Crypto.sha256(seed)
    while #raw < bytes do
        raw = raw .. Crypto.sha256(raw .. seed)
    end

    return Crypto.tohex(raw:sub(1, bytes))
end

ZShield.Crypto = Crypto

return Crypto
