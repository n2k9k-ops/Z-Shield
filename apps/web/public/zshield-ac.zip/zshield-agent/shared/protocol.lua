--[[
    zshield-agent / shared/protocol.lua

    PURPOSE
        The contract between the agent and the SaaS platform. This file is the
        normative reference: if the platform and the agent disagree, this file
        (and docs/PROTOCOL.md, generated from it) is what both sides implement.

        It defines:
          - the canonical string that gets signed, in both directions;
          - the request envelope;
          - the schema of every response the agent will accept;
          - the mapping from HTTP status to agent error codes.

    DEPENDENCIES
        shared/constants.lua
        shared/validation.lua

    PUBLIC API
        ZShield.Protocol.canonicalRequest(parts)   -> string to sign
        ZShield.Protocol.canonicalResponse(parts)  -> string to verify
        ZShield.Protocol.envelope(kind, payload)   -> table
        ZShield.Protocol.RESPONSE[<endpoint>]      -> schema
        ZShield.Protocol.errorFromStatus(status)   -> errorCode, retryable

    SECURITY NOTES
        - Signing covers method, path, identity, timestamp, nonce and a digest
          of the body. Changing any of those invalidates the signature, so a
          captured request cannot be replayed against a different endpoint.
        - Responses are signed too. An attacker who terminates TLS (corporate
          proxy, compromised DNS, operator error) still cannot forge a
          configuration push or a command, because they do not hold the shared
          secret. This is defence in depth, not a replacement for TLS.
        - Every response is schema-checked before a single field is read. A
          200 OK from the right domain with the right signature is still
          untrusted input until it validates.
]]

ZShield = ZShield or {}

local Const = ZShield.Const
local Protocol = {}

Protocol.VERSION = Const.PROTOCOL_VERSION

-- ---------------------------------------------------------------------------
-- Canonicalisation
-- ---------------------------------------------------------------------------

--- Build the string signed by the agent for an outbound request.
---
--- Format (LF separated, no trailing newline):
---   ZSHIELD-AGENT-V<protocol>
---   <HTTP METHOD, uppercase>
---   <path, no query string>
---   <query string, sorted, or empty>
---   <agent_id>
---   <server_id>
---   <key_id>
---   <unix timestamp, seconds>
---   <nonce>
---   <lowercase hex sha256 of the raw body, or sha256 of empty string>
function Protocol.canonicalRequest(p)
    return table.concat({
        'ZSHIELD-AGENT-V' .. tostring(Protocol.VERSION),
        string.upper(p.method),
        p.path,
        p.query or '',
        p.agentId,
        p.serverId,
        p.keyId,
        tostring(p.timestamp),
        p.nonce,
        p.bodyHash,
    }, '\n')
end

--- Build the string the platform is expected to have signed for a response.
---
--- Format:
---   ZSHIELD-PLATFORM-V<protocol>
---   <HTTP status code>
---   <request id echoed back by the platform>
---   <unix timestamp, seconds>
---   <nonce>
---   <lowercase hex sha256 of the raw response body>
function Protocol.canonicalResponse(p)
    return table.concat({
        'ZSHIELD-PLATFORM-V' .. tostring(Protocol.VERSION),
        tostring(p.status),
        p.requestId,
        tostring(p.timestamp),
        p.nonce,
        p.bodyHash,
    }, '\n')
end

-- ---------------------------------------------------------------------------
-- Request envelope
-- ---------------------------------------------------------------------------

--- Every request body is wrapped in the same envelope so the platform can
--- route and version without parsing endpoint-specific payloads first.
function Protocol.envelope(kind, payload, ctx)
    return {
        protocol_version = Protocol.VERSION,
        agent_version    = Const.AGENT_VERSION,
        kind             = kind,
        server_id        = ctx.serverId,
        agent_id         = ctx.agentId,
        environment      = ctx.environment,
        sent_at          = os.time(),
        payload          = payload,
    }
end

-- ---------------------------------------------------------------------------
-- Response schemas
-- ---------------------------------------------------------------------------

local S = {} -- shorthand for building schemas

S.errorBody = {
    type = 'table',
    fields = {
        ok      = { type = 'boolean' },
        error   = { type = 'string', required = true, max = 64 },
        message = { type = 'string', max = 512 },
        retry_after = { type = 'integer', min = 0, max = 86400 },
    },
}

--- Fields shared by every successful response.
local function withCommon(fields)
    fields.ok = { type = 'boolean', required = true }
    fields.request_id = { type = 'string', max = 64 }
    fields.server_time = { type = 'integer', required = true, min = 0 }
    return { type = 'table', fields = fields }
end

--- Remote configuration. This is the only inbound payload that changes agent
--- behaviour, so its schema is the tightest one in the file. Anything not
--- listed here is rejected, which is why `strict` stays on.
Protocol.REMOTE_CONFIG_SCHEMA = {
    type = 'table',
    strict = true,
    fields = {
        config_version     = { type = 'integer', required = true, min = 0 },
        telemetry_enabled  = { type = 'boolean' },
        heartbeat_interval = { type = 'integer', min = 15, max = 900 },
        telemetry_interval = { type = 'integer', min = 30, max = 3600 },
        alert_batch_size   = { type = 'integer', min = 1, max = 200 },
        alert_flush_interval = { type = 'integer', min = 1, max = 300 },
        log_level          = { type = 'string', enum = { 'DEBUG', 'INFO', 'WARN', 'ERROR' } },
        metrics = {
            type = 'table',
            strict = true,
            fields = {
                players      = { type = 'boolean' },
                performance  = { type = 'boolean' },
                errors       = { type = 'boolean' },
                dependencies = { type = 'boolean' },
                resources    = { type = 'boolean' },
            },
        },
    },
}

Protocol.COMMAND_SCHEMA = {
    type = 'table',
    strict = true,
    fields = {
        id         = { type = 'string', required = true, min = 8, max = 64, pattern = '^[%w%-_]+$' },
        type       = { type = 'string', required = true, max = 64, enum = {
            Const.COMMAND.REQUEST_STATUS,
            Const.COMMAND.REQUEST_HEALTH_CHECK,
            Const.COMMAND.REFRESH_CONFIGURATION,
            Const.COMMAND.RELOAD_SAFE_CONFIGURATION,
            Const.COMMAND.PING,
            Const.COMMAND.FLUSH_QUEUE,
            Const.COMMAND.ROTATE_CREDENTIAL,
            Const.COMMAND.SPECTATE_REQUEST,
            Const.COMMAND.SPECTATE_STOP,
        } },
        issued_at  = { type = 'integer', required = true, min = 0 },
        expires_at = { type = 'integer', min = 0 },
        -- Commands carry no executable payload by design. A bounded key/value
        -- map is allowed for parameters such as a correlation id.
        payload    = { type = 'table', maxKeys = 8, maxValueLength = 256 },
    },
}

Protocol.RESPONSE = {}

Protocol.RESPONSE[Const.ENDPOINT.HANDSHAKE] = withCommon({
    api_version          = { type = 'integer', required = true, min = 1 },
    min_agent_protocol   = { type = 'integer', required = true, min = 1 },
    organization         = { type = 'string', max = 128 },
    server_name          = { type = 'string', max = 128 },
    key_id               = { type = 'string', max = 64, pattern = '^[%w%-_]+$' },
    config               = Protocol.REMOTE_CONFIG_SCHEMA,
})

Protocol.RESPONSE[Const.ENDPOINT.HEARTBEAT] = withCommon({
    commands_pending = { type = 'integer', min = 0, max = 10000 },
    config_version   = { type = 'integer', min = 0 },
    -- The platform may ask the agent to slow down. Honoured, within bounds.
    suggested_interval = { type = 'integer', min = 15, max = 900 },
})

Protocol.RESPONSE[Const.ENDPOINT.TELEMETRY] = withCommon({
    accepted = { type = 'integer', min = 0 },
})

Protocol.RESPONSE[Const.ENDPOINT.ALERTS] = withCommon({
    accepted = { type = 'integer', min = 0 },
    rejected = { type = 'array', max = 200, items = {
        type = 'table',
        strict = true,
        fields = {
            id     = { type = 'string', required = true, max = 64 },
            reason = { type = 'string', max = 256 },
        },
    } },
})

Protocol.RESPONSE[Const.ENDPOINT.CONFIG] = withCommon({
    config = Protocol.REMOTE_CONFIG_SCHEMA,
})

Protocol.RESPONSE[Const.ENDPOINT.COMMANDS] = withCommon({
    commands = { type = 'array', max = Const.LIMIT.MAX_COMMANDS_PER_POLL, items = Protocol.COMMAND_SCHEMA },
})

Protocol.RESPONSE[Const.ENDPOINT.COMMAND_RESULT] = withCommon({
    accepted = { type = 'integer', min = 0 },
})

Protocol.RESPONSE[Const.ENDPOINT.ROTATE] = withCommon({
    -- min = 1 to stay consistent with the config and handshake schemas: a
    -- dashboard is free to issue short key ids such as 'k2'.
    key_id     = { type = 'string', required = true, min = 1, max = 64, pattern = '^[%w%-_]+$' },
    secret     = { type = 'string', required = true, min = 32, max = 256 },
    expires_at = { type = 'integer', min = 0 },
})

Protocol.ERROR_RESPONSE = S.errorBody

-- ---------------------------------------------------------------------------
-- HTTP status mapping
-- ---------------------------------------------------------------------------

--- Map a transport outcome to (errorCode, retryable).
--- FXServer reports network failures as a status <= 0.
function Protocol.errorFromStatus(status)
    if status == nil or status <= 0 then
        return Const.ERROR.NETWORK_UNREACHABLE, true
    elseif status >= 200 and status < 300 then
        return nil, false
    elseif status == 400 then
        return Const.ERROR.VALIDATION, false
    elseif status == 401 or status == 403 then
        return Const.ERROR.CREDENTIAL_REVOKED, false
    elseif status == 409 then
        return Const.ERROR.PROTOCOL_UNSUPPORTED, false
    elseif status == 413 then
        return Const.ERROR.PAYLOAD_TOO_LARGE, false
    elseif status == 426 then
        return Const.ERROR.PROTOCOL_UNSUPPORTED, false
    elseif status == 429 then
        return Const.ERROR.RATE_LIMITED, true
    elseif status == 408 or status == 504 then
        return Const.ERROR.TIMEOUT, true
    elseif status >= 500 then
        return Const.ERROR.INTERNAL, true
    end
    return Const.ERROR.BAD_RESPONSE, false
end

--- True when a failed exchange should be retried with the same payload.
function Protocol.isRetryable(errorCode)
    if errorCode == nil then
        return false
    end
    return not Const.FATAL_ERRORS[errorCode]
end

ZShield.Protocol = Protocol

return Protocol
