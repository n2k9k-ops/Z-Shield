--[[
    zshield-agent / shared/constants.lua

    PURPOSE
        Single source of truth for versions, enums, header names, limits and
        error codes. Nothing in this file has behaviour; it exists so that no
        other module contains a magic string or magic number.

    DEPENDENCIES
        None.

    PUBLIC API
        ZShield.Const.<...>  (read-only table)
]]

ZShield = ZShield or {}

local Const = {}

-- ---------------------------------------------------------------------------
-- Versions
-- ---------------------------------------------------------------------------

--- Agent implementation version. Bump on every release.
Const.AGENT_VERSION = '1.0.0'

--- Wire protocol version. Bump only when the envelope, signing scheme or
--- endpoint semantics change in a non-backward-compatible way.
Const.PROTOCOL_VERSION = 1

--- Oldest SaaS API version this agent can talk to. The handshake fails closed
--- if the platform reports something lower.
Const.MIN_SUPPORTED_API_VERSION = 1

--- Newest SaaS API version this agent understands. A higher value from the
--- platform is tolerated (we keep using our own version), but logged.
Const.MAX_SUPPORTED_API_VERSION = 1

-- ---------------------------------------------------------------------------
-- Agent lifecycle
-- ---------------------------------------------------------------------------

Const.AGENT_STATE = {
    BOOTING       = 'BOOTING',       -- resource started, config not yet loaded
    MISCONFIGURED = 'MISCONFIGURED', -- config invalid: no network activity at all
    HANDSHAKING   = 'HANDSHAKING',   -- attempting first authenticated exchange
    ONLINE        = 'ONLINE',        -- platform reachable, last exchange succeeded
    DEGRADED      = 'DEGRADED',      -- reachable but erroring, or queue backing up
    OFFLINE       = 'OFFLINE',       -- platform unreachable, buffering locally
    STOPPING      = 'STOPPING',      -- resource stop in progress, flushing
}

--- Health status reported per component and aggregated for the agent.
Const.HEALTH = {
    HEALTHY  = 'HEALTHY',
    DEGRADED = 'DEGRADED',
    FAILED   = 'FAILED',
    UNKNOWN  = 'UNKNOWN',
}

-- ---------------------------------------------------------------------------
-- Alerts
-- ---------------------------------------------------------------------------

Const.SEVERITY = {
    INFO     = 'INFO',
    LOW      = 'LOW',
    MEDIUM   = 'MEDIUM',
    HIGH     = 'HIGH',
    CRITICAL = 'CRITICAL',
}

--- Ordering used for queue eviction and batch prioritisation.
Const.SEVERITY_WEIGHT = {
    INFO     = 1,
    LOW      = 2,
    MEDIUM   = 3,
    HIGH     = 4,
    CRITICAL = 5,
}

--- Free-form but validated: the platform stores the category as a string.
--- Keeping a known list here lets the agent reject typos from other resources.
Const.ALERT_CATEGORY = {
    'event',        -- network event abuse / validation failure
    'entity',       -- entity or vehicle spawn anomaly
    'movement',     -- position / velocity anomaly
    'economy',      -- money or inventory anomaly
    'weapon',       -- damage anomaly
    'resource',     -- resource integrity / unexpected state
    'admin',        -- administrative action worth surfacing
    'agent',        -- the agent reporting on itself
    'other',
}

-- ---------------------------------------------------------------------------
-- Log levels
-- ---------------------------------------------------------------------------

Const.LOG_LEVEL = {
    DEBUG    = 10,
    INFO     = 20,
    WARN     = 30,
    ERROR    = 40,
    SECURITY = 50, -- always emitted, never suppressed by level configuration
}

Const.LOG_LEVEL_NAME = {
    [10] = 'DEBUG',
    [20] = 'INFO',
    [30] = 'WARN',
    [40] = 'ERROR',
    [50] = 'SECURITY',
}

-- ---------------------------------------------------------------------------
-- Transport
-- ---------------------------------------------------------------------------

Const.HEADER = {
    AGENT_ID   = 'X-ZShield-Agent-Id',
    SERVER_ID  = 'X-ZShield-Server-Id',
    KEY_ID     = 'X-ZShield-Key-Id',
    TIMESTAMP  = 'X-ZShield-Timestamp',
    NONCE      = 'X-ZShield-Nonce',
    SIGNATURE  = 'X-ZShield-Signature',
    PROTOCOL   = 'X-ZShield-Protocol',
    AGENT_VER  = 'X-ZShield-Agent-Version',
    REQUEST_ID = 'X-ZShield-Request-Id',
}

Const.ENDPOINT = {
    HANDSHAKE      = '/v1/agents/handshake',
    HEARTBEAT      = '/v1/agents/heartbeat',
    TELEMETRY      = '/v1/agents/telemetry',
    ALERTS         = '/v1/agents/alerts',
    CONFIG         = '/v1/agents/config',
    COMMANDS       = '/v1/agents/commands',
    COMMAND_RESULT = '/v1/agents/commands/results',
    ROTATE         = '/v1/agents/credentials/rotate',
}

--- Maximum accepted clock difference between agent and platform, in seconds.
--- Used both for outgoing timestamps and for validating signed responses.
Const.CLOCK_SKEW_TOLERANCE = 300

--- Hard ceiling on a single request body. Protects the platform from a
--- runaway local producer and keeps FXServer HTTP calls predictable.
Const.MAX_PAYLOAD_BYTES = 256 * 1024

-- ---------------------------------------------------------------------------
-- Error codes
-- ---------------------------------------------------------------------------
-- RETRYABLE errors mean "try again later, the request was probably fine".
-- FATAL errors mean "do not retry this payload, it will never succeed".

Const.ERROR = {
    -- transport
    NETWORK_UNREACHABLE = 'E_NETWORK_UNREACHABLE',
    TIMEOUT             = 'E_TIMEOUT',
    BAD_RESPONSE        = 'E_BAD_RESPONSE',
    -- authentication
    INVALID_SIGNATURE   = 'E_AUTH_INVALID_SIGNATURE',
    CLOCK_SKEW          = 'E_AUTH_CLOCK_SKEW',
    REPLAY              = 'E_AUTH_REPLAY',
    CREDENTIAL_REVOKED  = 'E_AUTH_CREDENTIAL_REVOKED',
    CREDENTIAL_UNKNOWN  = 'E_AUTH_CREDENTIAL_UNKNOWN',
    -- protocol
    PROTOCOL_UNSUPPORTED = 'E_PROTOCOL_UNSUPPORTED',
    VALIDATION           = 'E_VALIDATION',
    PAYLOAD_TOO_LARGE    = 'E_PAYLOAD_TOO_LARGE',
    UNKNOWN_COMMAND      = 'E_UNKNOWN_COMMAND',
    -- platform
    RATE_LIMITED         = 'E_RATE_LIMITED',
    INTERNAL             = 'E_INTERNAL',
    -- local
    MISCONFIGURED        = 'E_MISCONFIGURED',
    QUEUE_FULL           = 'E_QUEUE_FULL',
    COMMAND_FAILED       = 'E_COMMAND_FAILED',
}

--- Errors that must not cause the payload to be requeued.
Const.FATAL_ERRORS = {
    [Const.ERROR.VALIDATION]           = true,
    [Const.ERROR.PAYLOAD_TOO_LARGE]    = true,
    [Const.ERROR.PROTOCOL_UNSUPPORTED] = true,
    [Const.ERROR.CREDENTIAL_REVOKED]   = true,
    [Const.ERROR.CREDENTIAL_UNKNOWN]   = true,
    [Const.ERROR.UNKNOWN_COMMAND]      = true,
}

-- ---------------------------------------------------------------------------
-- Commands (allowlist)
-- ---------------------------------------------------------------------------
-- The platform can never ask for anything outside this set. There is
-- deliberately no command that evaluates code, reads files, or touches
-- secrets. Adding a command here is a security decision, not a feature.

Const.COMMAND = {
    REQUEST_STATUS       = 'request_status',
    REQUEST_HEALTH_CHECK = 'request_health_check',
    REFRESH_CONFIGURATION = 'refresh_configuration',
    RELOAD_SAFE_CONFIGURATION = 'reload_safe_configuration',
    PING                 = 'ping',
    FLUSH_QUEUE          = 'flush_queue',
    ROTATE_CREDENTIAL    = 'rotate_credential',
    -- Observation serveur-autoritative (Multi-vue) : caméra d'administration
    -- DANS le monde du jeu, jamais une capture de l'écran du joueur. Relayée au
    -- cœur (zshield-ac) qui met en place la caméra.
    SPECTATE_REQUEST     = 'spectate_request',
    SPECTATE_STOP        = 'spectate_stop',
}

Const.COMMAND_STATUS = {
    COMPLETED = 'COMPLETED',
    FAILED    = 'FAILED',
    REJECTED  = 'REJECTED',
    DUPLICATE = 'DUPLICATE',
}

-- ---------------------------------------------------------------------------
-- Queue
-- ---------------------------------------------------------------------------

Const.QUEUE_KIND = {
    ALERT     = 'alert',
    TELEMETRY = 'telemetry',
}

Const.STORAGE = {
    QUEUE = 'data/queue.json',
    STATE = 'data/state.json',
}

-- ---------------------------------------------------------------------------
-- Limits that are not user-configurable
-- ---------------------------------------------------------------------------

Const.LIMIT = {
    MAX_BACKOFF_SECONDS      = 300,
    MIN_BACKOFF_SECONDS      = 2,
    CIRCUIT_FAILURE_THRESHOLD = 6,
    CIRCUIT_OPEN_SECONDS     = 60,
    COMMAND_HISTORY_SIZE     = 256,
    MAX_COMMANDS_PER_POLL    = 25,
    MAX_SUMMARY_LENGTH       = 512,
    MAX_METADATA_KEYS        = 32,
    MAX_METADATA_STRING      = 1024,
}

ZShield.Const = Const

return Const
