--[[
    FILE:         tests/run_discord.lua
    PURPOSE:      Tests de l'intégration Discord (§39, §120, §117, §55). Prouve que Discord
                  est strictement sortant et en fin de chaîne, que sa panne n'affecte pas la
                  sécurité (§38), que le webhook n'est jamais journalisé (§117), et que la
                  file résiste (retry, éviction par priorité).
    USAGE:        lua5.4 tests/run_discord.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/persistence/circuit.lua')
dofile('server/incident.lua')
dofile('server/integrations/discord.lua')

local C = ZShield.Const
local Discord = ZShield.Discord

ZShield.Log.console = false
H.reset()

local function resetDiscord()
    Discord.queue = {}
    Discord.stats = { queued = 0, sent = 0, dropped = 0, failures = 0 }
    Discord.enabled = false
    Discord.webhook = nil
end

-- ===========================================================================
T.section('discord : désactivé par défaut, sortant uniquement §39')

resetDiscord()
-- Sans configuration, aucune notification n'est mise en file.
T.falsy(Discord.notify({ title = 'x', severity = 'HIGH' }), 'désactivé -> notify refusé')
T.equal(Discord.size(), 0, 'file vide quand désactivé')

-- Discord n'expose AUCUNE fonction qui influencerait une décision (§39). Vérifions que
-- l'API est purement sortante : notify, pump, configure, attach — jamais un "decide".
T.falsy(Discord.decide, 'aucune fonction de décision (Discord ne décide rien) §39')
T.falsy(Discord.authorize, 'aucune fonction d autorisation §39')

-- ===========================================================================
T.section('discord : webhook secret, jamais journalisé §117')

resetDiscord()
Discord.configure({ enabled = true, webhook = 'https://discord.com/api/webhooks/SECRET123' })
T.truthy(Discord.enabled, 'activé avec webhook')

-- Le webhook n'apparaît JAMAIS dans les stats.
local stats = Discord.getStats()
local statsStr = ZShield.Log.encode(stats)
T.falsy(statsStr:find('SECRET123'), 'webhook absent des stats §117')

-- Mettre une notif, vérifier qu'aucun log ne contient le webhook.
Discord.notify({ title = 'test', severity = 'HIGH' })
local logs = ZShield.Log:recent(50)
local leaked = false
for _, e in ipairs(logs) do
    if ZShield.Log.encode(e):find('SECRET123') then leaked = true end
end
T.falsy(leaked, 'webhook jamais présent dans les logs §117')

-- ===========================================================================
T.section('discord : mise en file et priorité §120')

resetDiscord()
Discord.configure({ enabled = true, webhook = 'https://x', max_queue = 3 })

T.truthy(Discord.notify({ title = 'a', severity = 'LOW' }), 'notif LOW en file')
T.truthy(Discord.notify({ title = 'b', severity = 'MEDIUM' }), 'notif MEDIUM en file')
T.truthy(Discord.notify({ title = 'c', severity = 'LOW' }), 'notif LOW en file')
T.equal(Discord.size(), 3, 'file pleine (3)')

-- Une CRITICAL sur file pleine évince une LOW (§120).
Discord.notify({ title = 'urgent', severity = 'CRITICAL' })
T.equal(Discord.size(), 3, 'file toujours à 3 (éviction)')
local hasCritical = false
for _, item in ipairs(Discord.queue) do
    if item.payload.severity == 'CRITICAL' then hasCritical = true end
end
T.truthy(hasCritical, 'CRITICAL conservée, LOW évincée §120')
T.truthy(Discord.stats.dropped >= 1, 'éviction comptée (jamais silencieuse)')

-- Une LOW sur file pleine de plus prioritaires : refusée.
resetDiscord()
Discord.configure({ enabled = true, webhook = 'https://x', max_queue = 2 })
Discord.notify({ title = 'a', severity = 'CRITICAL' })
Discord.notify({ title = 'b', severity = 'CRITICAL' })
T.falsy(Discord.notify({ title = 'c', severity = 'LOW' }), 'LOW refusée si rien de moins prioritaire §120')

-- ===========================================================================
T.section('discord : panne n affecte pas la sécurité §38 §39')

resetDiscord()
Discord.configure({ enabled = true, webhook = 'https://x', max_queue = 100 })

-- Simuler Discord down : PerformHttpRequest renvoie une erreur.
H.httpResponder = function(url, cb) cb(500, '', {}) end

-- Empiler plusieurs notifications.
for i = 1, 10 do Discord.notify({ title = 'n' .. i, severity = 'HIGH' }) end
T.equal(Discord.size(), 10, '10 notifs en file')

-- Pomper : Discord échoue, mais rien ne plante et les notifs restent (retry §120).
local safe = pcall(Discord.pump)
T.truthy(safe, 'pump ne plante pas quand Discord est down §38')
-- La notification reste en file pour retry (elle n'est pas perdue au premier échec).
T.truthy(Discord.size() >= 9, 'notif conservée pour retry après échec §120')

-- POINT CRUCIAL : notify continue de fonctionner pendant la panne (§38).
T.truthy(Discord.notify({ title = 'during_outage', severity = 'HIGH' }), 'la file accepte pendant la panne §38')

-- ===========================================================================
T.section('discord : envoi réussi vide la file §120')

resetDiscord()
Discord.configure({ enabled = true, webhook = 'https://x', max_queue = 100 })
-- Discord répond OK.
H.httpResponder = function(url, cb) cb(204, '', {}) end

Discord.notify({ title = 'ok1', severity = 'HIGH' })
Discord.notify({ title = 'ok2', severity = 'HIGH' })
local before = Discord.size()
Discord.pump()
T.truthy(Discord.size() < before, 'envoi réussi retire de la file')
T.truthy(Discord.stats.sent >= 1, 'compteur d envoi incrémenté')

-- ===========================================================================
T.section('discord : notifie APRÈS décision d incident §39')

resetDiscord()
Discord.configure({ enabled = true, webhook = 'https://x' })
Discord.attach()
H.httpResponder = function(url, cb) cb(204, '', {}) end

-- Ouvrir un incident et le DÉCIDER : Discord ne notifie qu'après la décision (§39).
ZShield.Incident.incidents = {}; ZShield.Incident.order = {}; ZShield.Incident.dedup = {}
ZShield.Incident.byPlayer = {}; ZShield.Incident.stats = { opened = 0, deduplicated = 0, decided = 0 }

local inc = ZShield.Incident.open({ source = 5, detector = 'movement.teleport',
    category = 'movement', severity = 'HIGH', confidence = 0.9, risk_after = 72 })
-- Avant décision : rien en file (Discord est en fin de chaîne).
local queueBefore = Discord.size()

ZShield.Incident.setDecision(inc.id, { action = 'KICK', reason = 'confirmed', policy = 'ladder' })
-- Après décision : une notification a été mise en file.
T.truthy(Discord.size() > queueBefore, 'Discord notifie APRÈS la décision d incident §39')

-- La notification LOW n'aurait pas déclenché de bruit.
resetDiscord(); Discord.configure({ enabled = true, webhook = 'https://x' }); Discord.attach()
local incLow = ZShield.Incident.open({ source = 6, detector = 'd', category = 'event',
    severity = 'LOW', confidence = 0.5, risk_after = 20 })
ZShield.Incident.setDecision(incLow.id, { action = 'LOG', reason = 'minor' })
T.equal(Discord.size(), 0, 'incident LOW ne notifie pas (pas de bruit) §39')

H.httpResponder = nil
os.exit(T.summary() and 0 or 1)
