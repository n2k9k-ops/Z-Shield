--[[
    FILE:         tests/harness.lua
    PURPOSE:      Fixture de test. Fournit des stubs des natives FXServer utilisées par le
                  core, un ordonnanceur coopératif à temps virtuel, et des aides
                  d'assertion. Permet d'exécuter le vrai code du core hors FXServer.
    DEPENDENCIES: aucune (chargée avant le core dans les tests)

    Le temps est VIRTUEL et contrôlé : GetGameTimer() renvoie une horloge que les tests
    avancent explicitement via H.advance(ms). Cela rend déterministes les tests de
    cooldown, de decay et de fenêtres temporelles, sans sleep réel.
]]

local H = { t = 0, players = {}, convars = {}, resourceName = 'zshield-ac' }

-- Horloge virtuelle. Monotone, avancée par les tests.
function GetGameTimer() return H.t end
function H.advance(ms) H.t = H.t + ms end
function H.reset() H.t = 0; H.players = {}; H.convars = {} end

-- Convars serveur.
function GetConvar(name, default)
    local v = H.convars[name]
    if v == nil then return default end
    return v
end
function SetConvar(name, value) H.convars[name] = value end

-- Ressource courante.
function GetCurrentResourceName() return H.resourceName end

-- Joueurs. H.players[src] = { name=, identifiers={} }
function GetPlayers()
    local out = {}
    for src in pairs(H.players) do out[#out + 1] = tostring(src) end
    table.sort(out)
    return out
end
function GetPlayerName(src)
    local p = H.players[tonumber(src)]
    return p and p.name or nil
end
function GetPlayerIdentifiers(src)
    local p = H.players[tonumber(src)]
    return p and p.identifiers or {}
end
function DropPlayer(src, reason)
    H.players[tonumber(src)] = nil
    H.lastDrop = { src = tonumber(src), reason = reason }
end
function H.addPlayer(src, name, identifiers)
    H.players[src] = { name = name or ('Player' .. src), identifiers = identifiers or {} }
end

-- Threads coopératifs. On n'exécute pas de vraie boucle ; les tests appellent
-- directement les fonctions. CreateThread stocke la fonction pour exécution manuelle.
H.threads = {}
function CreateThread(fn) H.threads[#H.threads + 1] = fn end
function Wait(_) end -- no-op en test ; les boucles doivent être bornées par les tests
function H.runThreads()
    -- Exécute chaque thread une fois, sous pcall (comme le vrai runtime isole).
    for _, fn in ipairs(H.threads) do pcall(fn) end
    H.threads = {}
end

-- Events serveur. On enregistre les handlers pour pouvoir les déclencher.
H.handlers = {}
function RegisterNetEvent(name) H.handlers[name] = H.handlers[name] or {} end
function AddEventHandler(name, fn)
    H.handlers[name] = H.handlers[name] or {}
    H.handlers[name][#H.handlers[name] + 1] = fn
    return { name = name }
end
function RemoveEventHandler() end
function TriggerEvent(name, ...)
    local hs = H.handlers[name]
    if not hs then return end
    for _, fn in ipairs(hs) do pcall(fn, ...) end
end
-- `source` global : FXServer l'expose dans les handlers d'event réseau.
source = nil
function H.withSource(src, fn) source = src; fn(); source = nil end

-- Annulation d'event (game events natifs annulables : explosion/damage/entityCreating).
H.canceled = false
function CancelEvent() H.canceled = true end
function WasEventCanceled() return H.canceled end
function H.resetCancel() H.canceled = false end

-- State bags : capture les handlers pour déclenchement manuel.
H.sbHandlers = {}
function AddStateBagChangeHandler(keyFilter, bagFilter, fn)
    H.sbHandlers[#H.sbHandlers + 1] = { key = keyFilter, bag = bagFilter, fn = fn }
    return #H.sbHandlers
end
function H.fireStateBag(bagName, key, value, replicated)
    for _, h in ipairs(H.sbHandlers) do
        if (h.key == nil or h.key == key) then pcall(h.fn, bagName, key, value, nil, replicated) end
    end
end

-- Natives OneSync (orchestrateur). On capture les appels pour vérifier le plan appliqué.
H.native = {}
function SetRoutingBucketEntityLockdownMode(bucket, mode)
    H.native[#H.native + 1] = { 'SetRoutingBucketEntityLockdownMode', bucket, mode }
end
function SetRoutingBucketPopulationEnabled(bucket, enabled)
    H.native[#H.native + 1] = { 'SetRoutingBucketPopulationEnabled', bucket, enabled }
end
function SetEntityOrphanMode(mode)
    H.native[#H.native + 1] = { 'SetEntityOrphanMode', mode }
end
function NetworkGetEntityOwner(_) return H.entityOwner end
function GetEntityModel(_) return H.entityModel end

-- Exports. Table simulée.
H.exports = {}
exports = setmetatable({}, {
    __index = function(_, resource)
        return H.exports[resource] or {}
    end,
    __call = function(_, name, fn)
        -- exports('name', fn) : enregistre un export de la ressource courante
        H.exports[H.resourceName] = H.exports[H.resourceName] or {}
        H.exports[H.resourceName][name] = fn
    end,
})
function GetInvokingResource() return H.invoking end
function H.setInvoking(r) H.invoking = r end

-- HTTP sortant (Discord/agent). On capture les appels au lieu de les envoyer.
H.httpCalls = {}
function PerformHttpRequest(url, cb, method, data, headers)
    H.httpCalls[#H.httpCalls + 1] = { url = url, method = method, data = data, headers = headers }
    -- Réponse simulée par défaut : 204. Les tests peuvent surcharger H.httpResponder.
    if H.httpResponder then
        H.httpResponder(url, cb, method, data, headers)
    elseif cb then
        cb(204, '', {})
    end
end

-- FS de ressource virtuel, pour la persistance disque éventuelle.
H.fs = {}
function LoadResourceFile(_, path) return H.fs[path] end
function SaveResourceFile(_, path, content) H.fs[path] = content; return true end

-- ---------------------------------------------------------------------------
-- Assertions
-- ---------------------------------------------------------------------------
local T = { passed = 0, failed = 0, suite = '' }

function T.section(name) print('\n== ' .. name); T.suite = name end

local function record(ok, msg)
    if ok then T.passed = T.passed + 1; print('  ok   ' .. msg)
    else T.failed = T.failed + 1; print('  FAIL ' .. msg) end
end

function T.ok(cond, msg) record(cond and true or false, msg) end
function T.equal(a, b, msg)
    record(a == b, msg .. (a ~= b and ('  (got ' .. tostring(a) .. ', want ' .. tostring(b) .. ')') or ''))
end
function T.notEqual(a, b, msg) record(a ~= b, msg) end
function T.truthy(v, msg) record(v and true or false, msg) end
function T.falsy(v, msg) record(not v, msg) end

function T.summary()
    print(string.format('\n%d passed, %d failed', T.passed, T.failed))
    return T.failed == 0
end

H.T = T
return H
