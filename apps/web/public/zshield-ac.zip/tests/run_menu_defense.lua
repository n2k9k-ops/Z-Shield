--[[
    FILE:         tests/run_menu_defense.lua
    PURPOSE:      Défenses anti-menu : honeypot (appât -> incident critique), bans
                  multi-jetons (>=2 correspondances = lien dur ; 1 = revue ; 0 = rien),
                  garde d'origine serveur (GetInvokingResource nil + client = refus).
    USAGE:        lua5.4 tests/run_menu_defense.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/honeypot.lua')
dofile('server/serveronly.lua')
ZShield.Log.console = false

-- ===========================================================================
T.section('Honeypot : un appât déclenché = tricheur confirmé (critique, instant ban)')
local sig = ZShield.Honeypot.onTrigger(12, 'admin:giveMoney')
T.equal(sig.severity, ZShield.Const.SEVERITY.CRITICAL, 'sévérité CRITICAL')
T.truthy(sig.instant_ban, 'ban immédiat')
T.equal(sig.category, ZShield.Const.CATEGORY.RESOURCE, 'catégorie RESOURCE')
T.truthy(#ZShield.Honeypot.defaults() >= 6, 'liste d\'appâts par défaut non vide')

-- ===========================================================================
T.section('Garde origine serveur (GetInvokingResource)')
T.truthy(ZShield.serverOriginOk('esx_banking', 101), 'ressource serveur -> OK')
T.falsy(ZShield.serverOriginOk(nil, 101), 'origine réseau + joueur -> REFUS')
T.falsy(ZShield.serverOriginOk('', 55), 'ressource vide + joueur -> REFUS')
T.truthy(ZShield.serverOriginOk(nil, nil), 'contexte serveur pur (pas de source) -> OK')
T.truthy(ZShield.serverOriginOk(nil, 0), 'source 0 (serveur) -> OK')

-- ===========================================================================
-- Bans multi-jetons : matchTokens est pur. On charge clientguard pour l'exposer.
dofile('server/clientguard.lua')
local CG = ZShield.ClientGuard
T.section('Bans multi-jetons : comptage des correspondances')
local blocklist = { 'tokA', 'tokB', 'tokC' }
T.equal(CG.matchTokens({ 'tokA', 'tokB', 'x' }, blocklist), 2, '2 correspondances comptées')
T.equal(CG.matchTokens({ 'tokA', 'tokA', 'tokA' }, blocklist), 1, 'doublons comptés une fois')
T.equal(CG.matchTokens({ 'x', 'y' }, blocklist), 0, 'aucune correspondance')
T.equal(CG.matchTokens({ 'tokA' }, { ['tokA'] = true, ['tokB'] = true }), 1, 'liste sous forme d\'ensemble')
-- Seuil de lien dur : >=2 correspondances (défaut) => ban ; 1 => revue.
local min = 2
T.truthy(CG.matchTokens({ 'tokA', 'tokB' }, blocklist) >= min, '2 correspondances -> lien dur (ban)')
T.falsy(CG.matchTokens({ 'tokA' }, blocklist) >= min, '1 correspondance -> pas de lien dur (revue)')

os.exit(T.summary() and 0 or 1)
