--[[
    FILE:         tests/run_firewall.lua
    PURPOSE:      Tests de la couche firewall (§55) : rate limiting (4 stratégies),
                  machine à états gardée, téléports de confiance, et le pipeline complet du
                  pare-feu avec ses 7 étapes et verdicts.
    USAGE:        lua5.4 tests/run_firewall.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/firewall/ratelimit.lua'); dofile('server/context.lua'); dofile('server/firewall/firewall.lua')

local C = ZShield.Const
local RL = ZShield.RateLimit
local Context = ZShield.Context
local Firewall = ZShield.Firewall
local Config = ZShield.Config

ZShield.Log.console = false
local _rawLoad = Config.load
Config.load = function(raw) local ok, r = _rawLoad(raw); ZShield.Log.console = false; return ok, r end
Config.load({ mode = 'ENFORCE' })
H.reset()

-- ===========================================================================
T.section('rate limit : token bucket §07')

local tb = RL.tokenBucket({ capacity = 3, refillPerSec = 1 })
local allowed = 0
for _ = 1, 3 do if tb:check('p1') then allowed = allowed + 1 end end
T.equal(allowed, 3, 'burst jusqu à capacity autorisé')
T.falsy((tb:check('p1')), '4e requête refusée (bucket vide)')

-- Recharge après 1 seconde virtuelle.
H.advance(1000)
T.truthy((tb:check('p1')), 'un jeton rechargé après 1s')

-- Clés indépendantes.
T.truthy((tb:check('p2')), 'clé distincte a son propre bucket')

-- ===========================================================================
T.section('rate limit : sliding window §07')

H.reset()
local sw = RL.slidingWindow({ limit = 2, windowMs = 1000 })
T.truthy((sw:check('k')), '1re dans la fenêtre')
T.truthy((sw:check('k')), '2e dans la fenêtre')
T.falsy((sw:check('k')), '3e refusée (limite atteinte)')
H.advance(1001)
T.truthy((sw:check('k')), 'fenêtre glissée : de nouveau autorisé')

-- ===========================================================================
T.section('rate limit : cooldown §07')

H.reset()
local cd = RL.cooldown({ cooldownMs = 500 })
T.truthy((cd:check('a')), '1re action autorisée')
T.falsy((cd:check('a')), 'action immédiate refusée')
H.advance(500)
T.truthy((cd:check('a')), 'après cooldown, autorisée')

-- ===========================================================================
T.section('rate limit : adaptive §07 §35')

H.reset()
local base = RL.tokenBucket({ capacity = 4, refillPerSec = 0 }) -- pas de recharge
local ad = RL.adaptive(base, { suspicionFactor = 0.5 })
-- Joueur normal : 4 actions possibles.
local normal = 0
for _ = 1, 4 do if ad:check('normal') then normal = normal + 1 end end
T.equal(normal, 4, 'joueur normal : quota plein')

-- Joueur suspect : quota resserré (draine 2x plus vite).
ad:markSuspect('suspect')
local suspect = 0
for _ = 1, 4 do if ad:check('suspect') then suspect = suspect + 1 end end
T.truthy(suspect < 4, 'joueur suspect : quota resserré (' .. suspect .. ' < 4)')
T.truthy(ad:isSuspect('suspect'), 'marqué suspect')

-- ===========================================================================
T.section('contexte : machine à états gardée §08')

H.reset()
Context.init(1)
T.equal(Context.get(1).state, 'CONNECTING', 'état initial CONNECTING')

T.truthy((Context.transition(1, 'CONNECTED')), 'CONNECTING -> CONNECTED')
T.truthy((Context.transition(1, 'SPAWNING')), 'CONNECTED -> SPAWNING')
T.truthy((Context.transition(1, 'ACTIVE')), 'SPAWNING -> ACTIVE')
T.truthy((Context.transition(1, 'DEAD')), 'ACTIVE -> DEAD')

-- Transition interdite : DEAD -> ACTIVE sans RESPAWN.
local ok, reason = Context.transition(1, 'ACTIVE')
T.falsy(ok, 'DEAD -> ACTIVE refusé (doit passer par RESPAWN) §08')
T.truthy(reason and reason:find('not allowed'), 'raison explicite')

-- La transition interdite a produit un log SECURITY.
local sawSec = false
for _, e in ipairs(ZShield.Log:recent(50)) do
    if e.module == 'context' and e.level == 'SECURITY' then sawSec = true end
end
T.truthy(sawSec, 'transition invalide journalisée en SECURITY')

-- Chemin légitime de renaissance.
T.truthy((Context.transition(1, 'RESPAWN')), 'DEAD -> RESPAWN')
T.truthy((Context.transition(1, 'ACTIVE')), 'RESPAWN -> ACTIVE')

-- ===========================================================================
T.section('contexte : téléports de confiance §15')

H.reset()
Context.init(2)
Context.forceState(2, 'ACTIVE')

-- Pas de téléport enregistré : consume renvoie nil.
T.falsy(Context.consumeTeleport(2), 'aucun téléport en attente')

-- Le serveur enregistre un téléport (admin, mission).
Context.registerTeleport(2, { to = { x = 100, y = 200, z = 30 }, reason = 'admin_tp' })
local tp = Context.consumeTeleport(2)
T.truthy(tp, 'téléport de confiance consommé')
T.equal(tp.reason, 'admin_tp', 'raison conservée')
-- Consommé une seule fois.
T.falsy(Context.consumeTeleport(2), 'téléport consommé une seule fois')

-- Téléport expiré (au-delà du TTL).
Context.registerTeleport(2, { to = { x = 0, y = 0, z = 0 }, reason = 'old' })
H.advance(6000) -- > TELEPORT_TTL_MS (5000)
T.falsy(Context.consumeTeleport(2), 'téléport expiré ignoré §15')

-- ===========================================================================
T.section('firewall : pipeline zéro-confiance §04 §05')

H.reset()
Firewall.events = {} -- repartir propre
Context.init(10)
Context.forceState(10, 'ACTIVE')

-- Le contre-exemple de §04, fait correctement : le serveur connaît la récompense,
-- ne fait PAS confiance au montant client.
local granted = {}
Firewall.register({
    name = 'mission:reward',
    schema = { type = 'table', fields = { mission_id = { type = 'string', required = true } } },
    states = { 'ACTIVE', 'MISSION' },
    rateLimit = { strategy = 'cooldown', cooldownMs = 1000 },
    execute = function(ctx)
        -- Le serveur DÉTERMINE la récompense ; le client n'a envoyé qu'un mission_id.
        granted[ctx.source] = (granted[ctx.source] or 0) + 500
    end,
})

-- Event valide.
local v = Firewall.dispatch('mission:reward', 10, { mission_id = 'heist_01' })
T.equal(v, C.VERDICT.ALLOW, 'event valide autorisé')
T.equal(granted[10], 500, 'exécution serveur-authoritative (montant décidé serveur)')

-- Rejet : argument injecté (le client tente de passer un montant).
v = Firewall.dispatch('mission:reward', 10, { mission_id = 'heist_01', amount = 999999 })
T.equal(v, C.VERDICT.REJECT, 'champ injecté rejeté (schéma strict) §06')
T.equal(granted[10], 500, 'aucune récompense supplémentaire accordée')

-- Rate limit : deuxième appel immédiat (cooldown 1s).
v = Firewall.dispatch('mission:reward', 10, { mission_id = 'heist_02' })
T.equal(v, C.VERDICT.RATE_LIMIT, 'appel trop rapproché rate-limité §07')

-- Mauvais état : passer en DEAD, l'event n'est plus autorisé.
H.advance(2000) -- lever le cooldown
Context.forceState(10, 'DEAD')
v = Firewall.dispatch('mission:reward', 10, { mission_id = 'heist_03' })
T.equal(v, C.VERDICT.BAD_STATE, 'event interdit dans l état DEAD §08')

-- Event inconnu : politique monitor (défaut) journalise mais ne bloque pas le gameplay.
Config.load({ mode = 'ENFORCE', events = { unknown_policy = 'monitor' } }); ZShield.Log.console = false
local _, payload = Firewall.dispatch('totally:unknown', 10, {})
T.falsy(payload.blocked, 'event inconnu en monitor : journalisé, non bloqué §05')

-- Politique reject : bloque.
Config.load({ mode = 'ENFORCE', events = { unknown_policy = 'reject' } }); ZShield.Log.console = false
_, payload = Firewall.dispatch('totally:unknown', 10, {})
T.truthy(payload.blocked, 'event inconnu en reject : bloqué')

-- ===========================================================================
T.section('firewall : autorisation et règle métier §04')

H.reset()
Firewall.events = {}
Context.init(20); Context.forceState(20, 'ACTIVE')
Context.set(20, 'is_admin', false)

Firewall.register({
    name = 'admin:action',
    authorize = function(ctx)
        -- Permission calculée SERVEUR (§04, §68), jamais crue du client.
        if ZShield.Context.value(ctx.source, 'is_admin') then return true end
        return false, 'admin only'
    end,
    execute = function() end,
})

local vv = Firewall.dispatch('admin:action', 20, {})
T.equal(vv, C.VERDICT.UNAUTHORIZED, 'non-admin refusé §04')

Context.set(20, 'is_admin', true)
vv = Firewall.dispatch('admin:action', 20, {})
T.equal(vv, C.VERDICT.ALLOW, 'admin autorisé')

-- Règle métier : validate rejette une valeur hors contexte.
Firewall.register({
    name = 'shop:buy',
    schema = { type = 'table', fields = { item = { type = 'string', required = true }, qty = { type = 'integer', required = true, min = 1 } } },
    validate = function(ctx)
        -- Le serveur borne la quantité selon SA connaissance, pas selon le client.
        if ctx.args.qty > 10 then return false, 'quantity exceeds limit' end
        return true
    end,
    execute = function() end,
})
vv = Firewall.dispatch('shop:buy', 20, { item = 'medkit', qty = 5 })
T.equal(vv, C.VERDICT.ALLOW, 'achat valide')
vv = Firewall.dispatch('shop:buy', 20, { item = 'medkit', qty = 50 })
T.equal(vv, C.VERDICT.REJECT, 'quantité hors borne métier rejetée §04')
vv = Firewall.dispatch('shop:buy', 20, { item = 'medkit', qty = 0 })
T.equal(vv, C.VERDICT.REJECT, 'qty=0 rejeté par schéma (min 1)')

-- ===========================================================================
T.section('firewall : exécuteur fautif isolé §104')

H.reset()
Firewall.events = {}
Context.init(30); Context.forceState(30, 'ACTIVE')
Firewall.register({
    name = 'buggy:event',
    execute = function() error('boom in business code') end,
})
-- L'exception de l'exécuteur ne doit pas propager : verdict REJECT, firewall vivant.
local safe = pcall(Firewall.dispatch, 'buggy:event', 30, {})
T.truthy(safe, 'dispatch ne propage pas l exception de l exécuteur §104')
local v2 = Firewall.dispatch('buggy:event', 30, {})
T.equal(v2, C.VERDICT.REJECT, 'exécuteur fautif -> REJECT, firewall reste fonctionnel')

-- Le firewall répond toujours pour un autre event.
Firewall.register({ name = 'ok:event', execute = function() end })
T.equal(Firewall.dispatch('ok:event', 30, {}), C.VERDICT.ALLOW, 'autres events non affectés')

-- ===========================================================================
T.section('firewall : verdict émis sur le bus §29')

H.reset()
Firewall.events = {}
Context.init(40); Context.forceState(40, 'ACTIVE')
local busVerdicts = {}
ZShield.Bus:on('firewall.verdict', function(p) busVerdicts[#busVerdicts + 1] = p.verdict end)
Firewall.register({ name = 'traced:event', execute = function() end })
Firewall.dispatch('traced:event', 40, {})
T.truthy(#busVerdicts >= 1, 'verdict émis sur le bus pour traçabilité §29')
T.equal(busVerdicts[#busVerdicts], C.VERDICT.ALLOW, 'verdict correct sur le bus')

os.exit(T.summary() and 0 or 1)
