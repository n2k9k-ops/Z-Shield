--[[
    FILE:         tests/run_license_online.lua
    PURPOSE:      Kill-switch de licence EN LIGNE (anti-leak) : verdict distant signé,
                  révocation immédiate et collante, période de grâce quand le SaaS est
                  injoignable, anti-rejeu. Prouve qu'une clé leakée est révocable sans
                  couper un serveur légitime en cas de panne réseau.
    USAGE:        lua5.4 tests/run_license_online.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/sha256.lua'); dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/license.lua')
dofile('server/license_online.lua')

local LO = ZShield.LicenseOnline
local License = ZShield.License
ZShield.Log.console = false
License.setSecret('TEST-LICENSE-SECRET')
License.setIdentity('server-fingerprint-AAA')
ZShield.Config.load({ license = { online_check = true, online_grace_hours = 72 } })

local HOUR = 3600
local t0 = 1700000000

local function verdict(status, issued_at, server_id)
    return LO.signVerdict({ server_id = server_id or 'server-fingerprint-AAA',
        status = status, issued_at = issued_at })
end

-- ===========================================================================
T.section('verdict signé : le SaaS confirme une clé active')

LO.reset()
local e = LO.applyRemote(verdict('active', t0), t0)
T.equal(e.state, LO.STATE.ACTIVE, 'verdict active signé -> ACTIVE')
T.truthy(e.active, 'protection active')

-- ===========================================================================
T.section('révocation immédiate et COLLANTE (kill-switch)')

LO.reset()
LO.applyRemote(verdict('active', t0), t0)
local rev = LO.applyRemote(verdict('revoked', t0 + HOUR), t0 + HOUR)
T.equal(rev.state, LO.STATE.REVOKED, 'verdict revoked -> REVOKED')
T.falsy(rev.active, 'protection considérée non valable (clé leakée coupée)')

-- Un « active » PLUS RÉCENT ne peut pas ré-activer une clé révoquée (collant).
local reactivate = LO.applyRemote(verdict('active', t0 + 2 * HOUR), t0 + 2 * HOUR)
T.equal(reactivate.state, LO.STATE.REVOKED, 'active posterieur -> reste REVOKED (collant)')

-- Même le SaaS injoignable après révocation garde l'état révoqué.
T.falsy(LO.onUnreachable(t0 + 10 * HOUR).active, 'SaaS injoignable apres revocation -> reste coupe')

-- ===========================================================================
T.section('anti-rejeu : un verdict plus ancien est ignoré')

LO.reset()
LO.applyRemote(verdict('revoked', t0 + 5 * HOUR), t0 + 5 * HOUR)
-- Rejeu d'un ancien « active » capturé (issued_at plus petit) -> ignoré.
local replayed = LO.applyRemote(verdict('active', t0 + HOUR), t0 + 6 * HOUR)
T.equal(replayed.state, LO.STATE.REVOKED, 'ancien verdict rejoue -> ignore, reste REVOKED')

-- ===========================================================================
T.section('période de grâce : SaaS injoignable ne coupe pas un serveur légitime')

LO.reset()
-- Le SaaS a confirmé à t0, puis devient injoignable.
LO.applyRemote(verdict('active', t0), t0)
T.truthy(LO.onUnreachable(t0 + 10 * HOUR).active, 'a 10 h sans SaaS -> encore actif (grace)')
T.truthy(LO.onUnreachable(t0 + 71 * HOUR).active, 'a 71 h -> encore dans la grace (72 h)')
local locked = LO.onUnreachable(t0 + 80 * HOUR)
T.equal(locked.state, LO.STATE.LOCKED, 'au-dela de 72 h sans confirmation -> LOCKED')
T.falsy(locked.active, 'grace depassee -> protection en ligne coupee')

-- Jamais confirmé du tout : la grâce court à partir de la première évaluation.
LO.reset()
local first = LO.effective(t0)
T.truthy(first.active, 'jamais confirme mais dans la grace initiale -> actif')
T.falsy(LO.effective(t0 + 100 * HOUR).active, 'jamais confirme + 100 h -> LOCKED')

-- ===========================================================================
T.section('signature : un verdict forgé (mauvais secret) est rejeté')

LO.reset()
LO.applyRemote(verdict('active', t0), t0)
-- Forger un « revoked » avec un autre secret ne doit pas passer.
License.setSecret('ATTACKER-SECRET')
local forged = LO.signVerdict({ server_id = 'server-fingerprint-AAA', status = 'revoked', issued_at = t0 + HOUR })
License.setSecret('TEST-LICENSE-SECRET')
local afterForged = LO.applyRemote(forged, t0 + HOUR)
T.equal(afterForged.state, LO.STATE.ACTIVE, 'verdict forge (mauvais secret) -> ignore, reste ACTIVE')

-- ===========================================================================
T.section('liaison serveur : un verdict pour un autre serveur est ignoré')

LO.reset()
LO.applyRemote(verdict('active', t0), t0)
local other = LO.applyRemote(verdict('revoked', t0 + HOUR, 'server-fingerprint-ZZZ'), t0 + HOUR)
T.equal(other.state, LO.STATE.ACTIVE, 'revoked pour un AUTRE serveur -> ignore ici')

-- Un verdict 'any' (passe partout) s'applique bien.
local anyRev = LO.applyRemote(verdict('revoked', t0 + 2 * HOUR, 'any'), t0 + 2 * HOUR)
T.equal(anyRev.state, LO.STATE.REVOKED, "verdict 'any' revoked -> applique")

os.exit(T.summary() and 0 or 1)
