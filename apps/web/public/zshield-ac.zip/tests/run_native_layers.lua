--[[
    FILE:         tests/run_native_layers.lua
    PURPOSE:      Tests des couches natives event-driven ajoutées (§08, §10, §21) et des
                  garde-fous transverses (§15 evidence, §17 reputation, §29 performance).
    USAGE:        lua5.4 tests/run_native_layers.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua'); dofile('core/perf.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/firewall/ratelimit.lua'); dofile('server/context.lua')
dofile('server/detection/engine.lua'); dofile('server/detection/reputation.lua')
dofile('server/detection/evidence.lua'); dofile('server/detection/entity.lua')
dofile('server/firewall/gameevents.lua'); dofile('server/firewall/statebag.lua')
dofile('server/hardening/orchestrator.lua')

local C = ZShield.Const
local Config = ZShield.Config
ZShield.Log.console = false
local _rawLoad = Config.load
Config.load = function(raw) local ok, r = _rawLoad(raw); ZShield.Log.console = false; return ok, r end
Config.load({ mode = 'ENFORCE' })
H.reset()

-- ===========================================================================
T.section('game event firewall : dégâts d\'arme §08')

local v = ZShield.GameEvents.checkWeaponDamage(1, { weaponDamage = 50 })
T.falsy(v.block, 'dégât normal (50) non bloqué')

v = ZShield.GameEvents.checkWeaponDamage(1, { weaponDamage = 9999 })
T.truthy(v.block, 'dégât impossible (9999 > cap) bloqué')
T.equal(v.severity, C.SEVERITY.HIGH, 'gravité HIGH sur dégât modifié')
T.truthy(v.confidence >= 0.8, 'confiance élevée sur plafond dur franchi')

-- ===========================================================================
T.section('game event firewall : flood d\'explosions §08')

ZShield.GameEvents._resetLimiter()
local blockedAt
for i = 1, 15 do
    local r = ZShield.GameEvents.checkExplosion({ explosionType = 2, source = 7 })
    if r.block and not blockedAt then blockedAt = i end
end
T.truthy(blockedAt ~= nil, 'un flood d\'explosions finit par être bloqué')
T.truthy(blockedAt and blockedAt > 5, 'le burst légitime passe avant blocage (' .. tostring(blockedAt) .. ')')

-- Explosion isolée d'un autre joueur : pas bloquée.
ZShield.GameEvents._resetLimiter()
local iso = ZShield.GameEvents.checkExplosion({ explosionType = 2, source = 99 })
T.falsy(iso.block, 'explosion isolée non bloquée (pas de faux positif)')

-- Explosion à DÉGÂTS sans propriétaire réseau : falsification signalée (HIGH),
-- sans blocage automatique par défaut.
ZShield.GameEvents._resetLimiter()
local spoof = ZShield.GameEvents.checkExplosion({ explosionType = 2, source = 42, damageScale = 1.0, ownerNetId = 0 })
T.falsy(spoof.block, 'explosion falsifiée : pas de blocage auto par défaut')
T.equal(spoof.severity, C.SEVERITY.HIGH, 'explosion falsifiée signalée en gravité élevée')
-- Même explosion mais AVEC propriétaire réseau (joueur légitime) : pas signalée.
ZShield.GameEvents._resetLimiter()
local legit = ZShield.GameEvents.checkExplosion({ explosionType = 2, source = 42, damageScale = 1.0, ownerNetId = 55 })
T.falsy(legit.block, 'explosion légitime (avec propriétaire) non bloquée')
T.truthy(legit.severity ~= C.SEVERITY.HIGH, 'explosion légitime non signalée en gravité élevée')
-- Explosion sans dégâts et sans propriétaire (explosion de monde) : pas signalée.
ZShield.GameEvents._resetLimiter()
local world = ZShield.GameEvents.checkExplosion({ explosionType = 2, source = 42, damageScale = 0, ownerNetId = 0 })
T.truthy(world.severity ~= C.SEVERITY.HIGH, 'explosion de monde sans dégâts non signalée (pas de FP)')

-- ===========================================================================
T.section('game event firewall : création d\'entité §16')

ZShield.Entity.setQuota(4, 1)  -- quota très bas pour le test
local e1 = ZShield.GameEvents.checkEntityCreate(4, { model = 111 })
T.falsy(e1.block, '1re création sous quota autorisée')
local e2 = ZShield.GameEvents.checkEntityCreate(4, { model = 111 })
T.truthy(e2.block, '2e création au-delà du quota bloquée')

-- Entité serveur (source nil) jamais bloquée.
local es = ZShield.GameEvents.checkEntityCreate(nil, { model = 111 })
T.falsy(es.block, 'création serveur (source nil) non bloquée')

-- ===========================================================================
T.section('state bag security : clé serveur écrite par client §10')

ZShield.StateBag.loadDefaults()
local d = ZShield.StateBag.check({ key = 'godmode', value = true, source = 12 })
T.truthy(d.deny, 'écriture client d\'une clé serveur (godmode) refusée')
T.equal(d.category, C.CATEGORY.STATE, 'catégorie STATE')

-- Même clé, écriture serveur (source 0/absent) : autorisée.
local ok0 = ZShield.StateBag.check({ key = 'godmode', value = true, source = 0 })
T.falsy(ok0.deny, 'écriture serveur de la même clé autorisée')

-- Clé non protégée : ignorée (coût ~0, pas de faux positif).
local free = ZShield.StateBag.check({ key = 'positionCosmetic', value = 3, source = 12 })
T.falsy(free.deny, 'clé non protégée ignorée')

-- Mauvais type sur clé typée.
ZShield.StateBag.protect('money', { writer = 'server', allowed_type = 'number' })
local badType = ZShield.StateBag.check({ key = 'money', value = 'lots', source = 0 })
T.truthy(badType.deny, 'type invalide sur clé typée refusé')

-- ===========================================================================
T.section('state bag security : handler natif branché')

H.reset()
ZShield.StateBag._limiter = nil
ZShield.StateBag.attach()   -- branche AddStateBagChangeHandler (stub harness)
H.fireStateBag('player:15', 'isAdmin', true, true)
-- Le handler doit avoir tourné sans erreur ; on vérifie via les stats.
T.truthy(ZShield.StateBag.getStats().changes >= 1, 'changement de state bag traité par le handler')

-- ===========================================================================
T.section('native orchestrator : plan et application §21')

-- Défaut : onesync désactivé => plan vide, aucune native appelée.
Config.load({ mode = 'ENFORCE' })
H.native = {}
local applied = ZShield.Orchestrator.apply()
T.equal(applied, 0, 'aucune orchestration native par défaut (sûr)')
T.equal(#H.native, 0, 'aucune native appelée par défaut')

-- Activé en strict : lockdown appliqué.
Config.load({ mode = 'ENFORCE', onesync = { enabled = true, lockdown_mode = 'strict',
             disable_population = true, orphan_keep = true, bucket = 0 } })
H.native = {}
applied = ZShield.Orchestrator.apply()
T.equal(applied, 3, 'trois protections natives appliquées (lockdown + population + orphan)')
local sawLockdown = false
for _, call in ipairs(H.native) do
    if call[1] == 'SetRoutingBucketEntityLockdownMode' and call[3] == 'strict' then sawLockdown = true end
end
T.truthy(sawLockdown, 'entity lockdown strict appliqué sur le bucket')

-- ===========================================================================
T.section('niveaux de preuve E0–E5 §15')

local Ev = ZShield.Evidence
T.equal(Ev.classify({ confidence = 0.1 }), C.EVIDENCE.E0, 'télémétrie brute = E0')
T.equal(Ev.classify({ confidence = 0.4 }), C.EVIDENCE.E1, 'signal normalisé = E1')
T.equal(Ev.classify({ confidence = 0.7 }), C.EVIDENCE.E2, 'anomalie validée = E2')
T.equal(Ev.classify({ correlated_categories = 2, confidence = 0.6 }), C.EVIDENCE.E3, 'corrélée = E3')
T.equal(Ev.classify({ correlated_categories = 2, confidence = 0.85 }), C.EVIDENCE.E4, 'corrélée forte = E4')
T.equal(Ev.classify({ blocked = true }), C.EVIDENCE.E5, 'blocage serveur = E5')

-- Une sanction dure exige un niveau de preuve suffisant (§38).
T.falsy(Ev.meetsRequirement(C.EVIDENCE.E2, C.ACTION.PERM_BAN), 'E2 ne suffit pas pour un ban définitif')
T.truthy(Ev.meetsRequirement(C.EVIDENCE.E5, C.ACTION.PERM_BAN), 'E5 autorise le ban définitif')
T.truthy(Ev.meetsRequirement(C.EVIDENCE.E1, C.ACTION.WARN), 'E1 suffit pour un avertissement')

-- ===========================================================================
T.section('réputation des détecteurs §17')

local R = ZShield.Reputation
-- Un détecteur avec beaucoup de faux positifs passe en OBSERVATION.
for _ = 1, 10 do R.record('noisy.detector', 'false_positive') end
T.equal(R.state('noisy.detector'), C.DETECTOR_STATE.OBSERVATION, 'détecteur bruyant → OBSERVATION')
T.falsy(R.canEnforce('noisy.detector'), 'un détecteur en OBSERVATION ne sanctionne plus')
T.equal(R.weight('noisy.detector'), 0.0, 'poids nul en OBSERVATION')

-- Un détecteur fiable reste ACTIVE avec poids plein.
for _ = 1, 10 do R.record('good.detector', 'confirmed') end
T.equal(R.state('good.detector'), C.DETECTOR_STATE.ACTIVE, 'détecteur fiable → ACTIVE')
T.equal(R.weight('good.detector'), 1.0, 'poids plein en ACTIVE')

-- Sous le minimum d'échantillons, on ne juge pas (pas de rétrogradation hâtive).
R.record('new.detector', 'false_positive')
T.equal(R.state('new.detector'), C.DETECTOR_STATE.ACTIVE, 'pas de jugement sous le seuil d\'échantillons')

-- ===========================================================================
T.section('moteur de performance §29')

local P = ZShield.Perf
P.configure({ enabled = true, budget_ms = 5 })
P.tick()
-- Une tâche critique qui consomme du temps virtuel.
P.measure(C.PERF_TIER.REALTIME, 'firewall.check', function() H.advance(8) end)
T.truthy(P.report().critical_ms >= 8, 'temps critique mesuré')
-- Le budget critique dépassé => les tâches différables doivent se retenir (backpressure).
T.truthy(P.shouldDefer(C.PERF_TIER.FORENSICS), 'forensics diffère quand le critique sature')
T.falsy(P.shouldDefer(C.PERF_TIER.REALTIME), 'le chemin critique ne se diffère jamais')
-- measure est transparent : il rend la valeur de la fonction.
local ret = P.measure(C.PERF_TIER.NORMAL, 'x', function() return 42 end)
T.equal(ret, 42, 'measure retourne la valeur de la fonction mesurée')

-- ===========================================================================
T.section('histogramme de preuve + agrégat protections')

dofile('server/api.lua')
-- Observe quelques signaux de maturité croissante.
ZShield.Evidence.observe({ confidence = 0.1 })                       -- E0
ZShield.Evidence.observe({ confidence = 0.7 })                       -- E2
ZShield.Evidence.observe({ blocked = true })                        -- E5
local dist = ZShield.Evidence.distribution()
T.truthy(dist.E0 >= 1, 'distribution compte les E0')
T.truthy(dist.E2 >= 1, 'distribution compte les E2')
T.truthy(dist.E5 >= 1, 'distribution compte les E5 (blocage serveur)')

-- Agrégat exposé à l'agent. On repart d'une config par défaut (lockdown inactif).
Config.load({ mode = 'ENFORCE' })
local prot = ZShield.GetProtections()
T.truthy(type(prot) == 'table', 'GetProtections renvoie une table')
T.truthy(prot.layers and prot.layers.game_events ~= nil, 'couche game_events présente')
T.truthy(prot.layers.statebag ~= nil, 'couche statebag présente')
T.equal(prot.onesync_lockdown, 'inactive', 'lockdown par défaut inactif')
T.truthy(prot.performance and prot.performance.budget_ms ~= nil, 'métriques de performance présentes')
T.truthy(prot.reputation and prot.reputation.ACTIVE ~= nil, 'réputation agrégée par état')

-- SetLockdown à chaud : change le mode et ré-applique l'orchestrateur.
H.native = {}
local ok = ZShield.SetLockdown('strict')
T.truthy(ok, 'SetLockdown(strict) accepté')
T.equal(ZShield.GetProtections().onesync_lockdown, 'strict', 'lockdown mis à jour à chaud')
local sawStrict = false
for _, call in ipairs(H.native) do
    if call[1] == 'SetRoutingBucketEntityLockdownMode' and call[3] == 'strict' then sawStrict = true end
end
T.truthy(sawStrict, 'orchestrateur ré-appliqué avec strict')
T.falsy((ZShield.SetLockdown('banana')), 'mode invalide refusé')

os.exit(T.summary() and 0 or 1)
