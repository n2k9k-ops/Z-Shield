--[[
    FILE:         tests/run_incident.lua
    PURPOSE:      Tests de l'incident engine (§28, §29, §102, §147, §151, §55). Prouve la
                  déduplication, la timeline, la chaîne de preuve, la référence de config,
                  le verrouillage des incidents critiques, et l'ouverture automatique sur
                  franchissement de seuil de risque.
    USAGE:        lua5.4 tests/run_incident.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/context.lua')
dofile('server/detection/engine.lua'); dofile('server/detection/correlation.lua'); dofile('server/detection/risk.lua')
dofile('server/incident.lua')

local C = ZShield.Const
local Incident = ZShield.Incident
local Risk = ZShield.Risk
local Config = ZShield.Config

ZShield.Log.console = false
local _rawLoad = Config.load
Config.load = function(raw) local ok, r = _rawLoad(raw); ZShield.Log.console = false; return ok, r end
Config.load({ mode = 'ENFORCE' })
H.reset()

local function resetIncidents()
    Incident.incidents = {}; Incident.order = {}; Incident.dedup = {}
    Incident.byPlayer = {}; Incident.stats = { opened = 0, deduplicated = 0, decided = 0 }
end

-- ===========================================================================
T.section('incident : ouverture et structure §28')

resetIncidents()
local inc = Incident.open({
    source = 1, detector = 'movement.teleport', category = C.CATEGORY.MOVEMENT,
    severity = 'HIGH', confidence = 0.9, risk_before = 40, risk_after = 70,
    signals = { { detector = 'movement.teleport', score = 30 } },
    context = { state = 'ACTIVE' },
})
T.truthy(inc ~= nil, 'incident ouvert')
T.truthy(inc.id:match('^inc_'), 'id préfixé inc_')
T.equal(inc.source, 1, 'joueur enregistré')
T.equal(inc.severity, 'HIGH', 'gravité enregistrée')
T.equal(inc.occurrences, 1, 'une occurrence')
T.truthy(#inc.timeline >= 1, 'timeline initialisée §28')
T.equal(inc.timeline[1].kind, 'opened', 'première entrée de timeline = opened')

-- §151 : référence de config.
T.truthy(inc.config_version >= 1, 'version de config référencée §151')

-- ===========================================================================
T.section('incident : déduplication §102 §103')

resetIncidents()
-- 100 fois la même anomalie en peu de temps -> 1 incident, 100 occurrences.
for i = 1, 100 do
    Incident.open({ source = 5, detector = 'entity.spam', category = C.CATEGORY.ENTITY,
                    severity = 'MEDIUM', confidence = 0.7, risk_after = 30 })
end
T.equal(Incident.stats.opened, 1, '100 anomalies identiques -> 1 incident ouvert §102')
T.equal(Incident.stats.deduplicated, 99, '99 fusionnées')
local dedup = Incident.list()[1]
T.equal(dedup.occurrences, 100, '100 occurrences comptées')
-- La timeline ne contient PAS 100 entrées (§28 lisibilité).
T.truthy(#dedup.timeline < 20, 'timeline agrégée, pas 100 entrées (' .. #dedup.timeline .. ')')

-- Anomalie DIFFÉRENTE -> nouvel incident.
Incident.open({ source = 5, detector = 'movement.speed', category = C.CATEGORY.MOVEMENT,
                severity = 'HIGH', confidence = 0.8, risk_after = 50 })
T.equal(Incident.stats.opened, 2, 'anomalie différente -> nouvel incident')

-- Hors fenêtre de dédup -> nouvel incident même détecteur.
H.advance(31000) -- > DEDUP_WINDOW_MS (30000)
Incident.open({ source = 5, detector = 'entity.spam', category = C.CATEGORY.ENTITY,
                severity = 'MEDIUM', confidence = 0.7, risk_after = 30 })
T.equal(Incident.stats.opened, 3, 'hors fenêtre de dédup -> nouvel incident §102')

-- ===========================================================================
T.section('incident : observations et décision §85')

resetIncidents()
inc = Incident.open({ source = 2, detector = 'd', category = C.CATEGORY.EVENT,
                      severity = 'MEDIUM', confidence = 0.6, risk_after = 45 })
T.truthy((Incident.addObservation(inc.id, { note = 'player also flagged for economy' })), 'observation ajoutée')
T.equal(#inc.observations, 1, 'observation enregistrée')

Incident.setDecision(inc.id, {
    action = C.ACTION.WARN, policy = 'two_phase', reason = 'suspicious but not confirmed',
    confidence = 0.6, threshold = 40,
})
T.truthy(inc.decision ~= nil, 'décision enregistrée')
T.equal(inc.decision.action, 'WARN', 'action correcte')
T.equal(inc.decision.policy, 'two_phase', 'politique enregistrée §85')
-- La décision figure dans la timeline.
local hasDecision = false
for _, e in ipairs(inc.timeline) do if e.kind == 'decision' then hasDecision = true end end
T.truthy(hasDecision, 'décision dans la timeline §28')

-- ===========================================================================
T.section('incident : verrouillage des critiques §147')

resetIncidents()
local crit = Incident.open({ source = 3, detector = 'd', category = C.CATEGORY.STATE,
                             severity = 'CRITICAL', confidence = 0.95, risk_after = 90 })
T.truthy(crit.critical, 'incident CRITICAL marqué critique')
T.falsy(crit.locked, 'pas encore verrouillé avant décision')

Incident.setDecision(crit.id, { action = C.ACTION.TEMP_BAN, reason = 'confirmed cheat' })
T.truthy(crit.locked, 'incident critique verrouillé après décision §147')

-- Toute modification ultérieure est refusée.
local ok = Incident.addObservation(crit.id, { note = 'late tampering' })
T.falsy(ok, 'observation refusée sur incident verrouillé §147')
ok = Incident.setDecision(crit.id, { action = C.ACTION.LOG, reason = 'downgrade attempt' })
T.falsy(ok, 'seconde décision refusée sur incident verrouillé §147')

-- ===========================================================================
T.section('incident : chaîne de preuve §29')

resetIncidents()
inc = Incident.open({
    source = 7, detector = 'movement.teleport', category = C.CATEGORY.MOVEMENT,
    severity = 'HIGH', confidence = 0.85, risk_before = 30, risk_after = 72,
    signals = {
        { detector = 'movement.teleport', severity = 'HIGH', score = 30, at = 100 },
        { detector = 'entity.spam', severity = 'MEDIUM', score = 12, at = 200 },
    },
    correlation = { correlated = true, distinct_categories = 2, categories = { 'movement', 'entity' } },
    context = { state = 'ACTIVE' },
})
Incident.setDecision(inc.id, { action = C.ACTION.KICK, policy = 'confirmation', reason = 'correlated anomalies', threshold = 65 })

local chain = Incident.evidenceChain(inc.id)
T.truthy(chain ~= nil, 'chaîne de preuve disponible')
T.equal(chain.player, 7, 'chaîne nomme le joueur')
T.truthy(#chain.signals == 2, 'chaîne contient les signaux §29')
T.truthy(chain.correlation ~= nil, 'chaîne contient la corrélation §29')
T.truthy(chain.timeline ~= nil, 'chaîne contient la timeline §28')
T.truthy(chain.decision ~= nil, 'chaîne contient la décision §85')
T.truthy(chain.config_version >= 1, 'chaîne référence la version de config §151')
-- L'admin peut tout remonter : signal -> corrélation -> risque -> incident -> décision.
T.equal(chain.risk_before, 30, 'risque avant présent')
T.equal(chain.risk_after, 72, 'risque après présent')

-- ===========================================================================
T.section('incident : filtres et index par joueur §124 §125')

resetIncidents()
Incident.open({ source = 10, detector = 'a', category = C.CATEGORY.MOVEMENT, severity = 'LOW', risk_after = 10 })
Incident.open({ source = 10, detector = 'b', category = C.CATEGORY.ENTITY, severity = 'CRITICAL', risk_after = 90 })
Incident.open({ source = 11, detector = 'c', category = C.CATEGORY.EVENT, severity = 'HIGH', risk_after = 70 })

T.equal(#Incident.forPlayer(10), 2, 'index par joueur : 2 incidents pour le joueur 10')
T.equal(#Incident.forPlayer(11), 1, '1 incident pour le joueur 11')
T.equal(#Incident.list({ severity = 'CRITICAL' }), 1, 'filtre par gravité')
T.equal(#Incident.list({ min_risk = 60 }), 2, 'filtre par risque minimum')
T.equal(#Incident.list({ decided = false }), 3, 'filtre par non-décidés')

-- ===========================================================================
T.section('incident : ouverture auto sur seuil de risque §13 -> §28')

H.reset()
resetIncidents()
Risk.players = {}
Config.load({ mode = 'ENFORCE', scoring = { thresholds = { observe = 20, suspicious = 40, high_risk = 65, critical = 85 } } })
ZShield.Context.init(50); ZShield.Context.forceState(50, 'ACTIVE')

Risk.attach()          -- risque publie risk.level_changed
ZShield.Correlation.attach()
Incident.attach()      -- incident écoute et ouvre

-- Un joueur monte progressivement. En franchissant HIGH_RISK, un incident s'ouvre.
Risk.addSignal(50, { detector = 'movement.teleport', category = C.CATEGORY.MOVEMENT, severity = 'HIGH', confidence = 0.9, score = 66 })
T.truthy(Incident.stats.opened >= 1, 'incident ouvert automatiquement au franchissement HIGH_RISK §13->§28')
local autoInc = Incident.forPlayer(50)[1]
T.truthy(autoInc ~= nil, 'incident lié au joueur')
T.truthy(autoInc.risk_after >= 65, 'incident porte le score de risque')
T.truthy(autoInc.context ~= nil, 'incident capture le contexte joueur')

os.exit(T.summary() and 0 or 1)
