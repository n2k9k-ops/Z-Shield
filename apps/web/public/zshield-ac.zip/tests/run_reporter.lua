--[[
    FILE:         tests/run_reporter.lua
    PURPOSE:      Pont incident -> alerte plateforme. Vérifie la forme de l'alerte,
                  la proposition de sanction (identité + gravité), la résolution
                  d'identité via l'adaptateur de framework, et l'envoi via le sink.
    USAGE:        lua5.4 tests/run_reporter.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('server/reporter.lua')

local C = ZShield.Const
local Reporter = ZShield.Reporter
ZShield.Log.console = false

-- ===========================================================================
T.section('alerte : forme de base sans identité -> pas de sanction')

Reporter.setSink(nil)
local a = Reporter.alertOf({
    id = 'inc_abc', source = 7, detector = 'weapon.firerate',
    category = C.CATEGORY.DAMAGE, severity = C.SEVERITY.MEDIUM,
    confidence = 0.58, risk_after = 58,
})
T.equal(a.category, 'weapon', 'catégorie DAMAGE -> weapon')
T.equal(a.severity, 'MEDIUM', 'gravité conservée')
T.truthy(a.summary and #a.summary >= 3, 'résumé présent')
T.equal(a.reference, 'inc_abc', 'référence = id incident')
T.falsy(a.sanction, 'sans identité résolvable -> pas de sanction')

-- ===========================================================================
T.section('sanction : identité fournie dans le contexte')

local b = Reporter.alertOf({
    id = 'inc_def', source = 9, detector = 'aim.camera',
    category = C.CATEGORY.DAMAGE, severity = C.SEVERITY.HIGH,
    confidence = 0.7, risk_after = 72,
    context = { identity = { scope = 'license', identifier = 'license:abc123',
                             player_name = 'Sofia_B' }, evidence_kind = 'clip' },
})
T.truthy(b.sanction, 'identité + gravité HIGH -> sanction proposée')
T.equal(b.sanction.scope, 'license', 'scope repris')
T.equal(b.sanction.identifier, 'license:abc123', 'identifiant repris')
T.equal(b.sanction.detector, 'aim.camera', 'détecteur repris')
T.equal(b.sanction.risk, 72, 'risque = risk_after arrondi')
T.equal(b.sanction.evidence_kind, 'clip', 'preuve reprise')
T.equal(b.sanction.player_name, 'Sofia_B', 'pseudo repris')

-- ===========================================================================
T.section('gravité faible -> alerte sans sanction, même avec identité')

local c = Reporter.alertOf({
    id = 'inc_low', source = 3, detector = 'movement.jitter',
    category = C.CATEGORY.MOVEMENT, severity = C.SEVERITY.LOW,
    context = { identity = { scope = 'license', identifier = 'license:zzz' } },
})
T.falsy(c.sanction, 'LOW -> pas de sanction (au-dessous du seuil)')

-- ===========================================================================
T.section("résolution d'identité via l'adaptateur de framework")

-- Simule un adaptateur : source 42 -> license persistante.
ZShield.Framework = { getIdentifier = function(source)
    if source == 42 then return 'license:framework42' end
    return nil
end }

local d = Reporter.alertOf({
    id = 'inc_fw', source = 42, detector = 'weapon.firerate',
    category = C.CATEGORY.DAMAGE, severity = C.SEVERITY.MEDIUM, risk_after = 55,
})
T.truthy(d.sanction, 'identité résolue par le framework -> sanction')
T.equal(d.sanction.identifier, 'license:framework42', 'identifiant résolu')

ZShield.Framework = nil

-- ===========================================================================
T.section('envoi via le sink injecté')

local captured
Reporter.setSink(function(alert) captured = alert end)
local ok = Reporter.report({
    id = 'inc_send', source = 9, detector = 'aim.camera',
    category = C.CATEGORY.DAMAGE, severity = C.SEVERITY.HIGH, risk_after = 80,
    context = { identity = { scope = 'steam', identifier = 'steam:110000100000000' } },
})
T.truthy(ok, 'report réussit avec un sink')
T.truthy(captured and captured.sanction, 'le sink reçoit une alerte avec sanction')
T.equal(captured.sanction.scope, 'steam', 'scope steam transmis')
T.truthy(Reporter.getStats().sanctions >= 1, 'compteur de sanctions incrémenté')

-- Sans sink : pas d'erreur, simplement ignoré.
Reporter.setSink(nil)
local ok2 = Reporter.report({ id = 'inc_x', source = 1, detector = 'x',
    category = C.CATEGORY.EVENT, severity = C.SEVERITY.LOW })
T.falsy(ok2, 'sans sink -> report renvoie faux, sans lever')

os.exit(T.summary() and 0 or 1)
