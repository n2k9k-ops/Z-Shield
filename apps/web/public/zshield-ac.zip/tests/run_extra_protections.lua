--[[
    FILE:         tests/run_extra_protections.lua
    PURPOSE:      Nouvelles protections pilotables :
                    - blacklist de PEDS et d'OBJETS (refus à la création) ;
                    - blocage DUR de types d'explosion interdits ;
                    - filtre de pseudo (longueur, liste interdite) et anti-relog
                      à la connexion.
    USAGE:        lua5.4 tests/run_extra_protections.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/firewall/ratelimit.lua')
dofile('server/blacklist.lua')
dofile('server/detection/projectile.lua')
dofile('server/firewall/gameevents.lua')
dofile('server/connection.lua')

local BL = ZShield.Blacklist
local GE = ZShield.GameEvents
local Conn = ZShield.Connection
ZShield.Log.console = false
ZShield.Config.load({})

-- ===========================================================================
T.section('blacklist : peds et objets refusés à la création')

-- Le client saisit des NOMS ; le cœur les stocke en hash (joaat) et compare au
-- hash numérique fourni par le runtime à la création. On vérifie donc par hash.
local sharkHash = ZShield.Util.joaat('a_c_shark')
local wallHash = ZShield.Util.joaat('prop_huge_wall')
BL.set({ peds = { 'a_c_shark', 12345 }, objects = { 'prop_huge_wall' } })
T.truthy(BL.pedBlocked(sharkHash), 'ped saisi par nom -> bloqué (comparé par hash)')
T.truthy(BL.pedBlocked(12345), 'ped par hash -> bloqué')
T.truthy(BL.objectBlocked(wallHash), 'objet saisi par nom -> bloqué (comparé par hash)')
T.truthy(BL.modelBlocked(sharkHash), 'modelBlocked couvre les peds')
T.truthy(BL.modelBlocked(wallHash), 'modelBlocked couvre les objets')
T.falsy(BL.pedBlocked(ZShield.Util.joaat('a_m_y_business_01')), 'ped non listé -> autorisé')

local snap = BL.snapshot()
T.equal(snap.peds, 2, 'compte des peds')
T.equal(snap.objects, 1, 'compte des objets')

-- Le pare-feu game events refuse la création d'un ped blacklisté.
local v = GE.checkEntityCreate(1, { model = ZShield.Util.joaat('a_c_shark') })
T.truthy(v.block, "creation d'un ped blackliste -> bloquee")

-- ===========================================================================
T.section('explosion : type interdit bloqué à la source')

ZShield.Config.load({ game_events = { explosion_type_blocklist = { [59] = true, ['7'] = true } } })
local e1 = GE.checkExplosion({ source = 1, explosionType = 59, posX = 10, posY = 10, posZ = 5 })
T.truthy(e1.block, "type d'explosion interdit (numerique) -> bloque")
local e2 = GE.checkExplosion({ source = 1, explosionType = 7, posX = 10, posY = 10, posZ = 5 })
T.truthy(e2.block, "type interdit fourni en chaine -> bloque aussi")
local e3 = GE.checkExplosion({ source = 1, explosionType = 2, posX = 10, posY = 10, posZ = 5 })
T.falsy(e3.block, 'type non listé -> non bloqué par ce filtre')

-- ===========================================================================
T.section('connexion : filtre de pseudo (longueur + liste interdite)')

ZShield.Config.load({ connection = {
    min_name_length = 3, max_name_length = 20,
    name_blocklist = { 'admin', 'staff' }, max_threat_score = 40,
} })
local short = Conn.assess({ name = 'ab', identifiers = { license = 'lic:1' } })
T.truthy(short.threat >= 20, 'pseudo trop court -> menace')
local imposter = Conn.assess({ name = 'ServerAdmin', identifiers = { license = 'lic:2' } })
T.falsy(imposter.allow, 'pseudo usurpant « admin » -> refusé')

-- ===========================================================================
T.section('connexion : anti-relog (reconnexion trop rapide)')

ZShield.Config.load({ connection = { relog_cooldown_seconds = 60, max_threat_score = 25 } })
Conn.noteDisconnected('lic:relog', 1000)
-- Reconnexion 10 s après le départ : sous le cooldown -> menace ajoutée.
local fast = Conn.assess({ name = 'Kevin', identifiers = { license = 'lic:relog' }, now = 1010 })
T.truthy(fast.threat >= 30, 'reconnexion rapide -> menace')
T.falsy(fast.allow, 'au-dessus du seuil -> refusée')
-- Reconnexion bien plus tard : plus de pénalité.
local slow = Conn.assess({ name = 'Kevin', identifiers = { license = 'lic:relog' }, now = 2000 })
T.truthy(slow.allow, 'reconnexion tardive -> autorisée')

-- ===========================================================================
T.section('whitelist : mode « autoriser uniquement » (véhicules)')

ZShield.Config.load({})
local adderH = ZShield.Util.joaat('adder')
local policeH = ZShield.Util.joaat('police')
BL.set({ whitelist = { vehicle = { enabled = true, list = { 'adder', 'sultan' } } } })
T.truthy(BL.notWhitelisted('vehicle', policeH), 'modèle hors whitelist -> refusé')
T.falsy(BL.notWhitelisted('vehicle', adderH), 'modèle dans la whitelist -> autorisé')
-- Sans whitelist active, rien n'est refusé par ce mécanisme.
BL.set({})
T.falsy(BL.notWhitelisted('vehicle', policeH), 'pas de whitelist active -> aucun refus')

-- Le pare-feu refuse la création d'un véhicule hors whitelist.
BL.set({ whitelist = { vehicle = { enabled = true, list = { 'adder' } } } })
local wv = GE.checkEntityCreate(1, { model = policeH, kind = 'vehicle' })
T.truthy(wv.block, 'création hors whitelist véhicule -> bloquée')
local wv2 = GE.checkEntityCreate(1, { model = adderH, kind = 'vehicle' })
T.falsy(wv2.block, 'création dans la whitelist -> autorisée')

-- ===========================================================================
T.section('whitelist : mode « autoriser uniquement » (armes)')

local pistolH = ZShield.Util.joaat('weapon_pistol')
local rpgH = ZShield.Util.joaat('weapon_rpg')
BL.set({ whitelist = { weapon = { enabled = true, list = { 'weapon_pistol', 'weapon_knife' } } } })
T.truthy(BL.notWhitelisted('weapon', rpgH), 'arme hors whitelist -> refusée')
T.falsy(BL.notWhitelisted('weapon', pistolH), 'arme dans la whitelist -> autorisée')
-- Le pare-feu bloque un tir avec une arme hors whitelist.
local wwd = GE.checkWeaponDamage(1, { weaponType = rpgH, weaponDamage = 20 })
T.truthy(wwd.block, 'dégât d\'une arme hors whitelist -> bloqué')
local wwd2 = GE.checkWeaponDamage(1, { weaponType = pistolH, weaponDamage = 20 })
T.falsy(wwd2.block, 'dégât d\'une arme whitelistée -> autorisé')
BL.set({})  -- reset : pas de whitelist active

-- ===========================================================================
T.section('whitelist : projectiles')

BL.set({ whitelist = { projectile = { enabled = true, list = { 'WEAPON_SNOWBALL' } } } })
local Proj = ZShield.Projectile
Proj.forget(2)
local ps = Proj.observe(2, { projectileHash = ZShield.Util.joaat('WEAPON_RPG') }, 1000)
T.truthy(ps and ps.block, 'projectile hors whitelist -> signal de blocage')
BL.set({})

-- ===========================================================================
T.section('politiques explosions : annuler tout / invisible / inaudible')

ZShield.Config.load({ game_events = { cancel_all_explosions = true } })
T.truthy(GE.checkExplosion({ source = 1, explosionType = 2, posX = 1, posY = 1, posZ = 1 }).block,
    'annuler toutes les explosions -> bloquée')
ZShield.Config.load({ game_events = { cancel_all_fires = true } })
T.truthy(GE.checkExplosion({ source = 1, explosionType = 18, posX = 1, posY = 1, posZ = 1 }).block,
    'annuler les feux -> molotov bloqué')
T.falsy(GE.checkExplosion({ source = 1, explosionType = 2, posX = 1, posY = 1, posZ = 1 }).block,
    'annuler les feux -> une explosion non-feu passe')
ZShield.Config.load({ game_events = {} })
T.truthy(GE.checkExplosion({ source = 1, explosionType = 2, isInvisible = true, posX = 1, posY = 1, posZ = 1 }).block,
    'explosion invisible -> bloquée (défaut ON)')
T.truthy(GE.checkExplosion({ source = 1, explosionType = 2, isAudible = false, posX = 1, posY = 1, posZ = 1 }).block,
    'explosion inaudible -> bloquée (défaut ON)')

-- ===========================================================================
T.section('politiques véhicules : dégâts aux joueurs & suppression')

ZShield.Config.load({ vehicle = { disable_damage_to_players = true } })
local vd = GE.checkWeaponDamage(1, { weaponType = -1553120962 }) -- WEAPON_RUN_OVER_BY_CAR
T.truthy(vd.block, 'renversement en voiture -> bloqué quand la politique est active')
ZShield.Config.load({ vehicle = {} })
local vd2 = GE.checkWeaponDamage(1, { weaponType = -1553120962, weaponDamage = 30 })
T.falsy(vd2.block, 'politique inactive -> renversement non bloqué par cette règle')

ZShield.Config.load({ game_events = { anti_vehicle_deletion = true } })
T.truthy(GE.checkEntityRemove(5, { kind = 'vehicle', owner = 9 }).block,
    'suppression par un non-propriétaire -> bloquée')
T.falsy(GE.checkEntityRemove(9, { kind = 'vehicle', owner = 9 }).block,
    'le propriétaire peut supprimer son véhicule')
ZShield.Config.load({ game_events = {} })
T.falsy(GE.checkEntityRemove(5, { kind = 'vehicle', owner = 9 }).block,
    'politique inactive -> suppression non bloquée')

os.exit(T.summary() and 0 or 1)
