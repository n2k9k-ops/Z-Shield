--[[
    FILE:    tests/run_preflight.lua
    PURPOSE: Contrôle préflight (analyse PURE des erreurs de branchement).
    USAGE:   lua5.4 tests/run_preflight.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/preflight.lua')
ZShield.Log.console = false

local P = ZShield.Preflight

local function has(list, code)
    for _, w in ipairs(list) do if w.code == code then return w end end
    return nil
end

-- ===========================================================================
T.section('préflight : staff non configuré = le grand classique')

-- exempt=true, aucune source d'identité, aucun framework admin -> AVERTISSEMENT.
local w = P.analyze({ staff = { exempt = true, ace_perms = {}, identifiers = {} }, mode = 'ENFORCE' },
                    { framework_admin = false, onesync = true, licensed = true })
T.truthy(has(w, 'staff_unconfigured'), 'staff sans identité -> avertissement (admins détectés)')

-- Avec des permissions ACE -> plus d'avertissement staff.
local w2 = P.analyze({ staff = { exempt = true, ace_perms = { 'zshield.exempt' }, identifiers = {} }, mode = 'ENFORCE' },
                     { framework_admin = false, onesync = true, licensed = true })
T.falsy(has(w2, 'staff_unconfigured'), 'staff avec ACE -> pas d\'avertissement')

-- Avec un adaptateur framework isAdmin -> plus d'avertissement.
local w3 = P.analyze({ staff = { exempt = true, ace_perms = {}, identifiers = {} }, mode = 'ENFORCE' },
                     { framework_admin = true, onesync = true, licensed = true })
T.falsy(has(w3, 'staff_unconfigured'), 'staff via framework -> pas d\'avertissement')

-- exempt=false -> avertissement distinct.
local w4 = P.analyze({ staff = { exempt = false }, mode = 'ENFORCE' }, { onesync = true, licensed = true })
T.truthy(has(w4, 'staff_exempt_off'), 'exempt=false -> avertissement')

-- ===========================================================================
T.section('préflight : autres pièges de branchement')

-- OneSync off.
local o = P.analyze({ mode = 'ENFORCE' }, { onesync = false, licensed = true })
T.truthy(has(o, 'onesync_off'), 'OneSync off -> avertissement')

-- Licence invalide.
local l = P.analyze({ mode = 'ENFORCE' }, { licensed = false, onesync = true })
T.truthy(has(l, 'license_invalid'), 'licence invalide -> avertissement')

-- Mode SHADOW -> info (pas une erreur).
local s = P.analyze({ mode = 'SHADOW' }, { onesync = true, licensed = true })
T.truthy(has(s, 'mode_shadow'), 'SHADOW -> info')

-- Whitelist active mais vide.
local wl = P.analyze({ mode = 'ENFORCE', whitelist_state = { vehicle = 0 } }, { onesync = true, licensed = true })
T.truthy(has(wl, 'whitelist_empty'), 'whitelist vide -> avertissement')

-- Capture activée sans URL.
local ev = P.analyze({ mode = 'ENFORCE', evidence = { enabled = true, upload_url = '' } },
                     { onesync = true, licensed = true })
T.truthy(has(ev, 'evidence_no_url'), 'capture sans URL -> avertissement')

-- Clé de provisioning par défaut.
local pv = P.analyze({ mode = 'ENFORCE' }, { onesync = true, licensed = true, provisioning_default = true })
T.truthy(has(pv, 'provisioning_default'), 'clé provisioning par défaut -> avertissement')

-- Config saine -> aucun avertissement WARN.
local clean = P.analyze(
  { mode = 'ENFORCE', staff = { exempt = true, ace_perms = { 'zshield.exempt' } }, evidence = { enabled = false } },
  { onesync = true, licensed = true, provisioning_default = false })
local warns = 0
for _, x in ipairs(clean) do if x.level == 'WARN' then warns = warns + 1 end end
T.equal(warns, 0, 'config saine -> aucun avertissement')

os.exit(T.summary() and 0 or 1)
