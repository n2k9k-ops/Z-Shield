--[[
    FILE:         tests/run_more_detection.lua
    PURPOSE:      Vague 2 de détections serveur-autoritatives :
                    - freecam  : ped figé + joueur actif -> freecam probable
                    - sequence : tir en étant mort / arme jamais donnée / avant spawn
                    - desync   : action loin de la position serveur + lag-switch
                    - budget   : no-reload / stamina infinie / combat-roll (3 bleus -> verts)
                  Chaque moteur : cas légitime silencieux, cas triche détecté, impact config.
    USAGE:        lua5.4 tests/run_more_detection.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/freecam.lua')
dofile('server/detection/sequence.lua')
dofile('server/detection/desync.lua')
dofile('server/detection/budget.lua')

local C = ZShield.Const
local FC = ZShield.Freecam
local SEQ = ZShield.Sequence
local DS = ZShield.Desync
local B = ZShield.Budget
ZShield.Log.console = false

-- ===========================================================================
T.section("freecam : ped qui bouge ne declenche pas")

ZShield.Config.load({ freecam = { enabled = true, epsilon_m = 0.5, hold_ms = 4000, min_activity = 5 } })
FC.forget(1)
local mv
for i = 1, 8 do
    mv = FC.observe(1, { pos = { x = i * 5, y = 0, z = 30 }, active = true, now = 1000 + i * 1000 })
end
T.falsy(mv, "ped qui se deplace en agissant -> pas de freecam")

T.section("freecam : ped fige + joueur actif -> signal")
FC.forget(2)
local fcsig
for i = 1, 8 do
    local r = FC.observe(2, { pos = { x = 10, y = 10, z = 30 }, active = true, now = 1000 + i * 1000 })
    if r then fcsig = r end
end
T.truthy(fcsig and fcsig.metadata.kind == "freecam", "fige >4 s en restant actif -> freecam")

T.section("freecam : fige mais AFK (aucune activite) -> pas de signal")
FC.forget(3)
local afk
for i = 1, 8 do
    afk = FC.observe(3, { pos = { x = 10, y = 10, z = 30 }, active = false, now = 1000 + i * 1000 })
end
T.falsy(afk, "fige mais inactif (AFK) -> pas de freecam")

-- ===========================================================================
T.section("sequence : actions causales impossibles")

ZShield.Config.load({ sequence = { enabled = true, check_dead = true,
    check_weapon_provenance = true, check_spawn = true } })
SEQ.forget(1)
SEQ.observe(1, { type = "spawn" })
SEQ.observe(1, { type = "give_weapon", weapon = "pistol" })
T.falsy(SEQ.observe(1, { type = "fire", weapon = "pistol" }), "tir avec arme donnee, vivant -> ok")

local deadSig = (function()
    SEQ.observe(1, { type = "death" })
    return SEQ.observe(1, { type = "fire", weapon = "pistol" })
end)()
T.truthy(deadSig and deadSig.metadata.kind == "action_while_dead", "tir en etant mort -> signal")

SEQ.forget(2)
SEQ.observe(2, { type = "spawn" })
local injSig = SEQ.observe(2, { type = "fire", weapon = "rpg" })
T.truthy(injSig and injSig.metadata.kind == "weapon_never_given", "arme jamais donnee -> signal injection")

T.section("sequence : desactive -> silence")
ZShield.Config.load({ sequence = { enabled = false } })
SEQ.forget(3)
SEQ.observe(3, { type = "death" })
T.falsy(SEQ.observe(3, { type = "fire", weapon = "pistol" }), "detecteur desactive -> aucun signal")

-- ===========================================================================
T.section("desync : origine d'action loin de la position serveur")

ZShield.Config.load({ desync = { enabled = true, max_origin_m = 8,
    lagswitch_enabled = true, min_gap_ms = 1500 } })
DS.forget(1)
DS.observePosition(1, { x = 0, y = 0, z = 30 }, 1000)
T.falsy(DS.observeAction(1, { origin = { x = 3, y = 2, z = 30 }, now = 1100 }),
    "action a 3-4 m -> ok")
local dsig = DS.observeAction(1, { origin = { x = 100, y = 0, z = 30 }, now = 1200 })
T.truthy(dsig and dsig.metadata.kind == "origin_desync", "action a 100 m de la position serveur -> signal")

-- Physique : un joueur RAPIDE mais plausible sur le temps écoulé n'est PAS accusé.
DS.forget(8)
DS.observePosition(8, { x = 0, y = 0, z = 30 }, 1000)
-- 60 m en 2 s = 30 m/s : sous la vitesse max -> déplacement explicable, pas de désync.
T.falsy(DS.observeAction(8, { origin = { x = 60, y = 0, z = 30 }, now = 3000 }),
    "60 m en 2 s (30 m/s, plausible) -> pas de faux positif")
-- Teleport-shoot : 300 m « instantanés » (0.1 s) = inexplicable -> signal.
DS.forget(9)
DS.observePosition(9, { x = 0, y = 0, z = 30 }, 1000)
local tp = DS.observeAction(9, { origin = { x = 300, y = 0, z = 30 }, now = 1100 })
T.truthy(tp and tp.metadata.kind == "origin_desync", "300 m en 0,1 s -> teleport-shoot detecte")
T.truthy(tp.metadata.unexplained_m > 8, "distance inexpliquee au-dela du seuil")

T.section("desync : lag-switch (gel + effet monde)")
T.falsy(DS.observeGap(1, { gap_ms = 400, effect_during_gap = true }), "petit gel -> ignore")
local lag = DS.observeGap(1, { gap_ms = 3000, effect_during_gap = true })
T.truthy(lag and lag.metadata.kind == "lagswitch", "gel 3 s avec effet -> lag-switch")
T.falsy(DS.observeGap(1, { gap_ms = 3000, effect_during_gap = false }), "gel sans effet -> ignore")

-- ===========================================================================
T.section("budget : no-reload (tirs > chargeur sans recharge)")

ZShield.Config.load({ budget = { no_reload_enabled = true, default_magazine = 5, reload_margin = 1,
    stamina_enabled = true, max_sprint_ms = 45000,
    combat_roll_enabled = true, roll_window_ms = 10000, roll_max = 6 } })
B.forget(1)
local nr
for i = 1, 6 do nr = B.shot(1, { weapon = "smg", mag = 5 }) end
T.falsy(nr, "6 tirs (chargeur 5 + marge 1) -> encore ok")
nr = B.shot(1, { weapon = "smg", mag = 5 })
T.truthy(nr and nr.metadata.kind == "no_reload", "7e tir sans recharge -> no-reload")
B.reload(1, "smg")
T.falsy(B.shot(1, { weapon = "smg", mag = 5 }), "apres recharge -> compteur remis a zero")

T.section("budget : stamina infinie (sprint continu)")
B.forget(2)
T.falsy(B.sprint(2, { active = true, now = 0 }), "debut de sprint -> ok")
T.falsy(B.sprint(2, { active = true, now = 40000 }), "40 s de sprint -> encore dans le budget")
local st = B.sprint(2, { active = true, now = 50000 })
T.truthy(st and st.metadata.kind == "infinite_stamina", "50 s de sprint continu -> stamina infinie")

T.section("budget : combat-roll flood")
B.forget(3)
local roll
for i = 1, 6 do roll = B.roll(3, i * 100) end
T.falsy(roll, "6 roulades dans la fenetre -> ok")
roll = B.roll(3, 700)
T.truthy(roll and roll.metadata.kind == "combat_roll", "7e roulade dans la fenetre -> flood")

T.section("budget : desactive -> silence")
ZShield.Config.load({ budget = { no_reload_enabled = false } })
B.forget(4)
local off
for i = 1, 20 do off = B.shot(4, { weapon = "smg", mag = 5 }) end
T.falsy(off, "no-reload desactive -> aucun signal")

os.exit(T.summary() and 0 or 1)
