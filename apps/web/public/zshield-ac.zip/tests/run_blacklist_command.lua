--[[
    FILE:         tests/run_blacklist_command.lua
    PURPOSE:      Liste d'interdiction (armes/véhicules) appliquée à la source par le
                  pare-feu, et anti-flood de commandes. Vérifie la correspondance
                  nom -> hash (joaat) et le blocage réel.
    USAGE:        lua5.4 tests/run_blacklist_command.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/blacklist.lua')
dofile('server/firewall/ratelimit.lua')
dofile('server/firewall/gameevents.lua')
dofile('server/detection/command.lua')

local Util = ZShield.Util
local Blacklist = ZShield.Blacklist
local GE = ZShield.GameEvents
local CG = ZShield.CommandGuard
ZShield.Log.console = false
ZShield.Config.load({})

-- ===========================================================================
T.section('blacklist : correspondance nom -> hash')

Blacklist.set({ weapons = { 'WEAPON_RPG', 'WEAPON_MINIGUN' }, vehicles = { 'adder' } })
T.truthy(Blacklist.weaponBlocked(Util.joaat('weapon_rpg')), 'WEAPON_RPG bloquée (par nom)')
T.truthy(Blacklist.weaponBlocked(Util.joaat('WEAPON_MINIGUN')), 'insensible à la casse')
T.falsy(Blacklist.weaponBlocked(Util.joaat('weapon_pistol')), 'arme non listée -> non bloquée')
T.truthy(Blacklist.vehicleBlocked(Util.joaat('adder')), 'véhicule adder bloqué')
T.falsy(Blacklist.vehicleBlocked(Util.joaat('sultan')), 'véhicule non listé -> non bloqué')

-- Hash numérique direct accepté aussi.
Blacklist.set({ weapons = { 1119849093 }, vehicles = {} })
T.truthy(Blacklist.weaponBlocked(1119849093), 'hash numérique accepté')

-- ===========================================================================
T.section('blacklist : blocage réel par le pare-feu')

Blacklist.set({ weapons = { 'WEAPON_RPG' }, vehicles = { 'adder' } })
local v = GE.checkWeaponDamage(1, { weaponType = Util.joaat('weapon_rpg'), weaponDamage = 10 })
T.truthy(v.block, "dégât d'une arme blacklistée -> bloqué")

local ok = GE.checkWeaponDamage(1, { weaponType = Util.joaat('weapon_pistol'), weaponDamage = 10 })
T.falsy(ok.block, 'arme normale, dégât normal -> non bloqué')

local ve = GE.checkEntityCreate(1, { model = Util.joaat('adder') })
T.truthy(ve.block, "création d'un véhicule blacklisté -> bloquée")

-- ===========================================================================
T.section('commandes : anti-flood')

CG.forget(5)
T.falsy(CG.observe(5, 'me', 1000), 'une commande -> rien')

CG.forget(6)
local sig
for k = 0, 14 do
    -- 15 commandes en ~0,3 s : bien au-delà du plafond (8/s).
    sig = CG.observe(6, 'givemoney', 5000 + k * 20)
end
T.truthy(sig, 'flood de commandes -> signal')
T.equal(sig.protection, 'sp_commands', 'protection spam commandes')
T.equal(sig.category, 'network', 'catégorie network')

-- ===========================================================================
T.section('whitelist de commandes (mode « autoriser uniquement »)')

-- Sans whitelist active : tout est autorisé.
T.truthy(CG.commandAllowed('givemoney'), 'pas de whitelist -> commande autorisée')

ZShield.Config.load({ command = { whitelist_enabled = true, whitelist = { 'me', 'help', 'ooc' } } })
T.truthy(CG.commandAllowed('me'), 'commande dans la whitelist -> autorisée')
T.truthy(CG.commandAllowed('HELP'), 'whitelist insensible à la casse')
T.falsy(CG.commandAllowed('givemoney'), 'commande hors whitelist -> refusée')
CG.forget(7)
local usig = CG.observe(7, 'givemoney', 1000)
T.truthy(usig, 'commande hors whitelist -> signal')
T.equal(usig.protection, 'sp_commands', 'signal protection commandes')
T.truthy(string.find(usig.reason, 'unauthorized'), 'raison = commande non autorisée')
ZShield.Config.load({})  -- reset

os.exit(T.summary() and 0 or 1)
