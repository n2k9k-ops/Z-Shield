--[[
    FILE:         tests/run_projectile.lua
    PURPOSE:      Détecteur de projectiles : spam de lancement, et tir depuis une
                  position incohérente avec le joueur (explosion à distance). Horloge
                  et position joueur injectées (déterministe).
    USAGE:        lua5.4 tests/run_projectile.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/projectile.lua')

local Projectile = ZShield.Projectile
local Config = ZShield.Config
ZShield.Log.console = false
Config.load({})

local playerPos = { x = 100, y = 200, z = 30 }

-- ===========================================================================
T.section('projectile : lancement normal -> aucun signal')

Projectile.forget(20)
local r = Projectile.observe(20, {
    firePositionX = 101, firePositionY = 201, firePositionZ = 30,
}, 1000, playerPos)
T.falsy(r, 'un projectile près du joueur -> rien')

-- ===========================================================================
T.section('projectile : spam de lancement -> signal')

Projectile.forget(21)
local sig
for k = 0, 14 do
    -- 15 projectiles en ~0,3 s : bien au-delà du plafond (8/s).
    sig = Projectile.observe(21, {
        firePositionX = 100, firePositionY = 200, firePositionZ = 30,
    }, 5000 + k * 20, playerPos)
end
T.truthy(sig, 'spam de projectiles -> signal')
T.equal(sig.category, 'entity', 'catégorie entity')
T.equal(sig.protection, 'sp_explosions', 'protection explosions/spam')
T.truthy(sig.confidence > 0.5, 'confiance non nulle')

-- ===========================================================================
T.section('projectile : tir depuis une position incohérente -> signal')

Projectile.forget(22)
-- Position de tir à ~430 m du joueur : explosion à distance.
local d = Projectile.observe(22, {
    firePositionX = 100, firePositionY = 630, firePositionZ = 30,
}, 9000, playerPos)
T.truthy(d, 'tir lointain -> signal')
T.equal(d.source, 22, 'source = le joueur')
T.truthy(d.confidence > 0.5, 'confiance non nulle')

-- Sans position joueur connue, on ne peut pas juger la distance : pas de faux positif.
Projectile.forget(23)
local np = Projectile.observe(23, {
    firePositionX = 5000, firePositionY = 5000, firePositionZ = 30,
}, 12000, nil)
T.falsy(np, 'sans position joueur -> pas de jugement de distance')

os.exit(T.summary() and 0 or 1)
