--[[
    FILE:         tests/run_wiring_e2e.lua
    PURPOSE:      TEST DE BOUT EN BOUT du câblage. Charge tous les moteurs + le répartiteur pur
                  (server/dispatch.lua) et fait passer un FLUX D'ÉVÉNEMENTS NORMALISÉS (comme le
                  ferait la couche FiveM). Prouve que :
                    - un flux LÉGITIME ne génère aucun signal ;
                    - un flux de TRICHE déclenche les bons détecteurs À TRAVERS le répartiteur ;
                    - la corrélation (trainer) et la fusion (cote composite) remontent bien ;
                    - le sink reçoit chaque signal (chaîne complète).
    USAGE:        lua5.4 tests/run_wiring_e2e.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
for _, f in ipairs({
    'aimstats', 'flight', 'damage', 'provenance', 'freecam', 'sequence', 'desync', 'budget',
    'esp', 'reach', 'godmode', 'ownership', 'trainer', 'behavior', 'spawnprotect', 'chatspam',
    'teleport', 'selfprotect', 'executor', 'menu', 'crashguard', 'invariants', 'envelope',
    'sprt', 'baseline', 'hitreg', 'fusion', 'markov', 'clocksync',
}) do dofile('server/detection/' .. f .. '.lua') end
dofile('server/reconcile.lua'); dofile('server/reputation.lua')
dofile('server/dispatch.lua')

local C = ZShield.Const
local D = ZShield.Dispatch
ZShield.Log.console = false

-- Active tout ce que le flux va exercer.
ZShield.Config.load({
    flight = { enabled = true }, teleport = { enabled = true, min_jump_m = 100, min_repeats = 3 },
    damage_integrity = { enabled = true, default_base = 60, default_range_m = 120, default_min_ms = 80 },
    aimstats = { enabled = true, min_samples = 30 }, godmode = { enabled = true, min_damage = 5 },
    chatspam = { enabled = true, max_messages = 8 }, menu = { enabled = true },
    crashguard = { enabled = true }, ownership = { enabled = true, max_create = 20 },
    envelope = { enabled = true, quotas = { fire = 10 } }, invariants = { enabled = true },
    trainer = { enabled = true, min_distinct = 3 }, fusion = { enabled = true, threshold = 1.2, decay_per_sec = 0 },
    sequence = { enabled = true }, provenance = { enabled = true, min_amount = 100 },
    executor = { enabled = true, blocklist_patterns = { 'executor' } },
    reconcile = { enabled = true, max_health = 200 },
})

-- Collecteur (rôle du sink en production).
local collected = {}
local function sink(sig) collected[#collected + 1] = sig end
local function has(list, det) for _, s in ipairs(list) do if s.detector == det or (s.metadata and s.metadata.kind == det) then return true end end return false end

-- ===========================================================================
T.section("flux LÉGITIME -> silence")

D.forget(1)
collected = {}
D.handle({ type = 'spawn', source = 1, base = { health = 200, money = 500 }, now = 1000 }, sink)
D.handle({ type = 'give_weapon', source = 1, weapon = 100, ammo = 60, now = 1050 }, sink)   -- arme accordée serveur
D.handle({ type = 'position', source = 1, pos = { x = 0, y = 0, z = 30 }, now = 1500 }, sink)
D.handle({ type = 'position', source = 1, pos = { x = 3, y = 1, z = 30 }, now = 2000 }, sink)
local sigLegit = D.handle({ type = 'damage', source = 1, victim = 2, weapon = 100, damage = 30, dist = 20,
    hp_before = 100, hp_after = 70, now = 2500 }, sink)
T.equal(#sigLegit, 0, "un tir normal via le répartiteur -> aucun signal")
T.equal(#collected, 0, "le sink n'a rien reçu sur le flux légitime")

-- ===========================================================================
T.section("flux TRICHE -> les bons moteurs se déclenchent via le répartiteur")

D.forget(3)
collected = {}
-- 1) Téléport instantané (blink) via position.
local s1 = D.handle({ type = 'position', source = 3, pos = { x = 0, y = 0, z = 30 }, now = 1000 }, sink)
local s2 = D.handle({ type = 'position', source = 3, pos = { x = 300, y = 0, z = 30 }, now = 1200 }, sink)
T.truthy(has(s2, 'flight') or has(s2, 'blink'), "saut de 300 m -> flight/blink via répartiteur")

-- 2) Dégâts modifiés + hors portée.
local d1 = D.handle({ type = 'damage', source = 3, victim = 4, weapon = 100, damage = 300, dist = 20, now = 1300 }, sink)
T.truthy(has(d1, 'damage_integrity') or has(d1, 'modded_damage'), "300 dégâts (base 60) -> damage_integrity")

-- 3) God mode (dégâts encaissés, santé inchangée) — la victime est 4.
local g1 = D.handle({ type = 'damage', source = 3, victim = 4, weapon = 100, damage = 40, dist = 20,
    hp_before = 100, hp_after = 100, now = 1400 }, sink)
T.truthy(has(g1, 'godmode'), "santé victime inchangée sous 40 dégâts -> godmode")

-- 4) Entité malformée (crash).
local c1 = D.handle({ type = 'entity_create', source = 3, attrs = { x = 0 / 0, y = 0, z = 0 }, now = 1450 }, sink)
T.truthy(has(c1, 'crashguard') or has(c1, 'malformed_entity'), "coordonnée NaN -> crashguard")

-- 5) Event de menu.
local m1 = D.handle({ type = 'command', source = 3, name = 'trainer:godmode', now = 1500 }, sink)
T.truthy(has(m1, 'menu') or has(m1, 'menu_signature'), "event de menu -> menu")

T.truthy(#collected > 0, "le sink a bien reçu les signaux de triche (chaîne complète)")

-- ===========================================================================
T.section("corrélation + fusion remontent via le répartiteur")

-- Plusieurs détecteurs sérieux distincts sur le même joueur -> signature trainer + fusion.
local sawTrainer, sawFusion = false, false
for _, s in ipairs(collected) do
    if s.detector == 'trainer' then sawTrainer = true end
    if s.detector == 'fusion' then sawFusion = true end
end
T.truthy(sawTrainer, "détecteurs concomitants -> signature 'trainer' émise par le répartiteur")
T.truthy(sawFusion, "faisceau d'indices -> cote composite 'fusion' émise par le répartiteur")

-- ===========================================================================
T.section("réconciliation via report_value dans la chaîne")

D.forget(7)
collected = {}
D.handle({ type = 'spawn', source = 7, base = { health = 200, money = 500 }, now = 1000 }, sink)
-- Le serveur applique 120 de dégâts (transition autoritaire) puis le client prétend être full.
if ZShield.Reconcile then ZShield.Reconcile.applyDamage(7, 120) end
local rv = D.handle({ type = 'report_value', source = 7, field = 'health', value = 200, now = 1100 }, sink)
T.truthy(has(rv, 'reconcile') or has(rv, 'reconcile_reject'), "santé gonflée rejetée via le répartiteur")

-- ===========================================================================
T.section("anti-flood d'entités via le répartiteur")

D.forget(8)
collected = {}
local flood
for i = 1, 22 do flood = D.handle({ type = 'entity_create', source = 8, attrs = { x = 1, y = 1, z = 1 }, now = 1000 + i }, sink) end
T.truthy(has(flood, 'ownership') or has(flood, 'entity_flood') or has(flood, 'envelope'),
    "22 créations d'entités -> ownership/envelope via le répartiteur")

os.exit(T.summary() and 0 or 1)
