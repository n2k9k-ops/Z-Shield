--[[
    FILE:         tests/run_triggers.lua
    PURPOSE:      Règles d'événements pilotées : liste noire, limite de débit par
                  événement, exceptions. Prouve que chaque réglage a un effet.
    USAGE:        lua5.4 tests/run_triggers.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/firewall/ratelimit.lua')
dofile('server/triggers.lua')

local Tr = ZShield.Triggers
ZShield.Log.console = false

-- ===========================================================================
T.section('liste noire de triggers')

ZShield.Config.load({ game_events = { trigger_blocklist = { 'esx:giveMoney' } } })
T.truthy(Tr.check(1, 'esx:giveMoney').block, 'événement sur liste noire -> bloqué')
T.falsy(Tr.check(1, 'esx:heartbeat').block, 'événement hors liste -> autorisé')

-- ===========================================================================
T.section('exceptions : jamais contrôlées')

ZShield.Config.load({ game_events = {
    trigger_blocklist = { 'esx:heartbeat' },
    trigger_exceptions = { 'esx:heartbeat' },
} })
T.falsy(Tr.check(1, 'esx:heartbeat').block, "l'exception l'emporte sur la liste noire")

-- ===========================================================================
T.section('limite de débit par événement')

Tr.reset()
ZShield.Config.load({ game_events = { trigger_rate_rules = { ['shop:buy'] = 3 } } })
local blocked = false
for i = 1, 10 do
    if Tr.check(2, 'shop:buy').block then blocked = true end
end
T.truthy(blocked, 'au-delà de 3/s le même joueur est bloqué')
-- Un autre événement non limité passe toujours.
T.falsy(Tr.check(2, 'shop:sell').block, 'un événement sans règle de débit passe')

-- ===========================================================================
T.section('aucune règle -> tout passe')

Tr.reset()
ZShield.Config.load({ game_events = {} })
T.falsy(Tr.check(1, 'anything').block, 'sans configuration, aucun événement bloqué')

os.exit(T.summary() and 0 or 1)
