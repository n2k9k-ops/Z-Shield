--[[
    FILE:         tests/run_wave6_authoritative.lua
    PURPOSE:      Vague 6 — couche serveur-autoritative (la plus coriace à contourner) :
                    - reconcile  : la valeur client au-dessus de la vérité serveur est rejetée/corrigée
                    - invariants : registre de règles dures (bornes physiques du jeu)
                    - envelope   : quota de débit par classe d'événement
    USAGE:        lua5.4 tests/run_wave6_authoritative.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/reconcile.lua')
dofile('server/detection/invariants.lua')
dofile('server/detection/envelope.lua')

local C = ZShield.Const
local RC = ZShield.Reconcile
local INV = ZShield.Invariants
local EV = ZShield.Envelope
ZShield.Log.console = false

-- ===========================================================================
T.section("reconcile : la sante gonflee cote client est rejetee et corrigee")

ZShield.Config.load({ reconcile = { enabled = true, max_health = 200, tolerance = 1 } })
RC.forget(1)
RC.spawn(1, { health = 200, armor = 0, money = 500 })
RC.applyDamage(1, 120)   -- verite serveur : 80
local low = RC.report(1, "health", 75)
T.truthy(low.ok, "client rapporte 75 (<= verite) -> accepte")
local cheat = RC.report(1, "health", 200)   -- pretend etre full
T.falsy(cheat.ok, "client rapporte 200 alors que verite = 80 -> rejete")
T.equal(cheat.corrected, 75, "corrige a la verite serveur (75, adoptee au tour precedent)")
T.truthy(cheat.signal and cheat.signal.metadata.kind == "reconcile_reject", "signal de rejet emis")

T.section("reconcile : argent injecte rejete")
RC.forget(2)
RC.spawn(2, { health = 200, money = 500 })
RC.grantMoney(2, 300)   -- verite : 800
local moneyCheat = RC.report(2, "money", 9999999)
T.falsy(moneyCheat.ok, "argent injecte 9,999,999 > verite 800 -> rejete")
T.equal(moneyCheat.corrected, 800, "corrige a 800 (verite serveur)")

T.section("reconcile : munitions infinies rejetees")
RC.forget(3)
RC.spawn(3)
RC.grantAmmo(3, "smg", 30)
RC.consumeAmmo(3, "smg", 10)   -- verite : 20
local ammoCheat = RC.report(3, "ammo", 250, { weapon = "smg" })
T.falsy(ammoCheat.ok, "250 munitions > verite 20 -> rejete")
T.equal(ammoCheat.corrected, 20, "corrige a 20")

T.section("reconcile : desactive -> pas de correction")
ZShield.Config.load({ reconcile = { enabled = false } })
local off = RC.report(1, "health", 200)
T.truthy(off.ok, "reconcile desactive -> valeur client laissee telle quelle")

-- ===========================================================================
T.section("invariants : registre de regles dures")

ZShield.Config.load({ invariants = { enabled = true, max_health = 200, max_armor = 100,
    max_speed_foot = 12, max_money = 1e12, max_coord = 1e6 } })
T.truthy(INV.count() >= 12, "au moins 12 invariants enregistres")
local clean = INV.check(1, { health = 150, armor = 50, money = 5000, speed = 6, mode = "foot",
    x = 100, y = 200, z = 30, scale = 1, stamina = 80 })
T.equal(#clean, 0, "etat sain -> aucune violation")

local dirty = INV.check(1, { health = 500, armor = 200, money = -10, speed = 999, mode = "foot",
    x = 5e9, z = 30, scale = 999, weapon_damage = 400, weapon_base = 60 })
T.truthy(#dirty >= 5, "etat aberrant -> plusieurs invariants violes")
local ids = {}
for _, v in ipairs(dirty) do ids[v.metadata.invariant] = true end
T.truthy(ids["health_le_max"], "sante > max detectee")
T.truthy(ids["speed_le_max"], "vitesse > max detectee")
T.truthy(ids["money_ge_zero"], "argent negatif detecte")
T.truthy(ids["coord_in_world"], "coordonnee hors monde detectee")
T.truthy(ids["weapon_damage_le_base"], "degats > base detectes")

T.section("invariants : desactivation individuelle + globale")
local partial = INV.check(1, { health = 500, disabled = true })
-- health toujours actif ici (pas desactive) :
T.truthy(#partial >= 1, "sante > max toujours prise sans desactivation")
ZShield.Config.load({ invariants = { enabled = true, disabled = { health_le_max = true }, max_health = 200 } })
local dis = INV.check(1, { health = 500 })
T.equal(#dis, 0, "invariant health_le_max desactive individuellement -> ignore")
ZShield.Config.load({ invariants = { enabled = false } })
T.equal(#INV.check(1, { health = 9999 }), 0, "invariants desactives globalement -> rien")

-- ===========================================================================
T.section("envelope : quota de debit par classe")

ZShield.Config.load({ envelope = { enabled = true, window_ms = 10000, default_quota = 60,
    quotas = { fire = 10 } } })
EV.forget(1)
local over
for i = 1, 11 do over = EV.observe(1, "fire", 1000 + i) end
T.truthy(over and over.over, "11 tirs > quota 10 -> bride")
EV.forget(2)
local ok
for i = 1, 5 do ok = EV.observe(2, "chat", 1000 + i * 100) end
T.falsy(ok, "5 messages sous le quota -> ok")
ZShield.Config.load({ envelope = { enabled = false } })
EV.forget(3)
local eoff
for i = 1, 100 do eoff = EV.observe(3, "fire", 1000 + i) end
T.falsy(eoff, "enveloppe desactivee -> aucun bridage")

os.exit(T.summary() and 0 or 1)
