--[[
    FILE:         tests/run_state_vehicle.lua
    PURPOSE:      Détecteurs d'état joueur (vie/armure/invincibilité/régénération) et de
                  véhicule (vitesse impossible / réparation instantanée). Horloge injectée.
    USAGE:        lua5.4 tests/run_state_vehicle.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/health.lua')
dofile('server/detection/vehicle.lua')

local Hp = ZShield.Health2
local Veh = ZShield.Vehicle
ZShield.Log.console = false
ZShield.Config.load({})

-- ===========================================================================
T.section('état : vie/armure au-dessus du maximum')

Hp.forget(1)
local s = Hp.observe(1, { health = 350, max_health = 200, armor = 0 }, 1000)
T.truthy(s, 'vie 350 > max 200 -> signal')
T.equal(s.protection, 'pl_health_over_max', 'protection vie au-dessus du max')
T.equal(s.category, 'state', 'catégorie state')

Hp.forget(2)
s = Hp.observe(2, { health = 100, armor = 200, max_health = 200 }, 1000)
T.equal(s and s.protection, 'pl_armor', 'armure 200 > max -> pl_armor')

-- Vie normale : rien.
Hp.forget(3)
T.falsy(Hp.observe(3, { health = 100, armor = 0, max_health = 200 }, 1000), 'vie normale -> rien')

-- ===========================================================================
T.section('état : régénération instantanée répétée')

Hp.forget(4)
Hp.observe(4, { health = 100, max_health = 200 }, 1000)  -- base
Hp.observe(4, { health = 40,  max_health = 200 }, 1200)  -- dégâts
Hp.observe(4, { health = 100, max_health = 200 }, 1300)  -- re-full instantané (x1)
Hp.observe(4, { health = 40,  max_health = 200 }, 1500)  -- dégâts
local r = Hp.observe(4, { health = 100, max_health = 200 }, 1600)  -- re-full (x2)
T.truthy(r, 'deux re-full rapprochés -> signal')
T.equal(r.protection, 'pl_regen', 'protection régénération')

-- ===========================================================================
T.section('état : invincibilité (dégâts subis, vie inchangée)')

Hp.forget(5)
Hp.observe(5, { health = 100, max_health = 200, expected_damage = 0 }, 1000)
Hp.observe(5, { health = 100, max_health = 200, expected_damage = 40 }, 1100) -- x1
local inv = Hp.observe(5, { health = 100, max_health = 200, expected_damage = 40 }, 1200) -- x2
T.truthy(inv, 'dégâts encaissés sans perte de vie -> signal')
T.equal(inv.protection, 'pl_invincible', 'protection invincibilité')

-- ===========================================================================
T.section('véhicule : vitesse impossible')

Veh.forget(6)
local v = Veh.observe(6, { speed_ms = 220 }, 1000)  -- ~790 km/h
T.truthy(v, 'vitesse 220 m/s -> signal')
T.equal(v.protection, 'vh_speed', 'protection vitesse véhicule')
T.equal(v.category, 'entity', 'catégorie entity')

-- Vitesse normale : rien.
Veh.forget(7)
T.falsy(Veh.observe(7, { speed_ms = 40 }, 1000), 'vitesse normale -> rien')

-- ===========================================================================
T.section('véhicule : réparation instantanée répétée')

Veh.forget(8)
Veh.observe(8, { vehicle_health = 300 }, 1000)   -- abîmé
Veh.observe(8, { vehicle_health = 1000 }, 1200)  -- réparé (x1)
Veh.observe(8, { vehicle_health = 200 }, 1400)   -- réabîmé
local rep = Veh.observe(8, { vehicle_health = 1000 }, 1600) -- réparé (x2)
T.truthy(rep, 'deux réparations rapprochées -> signal')
T.equal(rep.protection, 'vh_repair', 'protection réparation instantanée')

-- ===========================================================================
T.section('vol de véhicule (véhicule terrestre maintenu en l air)')

Veh.forget(9)
-- Véhicule terrestre en l'air longtemps et haut -> signal vh_fly.
local fly = Veh.observe(9, { is_aircraft = false, airborne_ms = 6000, altitude_m = 20 }, 2000)
T.truthy(fly, 'véhicule terrestre aéroporté longtemps -> signal')
T.equal(fly.protection, 'vh_fly', 'protection vol de véhicule')
-- Un avion en l'air : normal, aucun signal.
Veh.forget(10)
T.falsy(Veh.observe(10, { is_aircraft = true, airborne_ms = 60000, altitude_m = 500 }, 2000),
    'aéronef en vol -> aucun signal (pas de FP)')
-- Un saut de rampe (bref, bas) : aucun signal.
Veh.forget(11)
T.falsy(Veh.observe(11, { is_aircraft = false, airborne_ms = 800, altitude_m = 3 }, 2000),
    'saut bref/bas -> aucun signal (pas de FP)')

os.exit(T.summary() and 0 or 1)
