--[[
    FILE:         tests/run_connection.lua
    PURPOSE:      Contrôle à la connexion : score de menace et refus au-delà du seuil.
    USAGE:        lua5.4 tests/run_connection.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/connection.lua')

local Conn = ZShield.Connection
ZShield.Log.console = false

-- ===========================================================================
T.section('connexion : joueur légitime autorisé')

ZShield.Config.load({})
local ok = Conn.assess({ name = 'Lucas_Martin',
    identifiers = { license = 'lic:aaa', steam = 'steam:1', discord = 'discord:1' } })
T.truthy(ok.allow, 'identifiants complets, nom propre -> autorisé')
T.equal(ok.threat, 0, 'score de menace nul')

-- ===========================================================================
T.section('connexion : signaux qui montent le score')

ZShield.Config.load({ connection = { require_alphanumeric = true, require_discord = true,
    anti_vpn = true, max_threat_score = 60 } })

-- Nom avec caractères d'exploit + pas de Discord + VPN : refusé.
local bad = Conn.assess({ name = '☠x\0hack', vpn = true,
    identifiers = { license = 'lic:bbb' } })
T.falsy(bad.allow, 'nom exploit + vpn + pas de discord -> refusé')
T.truthy(bad.threat >= 60, 'score au-dessus du seuil')

-- ===========================================================================
T.section('connexion : identifiant manquant + duplication')

ZShield.Config.load({ connection = { max_threat_score = 40 } })
Conn.noteConnected('lic:ccc')
local dup = Conn.assess({ name = 'Enzo', identifiers = { license = 'lic:ccc' } })
T.falsy(dup.allow, 'même licence déjà connectée -> refusé (duplication 50)')
Conn.noteDisconnected('lic:ccc')
local okAgain = Conn.assess({ name = 'Enzo', identifiers = { license = 'lic:ccc' } })
T.truthy(okAgain.allow, 'après déconnexion -> ré-autorisé')

os.exit(T.summary() and 0 or 1)
