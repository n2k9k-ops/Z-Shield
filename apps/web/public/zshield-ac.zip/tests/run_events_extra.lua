--[[
    FILE:         tests/run_events_extra.lua
    PURPOSE:      Vérifs d'événements armes/véhicules pilotées par config, plus
                  exceptions de motifs d'exécution, anti-LUA-input, anti-unisolated,
                  et type de preuve (screenshot/enregistrement) via le reporter.
    USAGE:        lua5.4 tests/run_events_extra.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/incident.lua')
dofile('server/detection/injection.lua')
dofile('server/events_extra.lua')
dofile('server/reporter.lua')

local C = ZShield.Const
local EX = ZShield.EventsExtra
local Inj = ZShield.Injection
local Rep = ZShield.Reporter
ZShield.Log.console = false

-- ===========================================================================
T.section('armes : give / remove / munitions / infinies')

ZShield.Config.load({ weapon = { anti_give = true } })
T.truthy(EX.checkGiveWeapon(1, 123, { authorized = false }).block, 'give non autorisé -> bloqué')
T.falsy(EX.checkGiveWeapon(1, 123, { authorized = true }).block, 'give autorisé par le serveur -> permis')
ZShield.Config.load({ weapon = { anti_give = false } })
T.falsy(EX.checkGiveWeapon(1, 123, { authorized = false }).block, 'option OFF -> aucun blocage')

ZShield.Config.load({ weapon = { anti_remove = true } })
T.truthy(EX.checkRemoveWeapon(1, 2).block, 'retrait arme autrui -> bloque')
T.falsy(EX.checkRemoveWeapon(1, 1).block, 'retirer sa propre arme -> permis')

ZShield.Config.load({ weapon = { anti_ammo = true, max_ammo_gain = 250 } })
T.truthy(EX.checkAmmo(1, 9999, { pickup = false }).block, 'gain de munitions énorme sans pickup -> bloqué')
T.falsy(EX.checkAmmo(1, 30, { pickup = false }).block, 'petit gain -> permis')

ZShield.Config.load({ weapon = { anti_infinite_ammo = true } })
T.truthy(EX.checkInfiniteAmmo(1, 20, 0).block, '20 tirs sans consommation -> munitions infinies')

-- ===========================================================================
T.section('véhicules : throwing / hijack / plaque / contrôle / attache / spawn IA')

ZShield.Config.load({ vehicle = { anti_throw = true, throw_speed_ms = 50 } })
T.truthy(EX.checkVehicleThrow(1, 120, { occupied = false }).block, 'vehicule vide projete 120ms -> bloque')
T.falsy(EX.checkVehicleThrow(1, 120, { occupied = true }).block, 'véhicule conduit -> non concerné')

ZShield.Config.load({ vehicle = { anti_hijack = true } })
T.truthy(EX.checkVehicleHijack(1, { occupied = true, owner = 2 }).block, 'hijack vehicule occupe autrui -> bloque')
T.falsy(EX.checkVehicleHijack(2, { occupied = true, owner = 2 }).block, 'le proprietaire nest pas concerne')

ZShield.Config.load({ vehicle = { anti_plate_change = true } })
T.truthy(EX.checkPlateChange(1, { from = 'AAA111', to = 'ZZZ999' }).block, 'changement de plaque -> bloqué')

ZShield.Config.load({ vehicle = { anti_control_request = true } })
T.truthy(EX.checkControlRequest(1, 2).block, 'requete controle vehicule autrui -> bloquee')

ZShield.Config.load({ vehicle = { anti_attachment = true } })
T.truthy(EX.checkAttachment(1, {}).block, 'attache entites -> bloquee')

ZShield.Config.load({ entity = { anti_ai_vehicle_spawn = true } })
T.truthy(EX.checkAISpawn(nil, 'vehicle', true).block, 'spawn véhicule par IA -> bloqué')
ZShield.Config.load({ entity = { anti_ai_ped_spawn = true } })
T.truthy(EX.checkAISpawn(nil, 'ped', true).block, 'spawn ped par IA -> bloqué')

ZShield.Config.load({ game_events = { anti_forced_ragdoll = true } })
T.truthy(EX.checkForcedRagdoll(1, 2).block, 'ragdoll force sur autrui -> bloque')
T.falsy(EX.checkForcedRagdoll(1, 1).block, 'ragdoll sur soi -> permis')

ZShield.Config.load({ vehicle = { auto_delete_destroyed = true } })
T.truthy(EX.shouldAutoDelete({ destroyed = true }), 'véhicule détruit -> auto-suppression')
T.falsy(EX.shouldAutoDelete({ destroyed = false }), 'véhicule intact -> conservé')

-- ===========================================================================
T.section('injection : exceptions de motifs, anti-LUA-input, anti-unisolated')

ZShield.Config.load({ injection = { execution_exceptions = { 'my_pattern' } } })
Inj.reset(1); Inj.trace(1, 'exec_outside_resource', { pattern = 'my_pattern' })
T.equal(Inj.total(1), 0, 'motif exempté -> trace non comptée')
Inj.reset(2); Inj.trace(2, 'exec_outside_resource', { pattern = 'evil_pattern' })
T.truthy(Inj.total(2) > 0, 'motif non exempté -> trace comptée')

ZShield.Config.load({ injection = { anti_lua_input = true } })
Inj.reset(3); Inj.luaInput(3, {})
T.truthy(Inj.total(3) > 0, 'anti-LUA-input actif -> trace enregistrée')
ZShield.Config.load({ injection = { anti_lua_input = false } })
Inj.reset(4); Inj.luaInput(4, {})
T.equal(Inj.total(4), 0, 'anti-LUA-input inactif -> rien')

ZShield.Config.load({ injection = { anti_unisolated = true } })
Inj.reset(5); Inj.unisolated(5, {})
T.truthy(Inj.total(5) > 0, 'anti-unisolated actif -> trace enregistrée')

-- ===========================================================================
T.section('preuve : screenshot / enregistrement pilotent evidence_kind')

local inc = { id = 'inc_ev', source = 1, detector = 'weapon.firerate',
    category = C.CATEGORY.DAMAGE, severity = C.SEVERITY.HIGH, risk_after = 70,
    context = { identity = { scope = 'license', identifier = 'license:abc' } } }
ZShield.Config.load({ evidence = { gameplay_recording = true } })
T.equal(Rep.alertOf(inc).sanction.evidence_kind, 'clip', 'enregistrement -> preuve = clip')
ZShield.Config.load({ evidence = { screenshot = true } })
T.equal(Rep.alertOf(inc).sanction.evidence_kind, 'screenshot', 'screenshot -> preuve = capture')

os.exit(T.summary() and 0 or 1)
