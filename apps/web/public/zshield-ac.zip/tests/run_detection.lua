--[[
    FILE:         tests/run_detection.lua
    PURPOSE:      Tests du quatuor détection → corrélation → risque (§10-14, §55). Prouve la
                  séparation severity/confidence/risk (§11), la décroissance temporelle
                  (§14), l'isolation des détecteurs fautifs (§104), et que corrélation ≠
                  preuve (§12).
    USAGE:        lua5.4 tests/run_detection.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/engine.lua'); dofile('server/detection/correlation.lua'); dofile('server/detection/risk.lua')

local C = ZShield.Const
local Detection = ZShield.Detection
local Correlation = ZShield.Correlation
local Risk = ZShield.Risk
local Config = ZShield.Config

ZShield.Log.console = false
local _rawLoad = Config.load
Config.load = function(raw) local ok, r = _rawLoad(raw); ZShield.Log.console = false; return ok, r end
Config.load({ mode = 'ENFORCE' })
H.reset()

-- ===========================================================================
T.section('détection : interface et normalisation §10')

Detection.detectors = {}; Detection.order = {}; Detection.health = {}
Detection.stats = { evaluated = 0, signals = 0, detector_errors = 0 }

local ok = Detection.register({
    id = 'test.high_certain', category = C.CATEGORY.MOVEMENT,
    evaluate = function(ctx)
        if ctx.trigger then return { severity = 'HIGH', confidence = 1.0, reason = 'certain' } end
        return nil
    end,
})
T.truthy(ok, 'détecteur enregistré')
T.falsy((Detection.register({ id = 'test.high_certain', evaluate = function() end })), 'doublon rejeté')
T.falsy((Detection.register({ id = 'no_eval' })), 'détecteur sans evaluate rejeté')

-- Un détecteur qui ne trigger pas ne produit rien.
local signals = Detection.evaluate({ trigger = false })
T.equal(#signals, 0, 'aucun signal si pas de trigger')

-- Trigger : un signal produit, score = poids(HIGH=35) × confidence(1.0) = 35.
signals = Detection.evaluate({ trigger = true })
T.equal(#signals, 1, 'un signal produit')
T.equal(signals[1].score, 35, 'score = poids(HIGH) × confiance(1.0) = 35')
T.equal(signals[1].severity, 'HIGH', 'severity conservée séparément')
T.equal(signals[1].confidence, 1.0, 'confidence conservée séparément')

-- ===========================================================================
T.section('détection : séparation severity/confidence/risk §11 (anti faux positif)')

Detection.detectors = {}; Detection.order = {}; Detection.health = {}
-- Le cas critique de §11 : anomalie spectaculaire (HIGH) mais incertaine (0.2).
Detection.register({
    id = 'test.spectacular_uncertain', category = C.CATEGORY.MOVEMENT,
    evaluate = function() return { severity = 'HIGH', confidence = 0.2, reason = 'flashy but unsure' } end,
})
signals = Detection.evaluate({})
T.equal(signals[1].severity, 'HIGH', 'la gravité reste HIGH (spectaculaire)')
-- Mais le score est faible : 35 × 0.2 = 7. Une telle anomalie ne doit PAS sanctionner.
T.equal(signals[1].score, 7, 'score faible malgré gravité HIGH (7 = 35×0.2) §11')

-- Comparaison : un CRITICAL certain pèse bien plus.
Detection.detectors = {}; Detection.order = {}; Detection.health = {}
Detection.register({
    id = 'test.critical_certain',
    evaluate = function() return { severity = 'CRITICAL', confidence = 0.95, reason = 'sure' } end,
})
local critSig = Detection.evaluate({})[1]
T.truthy(critSig.score > 60, 'CRITICAL certain pèse lourd (' .. critSig.score .. ' > 60)')
T.truthy(critSig.score > signals[1].score * 8, 'CRITICAL certain >> HIGH incertain')

-- confidence absente -> traitée comme incertaine (0.5), jamais 1.0.
Detection.detectors = {}; Detection.order = {}; Detection.health = {}
Detection.register({ id = 'test.no_conf', evaluate = function() return { severity = 'MEDIUM', reason = 'x' } end })
local noConf = Detection.evaluate({})[1]
T.equal(noConf.confidence, 0.5, 'confidence absente = 0.5 (incertain, pas coupable)')

-- severity invalide -> signal rejeté, pas de crash.
Detection.detectors = {}; Detection.order = {}; Detection.health = {}
Detection.register({ id = 'test.bad_sev', evaluate = function() return { severity = 'EXTREME', confidence = 1 } end })
T.equal(#Detection.evaluate({}), 0, 'severity invalide -> signal ignoré')

-- ===========================================================================
T.section('détection : détecteur fautif isolé §104')

Detection.detectors = {}; Detection.order = {}; Detection.health = {}
Detection.stats = { evaluated = 0, signals = 0, detector_errors = 0 }
Detection.register({ id = 'test.good1', evaluate = function() return { severity = 'LOW', confidence = 1 } end })
Detection.register({ id = 'test.bad', evaluate = function() error('detector boom') end })
Detection.register({ id = 'test.good2', evaluate = function() return { severity = 'LOW', confidence = 1 } end })

signals = Detection.evaluate({})
T.equal(#signals, 2, 'les deux détecteurs sains produisent malgré le fautif §104')
T.equal(Detection.stats.detector_errors, 1, 'erreur du détecteur comptée')

-- Le fautif est marqué DEGRADED.
local degraded = false
for _, d in ipairs(Detection.list()) do if d.id == 'test.bad' and d.health == 'DEGRADED' then degraded = true end end
T.truthy(degraded, 'détecteur fautif marqué DEGRADED')

-- Récupération : si le détecteur redevient sain, il repasse HEALTHY.
Detection.detectors['test.bad'].evaluate = function() return nil end
Detection.evaluate({})
local recovered = false
for _, d in ipairs(Detection.list()) do if d.id == 'test.bad' and d.health == 'HEALTHY' then recovered = true end end
T.truthy(recovered, 'détecteur rétabli repasse HEALTHY §104')

-- ===========================================================================
T.section('corrélation : multi-signaux §12')

H.reset()
Correlation.players = {}
Correlation.attach() -- s'abonne au bus

-- Répétition du MÊME détecteur : pas une corrélation (une seule catégorie).
Detection.detectors = {}; Detection.order = {}; Detection.health = {}
Detection.emit({ detector = 'movement.speed', category = C.CATEGORY.MOVEMENT, severity = 'MEDIUM', confidence = 0.8, source = 1 })
Detection.emit({ detector = 'movement.speed', category = C.CATEGORY.MOVEMENT, severity = 'MEDIUM', confidence = 0.8, source = 1 })
local corr = Correlation.correlate(1)
T.equal(corr.signal_count, 2, 'deux signaux enregistrés')
T.equal(corr.distinct_categories, 1, 'une seule catégorie')
T.falsy(corr.correlated, 'répétition d une catégorie n est PAS une corrélation')

-- Catégories DISTINCTES dans la fenêtre : corrélation reconnue.
Detection.emit({ detector = 'entity.spam', category = C.CATEGORY.ENTITY, severity = 'MEDIUM', confidence = 0.8, source = 1 })
corr = Correlation.correlate(1)
T.equal(corr.distinct_categories, 2, 'deux catégories distinctes')
T.truthy(corr.correlated, 'catégories distinctes -> corrélation §12')

-- La corrélation est un CONTEXTE explicable, pas une preuve : elle expose ses signaux.
T.truthy(#corr.signals >= 2, 'corrélation expose ses signaux pour la chaîne de preuve §29')
T.truthy(corr.combined_score > 0, 'score combiné calculé')
T.truthy(corr.max_severity ~= nil, 'gravité max exposée')

-- Fenêtre temporelle : un signal ancien sort de la fenêtre.
H.reset()
Correlation.players = {}
Detection.emit({ detector = 'a', category = C.CATEGORY.EVENT, severity = 'LOW', confidence = 1, source = 2 })
H.advance(7000) -- au-delà de la fenêtre par défaut (6000)
Detection.emit({ detector = 'b', category = C.CATEGORY.ENTITY, severity = 'LOW', confidence = 1, source = 2 })
corr = Correlation.correlate(2)
T.equal(corr.signal_count, 1, 'signal hors fenêtre exclu (seul le récent compte)')
T.falsy(corr.correlated, 'un seul signal dans la fenêtre -> pas de corrélation')

-- ===========================================================================
T.section('risque : accumulation et niveaux §13')

H.reset()
Risk.players = {}
Config.load({ mode = 'ENFORCE', scoring = { thresholds = { observe = 20, suspicious = 40, high_risk = 65, critical = 85 } } })

T.equal(Risk.score(1), 0, 'score initial 0')
T.equal(Risk.level(1), 'NORMAL', 'niveau initial NORMAL')

-- Ajouter des signaux monte le score et le niveau.
Risk.addSignal(1, { detector = 'd', severity = 'MEDIUM', confidence = 0.9, score = 25 })
T.equal(Risk.level(1), 'OBSERVE', 'score 25 -> OBSERVE')
Risk.addSignal(1, { detector = 'd', severity = 'HIGH', confidence = 0.9, score = 30 })
T.equal(Risk.level(1), 'SUSPICIOUS', 'score 55 -> SUSPICIOUS')
Risk.addSignal(1, { detector = 'd', severity = 'CRITICAL', confidence = 0.9, score = 40 })
T.truthy(Risk.score(1) >= 85, 'score cumulé')
T.equal(Risk.level(1), 'CRITICAL', 'score >= 85 -> CRITICAL')

-- Le score est borné à 100.
Risk.addSignal(1, { detector = 'd', severity = 'CRITICAL', confidence = 1, score = 70 })
T.equal(Risk.score(1), 100, 'score borné à 100')

-- ===========================================================================
T.section('risque : décroissance temporelle §14')

H.reset()
Risk.players = {}
Config.load({ mode = 'ENFORCE', scoring = { decay = true, decay_half_life_s = 60 } }) -- demi-vie 60s

Risk.addSignal(1, { detector = 'd', severity = 'CRITICAL', confidence = 1, score = 80 })
T.equal(math.floor(Risk.score(1)), 80, 'score initial 80')

-- Après une demi-vie (60s), le score est divisé par deux.
H.advance(60000)
local decayed = Risk.score(1)
T.truthy(decayed >= 39 and decayed <= 41, 'après 1 demi-vie: ~40 (got ' .. math.floor(decayed) .. ')')

-- Après une seconde demi-vie, encore /2.
H.advance(60000)
decayed = Risk.score(1)
T.truthy(decayed >= 19 and decayed <= 21, 'après 2 demi-vies: ~20 (got ' .. math.floor(decayed) .. ')')

-- Un score non alimenté finit par retomber sous le plancher -> 0.
H.advance(600000) -- 10 min
T.equal(Risk.score(1), 0, 'score non alimenté finit à 0 §14')

-- decay désactivé : le score ne bouge pas.
H.reset(); Risk.players = {}
Config.load({ mode = 'ENFORCE', scoring = { decay = false } })
Risk.addSignal(2, { detector = 'd', severity = 'HIGH', confidence = 1, score = 50 })
H.advance(3600000) -- 1h
T.equal(math.floor(Risk.score(2)), 50, 'decay off: score inchangé')

-- ===========================================================================
T.section('risque : explication légitime §13 et snapshot')

H.reset(); Risk.players = {}
Config.load({ mode = 'ENFORCE', scoring = { decay = true, decay_half_life_s = 600 } })
Risk.addSignal(1, { detector = 'movement', severity = 'HIGH', confidence = 0.8, score = 40 })
local scoreBefore = Risk.score(1)
-- Un admin confirme un téléport légitime : le score baisse (§13).
Risk.explain(1, 'admin confirmed legitimate teleport', 25)
T.truthy(Risk.score(1) < scoreBefore, 'explication légitime réduit le score §13')

-- Snapshot explicable.
local snap = Risk.snapshot(1)
T.truthy(snap.signal_count >= 1, 'snapshot contient l historique')
T.truthy(snap.history[1].detector ~= nil, 'historique nomme le détecteur (explicabilité §152)')
T.truthy(snap.level ~= nil, 'snapshot expose le niveau')

-- ===========================================================================
T.section('chaîne complète : signal -> corrélation -> risque via bus')

H.reset()
Risk.players = {}; Correlation.players = {}
Config.load({ mode = 'ENFORCE', scoring = { decay = true, decay_half_life_s = 600, thresholds = { observe = 20, suspicious = 40, high_risk = 65, critical = 85 } } })
Risk.attach()      -- risque s'abonne au bus
Correlation.attach() -- corrélation s'abonne au bus

Detection.detectors = {}; Detection.order = {}; Detection.health = {}
-- Un signal émis alimente automatiquement corrélation ET risque via le bus.
Detection.emit({ detector = 'movement.teleport', category = C.CATEGORY.MOVEMENT, severity = 'HIGH', confidence = 0.9, score = 31.5, source = 99 })
T.truthy(Risk.score(99) > 0, 'signal émis alimente le risque via le bus')
T.truthy(Correlation.count(99) >= 1, 'signal émis alimente la corrélation via le bus')

os.exit(T.summary() and 0 or 1)
