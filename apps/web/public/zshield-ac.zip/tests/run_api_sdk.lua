--[[
    FILE:         tests/run_api_sdk.lua
    PURPOSE:      Tests de l'API publique (§45) et du SDK de sécurité (§76-77, §55). Prouve
                  que l'exemple exact de la spec (§77) fonctionne, que les validateurs
                  composables (permission, distance, état, cooldown) marchent, et que l'API
                  valide ses entrées.
    USAGE:        lua5.4 tests/run_api_sdk.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/firewall/ratelimit.lua'); dofile('server/context.lua'); dofile('server/firewall/firewall.lua')
dofile('server/detection/engine.lua'); dofile('server/detection/correlation.lua'); dofile('server/detection/risk.lua')
dofile('server/incident.lua'); dofile('server/detection/economy.lua')
dofile('server/api.lua'); dofile('server/sdk.lua')

local C = ZShield.Const
local Security = ZShield.Security
local Firewall = ZShield.Firewall
local Context = ZShield.Context
local Config = ZShield.Config

ZShield.Log.console = false
local _rawLoad = Config.load
Config.load = function(raw) local ok, r = _rawLoad(raw); ZShield.Log.console = false; return ok, r end
Config.load({ mode = 'ENFORCE', events = { unknown_policy = 'monitor' } })
H.reset()

-- ===========================================================================
T.section('API publique : accès de base §45')

T.equal(ZShield.GetVersion(), C.VERSION, 'GetVersion renvoie la version')

Context.init(1); Context.forceState(1, 'ACTIVE')
T.equal(ZShield.GetPlayerState(1), 'ACTIVE', 'GetPlayerState renvoie l état')
T.equal(ZShield.GetPlayerState(999), nil, 'GetPlayerState nil pour joueur inconnu')

local score, level = ZShield.GetRisk(1)
T.equal(score, 0, 'GetRisk : score initial 0')
T.equal(level, 'NORMAL', 'GetRisk : niveau NORMAL')

-- ===========================================================================
T.section('API publique : validation des entrées §54')

-- CreateIncident valide sa spec.
local id = ZShield.CreateIncident({ source = 1, detector = 'custom.d', severity = 'HIGH', confidence = 0.8, risk_after = 70 })
T.truthy(id ~= nil, 'CreateIncident renvoie un id')
T.truthy(id:match('^inc_'), 'id d incident valide')

-- Spec invalide rejetée (severity manquante).
local badId, err = ZShield.CreateIncident({ source = 1, detector = 'x' })
T.falsy(badId, 'CreateIncident rejette une spec sans severity §54')
T.truthy(err ~= nil, 'erreur retournée')

-- AddSignal valide.
T.truthy((ZShield.AddSignal({ detector = 'ext.d', severity = 'MEDIUM', confidence = 0.6, source = 1 })), 'AddSignal accepte un signal valide')
T.falsy((ZShield.AddSignal({ detector = 'ext.d', severity = 'BOGUS' })), 'AddSignal rejette une severity invalide')

-- ===========================================================================
T.section('SDK : exemple exact de la spec §77')

H.reset()
Firewall.events = {}
Context.init(2); Context.forceState(2, 'ACTIVE')

-- L'exemple conceptuel de §77, tel quel :
local bought = {}
local ok = Security:ProtectEvent('shop:buy', {
    schema = { type = 'table', fields = { item = { type = 'string', required = true } } },
    rateLimit = 2, -- 2 par seconde
    validate = function(ctx)
        return ctx.args.item ~= 'forbidden_item'
    end,
    execute = function(ctx)
        bought[#bought + 1] = ctx.args.item
    end,
})
T.truthy(ok, 'ProtectEvent enregistre l event (exemple §77)')

-- L'event fonctionne.
local v = Firewall.dispatch('shop:buy', 2, { item = 'medkit' })
T.equal(v, C.VERDICT.ALLOW, 'achat valide autorisé')
T.equal(bought[1], 'medkit', 'exécution réalisée')

-- La règle métier rejette l'item interdit.
v = Firewall.dispatch('shop:buy', 2, { item = 'forbidden_item' })
T.equal(v, C.VERDICT.REJECT, 'item interdit rejeté par validate §77')

-- Le rate limit s'applique (2/s).
Firewall.dispatch('shop:buy', 2, { item = 'a' })
Firewall.dispatch('shop:buy', 2, { item = 'b' })
v = Firewall.dispatch('shop:buy', 2, { item = 'c' })
T.equal(v, C.VERDICT.RATE_LIMIT, 'rate limit 2/s appliqué §77')

-- ===========================================================================
T.section('SDK : validateur de permission §76')

H.reset()
Firewall.events = {}
Context.init(3); Context.forceState(3, 'ACTIVE')

Security:ProtectEvent('admin:kick', {
    permission = 'admin',
    execute = function() end,
})

-- Sans la permission : refusé.
v = Firewall.dispatch('admin:kick', 3, {})
T.equal(v, C.VERDICT.UNAUTHORIZED, 'sans permission -> refusé §76')

-- Avec la permission (calculée serveur, stockée dans le contexte) : autorisé.
Context.set(3, 'perm.admin', true)
v = Firewall.dispatch('admin:kick', 3, {})
T.equal(v, C.VERDICT.ALLOW, 'avec permission -> autorisé §76')

-- Permission comme fonction.
H.reset(); Firewall.events = {}
Context.init(4); Context.forceState(4, 'ACTIVE')
Security:ProtectEvent('vip:action', {
    permission = function(ctx) return ctx.source == 4 end,
    execute = function() end,
})
T.equal(Firewall.dispatch('vip:action', 4, {}), C.VERDICT.ALLOW, 'permission-fonction autorise')

-- ===========================================================================
T.section('SDK : validateur de distance §76')

H.reset()
Firewall.events = {}
Context.init(5); Context.forceState(5, 'ACTIVE')
-- Position serveur connue du joueur.
Context.updatePosition(5, { x = 100, y = 100, z = 0 })

Security:ProtectEvent('object:interact', {
    validate = Security:RequireDistance(function(ctx) return { x = 105, y = 100, z = 0 } end, 10),
    execute = function() end,
})
-- Cible à 5 m : autorisé.
T.equal(Firewall.dispatch('object:interact', 5, {}), C.VERDICT.ALLOW, 'interaction proche autorisée §76')

-- Cible lointaine : refusé.
H.reset(); Firewall.events = {}
Context.init(6); Context.forceState(6, 'ACTIVE')
Context.updatePosition(6, { x = 0, y = 0, z = 0 })
Security:ProtectEvent('object:interact_far', {
    validate = Security:RequireDistance(function() return { x = 500, y = 0, z = 0 } end, 10),
    execute = function() end,
})
T.equal(Firewall.dispatch('object:interact_far', 6, {}), C.VERDICT.REJECT, 'interaction à distance impossible refusée §76')

-- ===========================================================================
T.section('SDK : ValidatePlayer et RequireContext §76 §08')

H.reset()
Context.init(7); Context.forceState(7, 'ACTIVE')
T.truthy(Security:ValidatePlayer(7), 'joueur ACTIVE valide')
Context.forceState(7, 'CONNECTING')
T.falsy(Security:ValidatePlayer(7), 'joueur CONNECTING non valide')
T.falsy(Security:ValidatePlayer(999), 'joueur inconnu non valide')

-- RequireContext comme validateur dynamique.
H.reset(); Firewall.events = {}
Context.init(8); Context.forceState(8, 'MISSION')
Security:ProtectEvent('mission:complete', {
    validate = Security:RequireContext({ 'MISSION' }),
    execute = function() end,
})
T.equal(Firewall.dispatch('mission:complete', 8, {}), C.VERDICT.ALLOW, 'action valide en MISSION')
Context.forceState(8, 'ACTIVE')
T.equal(Firewall.dispatch('mission:complete', 8, {}), C.VERDICT.REJECT, 'même action refusée hors MISSION §08')

-- ===========================================================================
T.section('SDK : cooldown et contrat §76 §75')

H.reset(); Firewall.events = {}
Context.init(9); Context.forceState(9, 'ACTIVE')
Security:ProtectEvent('respawn', {
    rateLimit = Security:Cooldown(2000), -- 2 s entre respawns
    execute = function() end,
})
T.equal(Firewall.dispatch('respawn', 9, {}), C.VERDICT.ALLOW, 'premier respawn')
T.equal(Firewall.dispatch('respawn', 9, {}), C.VERDICT.RATE_LIMIT, 'respawn immédiat bloqué (cooldown)')
H.advance(2000)
T.equal(Firewall.dispatch('respawn', 9, {}), C.VERDICT.ALLOW, 'respawn après cooldown')

-- Contrat de sécurité (§75).
Security:RegisterContract({
    resource = 'my_shop',
    events = { 'shop:buy', 'shop:sell' },
    permissions = { 'shop.access' },
})
local contracts = Security:GetContracts()
T.truthy(contracts.my_shop ~= nil, 'contrat enregistré §75')
T.equal(#contracts.my_shop.events, 2, 'contrat liste les events')

-- ===========================================================================
T.section('API : trusted teleport et transaction §45')

H.reset()
Context.init(10); Context.forceState(10, 'ACTIVE')
T.truthy((ZShield.RegisterTrustedTeleport(10, { to = { x = 1, y = 2, z = 3 }, reason = 'admin' })), 'RegisterTrustedTeleport OK')
T.falsy((ZShield.RegisterTrustedTeleport(10, { reason = 'bad' })), 'téléport sans destination rejeté')

local ok2, res = ZShield.ApplyTransaction({ account = 10, delta = 100, reason = 'test' })
T.truthy(ok2, 'ApplyTransaction OK')
T.equal(ZShield.Economy.balance(10), 100, 'transaction appliquée via API')

os.exit(T.summary() and 0 or 1)
