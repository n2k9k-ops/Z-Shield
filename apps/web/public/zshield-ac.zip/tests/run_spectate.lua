--[[
    FILE:         tests/run_spectate.lua
    PURPOSE:      Observation serveur-autoritative (Multi-vue) : enregistrement des
                  sessions, exécuteur injecté, arrêt, et absence d'exécuteur (la
                  demande est enregistrée sans prétendre observer).
    USAGE:        lua5.4 tests/run_spectate.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('server/spectate.lua')

local Spectate = ZShield.Spectate
ZShield.Log.console = false

-- ===========================================================================
T.section('sans exécuteur : demande enregistrée, pas de prétention')

Spectate.setExecutor(nil)
local ok, note = Spectate.request('license:abc', 'usr_admin')
T.truthy(ok, 'la demande est acceptée')
T.equal(note, 'no_executor', "signale honnetement l'absence de camera branchee")
T.truthy(Spectate.isActive('license:abc'), 'session enregistrée')
T.equal(#Spectate.active(), 1, 'une observation en cours')

-- ===========================================================================
T.section('avec exécuteur injecté : la caméra reçoit start/stop')

local calls = {}
Spectate.setExecutor(function(action, target, meta)
    calls[#calls + 1] = { action = action, target = target, admin = meta and meta.admin }
end)

Spectate.request('steam:110000100000001', 'usr_mod')
T.equal(calls[1].action, 'start', 'exécuteur appelé avec start')
T.equal(calls[1].target, 'steam:110000100000001', 'bonne cible')
T.equal(calls[1].admin, 'usr_mod', 'admin transmis')

Spectate.stop('steam:110000100000001')
T.equal(calls[2].action, 'stop', 'exécuteur appelé avec stop')
T.falsy(Spectate.isActive('steam:110000100000001'), 'session close après stop')

-- ===========================================================================
T.section('garde-fous')

local bad = Spectate.request(nil, 'x')
T.falsy(bad, 'cible vide -> refusée')

os.exit(T.summary() and 0 or 1)
