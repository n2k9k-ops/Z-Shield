--[[
    FILE:         tests/run_injection.lua
    PURPOSE:      Système de traces d'injection : accumulation de preuves confirmées,
                  seuil de bannissement, et ban IMMÉDIAT (PERM_BAN) via le moteur de
                  sanction sans passer par la deux-phases (sévérité CRITICAL).
    USAGE:        lua5.4 tests/run_injection.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/incident.lua')
dofile('server/detection/injection.lua')
dofile('server/enforcement/policy.lua')

local Inj = ZShield.Injection
local Policy = ZShield.Policy
ZShield.Log.console = false
ZShield.Config.load({ mode = 'ENFORCE' })

-- ===========================================================================
T.section('traces : une preuve E5 suffit')

Inj.reset(1)
T.falsy(Inj.shouldBan(1), 'aucune trace -> pas de ban')
local total, banNow = Inj.trace(1, 'phantom_event')
T.equal(total, 5, 'event fantôme = poids 5')
T.truthy(banNow, 'une preuve E5 atteint le seuil')

-- ===========================================================================
T.section('traces : deux preuves E4 nécessaires')

-- unexpected_resource_start reste un E4 NON instant (peut être un admin légitime) :
-- il faut donc bien deux occurrences pour atteindre le seuil de score.
Inj.reset(2)
Inj.trace(2, 'unexpected_resource_start')    -- 4
T.falsy(Inj.shouldBan(2), 'une seule preuve E4 non-instant -> pas encore')
Inj.trace(2, 'unexpected_resource_start')    -- +4 = 8
T.truthy(Inj.shouldBan(2), 'deux preuves E4 -> seuil atteint')

-- ===========================================================================
T.section('traces : dump = ban immédiat (type instant, sous le seuil de score)')

-- server_dump vaut 4 (< seuil 5) MAIS figure dans instant_ban_kinds : une seule
-- occurrence suffit, car l'anti-dump ne le signale qu'après un palier déjà élevé.
Inj.reset(5)
local dtot = Inj.trace(5, 'server_dump')     -- 4 < 5
T.equal(dtot, 4, 'dump = poids 4 (sous le seuil de score)')
T.truthy(Inj.shouldBan(5), 'dump seul -> ban immédiat (type instant)')
-- Un signal E4 NON instant (démarrage de ressource) reste soumis à corroboration.
Inj.reset(6)
Inj.trace(6, 'unexpected_resource_start')    -- 4, non instant
T.falsy(Inj.shouldBan(6), 'un E4 non-instant seul -> pas de ban')
-- Event serveur reçu du client = désormais instant.
Inj.reset(7)
Inj.trace(7, 'protected_event_from_client')
T.truthy(Inj.shouldBan(7), 'event serveur depuis un client -> ban immédiat')
-- Tentative de crash = instant.
Inj.reset(8)
Inj.trace(8, 'crash_attempt')
T.truthy(Inj.shouldBan(8), 'tentative de crash -> ban immédiat')

-- ===========================================================================
T.section('traces : ban IMMÉDIAT via le moteur de sanction')

Inj.reset(3)
Inj.trace(3, 'forbidden_export')  -- 5
local spec = Inj.incidentFor(3)
T.equal(spec.severity, 'CRITICAL', 'incident critique')
T.truthy(spec.instant_ban, 'marqué ban immédiat')
local d = Policy.decide(spec)
T.truthy(d, 'décision produite')
T.equal(d.action, 'PERM_BAN', 'bannissement permanent immédiat')
T.equal(d.phase, 'enforce', 'pas de phase d observation (CRITICAL)')

-- ===========================================================================
T.section('traces : report() ouvre l incident au seuil')

ZShield.Incident.incidents = {}; ZShield.Incident.order = {}; ZShield.Incident.dedup = {}
Inj.reset(4)
T.falsy(Inj.report(4, 'spoofed_identifier'), 'sous le seuil (3) -> pas d incident')
local inc = Inj.report(4, 'phantom_event')   -- +5 = 8 >= seuil
T.truthy(inc, 'seuil atteint -> incident ouvert')
T.equal(inc.severity, 'CRITICAL', 'incident ouvert critique')

os.exit(T.summary() and 0 or 1)
