--[[
    FILE:         tests/run_wave5_protection.lua
    PURPOSE:      Vague 5 — auto-protection & anti-tamper :
                    - selfprotect : anti-stop ressources / anti-stop AC / anti-bypass / watchdog
                    - executor    : anti-executor + blacklist ressources (signature + allowlist)
                    - menu        : anti-menu (signature + rafale d'actions puissantes)
                    - crashguard  : entités malformées (NaN/infini/hors bornes) -> drop
                    - reputation  : réputation persistante par identifiant (décroissance, seed)
    USAGE:        lua5.4 tests/run_wave5_protection.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/selfprotect.lua')
dofile('server/detection/executor.lua')
dofile('server/detection/menu.lua')
dofile('server/detection/crashguard.lua')
dofile('server/reputation.lua')

local C = ZShield.Const
local SP = ZShield.SelfProtect
local EX = ZShield.Executor
local M = ZShield.Menu
local CG = ZShield.CrashGuard
local REP = ZShield.Reputation
ZShield.Log.console = false

-- ===========================================================================
T.section("selfprotect : anti-stop ressources / anti-stop anticheat")

ZShield.Config.load({ selfprotect = { enabled = true, protected_resources = { "mon-core" },
    allow_stop_by = { "console" }, internal_prefix = "zshield:", watchdog_timeout_ms = 20000 } })
T.truthy(SP.isProtected("zshield-ac"), "le coeur AC est protege par defaut")
T.truthy(SP.isProtected("mon-core"), "ressource declaree protegee")
T.falsy(SP.isProtected("esx_menu"), "ressource quelconque -> non protegee")

local stopAC = SP.observeResourceStop("zshield-ac", nil)
T.truthy(stopAC.block, "arret AC par source non authentifiee -> BLOQUE")
T.equal(stopAC.signal.metadata.kind, "stop_anticheat", "kind = stop_anticheat")
T.equal(stopAC.signal.severity, C.SEVERITY.CRITICAL, "arret AC -> CRITICAL")
T.truthy(SP.observeResourceStop("mon-core", nil).block, "arret ressource protegee -> bloque")
T.falsy(SP.observeResourceStop("zshield-ac", "console").block, "arret par admin autorise -> permis")
T.falsy(SP.observeResourceStop("esx_menu", nil).block, "arret ressource non protegee -> permis")

T.section("selfprotect : anti-bypass (event interne emis par un client)")
local bypass = SP.observeInternalEventFromClient(5, "zshield:incident:open")
T.truthy(bypass and bypass.metadata.kind == "bypass_internal_event", "event interne cote client -> bypass")
T.falsy(SP.observeInternalEventFromClient(5, "zshield:cg:report"), "event protocole legitime -> ok")

T.section("selfprotect : watchdog du coeur AC")
SP.ping(1000)
T.falsy(SP.checkWatchdog(5000), "battements recents -> ok")
local down = SP.checkWatchdog(30000)
T.truthy(down and down.metadata.kind == "anticheat_down", "plus de battement > timeout -> AC down")

-- ===========================================================================
T.section("executor : signature + allowlist")

ZShield.Config.load({ executor = { enabled = true,
    blocklist_patterns = { "executor", "lynx", "injectlua" },
    allowlist = { "es_extended", "zshield-ac", "chat" } } })
local sighit = EX.observeEvent(3, { resource = "cool_executor_v2", event = "run", now = 1000 })
T.truthy(sighit and sighit.metadata.kind == "executor_signature", "ressource matche une signature -> signal")
local unknown = EX.observeEvent(3, { resource = "rando_injected", event = "x", now = 1000 })
T.truthy(unknown and unknown.metadata.kind == "unknown_resource", "ressource hors allowlist -> injection")
T.falsy(EX.observeEvent(3, { resource = "es_extended", event = "esx:getSharedObject", now = 1000 }),
    "ressource declaree -> ok")

-- ===========================================================================
T.section("menu : signature + rafale d'actions puissantes")

ZShield.Config.load({ menu = { enabled = true, burst_window_ms = 4000, burst_max = 5 } })
M.forget(1)
local msig = M.observeTrigger(1, { name = "trainer:godmode", now = 1000 })
T.truthy(msig and msig.metadata.kind == "menu_signature", "nom d'event de menu -> signature")
M.forget(2)
local burst
for i = 1, 6 do burst = M.observeTrigger(2, { name = "act", power = true, now = 1000 + i * 100 }) end
T.truthy(burst and burst.metadata.kind == "menu_burst", "rafale d'actions puissantes -> menu")
M.forget(3)
T.falsy(M.observeTrigger(3, { name = "shop:buy", power = false, now = 1000 }), "action normale -> rien")

-- ===========================================================================
T.section("crashguard : entites malformees -> drop")

ZShield.Config.load({ crashguard = { enabled = true, max_coord = 1e6, max_scale = 100, max_health = 1e6 } })
T.falsy(CG.checkEntity({ x = 100, y = 200, z = 30, health = 200 }), "entite normale -> rien")
local nan = CG.checkEntity({ x = 0 / 0, y = 0, z = 0 })
T.truthy(nan and nan.drop, "coordonnee NaN -> drop")
local inf = CG.checkEntity({ x = math.huge, y = 0, z = 0 })
T.truthy(inf and inf.drop, "coordonnee infinie -> drop")
local huge = CG.checkEntity({ x = 5e6, y = 0, z = 0 })
T.truthy(huge and huge.drop, "coordonnee hors bornes -> drop")

-- ===========================================================================
T.section("reputation : persistante, avec decroissance")

ZShield.Config.load({ reputation = { enabled = true, decay_per_hour = 5, max = 100,
    seed_factor = 0.5, join_threshold = 60 } })
REP.forget("lic:abc")
REP.add("lic:abc", 40, 0)
REP.add("lic:abc", 40, 0)
T.equal(REP.get("lic:abc", 0), 80, "deux incidents +40 -> 80 (borne 100)")
T.truthy(REP.flagged("lic:abc", 0), "80 >= seuil 60 -> signale")
-- Decroissance : 5/h pendant 4 h -> -20.
T.equal(REP.get("lic:abc", 4 * 3600000), 60, "apres 4 h -> 60 (decroissance)")
-- Seed du risque a la connexion (0.5 * score).
T.equal(REP.seedRisk("lic:abc", 0), 40, "seed risque = 0.5 * 80 = 40")
-- Persistance : le score ne depend pas d'une session (memoire par identifiant).
T.truthy(REP.get("lic:abc", 0) > 0, "le score survit a la reconnexion (indexe identifiant)")
ZShield.Config.load({ reputation = { enabled = false } })
T.equal(REP.seedRisk("lic:abc", 0), 0, "reputation desactivee -> pas de seed")

os.exit(T.summary() and 0 or 1)
