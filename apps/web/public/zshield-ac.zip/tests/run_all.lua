local suites = { 'tests/run_core.lua', 'tests/run_config.lua', 'tests/run_firewall.lua',
                 'tests/run_detection.lua', 'tests/run_incident.lua', 'tests/run_enforcement.lua',
                 'tests/run_movement_entity.lua', 'tests/run_economy.lua', 'tests/run_persistence.lua',
                 'tests/run_api_sdk.lua', 'tests/run_bootstrap.lua', 'tests/run_adapters_hardening.lua',
                 'tests/run_discord.lua', 'tests/run_native_layers.lua', 'tests/run_license.lua',
                 'tests/run_protections.lua', 'tests/run_weapon.lua',
                 'tests/run_projectile.lua', 'tests/run_state_vehicle.lua',
                 'tests/run_blacklist_command.lua', 'tests/run_injection.lua',
                 'tests/run_connection.lua', 'tests/run_silentaim_crash.lua',
                 'tests/run_reporter.lua', 'tests/run_spectate.lua',
                 'tests/run_extra_protections.lua', 'tests/run_config_impact.lua',
                 'tests/run_triggers.lua', 'tests/run_more_wiring.lua',
                 'tests/run_events_extra.lua', 'tests/run_clientguard.lua',
                 'tests/run_license_online.lua', 'tests/run_deep_detection.lua',
                 'tests/run_more_detection.lua', 'tests/run_wave3_detection.lua',
                 'tests/run_wave4_detection.lua', 'tests/run_wave5_protection.lua',
                 'tests/run_wave6_authoritative.lua', 'tests/run_wave7_research.lua', 'tests/run_wave8_advanced.lua', 'tests/run_wiring_e2e.lua',
                 'tests/run_antidump.lua', 'tests/run_statebag.lua', 'tests/run_menu_defense.lua',
                 'tests/run_reaction.lua', 'tests/run_preflight.lua' }
local allOk = true
for _, s in ipairs(suites) do
    local ok = os.execute('lua5.4 ' .. s .. ' >/dev/null 2>&1')
    print((ok and 'PASS ' or 'FAIL ') .. s)
    if not ok then allOk = false end
end
os.exit(allOk and 0 or 1)
