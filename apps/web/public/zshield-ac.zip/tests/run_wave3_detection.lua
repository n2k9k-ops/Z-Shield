--[[
    FILE:         tests/run_wave3_detection.lua
    PURPOSE:      Vague 3 de détections serveur-autoritatives :
                    - esp       : requêtes d'entités hors portée en volume (ESP/radar)
                    - reach     : action (mêlée/loot/interaction) au-delà de la portée
                    - godmode   : dégâts non appliqués + réparation véhicule injectée
                    - ownership : churn d'ownership / flood de création d'entités
                  Cas légitime silencieux, cas triche détecté, impact config.
    USAGE:        lua5.4 tests/run_wave3_detection.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/esp.lua')
dofile('server/detection/reach.lua')
dofile('server/detection/godmode.lua')
dofile('server/detection/ownership.lua')

local C = ZShield.Const
local E = ZShield.Esp
local R = ZShield.Reach
local G = ZShield.Godmode
local O = ZShield.Ownership
ZShield.Log.console = false

-- ===========================================================================
T.section("esp : requetes dans la portee ne declenchent pas")

ZShield.Config.load({ esp = { enabled = true, stream_range_m = 300, window_ms = 5000, max_far_requests = 12 } })
E.forget(1)
local near
for i = 1, 20 do near = E.observe(1, { entity_dist = 120, now = 1000 + i * 10 }) end
T.falsy(near, "20 requetes a 120 m (dans la portee) -> rien")

T.section("esp : trop d'entites lointaines reclamees -> signal")
E.forget(2)
local espsig
for i = 1, 14 do
    local r = E.observe(2, { entity_dist = 600, now = 1000 + i * 100 })
    if r then espsig = r end
end
T.truthy(espsig and espsig.metadata.kind == "esp", "14 entites hors portee en <2 s -> ESP")

T.section("esp : desactive -> silence")
ZShield.Config.load({ esp = { enabled = false } })
E.forget(3)
local eoff
for i = 1, 20 do eoff = E.observe(3, { entity_dist = 900, now = 1000 + i * 100 }) end
T.falsy(eoff, "ESP desactive -> aucun signal")

-- ===========================================================================
T.section("reach : distance legitime vs reach hack")

ZShield.Config.load({ reach = { enabled = true, max_melee_m = 4, max_loot_m = 6, max_interact_m = 6 } })
T.falsy(R.observe(1, { kind = "melee", dist = 2 }), "melee a 2 m -> ok")
local rsig = R.observe(1, { kind = "melee", dist = 15 })
T.truthy(rsig and rsig.metadata.kind == "reach", "melee a 15 m -> reach hack")
local lsig = R.observe(1, { kind = "loot", dist = 40 })
T.truthy(lsig and lsig.metadata.action == "loot", "loot a 40 m -> reach")
-- Ampleur : mêlée FRANCHE (x3.75) = HIGH ; léger dépassement (x1.25) = MEDIUM prudent.
T.equal(rsig.severity, C.SEVERITY.HIGH, "melee a 15 m (x3.75) -> HIGH")
local border = R.observe(1, { kind = "melee", dist = 5 })   -- 5 / 4 = x1.25
T.truthy(border and border.metadata.kind == "reach", "melee a 5 m -> signale")
T.equal(border.severity, C.SEVERITY.MEDIUM, "leger depassement (x1.25) -> MEDIUM prudent (anti-FP)")
ZShield.Config.load({ reach = { enabled = false } })
T.falsy(R.observe(1, { kind = "melee", dist = 100 }), "reach desactive -> aucun signal")

-- ===========================================================================
T.section("godmode : degats encaisses mais sante inchangee")

ZShield.Config.load({ godmode = { enabled = true, min_damage = 5, veh_enabled = true, veh_repair_delta = 200 } })
T.falsy(G.observeDamage(1, { damage_taken = 20, hp_before = 100, hp_after = 80 }),
    "sante qui baisse normalement -> ok")
local gm = G.observeDamage(1, { damage_taken = 30, hp_before = 100, hp_after = 100 })
T.truthy(gm and gm.metadata.kind == "godmode", "30 degats mais sante inchangee -> god mode")

-- Renfort série : encaissements répétés SANS baisse -> gravité/confiance qui montent.
G.forget(5)
local g1 = G.observeDamage(5, { damage_taken = 30, hp_before = 100, hp_after = 100 })
T.equal(g1.severity, C.SEVERITY.MEDIUM, "1er encaissement sans baisse -> MEDIUM (corroborant)")
local g2 = G.observeDamage(5, { damage_taken = 30, hp_before = 100, hp_after = 100 })
T.equal(g2.severity, C.SEVERITY.HIGH, "2e d'affilee -> HIGH (invincibilite soutenue)")
T.truthy(g2.confidence > g1.confidence, "confiance monte avec la serie")
T.equal(g2.metadata.streak, 2, "serie = 2")
-- Un encaissement NORMAL remet la serie a zero (anti-FP).
G.observeDamage(5, { damage_taken = 20, hp_before = 100, hp_after = 80 })
local g3 = G.observeDamage(5, { damage_taken = 30, hp_before = 100, hp_after = 100 })
T.equal(g3.metadata.streak, 1, "une baisse normale a reinitialise la serie")

T.section("godmode : reparation vehicule injectee")
T.falsy(G.observeVehicle(1, { veh_before = 300, veh_after = 1000, repair_event = true }),
    "reparation avec event legitime -> ok")
local veh = G.observeVehicle(1, { veh_before = 200, veh_after = 1000, repair_event = false })
T.truthy(veh and veh.metadata.kind == "veh_repair", "sante veh +800 sans event -> reparation injectee")

-- ===========================================================================
T.section("ownership : churn et flood")

ZShield.Config.load({ ownership = { enabled = true, window_ms = 3000, max_ownership = 25, max_create = 20 } })
O.forget(1)
local own
for i = 1, 26 do own = O.observe(1, { kind = "ownership", now = 1000 + i }) end
T.truthy(own and own.metadata.kind == "ownership_churn", "26 prises downership en <3 s -> churn")
O.forget(2)
local cre
for i = 1, 21 do cre = O.observe(2, { kind = "create", now = 1000 + i }) end
T.truthy(cre and cre.metadata.kind == "entity_flood", "21 creations en <3 s -> flood")
T.equal(cre.severity, C.SEVERITY.MEDIUM, "leger depassement (x1.05) -> MEDIUM prudent")
-- Flood massif : 60 creations (max 20 -> x3) = crasher quasi certain -> HIGH.
O.forget(22)
local big
for i = 1, 60 do big = O.observe(22, { kind = "create", now = 1000 + i }) end
T.equal(big.severity, C.SEVERITY.HIGH, "flood massif (x3) -> HIGH")
T.truthy(big.confidence >= 0.85, "flood massif -> confiance elevee")
O.forget(3)
local slow
for i = 1, 10 do slow = O.observe(3, { kind = "create", now = 1000 + i * 500 }) end
T.falsy(slow, "10 creations etalees -> ok")

os.exit(T.summary() and 0 or 1)
