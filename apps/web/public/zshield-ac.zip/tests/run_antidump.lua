--[[
    FILE:         tests/run_antidump.lua
    PURPOSE:      Anti server-dumper : un client honnête (peu d'events distincts) reste
                  silencieux ; un dumper (rafale d'events distincts et/ou inconnus dans
                  la fenêtre) est signalé UNE fois par fenêtre ; la fenêtre se réinitialise.
    USAGE:        lua5.4 tests/run_antidump.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/antidump.lua')

local AD = ZShield.AntiDump
ZShield.Log.console = false
ZShield.Config.load({ antidump = { enabled = true, window_ms = 8000, max_distinct = 25, max_unknown = 8 } })

-- ===========================================================================
T.section('client honnête : peu d\'events distincts -> aucun signal')
AD.resetAll()
local flagged = false
for i = 1, 10 do
    local r = AD.observe(1, 'esx:event' .. (i % 4), 1000 + i * 50, false) -- 4 events distincts
    if r.dumping then flagged = true end
end
T.falsy(flagged, '10 appels sur 4 events distincts -> pas de dump')

-- ===========================================================================
T.section('dumper : rafale de 25+ events distincts -> signalé une seule fois')
AD.resetAll()
local hits = 0
local last
for i = 1, 40 do
    last = AD.observe(2, 'evt_' .. i, 2000 + i, false) -- 40 events distincts, fenêtre 8s
    if last.dumping then hits = hits + 1 end
end
T.equal(hits, 1, 'un seul signal de dump par fenêtre malgré la rafale')
T.truthy(last.distinct >= 25, 'compteur de distincts atteint le seuil')

-- ===========================================================================
T.section('dumper : rafale d\'events INCONNUS (fantômes) -> signalé')
AD.resetAll()
local flaggedUnknown = false
for i = 1, 9 do
    local r = AD.observe(3, 'phantom_' .. i, 3000 + i, true) -- 9 events inconnus > max_unknown(8)
    if r.dumping then flaggedUnknown = true end
end
T.truthy(flaggedUnknown, '9 events inconnus -> dump détecté')

-- ===========================================================================
T.section('fenêtre glissante : après expiration, on repart à zéro')
AD.resetAll()
for i = 1, 40 do AD.observe(4, 'evt_' .. i, 4000 + i, false) end       -- déclenche dans la fenêtre
local afterReset = AD.observe(4, 'evt_new', 4000 + 20000, false)       -- bien après window_ms
T.falsy(afterReset.dumping, 'nouvel event après la fenêtre -> compteur réinitialisé')
T.equal(afterReset.distinct, 1, 'distinct repart à 1 dans la nouvelle fenêtre')

-- ===========================================================================
T.section('désactivé : aucun signal')
AD.resetAll()
ZShield.Config.load({ antidump = { enabled = false } })
local off = false
for i = 1, 40 do if AD.observe(5, 'evt_' .. i, 5000 + i, true).dumping then off = true end end
T.falsy(off, 'antidump désactivé -> jamais de dump')

os.exit(T.summary() and 0 or 1)
