--[[
    FILE:         tests/run_economy.lua
    PURPOSE:      Tests du ledger économique (§19-20, §55). Prouve que le serveur est
                  l'autorité (le client ne dicte pas le solde), la traçabilité complète des
                  transactions, la reconstruction, et la détection de duplication, séquence
                  impossible, fréquence anormale, et rupture d'intégrité.
    USAGE:        lua5.4 tests/run_economy.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/engine.lua')
dofile('server/detection/economy.lua')

local C = ZShield.Const
local Economy = ZShield.Economy
local Config = ZShield.Config

ZShield.Log.console = false
local _rawLoad = Config.load
Config.load = function(raw) local ok, r = _rawLoad(raw); ZShield.Log.console = false; return ok, r end
Config.load({ mode = 'ENFORCE' })
H.reset()

local function resetEco()
    Economy.balances = {}; Economy.ledger = {}; Economy.recent = {}; Economy.nonces = {}
    Economy.stats = { applied = 0, rejected = 0, signals = 0 }
end

-- ===========================================================================
T.section('économie : le serveur est l autorité §68')

resetEco()
T.equal(Economy.balance('acc1'), 0, 'solde initial 0')

-- Une transaction de crédit décidée par le serveur.
local ok, res = Economy.apply({ account = 'acc1', delta = 500, reason = 'mission_reward', source = 'system' })
T.truthy(ok, 'transaction appliquée')
T.equal(Economy.balance('acc1'), 500, 'solde = 500 (autorité serveur)')
T.truthy(res.transaction.transaction_id:match('^txn_'), 'transaction_id généré')

-- Le solde est la somme des deltas, PAS une valeur annoncée par le client.
Economy.apply({ account = 'acc1', delta = -200, reason = 'shop_purchase' })
T.equal(Economy.balance('acc1'), 300, 'solde reconstruit par deltas = 300')
T.equal(Economy.reconstruct('acc1'), 300, 'reconstruction depuis l historique = 300 §20')

-- ===========================================================================
T.section('économie : transaction explicable §20')

resetEco()
Economy.apply({ account = 5, delta = 1000, reason = 'heist_payout', source = 'system', context = { mission = 'bank' } })
local hist = Economy.history(5)
T.equal(#hist, 1, 'une transaction dans l historique')
local txn = hist[1]
-- §20 : transaction_id, player, before, delta, after, reason, source, context, timestamp.
T.truthy(txn.transaction_id ~= nil, 'transaction_id présent')
T.equal(txn.before, 0, 'before présent')
T.equal(txn.delta, 1000, 'delta présent')
T.equal(txn.after, 1000, 'after présent')
T.equal(txn.reason, 'heist_payout', 'reason présent')
T.equal(txn.source, 'system', 'source présent')
T.truthy(txn.context ~= nil, 'context présent')
T.truthy(txn.at ~= nil and txn.wallclock ~= nil, 'timestamps présents §20')

-- ===========================================================================
T.section('économie : duplication détectée §20')

resetEco()
-- Transaction avec nonce : la première passe.
ok = Economy.apply({ account = 7, delta = 250, reason = 'reward', nonce = 'abc123' })
T.truthy(ok, 'première transaction avec nonce acceptée')
T.equal(Economy.balance(7), 250, 'solde crédité')

-- Rejouer le même nonce : duplication rejetée + signal.
ok, res = Economy.apply({ account = 7, delta = 250, reason = 'reward', nonce = 'abc123' })
T.falsy(ok, 'nonce rejoué -> duplication rejetée §20')
T.truthy(res.reason:find('duplicate'), 'raison : duplication')
T.truthy(res.signal ~= nil, 'signal de duplication émis')
T.equal(res.signal.severity, 'HIGH', 'duplication = gravité HIGH')
T.equal(Economy.balance(7), 250, 'solde INCHANGÉ après duplication (pas de double crédit)')

-- ===========================================================================
T.section('économie : séquence impossible (solde négatif) §20')

resetEco()
Economy.apply({ account = 8, delta = 100, reason = 'start' })
-- Retrait supérieur au solde : refusé (le serveur ne laisse pas un solde négatif truqué).
ok, res = Economy.apply({ account = 8, delta = -500, reason = 'withdraw' })
T.falsy(ok, 'retrait > solde rejeté §20')
T.truthy(res.reason:find('negative'), 'raison : solde négatif')
T.truthy(res.signal ~= nil, 'signal de séquence impossible')
T.equal(Economy.balance(8), 100, 'solde inchangé après rejet')

-- allow_negative permet les cas légitimes (dette, découvert autorisé).
ok = Economy.apply({ account = 8, delta = -500, reason = 'loan', allow_negative = true })
T.truthy(ok, 'solde négatif autorisé quand explicitement permis')
T.equal(Economy.balance(8), -400, 'découvert appliqué')

-- ===========================================================================
T.section('économie : montant incohérent §20')

resetEco()
-- Montant énorme : transaction appliquée MAIS signalée (peut être un bug métier légitime).
ok, res = Economy.apply({ account = 9, delta = 5000000, reason = 'admin_grant' })
T.truthy(ok, 'transaction appliquée')
T.truthy(res.signal ~= nil, 'montant énorme -> signal §20')
T.truthy(res.signal.reason:find('implausible'), 'raison : montant implausible')
-- §11 : on trace sans bloquer une opération peut-être légitime.
T.truthy(res.signal.confidence < 1.0, 'signal, pas verdict (confiance < 1) §11')

-- ===========================================================================
T.section('économie : récompense répétée / fréquence §20')

H.reset()
resetEco()
-- Même raison beaucoup de fois en fenêtre courte : détecté.
local sawFrequencySignal = false
for i = 1, 15 do
    local _, r = Economy.apply({ account = 10, delta = 10, reason = 'kill_reward' })
    if r.signal and r.signal.reason:find('[Rr]epeated') then sawFrequencySignal = true end
end
T.truthy(sawFrequencySignal, 'récompense répétée en fenêtre -> signal §20')

-- Hors fenêtre : le compteur repart, pas de signal.
H.advance(6000) -- > FREQUENCY_WINDOW_MS (5000)
local _, r = Economy.apply({ account = 10, delta = 10, reason = 'kill_reward' })
T.falsy(r.signal, 'nouvelle fenêtre : compteur réinitialisé, pas de signal')

-- ===========================================================================
T.section('économie : intégrité du ledger §20')

resetEco()
Economy.apply({ account = 11, delta = 300, reason = 'a' })
Economy.apply({ account = 11, delta = -100, reason = 'b' })
Economy.apply({ account = 11, delta = 50, reason = 'c' })
-- Le solde autoritaire égale toujours la reconstruction.
T.equal(Economy.balance(11), Economy.reconstruct(11), 'solde == reconstruction (intégrité) §20')
T.equal(Economy.balance(11), 250, 'solde correct')

-- Détecteur d'intégrité : simule une corruption du solde et vérifie qu'il la détecte.
ZShield.Detection.detectors = {}; ZShield.Detection.order = {}; ZShield.Detection.health = {}
Economy.registerDetector()
-- Corruption manuelle du solde (comme le ferait une manipulation externe).
Economy.balances[11] = 999999
local signals = ZShield.Detection.evaluate({ economy_check = { account = 11 } })
T.truthy(#signals >= 1, 'rupture d intégrité détectée')
T.equal(signals[1].severity, 'CRITICAL', 'rupture d intégrité = CRITICAL')
T.truthy(signals[1].reason:find('integrity'), 'raison : intégrité')

-- ===========================================================================
T.section('économie : chaîne de preuve transaction §29')

resetEco()
local _, result = Economy.apply({ account = 12, delta = 750, reason = 'reward', context = { mission = 'x' } })
local txnId = result.transaction.transaction_id
-- Un admin peut retrouver la transaction exacte par son id (§29).
local found = Economy.getTransaction(12, txnId)
T.truthy(found ~= nil, 'transaction retrouvable par id §29')
T.equal(found.delta, 750, 'transaction correcte')
T.equal(found.before, 0, 'état avant tracé')
T.equal(found.after, 750, 'état après tracé')

os.exit(T.summary() and 0 or 1)
