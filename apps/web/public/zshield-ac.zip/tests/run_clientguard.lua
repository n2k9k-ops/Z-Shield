--[[
    FILE:         tests/run_clientguard.lua
    PURPOSE:      Réception serveur des rapports du module client : signature HMAC,
                  anti-rejeu, fenêtre d'horloge, heartbeat manquant (module retiré),
                  intégrité (hash falsifié). Prouve que le protocole tient.
    USAGE:        lua5.4 tests/run_clientguard.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/sha256.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/clientguard.lua')

local CG = ZShield.ClientGuard
local Util = ZShield.Util
ZShield.Log.console = false
ZShield.Config.load({ client = { heartbeat_timeout_ms = 30000, require = true } })

-- Horloge client simulée (GetGameTimer côté joueur) : monotone, croissante.
local clientClock = 1000
local function tick() clientClock = clientClock + 5000; return clientClock end

-- Construit un rapport correctement signé pour `source`, à l'horodatage `ts`.
local function signedReport(source, secret, ids, ts, hash)
    ts = ts or tick()
    local nonce = Util.uuid('n')
    local sig = ZShield.Sha256.hmac(secret, CG.canonical(source, ts, nonce, ids))
    return { ts = ts, nonce = nonce, ids = ids, sig = sig, hash = hash }
end

-- ===========================================================================
T.section('signature : un rapport valide est accepté')

local secret = CG.issueSecret(7)
T.truthy(secret and #secret > 0, 'un secret de session est émis')
local rep = signedReport(7, secret, { 'no_recoil', 'night_vision' })
local r = CG.ingest(7, rep)
T.truthy(r.accepted, 'rapport signé -> accepté')
T.equal(r.signals, 2, 'deux détections client ingérées')

-- ===========================================================================
T.section('signature invalide / rejeu / horodatage')

local bad = signedReport(7, secret, { 'hitbox' })
bad.sig = string.rep('0', 64)
T.falsy(CG.ingest(7, bad).accepted, 'mauvaise signature -> rejeté')

-- Rejeu : renvoyer un rapport déjà accepté (même ts) -> refusé (ts non croissant).
local rep2 = signedReport(7, secret, { 'hitbox' })
T.truthy(CG.ingest(7, rep2).accepted, 'premier envoi accepté')
T.falsy(CG.ingest(7, rep2).accepted, 'rejeu du même rapport -> rejeté (ts non croissant)')

-- Horodatage plus ancien que le dernier accepté -> rejeté.
local stale = signedReport(7, secret, { 'hitbox' }, 500)
T.falsy(CG.ingest(7, stale).accepted, 'horodatage plus ancien -> rejeté')

-- Un joueur ne peut pas signer avec le secret d'un autre.
CG.issueSecret(8)
local forged = signedReport(8, secret, { 'hitbox' }) -- signé avec le secret de 7
T.falsy(CG.ingest(8, forged).accepted, 'secret dun autre joueur -> rejete')

-- ===========================================================================
T.section('heartbeat : client retire cesse demettre (observable serveur)')

CG.forget(9); CG.issueSecret(9)
local missingNow = CG.checkMissing(Util.now())
local function has(list, v) for _, x in ipairs(list) do if x == v then return true end end return false end
T.falsy(has(missingNow, 9), 'client actif -> pas manquant')
local later = CG.checkMissing(Util.now() + 40000)
T.truthy(has(later, 9), 'plus de rapport depuis > 30 s -> manquant (signal serveur)')

-- ===========================================================================
T.section('intégrité : hash de scripts falsifié')

CG.forget(10)
ZShield.Config.load({ client = { expected_hash = 'GOODHASH', heartbeat_timeout_ms = 30000 } })
CG.issueSecret(10)
T.truthy(CG.checkIntegrity(10, 'TAMPERED'), 'hash different de lattendu -> falsification')
T.falsy(CG.checkIntegrity(10, 'GOODHASH'), 'hash conforme -> rien')

-- ===========================================================================
T.section('sanction auto : heartbeat manquant / falsification (gated)')

-- Stub du moteur d'incident pour capter ce qui serait ouvert.
local opened = {}
ZShield.Incident = { open = function(spec) opened[#opened + 1] = spec; return spec end }

-- Sans client.enforce : aucune sanction, même si le client est requis.
opened = {}
ZShield.Config.load({ client = { require = true, enforce = false, heartbeat_timeout_ms = 1000 } })
CG.forget(11); CG.issueSecret(11)
CG.checkMissing(Util.now() + 5000)
T.equal(#opened, 0, 'enforce OFF -> aucune sanction ouverte')

-- Avec client.enforce + action kick : une sanction est ouverte, une seule fois.
-- On isole : on oublie toutes les sessions précédentes.
for _, s in ipairs({ 7, 8, 9, 10, 11 }) do CG.forget(s) end
opened = {}
ZShield.Config.load({ client = { require = true, enforce = true, action = 'kick', heartbeat_timeout_ms = 1000 } })
CG.forget(12); CG.issueSecret(12)
CG.checkMissing(Util.now() + 5000)
CG.checkMissing(Util.now() + 6000)
T.equal(#opened, 1, 'heartbeat manquant -> une sanction (kick), sans répétition')
T.truthy(opened[1] and opened[1].requested_action == 'kick', 'action demandée = kick')

-- Falsification d'intégrité avec enforce + ban -> incident CRITIQUE (ban immédiat).
opened = {}
ZShield.Config.load({ client = { enforce = true, action = 'ban', expected_hash = 'GOOD' } })
CG.forget(13); CG.issueSecret(13)
CG.checkIntegrity(13, 'BAD')
T.equal(#opened, 1, 'falsification -> une sanction ouverte')
T.truthy(opened[1] and opened[1].instant_ban == true, 'action ban -> ban immédiat')

ZShield.Incident = nil

-- ===========================================================================
T.section('anti-flood : trop de rapports par fenêtre -> ignorés')

ZShield.Config.load({ client = { max_reports_per_10s = 5 } })
CG.forget(14)
local sec14 = CG.issueSecret(14)
local accepted, rejected = 0, 0
for i = 1, 12 do
    local rep14 = signedReport(14, sec14, { 'hitbox' })  -- ts croissant à chaque tick
    if CG.ingest(14, rep14).accepted then accepted = accepted + 1 else rejected = rejected + 1 end
end
T.truthy(accepted <= 5, 'au plus 5 rapports acceptés dans la fenêtre')
T.truthy(rejected >= 7, 'le reste est ignoré (anti-flood)')

-- ===========================================================================
T.section('échange de clés dérivées : le secret ne circule jamais')

ZShield.Config.load({ client = { provisioning_key = 'OPERATOR-ROOT-KEY', max_reports_per_10s = 100 } })
CG.forget(20)
local clientNonce = 'client-nonce-xyz'
local hs = CG.beginHandshake(20, clientNonce)
T.equal(hs.mode, 'derived', 'mode dérivé quand une clé de provisioning existe')
T.truthy(hs.session_id and hs.server_nonce, 'le serveur renvoie des nonces PUBLICS')
T.falsy(hs.secret, 'le secret dérivé n\'est JAMAIS renvoyé')

-- Le client recalcule le même secret à partir de la clé de provisioning + nonces.
local clientSecret = CG.deriveSecret('OPERATOR-ROOT-KEY', hs.session_id, hs.server_nonce, clientNonce)
local rep20 = signedReport(20, clientSecret, { 'no_recoil' })
T.truthy(CG.ingest(20, rep20).accepted, 'rapport signé avec le secret dérivé -> accepté')

-- Une mauvaise clé de provisioning dérive un autre secret -> refusé.
CG.forget(21)
local hs2 = CG.beginHandshake(21, 'n2')
local wrongSecret = CG.deriveSecret('WRONG-KEY', hs2.session_id, hs2.server_nonce, 'n2')
local rep21 = signedReport(21, wrongSecret, { 'hitbox' })
T.falsy(CG.ingest(21, rep21).accepted, 'secret dérivé d\'une mauvaise clé -> rejeté')

-- ===========================================================================
T.section('attestation d\'intégrité : défi-réponse (anti-rejeu)')

ZShield.Config.load({ client = { provisioning_key = 'ROOT', expected_hash = 'GOODHASH', enforce = false } })
CG.forget(22)
local hs3 = CG.beginHandshake(22, 'cn')
local secret22 = CG.deriveSecret('ROOT', hs3.session_id, hs3.server_nonce, 'cn')

local ch = CG.issueChallenge(22)
T.truthy(ch, 'le serveur émet un défi frais')
-- Réponse honnête : HMAC(secret, défi | hash conforme).
local goodResp = ZShield.Sha256.hmac(secret22, ch .. '|' .. 'GOODHASH')
T.truthy(CG.verifyAttestation(22, goodResp).ok, 'réponse correcte (scripts conformes) -> ok')

-- Rejeu de l'ancienne réponse sur un NOUVEAU défi -> échoue.
local ch2 = CG.issueChallenge(22)
T.truthy(CG.verifyAttestation(22, goodResp).tampered, 'rejeu de l\'ancienne réponse -> refusé')

-- Scripts falsifiés : le client répond avec un hash différent -> détecté.
local ch3 = CG.issueChallenge(22)
local tamperedResp = ZShield.Sha256.hmac(secret22, ch3 .. '|' .. 'BADHASH')
T.truthy(CG.verifyAttestation(22, tamperedResp).tampered, 'hash falsifié -> attestation échouée')

-- ===========================================================================
T.section('rotation de clé de provisioning : lancienne clé reste acceptee puis verrouillee')

-- L'opérateur tourne la clé : nouvelle = NEWKEY, ancienne = OLDKEY (grâce). Un
-- client qui n'a pas encore reçu NEWKEY signe avec OLDKEY : il doit rester accepté.
ZShield.Config.load({ client = {
    provisioning_key = 'NEWKEY', provisioning_key_previous = 'OLDKEY',
    max_reports_per_10s = 100 } })
CG.forget(30)
local hsRot = CG.beginHandshake(30, 'cn30')
T.equal(hsRot.mode, 'derived', 'handshake dérivé pendant la rotation')

-- Le client dérive avec l'ANCIENNE clé (il ne connaît pas encore la nouvelle).
local oldSecret = CG.deriveSecret('OLDKEY', hsRot.session_id, hsRot.server_nonce, 'cn30')
local repOld = signedReport(30, oldSecret, { 'no_recoil' })
T.truthy(CG.ingest(30, repOld).accepted, 'ancienne cle acceptee (grace de rotation)')

-- Après acceptation, la session se VERROUILLE sur la clé utilisée : l'ancienne
-- devient la clé courante, secret_prev est effacé.
local sessRot = CG.session(30)
T.falsy(sessRot.secret_prev, 'apres match ancienne cle -> secret_prev efface (verrouille)')
local repOld2 = signedReport(30, oldSecret, { 'hitbox' })
T.truthy(CG.ingest(30, repOld2).accepted, 'le client continue avec sa cle -> accepte')

-- Un client à jour (NEWKEY) est aussi accepté sur sa propre session.
CG.forget(31)
local hsNew = CG.beginHandshake(31, 'cn31')
local newSecret = CG.deriveSecret('NEWKEY', hsNew.session_id, hsNew.server_nonce, 'cn31')
T.truthy(CG.ingest(31, signedReport(31, newSecret, { 'night_vision' })).accepted,
    'nouvelle cle acceptee')

-- Une clé qui n'est NI la nouvelle NI l'ancienne -> rejetée.
CG.forget(32)
local hsBad = CG.beginHandshake(32, 'cn32')
local junkSecret = CG.deriveSecret('JUNK', hsBad.session_id, hsBad.server_nonce, 'cn32')
T.falsy(CG.ingest(32, signedReport(32, junkSecret, { 'hitbox' })).accepted,
    'cle hors rotation -> rejetee')

-- ===========================================================================
T.section('scelle materiel (HWID) : divergence client/serveur et evasion de ban')

-- Bus de détection stub pour capter les signaux émis.
local sigs = {}
ZShield.Detection = { emit = function(s) sigs[#sigs + 1] = s end }

-- (a) HWID rapporté = HWID observé serveur -> aucun signal d'usurpation.
ZShield.Config.load({ client = { provisioning_key = 'ROOT', max_reports_per_10s = 100 } })
CG.forget(40)
local hs40 = CG.beginHandshake(40, 'cn40')
local sec40 = CG.deriveSecret('ROOT', hs40.session_id, hs40.server_nonce, 'cn40')
CG.bindHwid(40, 'HWID-AAA')                       -- observé serveur (jeton FiveM)
sigs = {}
local rep40 = signedReport(40, sec40, { 'no_recoil' })
rep40.hwid = 'HWID-AAA'                            -- rapporté client = identique
CG.ingest(40, rep40)
local function hasSig(name)
    for _, s in ipairs(sigs) do if s.detector == name then return true end end
    return false
end
T.falsy(hasSig('client.hwid_spoof'), 'HWID identique -> aucun signal dusurpation')

-- (b) HWID rapporté != HWID observé -> signal hwid_spoof.
CG.forget(41)
local hs41 = CG.beginHandshake(41, 'cn41')
local sec41 = CG.deriveSecret('ROOT', hs41.session_id, hs41.server_nonce, 'cn41')
CG.bindHwid(41, 'HWID-AAA')
sigs = {}
local rep41 = signedReport(41, sec41, { 'no_recoil' })
rep41.hwid = 'HWID-ZZZ'                            -- divergent
CG.ingest(41, rep41)
T.truthy(hasSig('client.hwid_spoof'), 'HWID divergent -> signal hwid_spoof')

-- (c) Anti-évasion de ban : un HWID (observé serveur) sur la liste noire -> signal
-- + sanction (le matériel suit le tricheur même s'il recrée un compte).
local opened2 = {}
ZShield.Incident = { open = function(spec) opened2[#opened2 + 1] = spec; return spec end }
ZShield.Config.load({ client = { provisioning_key = 'ROOT', enforce = true, action = 'ban',
    hwid_blocklist = { 'HWID-BANNED' } } })
T.truthy(CG.hwidBanned('HWID-BANNED'), 'HWID present sur la liste noire -> banni')
T.falsy(CG.hwidBanned('HWID-CLEAN'), 'HWID absent -> non banni')

CG.forget(42)
CG.beginHandshake(42, 'cn42')
sigs = {}; opened2 = {}
CG.bindHwid(42, 'HWID-BANNED')                     -- observé serveur = banni
T.truthy(hasSig('client.hwid_banned'), 'HWID banni observe -> signal evasion de ban')
T.equal(#opened2, 1, 'HWID banni -> une sanction ouverte')
T.truthy(opened2[1] and opened2[1].instant_ban == true, 'action ban -> ban immediat')

-- Support d'une table-ensemble { [hwid] = true } en plus de la liste plate.
ZShield.Config.load({ client = { hwid_blocklist = { ['HWID-SET'] = true } } })
T.truthy(CG.hwidBanned('HWID-SET'), 'liste noire en table-ensemble supportee')

ZShield.Detection = nil
ZShield.Incident = nil

os.exit(T.summary() and 0 or 1)
