--[[
    FILE:         tests/run_reaction.lua
    PURPOSE:      Réaction & sanctions : escalade graduée (kick -> temp -> perma selon
                  récidive, sans jamais rétrograder), lockdown (whitelist-only) et
                  détection de raid (rafale de connexions -> alerte + lockdown auto).
    USAGE:        lua5.4 tests/run_reaction.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/enforcement/policy.lua')
dofile('server/connection.lua')
ZShield.Log.console = false
local C = ZShield.Const
local P = ZShield.Policy
local Conn = ZShield.Connection

-- ===========================================================================
T.section('Sanctions graduées : escalade selon la récidive')
T.equal(P.graduate(C.ACTION.KICK, 0), C.ACTION.KICK, '1re fois (0 récidive) -> kick')
T.equal(P.graduate(C.ACTION.KICK, 1), C.ACTION.TEMP_BAN, '2e fois -> ban temporaire')
T.equal(P.graduate(C.ACTION.KICK, 2), C.ACTION.PERM_BAN, '3e fois -> ban définitif')
T.equal(P.graduate(C.ACTION.KICK, 9), C.ACTION.PERM_BAN, 'récidive élevée -> perma')
T.equal(P.graduate(C.ACTION.WARN, 5), C.ACTION.WARN, 'action douce non graduée')
T.equal(P.graduate(C.ACTION.TEMP_BAN, 0), C.ACTION.TEMP_BAN, 'ne rétrograde jamais (temp reste temp)')
T.equal(P.graduate(C.ACTION.TEMP_BAN, 2), C.ACTION.PERM_BAN, 'temp + 2 récidives -> perma')

-- ===========================================================================
T.section('Lockdown : whitelist uniquement')
ZShield.Config.load({ connection = { lockdown = true, whitelist = { 'license:abc' },
    raid_window_ms = 15000, raid_max = 999 } })  -- raid_max haut pour isoler le lockdown
Conn._recent = {}; Conn.clearLockdown()
T.truthy(Conn.lockdownActive(1000), 'lockdown actif (config)')
local denied = Conn.assess({ name = 'Bob', identifiers = { license = 'license:zzz' }, now = 1000 })
T.falsy(denied.allow, 'identifiant non whitelisté -> refusé en lockdown')
T.truthy(denied.lockdown, 'motif lockdown')
local ok = Conn.assess({ name = 'Alice', identifiers = { license = 'license:abc' }, now = 1000 })
T.truthy(ok.allow, 'identifiant whitelisté -> autorisé en lockdown')

-- ===========================================================================
T.section('Anti-raid : rafale de connexions -> raid + lockdown auto')
ZShield.Config.load({ connection = { lockdown = false, raid_window_ms = 10000, raid_max = 5,
    auto_lockdown = true, auto_lockdown_seconds = 60, whitelist = {} } })
Conn._recent = {}; Conn.clearLockdown()
local raid
for i = 1, 5 do raid = Conn.checkRaid(2000 + i) end   -- 5 connexions dans la fenêtre
T.truthy(raid.raid, '5 connexions/fenêtre -> raid détecté')
T.truthy(Conn.lockdownActive(2010), 'lockdown auto déclenché par le raid')
-- Après la fenêtre, le compteur repart.
Conn._recent = {}
local calm = Conn.checkRaid(999999)
T.falsy(calm.raid, 'hors fenêtre -> plus de raid')

os.exit(T.summary() and 0 or 1)
