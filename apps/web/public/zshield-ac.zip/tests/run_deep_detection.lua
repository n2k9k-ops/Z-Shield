--[[
    FILE:         tests/run_deep_detection.lua
    PURPOSE:      Preuve des NOUVEAUX moteurs de détection profonds :
                    - aimstats        : distribution de visée improbable (headshots/snap/réaction)
                    - flight          : vol / noclip / blink par cinématique verticale
                    - damage_integrity: dégâts/cadence/portée par arme
                    - provenance      : gains sans source légitime (anti-dupe/injection)
                  Chaque moteur : un profil LÉGITIME ne déclenche pas, un profil TRICHE oui,
                  et l'option de config a un impact réel (désactivé -> silence).
    USAGE:        lua5.4 tests/run_deep_detection.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/aimstats.lua')
dofile('server/detection/flight.lua')
dofile('server/detection/damage.lua')
dofile('server/detection/provenance.lua')

local C = ZShield.Const
local AS = ZShield.Aimstats
local Flight = ZShield.Flight
local DI = ZShield.DamageIntegrity
local Prov = ZShield.Provenance
ZShield.Log.console = false

-- ===========================================================================
T.section("aimstats : un bon joueur ne declenche pas")

ZShield.Config.load({ aimstats = { enabled = true, min_samples = 30, window = 60 } })
AS.forget(1)
local sigLegit
for i = 1, 40 do
    sigLegit = AS.observe(1, { hit = true, headshot = (i % 5 == 0), snap_deg = 7, react_ms = 250 })
end
T.falsy(sigLegit, "profil humain (20% HS, snap 7deg, 250 ms) -> aucun signal")

T.section("aimstats : un aimbot est detecte sur la distribution")
AS.forget(2)
local sigCheat
for i = 1, 40 do
    sigCheat = AS.observe(2, { hit = true, headshot = true, snap_deg = 70, react_ms = 40 })
end
T.truthy(sigCheat, "profil aimbot (100% HS, snap 70deg, 40 ms) -> signal")
T.equal(sigCheat.severity, C.SEVERITY.HIGH, "3+ indicateurs surhumains -> HIGH")
T.truthy(sigCheat.confidence <= 0.85, "confiance plafonnee (correlante, jamais 1.0)")
T.truthy(sigCheat.metadata.indicators >= 2, "au moins 2 indicateurs concordants")

T.section("aimstats : regularite de reaction (triggerbot) fast+regulier vs lent+regulier")
ZShield.Config.load({ aimstats = { enabled = true, min_samples = 30, window = 60, react_cv_min = 0.12 } })
-- Fast + parfaitement regulier (80 ms constant) + snap eleve : CV + snap = 2 indicateurs.
AS.forget(11)
local sigBot
for i = 1, 40 do sigBot = AS.observe(11, { hit = true, headshot = (i % 4 == 0), snap_deg = 55, react_ms = 80 }) end
T.truthy(sigBot, "reaction rapide+reguliere (CV~0, 80 ms) + snap -> signal")
T.truthy(string.find(sigBot.reason, 'reguliere') ~= nil or sigBot.metadata.reaction_cv < 0.12, "indicateur de regularite present")
-- Lent + regulier (250 ms constant) + meme snap : le garde-fou exclut le CV -> 1 seul indicateur -> pas de signal.
AS.forget(12)
local sigCalm
for i = 1, 40 do sigCalm = AS.observe(12, { hit = true, headshot = (i % 4 == 0), snap_deg = 55, react_ms = 250 }) end
T.falsy(sigCalm, "joueur lent mais regulier (250 ms) -> pas accuse de bot (anti-FP)")

T.section("aimstats : impact config + seuil d'echantillon")
AS.forget(3)
for i = 1, 20 do AS.observe(3, { hit = true, headshot = true, snap_deg = 70, react_ms = 40 }) end
T.falsy(AS.observe(3, { hit = true, headshot = true, snap_deg = 70, react_ms = 40 }),
    "sous min_samples -> pas de verdict premature")
ZShield.Config.load({ aimstats = { enabled = false } })
AS.forget(4)
local off
for i = 1, 40 do off = AS.observe(4, { hit = true, headshot = true, snap_deg = 70, react_ms = 40 }) end
T.falsy(off, "aimstats desactive -> aucun signal")

-- ===========================================================================
T.section("flight : marche normale ne declenche pas")

ZShield.Config.load({ flight = { enabled = true, blink_distance_m = 75, max_climb_speed_ms = 20,
    max_altitude_m = 1500, min_altitude_m = -120 } })
Flight.forget(1)
Flight.observe(1, { x = 0, y = 0, z = 30 }, { now = 1000 })
local walk = Flight.observe(1, { x = 3, y = 2, z = 30 }, { now = 2000 })
T.falsy(walk, "petit deplacement au sol -> aucun signal")

T.section("flight : blink (teleport 1 tick) detecte, teleport de confiance ignore")
Flight.forget(2)
Flight.observe(2, { x = 0, y = 0, z = 30 }, { now = 1000 })
local blink = Flight.observe(2, { x = 200, y = 0, z = 30 }, { now = 1500 })
T.truthy(blink and blink.metadata.kind == "blink", "saut de 200 m en 1 tick -> signal blink")
Flight.forget(3)
Flight.observe(3, { x = 0, y = 0, z = 30 }, { now = 1000 })
local tp = Flight.observe(3, { x = 200, y = 0, z = 30 }, { now = 1500, trusted = true })
T.falsy(tp, "meme saut avec teleport de confiance serveur -> ignore")

T.section("flight : ascension impossible = fly, aeronef ignore")
Flight.forget(4)
Flight.observe(4, { x = 0, y = 0, z = 30 }, { now = 1000 })
local fly = Flight.observe(4, { x = 0, y = 0, z = 95 }, { now = 2000 })   -- +65 m en 1 s
T.truthy(fly and fly.metadata.kind == "fly", "ascension 65 m/s -> signal fly")
Flight.forget(5)
Flight.observe(5, { x = 0, y = 0, z = 30 }, { now = 1000 })
T.falsy(Flight.observe(5, { x = 0, y = 0, z = 95 }, { now = 2000, in_air = true }),
    "meme ascension en aeronef -> ignore")

T.section("flight : altitude hors-monde")
Flight.forget(6)
Flight.observe(6, { x = 0, y = 0, z = 30 }, { now = 1000 })
local alt = Flight.observe(6, { x = 1, y = 1, z = 3000 }, { now = 1200, trusted = true })
T.truthy(alt and alt.metadata.kind == "altitude", "z=3000 hors aeronef -> signal altitude")

-- ===========================================================================
T.section("damage_integrity : tir normal ne declenche pas")

ZShield.Config.load({ damage_integrity = { enabled = true, default_base = 60,
    default_min_ms = 80, default_range_m = 120, tolerance_pct = 0.25 } })
DI.forget(1)
local ok = DI.observe(1, { weapon = 100, damage = 30, dist = 20, now = 1000 })
T.falsy(ok, "30 degats a 20 m -> aucun signal")

T.section("damage_integrity : degats modifies / hors portee / rapid fire")
DI.forget(2)
local mod = DI.observe(2, { weapon = 100, damage = 200, dist = 20, now = 1000 })
T.truthy(mod and mod.metadata.kind == "modded_damage", "200 degats (base 60) -> modded")
DI.forget(3)
local rng = DI.observe(3, { weapon = 100, damage = 30, dist = 300, now = 1000 })
T.truthy(rng and rng.metadata.kind == "range", "touche a 300 m (portee 120) -> hors portee")
DI.forget(4)
DI.observe(4, { weapon = 100, damage = 30, dist = 10, now = 1000 })
local rf = DI.observe(4, { weapon = 100, damage = 30, dist = 10, now = 1030 })
T.truthy(rf and rf.metadata.kind == "rapid_fire", "deux tirs a 30 ms (min 80) -> rapid fire")
T.equal(rf.severity, C.SEVERITY.MEDIUM, "1er intervalle court isole -> MEDIUM (jitter possible)")
-- Serie de tirs sous la cadence -> escalade en HIGH, confiance croissante.
DI.forget(7)
DI.observe(7, { weapon = 100, damage = 30, dist = 10, now = 1000 })
local r1 = DI.observe(7, { weapon = 100, damage = 30, dist = 10, now = 1030 })
local r2 = DI.observe(7, { weapon = 100, damage = 30, dist = 10, now = 1060 })
local r3 = DI.observe(7, { weapon = 100, damage = 30, dist = 10, now = 1090 })
T.equal(r3.severity, C.SEVERITY.HIGH, "serie de tirs sous la cadence -> HIGH")
T.truthy(r3.confidence > r1.confidence, "confiance monte avec la serie de rapid-fire")
T.equal(r3.metadata.streak, 3, "serie rapid-fire = 3")
-- Un tir a cadence normale reinitialise la serie.
DI.observe(7, { weapon = 100, damage = 30, dist = 10, now = 2000 })
local r4 = DI.observe(7, { weapon = 100, damage = 30, dist = 10, now = 2030 })
T.equal(r4.metadata.streak, 1, "cadence normale a reinitialise la serie rapid-fire")

T.section("damage_integrity : modele par arme + desactivation")
ZShield.Config.load({ damage_integrity = { enabled = true, tolerance_pct = 0.25,
    weapons = { [100] = { base = 10, min_ms = 200, range = 50 } } } })
DI.forget(5)
local per = DI.observe(5, { weapon = 100, damage = 15, dist = 5, now = 1000 })
T.truthy(per and per.metadata.kind == "modded_damage", "15 degats vs base 10 (arme) -> modded")
ZShield.Config.load({ damage_integrity = { enabled = false } })
DI.forget(6)
T.falsy(DI.observe(6, { weapon = 100, damage = 999, dist = 5, now = 1000 }),
    "detecteur desactive -> aucun signal")

-- ===========================================================================
T.section("provenance : gain avec source legitime accepte")

ZShield.Config.load({ provenance = { enabled = true, min_amount = 100, window_ms = 8000,
    tolerance_pct = 0.05 } })
Prov.forget(1)
Prov.registerSource(1, { kind = "money", amount = 500, now = 1000 })
T.falsy(Prov.observe(1, { kind = "money", amount = 500, now = 1100 }),
    "gain 500 avec source 500 -> accepte")

T.section("provenance : source consommee ne se rejoue pas (anti-dupe)")
T.truthy(Prov.observe(1, { kind = "money", amount = 500, now = 1200 }),
    "meme gain sans nouvelle source -> signal (source deja consommee)")

T.section("provenance : gain inexplique et seuil")
Prov.forget(2)
local big = Prov.observe(2, { kind = "money", amount = 10000, now = 1000 })
T.truthy(big and big.severity == C.SEVERITY.HIGH, "10000 sans source -> signal HIGH")
Prov.forget(3)
T.falsy(Prov.observe(3, { kind = "money", amount = 50, now = 1000 }),
    "petit gain sous le seuil -> ignore")

T.section("provenance : le type doit correspondre")
Prov.forget(4)
Prov.registerSource(4, { kind = "money", amount = 500, now = 1000 })
T.truthy(Prov.observe(4, { kind = "item", amount = 500, now = 1100 }),
    "source money mais gain item -> non couvert -> signal")

os.exit(T.summary() and 0 or 1)
