--[[
    FILE:         tests/run_core.lua
    PURPOSE:      Tests des primitives du cœur (§55). Exécute le vrai code : constantes,
                  logger (rédaction, niveaux SECURITY non supprimés), bus (isolation des
                  exceptions), schéma (types, bornes, strict, types FiveM).
    USAGE:        lua5.4 tests/run_core.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

-- Charger le cœur dans l'ordre de dépendance.
dofile('shared/constants.lua')
dofile('core/log.lua')
dofile('core/util.lua')
dofile('shared/schema.lua')

local C = ZShield.Const
local Log = ZShield.Log
local Bus = ZShield.Bus
local Util = ZShield.Util
local Schema = ZShield.Schema

-- Silence console pour les tests (on inspecte le buffer, pas stdout).
Log.console = false

-- ===========================================================================
T.section('constantes et cohérence')

T.equal(C.VERSION, '1.0.0', 'version présente')
T.equal(#C.SEVERITY_ORDER, 4, 'quatre niveaux de gravité')
T.truthy(C.SEVERITY_WEIGHT.CRITICAL > C.SEVERITY_WEIGHT.HIGH, 'poids CRITICAL > HIGH')
T.truthy(C.SEVERITY_WEIGHT.HIGH > C.SEVERITY_WEIGHT.LOW, 'poids HIGH > LOW')

-- Chaque état a une entrée de transitions (même vide).
local allStatesHaveTransitions = true
for _, state in pairs(C.PLAYER_STATE) do
    if C.STATE_TRANSITIONS[state] == nil then allStatesHaveTransitions = false end
end
T.truthy(allStatesHaveTransitions, 'chaque état a une table de transitions')

-- DEAD ne peut pas aller directement en MISSION (doit passer par RESPAWN).
T.falsy(C.STATE_TRANSITIONS.DEAD.MISSION, 'DEAD -> MISSION interdit')
T.truthy(C.STATE_TRANSITIONS.DEAD.RESPAWN, 'DEAD -> RESPAWN autorisé')

-- ===========================================================================
T.section('logger : rédaction et niveaux')

Log:write(C.LOG.INFO, 'test', 'avec secret', { user = 'bob', api_key = 'SUPERSECRET', nested = { webhook = 'https://x' } })
local recent = Log:recent(1)
local entry = recent[#recent]
T.truthy(entry ~= nil, 'entrée journalisée')
T.equal(entry.fields.user, 'bob', 'champ non sensible conservé')
T.equal(entry.fields.api_key, '[redacted]', 'api_key rédigé')
T.equal(entry.fields.nested.webhook, '[redacted]', 'webhook imbriqué rédigé')

-- Le mot recherché ne doit pas apparaître dans la sortie encodée.
T.falsy(Log.encode(entry):find('SUPERSECRET', 1, true), 'le secret n apparaît nulle part')

-- SECURITY passe même si le niveau est monté au-dessus.
Log:setLevel('CRITICAL')
local before = #Log:recent(200)
Log:info('test', 'info supprimée')       -- sous le niveau -> ignorée
Log:security('test', 'événement de sécurité') -- doit passer malgré le niveau
local after = Log:recent(200)
local lastMsg = after[#after].message
T.equal(lastMsg, 'événement de sécurité', 'SECURITY émis malgré niveau CRITICAL')
Log:setLevel('INFO')

-- Compteurs.
local counts = Log:counters()
T.truthy(counts.security >= 1, 'compteur security incrémenté')

-- ===========================================================================
T.section('bus : isolation des exceptions §104')

local received = {}
Bus:on('sig', function(p) received[#received + 1] = p.v end)
local badCalled = false
Bus:on('sig', function() badCalled = true; error('boom') end) -- handler fautif
Bus:on('sig', function(p) received[#received + 1] = p.v * 10 end)

local delivered = Bus:emit('sig', { v = 3 })
T.equal(delivered, 2, 'deux handlers sains ont reçu, le fautif compté séparément')
T.truthy(badCalled, 'le handler fautif a bien été appelé')
-- Les deux handlers sains ont produit leur effet malgré l'exception du troisième.
local sum = 0
for _, v in ipairs(received) do sum = sum + v end
T.equal(sum, 33, 'les handlers sains ont tous produit leur effet (3 + 30)')

-- L'exception a été journalisée en ERROR.
local logs = Log:recent(200)
local sawBusError = false
for _, e in ipairs(logs) do
    if e.module == 'bus' and e.level == 'ERROR' then sawBusError = true end
end
T.truthy(sawBusError, 'exception du handler journalisée en ERROR')

-- off() retire un handler.
local id = Bus:on('temp', function() end)
Bus:off('temp', id)
T.equal(Bus:emit('temp', {}), 0, 'handler retiré ne reçoit plus')

-- ===========================================================================
T.section('util')

T.equal(Util.clamp(150, 0, 100), 100, 'clamp haut')
T.equal(Util.clamp(-5, 0, 100), 0, 'clamp bas')
T.equal(Util.clamp(50, 0, 100), 50, 'clamp milieu')
T.truthy(Util.isArray({ 1, 2, 3 }), 'tableau détecté')
T.falsy(Util.isArray({ a = 1 }), 'table associative non-tableau')
T.falsy(Util.isArray({ [1] = 'a', [3] = 'c' }), 'tableau troué rejeté')

local copy = Util.deepCopy({ a = { b = 1 } })
copy.a.b = 99
T.equal(Util.deepCopy({ a = { b = 1 } }).a.b, 1, 'deepCopy indépendant de l original')

local u1, u2 = Util.uuid('inc'), Util.uuid('inc')
T.notEqual(u1, u2, 'uuid uniques')
T.truthy(u1:match('^inc_'), 'uuid préfixé')

-- now() est monotone et suit l'horloge virtuelle.
H.reset()
local t0 = Util.now()
H.advance(500)
T.equal(Util.now() - t0, 500, 'now() suit l horloge virtuelle')

-- ===========================================================================
T.section('schéma : types de base')

local ok, err = Schema.validate('hello', { type = 'string', min = 3, max = 10 })
T.truthy(ok, 'string valide')
ok, err = Schema.validate('hi', { type = 'string', min = 3 })
T.falsy(ok, 'string trop courte rejetée')

T.truthy(Schema.validate(5, { type = 'integer' }), 'entier valide')
T.falsy(Schema.validate(5.5, { type = 'integer' }), 'float rejeté comme integer')
T.falsy(Schema.validate(0/0, { type = 'number' }), 'NaN rejeté')

-- enum
T.truthy(Schema.validate('HIGH', { type = 'string', enum = C.SEVERITY_ORDER }), 'enum valide')
T.falsy(Schema.validate('EXTREME', { type = 'string', enum = C.SEVERITY_ORDER }), 'hors enum rejeté')

-- pattern
T.truthy(Schema.validate('inc_12ab', { type = 'string', pattern = '^inc_%w+$' }), 'pattern respecté')
T.falsy(Schema.validate('xxx', { type = 'string', pattern = '^inc_%w+$' }), 'pattern non respecté')

-- ===========================================================================
T.section('schéma : types FiveM et strict')

T.truthy(Schema.validate(3, { type = 'playerId' }), 'playerId entier positif')
T.falsy(Schema.validate(-1, { type = 'playerId' }), 'playerId négatif rejeté')
T.falsy(Schema.validate(1.5, { type = 'entityId' }), 'entityId non entier rejeté')

T.truthy(Schema.validate({ x = 1.0, y = 2.0, z = 3.0 }, { type = 'vector3' }), 'vector3 valide')
T.falsy(Schema.validate({ x = 1, y = 2 }, { type = 'vector3' }), 'vector3 incomplet rejeté')

-- Objet strict : champ inconnu rejeté par défaut.
local eventSchema = {
    type = 'table', required = true,
    fields = {
        amount = { type = 'integer', required = true, min = 0 },
        reason = { type = 'string', required = false },
    },
}
T.truthy(Schema.validate({ amount = 100, reason = 'x' }, eventSchema), 'objet conforme')
T.truthy(Schema.validate({ amount = 100 }, eventSchema), 'champ optionnel absent OK')
ok, err = Schema.validate({ amount = 100, injected = 'evil' }, eventSchema)
T.falsy(ok, 'champ inconnu rejeté (strict) — §06')
T.truthy(err and err:find('injected'), 'erreur nomme le champ fautif')
ok, err = Schema.validate({ reason = 'x' }, eventSchema)
T.falsy(ok, 'champ requis manquant rejeté')

-- allowUnknown desserre la contrainte quand c'est voulu.
T.truthy(Schema.validate({ amount = 1, extra = true },
    { type = 'table', fields = { amount = { type = 'integer' } }, allowUnknown = true }),
    'allowUnknown accepte les champs supplémentaires')

-- coerce applique les défauts.
local coerced = Schema.coerce({}, {
    type = 'table',
    fields = {
        mode = { type = 'string', default = 'shadow' },
        enabled = { type = 'boolean', default = true },
    },
})
T.equal(coerced.mode, 'shadow', 'défaut appliqué (string)')
T.equal(coerced.enabled, true, 'défaut appliqué (boolean)')

-- Ne lève jamais sur donnée invalide : retourne false.
local safe = pcall(Schema.validate, { amount = 'not a number' }, eventSchema)
T.truthy(safe, 'validate ne lève pas sur donnée invalide §06')

os.exit(T.summary() and 0 or 1)
