--[[
    FILE:         tests/run_movement_entity.lua
    PURPOSE:      Tests des détecteurs métier mouvement (§15) et entités (§16-17). Prouve que
                  l'analyse de mouvement N'EST PAS « distance > X => ban » : téléports de
                  confiance respectés, latence atténuant la confiance, séries de vitesse. Et
                  que les quotas d'entités sont contextuels (mission = quota augmenté).
    USAGE:        lua5.4 tests/run_movement_entity.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/context.lua')
dofile('server/detection/engine.lua'); dofile('server/detection/correlation.lua'); dofile('server/detection/risk.lua')
dofile('server/detection/movement.lua'); dofile('server/detection/entity.lua')

local C = ZShield.Const
local Context = ZShield.Context
local Movement = ZShield.Movement
local Entity = ZShield.Entity
local Config = ZShield.Config

ZShield.Log.console = false
local _rawLoad = Config.load
Config.load = function(raw) local ok, r = _rawLoad(raw); ZShield.Log.console = false; return ok, r end
Config.load({ mode = 'ENFORCE', movement = { max_ground_speed_ms = 50, max_tick_distance_m = 75 } })
H.reset()

-- ===========================================================================
T.section('mouvement : déplacement normal ne signale rien §15')

Context.init(1); Context.forceState(1, 'ACTIVE')
-- Première position : pas de précédent, pas de signal.
T.falsy(Movement.analyze(1, { x = 0, y = 0, z = 0 }), 'première position : aucun signal')

-- Déplacement plausible : 10 m en 1 s = 10 m/s, sous le max.
H.advance(1000)
T.falsy(Movement.analyze(1, { x = 10, y = 0, z = 0 }), 'déplacement normal : aucun signal')

-- ===========================================================================
T.section('mouvement : saut de distance = signal, PAS ban §15 §11')

H.reset()
Context.init(2); Context.forceState(2, 'ACTIVE')
Movement.analyze(2, { x = 0, y = 0, z = 0 })
H.advance(100) -- 100 ms
-- Saut de 200 m en 100 ms : très au-delà de max_tick_distance (75).
local sig = Movement.analyze(2, { x = 200, y = 0, z = 0 }, { latency_ms = 30 })
T.truthy(sig ~= nil, 'saut anormal produit un signal')
T.equal(sig.severity, 'HIGH', 'gravité HIGH')
T.equal(sig.category, 'movement', 'catégorie movement')
-- C'est un SIGNAL (confidence < 1), pas un verdict. §11
T.truthy(sig.confidence < 1.0, 'confiance < 1 : signal, pas verdict §11')
T.truthy(sig.confidence >= 0.8, 'latence faible : confiance élevée mais pas absolue')

-- ===========================================================================
T.section('mouvement : téléport de confiance respecté §15')

H.reset()
Context.init(3); Context.forceState(3, 'ACTIVE')
Movement.analyze(3, { x = 0, y = 0, z = 0 })

-- Le serveur enregistre un téléport (admin/mission) vers (500, 500, 30).
Context.registerTeleport(3, { to = { x = 500, y = 500, z = 30 }, reason = 'admin_tp', radius = 50 })

H.advance(100)
-- Le joueur apparaît à la destination : saut ÉNORME mais LÉGITIME.
local tpSig = Movement.analyze(3, { x = 505, y = 498, z = 30 })
T.falsy(tpSig, 'téléport de confiance : saut énorme mais AUCUN signal §15')

-- Contre-preuve : sans téléport enregistré, le même saut signale.
H.reset()
Context.init(4); Context.forceState(4, 'ACTIVE')
Movement.analyze(4, { x = 0, y = 0, z = 0 })
H.advance(100)
local noTpSig = Movement.analyze(4, { x = 505, y = 498, z = 30 })
T.truthy(noTpSig ~= nil, 'même saut SANS téléport enregistré -> signal (contraste §15)')

-- ===========================================================================
T.section('mouvement : latence atténue la confiance §15 §26')

H.reset()
Context.init(5); Context.forceState(5, 'ACTIVE')
Movement.analyze(5, { x = 0, y = 0, z = 0 })
H.advance(100)
-- Même saut, mais latence ÉLEVÉE : la confiance doit être plus basse.
local highLat = Movement.analyze(5, { x = 200, y = 0, z = 0 }, { latency_ms = 600 })
T.truthy(highLat ~= nil, 'saut signalé même avec latence')
T.truthy(highLat.confidence <= 0.5, 'latence 600ms -> confiance atténuée (' .. highLat.confidence .. ') §15')

-- Comparaison directe : faible vs forte latence sur saut identique.
H.reset(); Context.init(6); Context.forceState(6, 'ACTIVE')
Movement.analyze(6, { x = 0, y = 0, z = 0 }); H.advance(100)
local lowLat = Movement.analyze(6, { x = 200, y = 0, z = 0 }, { latency_ms = 20 })
T.truthy(lowLat.confidence > highLat.confidence, 'faible latence -> confiance plus élevée que forte latence')

-- ===========================================================================
T.section('mouvement : mort ne bouge pas §08')

H.reset()
Context.init(7); Context.forceState(7, 'ACTIVE')
Movement.analyze(7, { x = 0, y = 0, z = 0 })
Context.forceState(7, 'DEAD')
H.advance(1000)
local deadSig = Movement.analyze(7, { x = 30, y = 0, z = 0 })
T.truthy(deadSig ~= nil, 'mouvement en état DEAD signalé')
T.truthy(deadSig.reason:find('dead'), 'raison : mouvement pendant la mort')

-- ===========================================================================
T.section('mouvement : série de vitesse monte la confiance')

H.reset()
Config.load({ mode = 'ENFORCE', movement = { max_ground_speed_ms = 20, max_tick_distance_m = 200 } })
Context.init(8); Context.forceState(8, 'ACTIVE')
Movement.analyze(8, { x = 0, y = 0, z = 0 })

-- Vitesse soutenue à 40 m/s (max 20), distance sous le seuil de téléport (200).
local confidences = {}
for i = 1, 4 do
    H.advance(1000)
    local s = Movement.analyze(8, { x = 40 * i, y = 0, z = 0 })
    if s then confidences[#confidences + 1] = s.confidence end
end
T.truthy(#confidences >= 2, 'plusieurs signaux de vitesse')
T.truthy(confidences[#confidences] > confidences[1], 'confiance monte avec la série soutenue')

-- ===========================================================================
T.section('entités : quota par défaut §16 §17')

H.reset()
Config.load({ mode = 'ENFORCE', entities = { default_quota = 5 } })
Entity.registry = {}; Entity.byOwner = {}; Entity.counts = {}; Entity.contextQuota = {}
Entity.stats = { registered = 0, removed = 0, quota_exceeded = 0 }

-- Sous le quota : autorisé, pas de signal.
local allowed, signal
for i = 1, 5 do allowed, signal = Entity.onCreating(1, 'prop_x', 'object') end
T.truthy(allowed, 'création sous quota autorisée')
T.falsy(signal, 'aucun signal sous quota')

-- Dépassement : refusé (à contenir) + signal.
allowed, signal = Entity.onCreating(1, 'prop_x', 'object')
T.falsy(allowed, 'création au-delà du quota refusée (containment) §88')
T.truthy(signal ~= nil, 'signal produit au dépassement')
T.equal(signal.category, 'entity', 'catégorie entity')
T.truthy(signal.reason:find('quota'), 'raison : quota dépassé')

-- ===========================================================================
T.section('entités : quota contextuel augmenté §17')

H.reset()
Config.load({ mode = 'ENFORCE', entities = { default_quota = 5 } })
Entity.registry = {}; Entity.byOwner = {}; Entity.counts = {}; Entity.contextQuota = {}
Entity.stats = { registered = 0, removed = 0, quota_exceeded = 0 }

-- Mission : le serveur augmente le quota du joueur (§17).
Entity.setQuota(2, 20)
local blocked = false
for i = 1, 15 do
    local ok = Entity.onCreating(2, 'veh', 'vehicle')
    if not ok then blocked = true end
end
T.falsy(blocked, '15 créations sous quota mission (20) : aucune bloquée §17')

-- Le quota mission retiré, on retombe au défaut.
Entity.clearQuota(2)
Entity.counts[2] = nil -- nouvelle fenêtre
for i = 1, 5 do Entity.onCreating(2, 'veh', 'vehicle') end
local ok6 = Entity.onCreating(2, 'veh', 'vehicle')
T.falsy(ok6, 'quota mission retiré : retour au quota par défaut §17')

-- ===========================================================================
T.section('entités : registre, ownership, cleanup §16 §110')

H.reset()
Entity.registry = {}; Entity.byOwner = {}; Entity.counts = {}
Entity.register(1001, { creator = 10, model = 'adder', type = 'vehicle', resource = 'garage' })
Entity.register(1002, { creator = 10, model = 'prop', type = 'object' })
Entity.register(1003, { creator = 20, model = 'veh', type = 'vehicle' })

T.equal(#Entity.ownedBy(10), 2, 'joueur 10 possède 2 entités')
T.equal(#Entity.ownedBy(20), 1, 'joueur 20 possède 1 entité')
T.truthy(Entity.isOwner(10, 1001), 'ownership vérifié §16')
T.falsy(Entity.isOwner(20, 1001), 'non-propriétaire rejeté §16')

-- Retrait (containment §88).
T.truthy(Entity.remove(1001), 'entité retirée')
T.equal(#Entity.ownedBy(10), 1, 'après retrait : 1 entité restante')

-- Départ du joueur : nettoyage (§110).
Entity.onPlayerDrop(10)
T.equal(#Entity.ownedBy(10), 0, 'départ joueur : entités nettoyées §110')
T.equal(#Entity.ownedBy(20), 1, 'entités des autres joueurs intactes')

-- ===========================================================================
T.section('intégration : détecteurs enregistrés et émettent via le moteur')

H.reset()
ZShield.Detection.detectors = {}; ZShield.Detection.order = {}; ZShield.Detection.health = {}
Config.load({ mode = 'ENFORCE', movement = { max_tick_distance_m = 75 } })
Context.init(30); Context.forceState(30, 'ACTIVE')

T.truthy((Movement.register()), 'détecteur mouvement enregistré')
T.truthy((Entity.registerDetector()), 'détecteur entité enregistré')

-- Le moteur évalue avec un contexte de mouvement.
Movement.analyze(30, { x = 0, y = 0, z = 0 }) -- pose la position initiale
H.advance(100)
local signals = ZShield.Detection.evaluate({ movement = { source = 30, position = { x = 300, y = 0, z = 0 }, latency_ms = 20 } })
T.truthy(#signals >= 1, 'le moteur produit un signal de mouvement via le détecteur enregistré')
T.equal(signals[1].category, 'movement', 'signal de catégorie movement')

-- ===========================================================================
T.section('exemption anti-FP (intérieur/instance/spectateur)')

H.reset()
Context.init(40); Context.forceState(40, 'ACTIVE')
Movement.analyze(40, { x = 0, y = 0, z = 0 })
H.advance(100)
-- Sans exemption : un bond énorme est signalé.
local before = Movement.analyze(40, { x = 400, y = 0, z = 0 }, { latency_ms = 20 })
T.truthy(before, 'sans exemption : téléport signalé')
-- Avec exemption : le même bond est ignoré (déplacement légitime en instance/mission).
Context.init(41); Context.forceState(41, 'ACTIVE')
Movement.analyze(41, { x = 0, y = 0, z = 0 })
H.advance(100)
Context.setExempt(41, 'instance')
T.truthy(Context.isExempt(41), 'joueur marqué exempté')
T.falsy(Movement.analyze(41, { x = 400, y = 0, z = 0 }, { latency_ms = 20 }),
    'joueur exempté : aucun signal de mouvement')
-- Retrait de l'exemption : on re-détecte.
Context.clearExempt(41)
T.falsy(Context.isExempt(41), 'exemption retirée')

os.exit(T.summary() and 0 or 1)
