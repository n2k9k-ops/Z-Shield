--[[
    FILE:         tests/run_more_wiring.lua
    PURPOSE:      Lot de câblage : ressources ignorées & signatures d'injection,
                  stop-on-backdoor, revive event, armes add-on déclarées, anti-spoofer
                  & anti-XSS à la connexion, pickup/spawn isolé/changement de modèle.
                  Chaque cas prouve que basculer l'option change le comportement.
    USAGE:        lua5.4 tests/run_more_wiring.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/incident.lua')
dofile('server/detection/injection.lua')
dofile('server/detection/health.lua')
dofile('server/firewall/ratelimit.lua')
dofile('server/detection/weapon.lua')
dofile('server/blacklist.lua')
dofile('server/firewall/gameevents.lua')
dofile('server/connection.lua')

local C = ZShield.Const
local Inj = ZShield.Injection
local H2 = ZShield.Health2
local Weapon = ZShield.Weapon
local GE = ZShield.GameEvents
local Conn = ZShield.Connection
ZShield.Log.console = false

-- ===========================================================================
T.section('injection : ressource ignorée -> trace non comptée')

ZShield.Config.load({ injection = { ignored_resources = { 'my_trusted_script' } } })
Inj.reset(1)
Inj.trace(1, 'phantom_event', { resource = 'my_trusted_script' })
T.equal(Inj.total(1), 0, "trace venant d'une ressource de confiance -> ignoree")
Inj.reset(2)
Inj.trace(2, 'phantom_event', { resource = 'unknown_menu' })
T.truthy(Inj.total(2) > 0, "trace venant d'une ressource inconnue -> comptee")

-- ===========================================================================
T.section('injection : signature de triche connue (Anti Synaps)')

ZShield.Config.load({ injection = { cheat_signatures = { 'synaps', 'lynx_menu' } } })
Inj.reset(3)
Inj.signatureHit(3, 'export_LynX_Menu_trigger')
T.truthy(Inj.total(3) > 0, 'nom contenant une signature -> trace forte')

-- ===========================================================================
T.section("injection : stop-on-backdoor dans la spec d'incident")

ZShield.Config.load({ injection = { stop_on_backdoor = true } })
Inj.reset(4); Inj.trace(4, 'phantom_event')
T.truthy(Inj.incidentFor(4).stop_server, 'incident porte stop_server = true')
ZShield.Config.load({ injection = {} })
Inj.reset(5); Inj.trace(5, 'phantom_event')
T.falsy(Inj.incidentFor(5).stop_server, "sans l'option -> stop_server absent/faux")

-- ===========================================================================
T.section('santé : événement de revive déclaré -> pas de faux positif regen')

ZShield.Config.load({ health = { revive_event = 'esx:revive', regen_gain = 40, regen_reset_ms = 4000 } })
H2.forget(6)
H2.observe(6, { health = 10 }, 1000)
local sigRevive = H2.observe(6, { health = 200, event = 'esx:revive' }, 1200)
T.falsy(sigRevive and sigRevive.protection == 'pl_regen', 'revive déclaré -> pas de signal regen')
-- Sans le bon événement, la même remontée est vue comme une régen suspecte.
H2.forget(7)
H2.observe(7, { health = 10 }, 1000)
H2.observe(7, { health = 200 }, 1200)
local sig2 = H2.observe(7, { health = 10 }, 1300)
sig2 = H2.observe(7, { health = 200 }, 1400)
T.truthy(sig2 and sig2.protection == 'pl_regen', 'remontées répétées sans revive -> regen détectée')

-- ===========================================================================
T.section('armes : add-on déclarée bornée (ni faux positif, ni triche non vue)')

ZShield.Config.load({ game_events = { weapon_detector = true, addon_weapons = { [777] = 100 } } })
Weapon.forget(8)
local okDmg = Weapon.observe(8, { weaponType = 777, weaponDamage = 90, overrideDefaultDamage = true }, 1000)
T.falsy(okDmg and okDmg.protection == 'wp_damage_fake', "degat plausible pour l'add-on -> non flagge")
Weapon.forget(9)
local badDmg = Weapon.observe(9, { weaponType = 777, weaponDamage = 400, overrideDefaultDamage = true }, 1000)
T.truthy(badDmg and badDmg.protection == 'wp_damage_fake', "degat delirant sur l'add-on -> flagge")

-- ===========================================================================
T.section('connexion : anti-XSS et anti-spoofer')

ZShield.Config.load({ connection = { anti_xss = true, max_threat_score = 50 } })
T.falsy(Conn.assess({ name = '<script>x', identifiers = { license = 'license:abcd' } }).allow,
    'pseudo avec balise script -> refusé')
ZShield.Config.load({ connection = { anti_spoofer = true, max_threat_score = 30 } })
T.falsy(Conn.assess({ name = 'Jo', identifiers = { license = 'not-a-license' } }).allow,
    'license mal formé -> refusé (spoof)')
T.truthy(Conn.assess({ name = 'Jo', identifiers = { license = 'license:deadbeef' } }).allow,
    'license bien formé -> autorisé')

-- ===========================================================================
T.section('entités : pickup, spawn isolé, changement de modèle')

ZShield.Config.load({ game_events = { block_pickups = true } })
T.truthy(GE.checkEntityCreate(1, { kind = 'pickup', model = 123 }).block, 'pickup bloqué par politique')
ZShield.Config.load({ game_events = { max_spawn_distance_m = 100 } })
T.truthy(GE.checkEntityCreate(1, { model = 123, dist = 250 }).block, 'spawn à 250 m > 100 m -> bloqué')
T.falsy(GE.checkEntityCreate(1, { model = 123, dist = 20 }).block, 'spawn proche -> autorisé')
ZShield.Config.load({ game_events = { anti_model_change = true, allowed_player_models = { 'mp_m_freemode_01' } } })
T.truthy(GE.checkModelChange(1, { to = 'a_c_shark' }).block, 'modèle non autorisé -> bloqué')
T.falsy(GE.checkModelChange(1, { to = 'mp_m_freemode_01' }).block, 'modèle autorisé -> permis')

os.exit(T.summary() and 0 or 1)
