--[[ Tests de chargement et validation de config (§48, §49). ]]
local H = dofile('tests/harness.lua')
local T = H.T
dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
ZShield.Log.console = false
-- La config réactive console via logging.console (défaut true), ce qui est le
-- comportement voulu en production. En test on le neutralise après chaque load.
local _rawLoad = ZShield.Config.load
ZShield.Config.load = function(raw)
  local ok, r = _rawLoad(raw)
  ZShield.Log.console = false
  return ok, r
end
local C = ZShield.Const
local Config = ZShield.Config

T.section('config : défauts sûrs')
local ok, cfg = Config.load({})
T.truthy(ok, 'config vide acceptée')
T.equal(cfg.mode, 'SHADOW', 'mode par défaut SHADOW (jamais enforce par accident) §31')
T.equal(cfg.scoring.decay_half_life_s, 600, 'demi-vie par défaut')
T.truthy(cfg.persistence.enabled, 'persistance activée par défaut')

T.section('config : validation')
ok = Config.load({ mode = 'ENFORCE' })
T.truthy(ok, 'mode ENFORCE valide')
local err
ok, err = Config.load({ mode = 'DESTROY' })
T.falsy(ok, 'mode invalide rejeté')
T.truthy(err and err:find('invalid'), 'erreur explicite')

ok, err = Config.load({ unknown_top = true })
T.falsy(ok, 'champ inconnu au sommet rejeté (strict)')

ok, err = Config.load({ scoring = { thresholds = { observe = 50, suspicious = 40, high_risk = 65, critical = 85 } } })
T.falsy(ok, 'seuils non croissants rejetés §49')
T.truthy(err and err:find('increasing'), 'erreur nomme la contrainte')

ok = Config.load({ scoring = { thresholds = { observe = 10, suspicious = 30, high_risk = 60, critical = 90 } } })
T.truthy(ok, 'seuils croissants acceptés')

T.section('config : bornes et compat')
ok = Config.load({ scoring = { decay_half_life_s = 999999 } })
-- 999999 dépasse le max 86400 -> validate échoue
T.falsy(ok, 'demi-vie hors borne rejetée')

ok, err = Config.load({ schema_version = 999 })
T.falsy(ok, 'version de schéma trop récente rejetée §49')

T.section('config : snapshot et value')
Config.load({ mode = 'MONITOR', scoring = { decay = false } })
local snap = Config.snapshot()
T.truthy(snap.version >= 1, 'snapshot versionné §151')
T.equal(snap.config.mode, 'MONITOR', 'snapshot contient le mode')
T.equal(Config.value('scoring.decay'), false, 'lecture par chemin pointé')
T.equal(Config.value('scoring.nonexistent', 'def'), 'def', 'défaut si chemin absent')
T.equal(Config.value('mode'), 'MONITOR', 'lecture simple')

-- Le logger a pris le niveau configuré.
Config.load({ logging = { level = 'WARN' } })
T.equal(ZShield.Log.level, C.LOG.WARN, 'logger configuré depuis la config')

os.exit(T.summary() and 0 or 1)
