--[[
    FILE:         tests/run_silentaim_crash.lua
    PURPOSE:      Silent aim (cibles multiples touchées en <0,7 s) et anti-crash
                  (valeurs impossibles dans explosion/dégât -> bloqué à la source).
    USAGE:        lua5.4 tests/run_silentaim_crash.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/firewall/ratelimit.lua')
dofile('server/firewall/gameevents.lua')
dofile('server/detection/weapon.lua')

local GE = ZShield.GameEvents
local Weapon = ZShield.Weapon
ZShield.Log.console = false
ZShield.Config.load({})

-- ===========================================================================
T.section('silent aim : cibles multiples en <0,7 s')

Weapon.forget(30)
local sig
local victims = { 'v1', 'v2', 'v3', 'v4', 'v5' }
for k, v in ipairs(victims) do
    sig = Weapon.observe(30, { weaponType = 453432689, weaponDamage = 25, hitGlobalId = v },
        1000 + (k - 1) * 50)
end
T.truthy(sig, 'plusieurs cibles distinctes très vite -> signal')
T.equal(sig.protection, 'ai_target_switch', 'protection silent aim / changement de cible')
T.truthy(sig.confidence < 0.5, 'confiance faible (indice, à corréler)')

-- ===========================================================================
T.section('anti-crash : explosion impossible')

local ex = GE.checkExplosion({ source = 1, explosionType = 2, posX = math.huge })
T.truthy(ex.block, 'coordonnée infinie -> bloqué')

local ex2 = GE.checkExplosion({ source = 1, explosionType = 2, damageScale = 0 / 0 })
T.truthy(ex2.block, 'échelle NaN -> bloqué')

-- ===========================================================================
T.section('anti-crash : dégât impossible')

local d = GE.checkWeaponDamage(1, { weaponType = 453432689, weaponDamage = math.huge })
T.truthy(d.block, 'dégât infini -> bloqué')

-- Une explosion normale n'est pas bloquée par l'anti-crash.
local okx = GE.checkExplosion({ source = 1, explosionType = 2, posX = 100, posY = 200, posZ = 30 })
T.falsy(okx.block, 'explosion normale -> non bloquée par anti-crash')

os.exit(T.summary() and 0 or 1)
