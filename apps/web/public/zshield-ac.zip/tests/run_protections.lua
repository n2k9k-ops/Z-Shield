--[[
    FILE:         tests/run_protections.lua
    PURPOSE:      Prouve que les réglages de protections pilotés par le dashboard
                  (activée/désactivée, mode Surveiller/Bloquer) agissent bien sur le
                  moteur de sanction :
                    - aucun réglage reçu -> comportement identique (défaut 'block') ;
                    - protection désactivée -> incident abandonné ;
                    - mode 'watch' -> décision prise mais sanction DURE non appliquée ;
                    - mode 'block' -> comportement normal ;
                    - agrégat par catégorie, conservateur.
    USAGE:        lua5.4 tests/run_protections.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/protections.lua')
dofile('server/incident.lua')
dofile('server/enforcement/policy.lua')

local C = ZShield.Const
local Policy = ZShield.Policy
local Protections = ZShield.Protections
local Config = ZShield.Config

ZShield.Log.console = false
Config.load({ mode = 'ENFORCE', enforcement = { two_phase = false } })

-- Incident « dur » : score/confiance qui donnent TEMP_BAN hors deux-phases.
local function hardMovement(extra)
    local inc = { source = 1, category = 'movement', severity = 'CRITICAL',
                  confidence = 0.8, risk_after = 88, occurrences = 1 }
    if extra then for k, v in pairs(extra) do inc[k] = v end end
    return inc
end

-- ===========================================================================
T.section('protections : aucun réglage reçu -> comportement inchangé (block)')

Protections.set({}) -- rien
T.falsy(Protections.loaded(), 'aucun réglage chargé')
local d = Policy.decide(hardMovement())
T.equal(d.action, 'TEMP_BAN', 'action dure calculée normalement')
T.falsy(d.blocked_by_mode, 'non bloquée par le mode')
T.falsy(d.watch_only, 'pas en surveillance')

-- ===========================================================================
T.section('protections : gate par catégorie')

-- État réaliste : plusieurs protections mouvement, dont deux en Bloquer.
Protections.set({
    { id = 'mv_teleport', enabled = true,  mode = 'block' },
    { id = 'mv_noclip',   enabled = true,  mode = 'block' },
    { id = 'mv_speed',    enabled = true,  mode = 'watch' },
})
T.truthy(Protections.loaded(), 'réglages chargés')
T.equal(Protections.gate(hardMovement()), 'block', 'catégorie mouvement -> block (au moins une en block)')

d = Policy.decide(hardMovement())
T.equal(d.action, 'TEMP_BAN', 'action dure appliquée (catégorie en block)')
T.falsy(d.blocked_by_mode, 'non bloquée')

-- ===========================================================================
T.section('protections : mode Surveiller sur une protection précise')

-- L'incident porte l'identifiant précis mv_speed (réglé en 'watch').
T.equal(Protections.gate(hardMovement({ protection = 'mv_speed' })), 'watch', 'mv_speed -> watch')
d = Policy.decide(hardMovement({ protection = 'mv_speed' }))
T.equal(d.action, 'TEMP_BAN', 'la décision est toujours calculée')
T.truthy(d.watch_only, 'marquée surveillance')
T.truthy(d.blocked_by_mode, 'sanction dure NON appliquée en surveillance')

-- mv_teleport reste en block -> sanction appliquée.
d = Policy.decide(hardMovement({ protection = 'mv_teleport' }))
T.falsy(d.blocked_by_mode, 'mv_teleport en block -> sanction appliquée')

-- ===========================================================================
T.section('protections : protection désactivée -> incident abandonné')

Protections.set({
    { id = 'mv_teleport', enabled = false, mode = 'block' },
    { id = 'mv_noclip',   enabled = true,  mode = 'block' },
})
T.equal(Protections.gate(hardMovement({ protection = 'mv_teleport' })), 'drop', 'mv_teleport désactivée -> drop')
T.falsy(Policy.decide(hardMovement({ protection = 'mv_teleport' })), 'incident abandonné (aucune décision)')

-- mv_noclip encore active -> décision normale.
T.truthy(Policy.decide(hardMovement({ protection = 'mv_noclip' })), 'mv_noclip active -> décision')

-- ===========================================================================
T.section('protections : catégorie entièrement désactivée -> drop')

Protections.set({
    { id = 'mv_teleport', enabled = false, mode = 'block' },
    { id = 'mv_noclip',   enabled = false, mode = 'block' },
})
T.equal(Protections.gate(hardMovement()), 'drop', 'toutes les protections mouvement coupées -> drop')
T.falsy(Policy.decide(hardMovement()), 'catégorie coupée -> aucune décision')

-- ===========================================================================
T.section('protections : catégorie entièrement en Surveiller -> watch')

Protections.set({
    { id = 'mv_teleport', enabled = true, mode = 'watch' },
    { id = 'mv_noclip',   enabled = true, mode = 'watch' },
})
T.equal(Protections.gate(hardMovement()), 'watch', 'toutes en watch -> catégorie watch')
d = Policy.decide(hardMovement())
T.truthy(d.blocked_by_mode, 'catégorie en surveillance -> sanction dure non appliquée')

os.exit(T.summary() and 0 or 1)
