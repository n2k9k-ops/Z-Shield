--[[
    FILE:         tests/run_wave4_detection.lua
    PURPOSE:      Vague 4 :
                    - trainer      : signature de menu (détecteurs sérieux concomitants)
                    - behavior     : bot/macro par régularité temporelle (CV bas)
                    - spawnprotect : spawn-kill (dégâts pendant la protection de spawn)
                    - chatspam     : débit + répétition de messages/commandes
                    - teleport     : téléports longue distance répétés (menu TP)
    USAGE:        lua5.4 tests/run_wave4_detection.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/trainer.lua')
dofile('server/detection/behavior.lua')
dofile('server/detection/spawnprotect.lua')
dofile('server/detection/chatspam.lua')
dofile('server/detection/teleport.lua')

local C = ZShield.Const
local TR = ZShield.Trainer
local BH = ZShield.Behavior
local SP = ZShield.SpawnProtect
local CS = ZShield.ChatSpam
local TP = ZShield.Teleport
ZShield.Log.console = false

-- ===========================================================================
T.section("trainer : detecteurs serieux concomitants -> signature de menu")

ZShield.Config.load({ trainer = { enabled = true, window_ms = 15000, min_distinct = 3, serious_only = true } })
TR.forget(1)
T.falsy(TR.observeSignal(1, { detector = "flight", severity = C.SEVERITY.HIGH, now = 1000 }), "1 detecteur -> rien")
T.falsy(TR.observeSignal(1, { detector = "godmode", severity = C.SEVERITY.HIGH, now = 1200 }), "2 detecteurs -> rien")
local trsig = TR.observeSignal(1, { detector = "sequence", severity = C.SEVERITY.HIGH, now = 1400 })
T.truthy(trsig and trsig.metadata.kind == "trainer", "3 detecteurs distincts serieux -> signature de menu")
T.equal(trsig.severity, C.SEVERITY.CRITICAL, "signature de menu -> CRITICAL")

T.section("trainer : meme detecteur repete ou signaux faibles -> rien")
TR.forget(2)
TR.observeSignal(2, { detector = "flight", severity = C.SEVERITY.HIGH, now = 1000 })
TR.observeSignal(2, { detector = "flight", severity = C.SEVERITY.HIGH, now = 1100 })
T.falsy(TR.observeSignal(2, { detector = "flight", severity = C.SEVERITY.HIGH, now = 1200 }),
    "meme detecteur 3x -> pas distinct -> rien")
TR.forget(3)
TR.observeSignal(3, { detector = "a", severity = C.SEVERITY.LOW, now = 1000 })
TR.observeSignal(3, { detector = "b", severity = C.SEVERITY.LOW, now = 1100 })
T.falsy(TR.observeSignal(3, { detector = "c", severity = C.SEVERITY.LOW, now = 1200 }),
    "signaux faibles -> ignores (serious_only)")

-- ===========================================================================
T.section("behavior : cadence metronomique -> bot")

ZShield.Config.load({ behavior = { enabled = true, min_actions = 12, max_cv = 0.06 } })
BH.forget(1)
local bot
for i = 1, 14 do bot = BH.observe(1, i * 500) end   -- intervalle constant = 500 ms
T.truthy(bot and bot.metadata.kind == "bot", "14 actions a intervalle constant -> macro/bot")

BH.forget(2)
local human, t = nil, 0
local jit = { 380, 900, 210, 1200, 640, 300, 1500, 450, 820, 260, 1100, 700, 340, 980 }
for i = 1, #jit do t = t + jit[i]; human = BH.observe(2, t) end
T.falsy(human, "intervalles irreguliers (humain) -> rien")

-- ===========================================================================
T.section("spawnprotect : spawn-kill")

ZShield.Config.load({ spawnprotect = { enabled = true, protect_ms = 5000 } })
SP.forget(9)
SP.markSpawn(9, 1000)
local sk = SP.observeDamage(2, 9, 2000)   -- 1 s apres spawn
T.truthy(sk and sk.metadata.kind == "spawnkill", "degats 1 s apres spawn -> spawn-kill")
T.falsy(SP.observeDamage(2, 9, 9000), "degats 8 s apres spawn -> hors protection -> rien")

-- ===========================================================================
T.section("chatspam : debit et repetition")

ZShield.Config.load({ chatspam = { enabled = true, window_ms = 10000, max_messages = 8, max_duplicates = 3 } })
CS.forget(1)
local sp
for i = 1, 9 do sp = CS.observe(1, { kind = "chat", text = "msg" .. i, now = 1000 + i * 100 }) end
T.truthy(sp and sp.metadata.kind == "rate", "9 messages en <1 s -> spam (debit)")
T.equal(sp.severity, C.SEVERITY.LOW, "leger depassement (9/8) -> LOW")
-- Flood franc : 25 messages (max 8 -> x3.1) = bot pub / crash-chat -> MEDIUM.
CS.forget(11)
local flood
for i = 1, 25 do flood = CS.observe(11, { kind = "chat", text = "spam" .. i, now = 1000 + i * 50 }) end
T.equal(flood.severity, C.SEVERITY.MEDIUM, "flood franc (x3+) -> MEDIUM")
T.truthy(flood.confidence >= 0.7, "flood franc -> confiance plus haute")

CS.forget(2)
local dup
for i = 1, 4 do dup = CS.observe(2, { kind = "chat", text = "achete pièces discord.gg/x", now = 1000 + i * 2000 }) end
T.truthy(dup and dup.metadata.kind == "duplicate", "meme message repete -> spam/pub")

CS.forget(3)
T.falsy(CS.observe(3, { kind = "chat", text = "bonjour", now = 1000 }), "un seul message -> rien")

-- ===========================================================================
T.section("teleport : sauts longue distance repetes -> menu de TP")

ZShield.Config.load({ teleport = { enabled = true, min_jump_m = 100, window_ms = 30000, min_repeats = 3 } })
TP.forget(1)
TP.observe(1, { jump_m = 400, now = 1000 })
TP.observe(1, { jump_m = 500, now = 5000 })
local tp = TP.observe(1, { jump_m = 600, now = 9000 })
T.truthy(tp and tp.metadata.kind == "teleport_menu", "3 grands sauts en 30 s -> menu de TP")

TP.forget(2)
T.falsy(TP.observe(2, { jump_m = 400, trusted = true, now = 1000 }), "teleport de confiance -> ignore")
T.falsy(TP.observe(2, { jump_m = 20, now = 2000 }), "petit saut -> ignore")

os.exit(T.summary() and 0 or 1)
