--[[
    FILE:         tests/run_statebag.lua
    PURPOSE:      Anti-exploit de state bags : clé protégée écrite par un client -> incident ;
                  charge géante -> incident (crash) ; flood par joueur -> incident ; écriture
                  serveur d'une clé protégée -> RIEN ; désactivé -> RIEN.
    USAGE:        lua5.4 tests/run_statebag.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/statebag.lua')

local SB = ZShield.StateBag
ZShield.Log.console = false
ZShield.Config.load({ statebags = { enabled = true, window_ms = 10000, max_changes = 60,
    max_value_bytes = 65536, protect = { ['isAdmin'] = { writer = 'server' } } } })

-- ===========================================================================
T.section('clé protégée écrite par un CLIENT -> incident')
SB.resetAll()
local s = SB.observe({ key = 'isAdmin', from_client = true, source = 7, value_bytes = 4, now = 1000 })
T.truthy(s, 'écriture cliente d\'une clé protégée signalée')
T.equal(s and s.category, ZShield.Const.CATEGORY.STATE, 'catégorie STATE')

-- ===========================================================================
T.section('clé protégée écrite par le SERVEUR -> rien')
SB.resetAll()
local ok = SB.observe({ key = 'isAdmin', from_client = false, source = nil, value_bytes = 4, now = 1000 })
T.falsy(ok, 'écriture serveur d\'une clé protégée = légitime')

-- ===========================================================================
T.section('charge géante -> incident (tentative de crash)')
SB.resetAll()
local big = SB.observe({ key = 'whatever', from_client = true, source = 8, value_bytes = 200000, now = 1000 })
T.truthy(big, 'charge > max_value_bytes signalée')
T.equal(big and big.metadata and big.metadata.kind, 'oversized_payload', 'motif = oversized_payload')

-- ===========================================================================
T.section('flood de state bags par un joueur -> incident, une fois')
SB.resetAll()
local hits = 0
for i = 1, 80 do
    local r = SB.observe({ key = 'k' .. i, from_client = true, source = 9, value_bytes = 8, now = 2000 + i })
    if r then hits = hits + 1 end
end
T.equal(hits, 1, 'un seul signal de flood par fenêtre')

-- ===========================================================================
T.section('désactivé -> rien')
SB.resetAll()
ZShield.Config.load({ statebags = { enabled = false } })
local off = SB.observe({ key = 'isAdmin', from_client = true, source = 7, value_bytes = 999999, now = 1000 })
T.falsy(off, 'détecteur désactivé -> aucun signal')

os.exit(T.summary() and 0 or 1)
