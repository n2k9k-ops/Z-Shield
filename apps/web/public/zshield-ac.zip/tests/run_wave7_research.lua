--[[
    FILE:         tests/run_wave7_research.lua
    PURPOSE:      Vague 7 — techniques statistiques AVANCÉES et RÉELLES issues de la littérature :
                    - sprt     : test séquentiel de Wald (taux d'erreur bornés) + test binomial
                    - baseline : z-score en ligne par joueur (Welford), anti-empoisonnement
                    - hitreg   : validation de tir avec compensation de latence (rewind)
    RÉFS : Wald 1945 ; chessprogramming.org/SPRT ; Yu & Hammerla (IEEE, aimbot detection) ;
           Welford 1962 ; validation de hit serveur-autoritaire (AccelByte / Roblox Rewind).
    USAGE:        lua5.4 tests/run_wave7_research.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/sprt.lua')
dofile('server/detection/baseline.lua')
dofile('server/detection/hitreg.lua')

local C = ZShield.Const
local S = ZShield.Sprt
local BL = ZShield.Baseline
local HR = ZShield.HitReg
ZShield.Log.console = false

-- ===========================================================================
T.section("sprt : accumulation de preuve -> decision tricheur, taux d'erreur bornes")

ZShield.Config.load({ sprt = { enabled = true, alpha = 0.01, beta = 0.05, p0 = 0.15, p1 = 0.6 } })
S.forget(1)
local decided
for i = 1, 40 do
    local r = S.observe(1, "superhuman_shot", 1)   -- que des tirs surhumains
    if r and r.decision == "cheat" then decided = r; break end
end
T.truthy(decided and decided.signal, "flux 100% surhumain -> decision 'tricheur' (SPRT)")
T.truthy(decided.n and decided.n < 40, "decision atteinte AVANT 40 obs (efficacite sequentielle)")

T.section("sprt : un joueur legitime n'est pas condamne")
S.forget(2)
local cheatWrong = false
-- ~15% de tirs surhumains (conforme a p0) : ne doit jamais decider 'tricheur'.
local pattern = { 1,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0 }
for rep = 1, 5 do
    for _, x in ipairs(pattern) do
        local r = S.observe(2, "superhuman_shot", x)
        if r and r.decision == "cheat" then cheatWrong = true end
    end
end
T.falsy(cheatWrong, "profil legitime (~15%) -> jamais condamne a tort")

T.section("sprt : test binomial du ratio de headshots")
-- 19 headshots sur 20 avec une base a 20% : p-value infime.
local p = S.binomTailP(20, 19, 0.20)
T.truthy(p < 1e-6, "19/20 headshots (base 20%) -> p-value infime")
local p2 = S.binomTailP(20, 4, 0.20)
T.truthy(p2 > 0.3, "4/20 headshots (base 20%) -> p-value elevee (normal)")
local hs = S.headshotTest(3, 20, 19)
T.truthy(hs and hs.metadata.kind == "binomial", "headshotTest 19/20 -> signal")
T.falsy(S.headshotTest(3, 20, 4), "headshotTest 4/20 -> rien")

-- ===========================================================================
T.section("baseline : z-score en ligne par joueur (Welford)")

ZShield.Config.load({ baseline = { enabled = true, min_samples = 20, z_max = 3.0,
    consecutive = 3, direction = "both" } })
BL.forget(1)
-- Apprentissage : temps de reaction ~250 ms, faible variance.
math.randomseed(42)
for i = 1, 30 do BL.observe(1, "reaction_ms", 250 + math.random(-15, 15)) end
local st = BL.stats(1, "reaction_ms")
T.truthy(st and st.n >= 20, "ligne de base apprise")
-- Puis une serie de reactions surhumaines (40 ms) : ecart soutenu -> signal.
local blsig
for i = 1, 5 do local r = BL.observe(1, "reaction_ms", 40); if r then blsig = r end end
T.truthy(blsig and blsig.metadata.kind == "zscore", "reactions 40ms soutenues -> z-score aberrant")

T.section("baseline : valeurs normales -> aucun signal + anti-empoisonnement")
BL.forget(2)
local none
for i = 1, 40 do none = BL.observe(2, "reaction_ms", 250 + math.random(-15, 15)) end
T.falsy(none, "valeurs normales -> aucun signal")

-- ===========================================================================
T.section("hitreg : validation de tir avec compensation de latence")

ZShield.Config.load({ hitreg = { enabled = true, max_rewind_ms = 1000, default_range = 120, angle_tol_deg = 12 } })
HR.forget(9)
-- La victime se deplace ; on enregistre son historique.
HR.record(9, { x = 0, y = 0, z = 30 }, 1000)
HR.record(9, { x = 10, y = 0, z = 30 }, 1100)
HR.record(9, { x = 20, y = 0, z = 30 }, 1200)
-- Tir plausible : tireur a 15 m, latence 100 ms (victime rembobinee ~ x=10).
local okHit = HR.validate(2, 9, { origin = { x = 10, y = 12, z = 30 }, latency_ms = 100, now = 1200, range = 120 })
T.falsy(okHit, "touche a portee et coherente -> acceptee")
-- Portee impossible : victime rembobinee a ~10, tireur a 500 m.
local far = HR.validate(2, 9, { origin = { x = 500, y = 0, z = 30 }, latency_ms = 100, now = 1200, range = 120 })
T.truthy(far and far.metadata.kind == "range_impossible", "cible a 490 m > portee 120 -> rejetee")
-- Hors ligne de visee : aim a 90 deg de la victime.
local noLos = HR.validate(2, 9, { origin = { x = 0, y = 0, z = 30 }, aim = { x = 0, y = 1, z = 0 },
    latency_ms = 100, now = 1200, range = 120 })
T.truthy(noLos and noLos.metadata.kind == "no_los", "touche hors ligne de visee -> silent-aim")

T.section("wave7 : desactivation globale")
ZShield.Config.load({ sprt = { enabled = false }, baseline = { enabled = false }, hitreg = { enabled = false } })
T.falsy(S.observe(1, "x", 1), "sprt desactive -> rien")
T.falsy(BL.observe(1, "m", 9999), "baseline desactive -> rien")
T.falsy(HR.validate(2, 9, { origin = { x = 9999, y = 0, z = 0 }, now = 1200 }), "hitreg desactive -> rien")

os.exit(T.summary() and 0 or 1)
