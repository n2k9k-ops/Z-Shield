--[[
    FILE:         tests/run_wave8_advanced.lua
    PURPOSE:      Vague 8 — fusion de preuves & analyse de séquences :
                    - fusion    : combinaison bayésienne (log-odds) de tous les signaux
                    - markov    : entropie/transitions de séquences d'actions (script/macro)
                    - clocksync : horloge client accélérée (speedhack time-scale)
    USAGE:        lua5.4 tests/run_wave8_advanced.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/fusion.lua')
dofile('server/detection/markov.lua')
dofile('server/detection/clocksync.lua')

local C = ZShield.Const
local F = ZShield.Fusion
local MK = ZShield.Markov
local CK = ZShield.ClockSync
ZShield.Log.console = false

-- ===========================================================================
T.section("fusion : des indices convergents franchissent le seuil composite")

ZShield.Config.load({ fusion = { enabled = true, threshold = 4.0, decay_per_sec = 0.0 } })
F.forget(1)
local fused
for i = 1, 8 do
    local r = F.observe(1, { source = 1, detector = "d" .. i, severity = C.SEVERITY.MEDIUM, confidence = 0.7 })
    if r then fused = r end
end
T.truthy(fused and fused.metadata.kind == "fusion", "plusieurs indices moyens -> confiance composite")
T.truthy(fused.confidence >= 0.8, "probabilite composite elevee")

T.section("fusion : un seul indice faible ne suffit pas")
F.forget(2)
T.falsy(F.observe(2, { source = 2, detector = "x", severity = C.SEVERITY.LOW, confidence = 0.3 }),
    "un indice faible isole -> pas de composite")

T.section("fusion : ne se re-fusionne pas elle-meme")
F.forget(3)
T.falsy(F.observe(3, { source = 3, detector = "fusion", severity = C.SEVERITY.HIGH, confidence = 0.9 }),
    "signal 'fusion' ignore (anti-boucle)")

-- ===========================================================================
T.section("markov : sequence scriptee (entropie basse) -> signal")

ZShield.Config.load({ markov = { enabled = true, min_events = 20, min_entropy = 0.3 } })
MK.forget(1)
local scripted
for i = 1, 40 do
    local a = (i % 2 == 0) and "fire" or "reload"   -- fire>reload>fire>reload... deterministe
    local r = MK.observe(1, a)
    if r and r.metadata.kind == "low_entropy" then scripted = r end
end
T.truthy(scripted, "sequence fire/reload alternee stricte -> entropie basse (script)")

T.section("markov : sequence humaine variee -> rien")
MK.forget(2)
math.randomseed(7)
local acts = { "fire", "move", "reload", "aim", "crouch", "jump", "interact", "sprint" }
local human
for i = 1, 60 do human = MK.observe(2, acts[math.random(#acts)]) end
T.falsy(human, "sequence variee (humaine) -> pas de signal d'entropie")

T.section("markov : transition interdite")
ZShield.Config.load({ markov = { enabled = true, min_events = 999, forbidden = { "dead>fire" } } })
MK.forget(3)
MK.observe(3, "dead")
local forb = MK.observe(3, "fire")
T.truthy(forb and forb.metadata.kind == "forbidden_transition", "transition dead>fire interdite -> signal")

-- ===========================================================================
T.section("clocksync : horloge client acceleree -> speedhack")

ZShield.Config.load({ clocksync = { enabled = true, min_samples = 6, max_ratio = 1.15 } })
CK.forget(1)
-- Horloge client avance 2x plus vite que le serveur.
local speed
local cs, ss = 0, 0
for i = 1, 10 do
    cs = cs + 200; ss = ss + 100   -- client +200 ms, serveur +100 ms
    local r = CK.observe(1, { client_ts = cs, now = ss })
    if r then speed = r end
end
T.truthy(speed and speed.metadata.kind == "timescale", "temps client ×2 -> speedhack detecte")
T.equal(speed.severity, C.SEVERITY.HIGH, "×2 -> HIGH")
T.truthy(speed.confidence >= 0.85, "×2 -> confiance elevee (>=0.85)")

-- Ampleur : un excès LÉGER (juste au-dessus du seuil) reste prudent (MEDIUM) — anti-FP jitter.
CK.forget(9)
local border
cs, ss = 0, 0
for i = 1, 10 do
    cs = cs + 122; ss = ss + 100   -- ratio ~1.22 (> seuil 1.15 mais léger)
    local r = CK.observe(9, { client_ts = cs, now = ss })
    if r then border = r end
end
T.truthy(border and border.metadata.kind == "timescale", "×1.22 -> signale quand meme")
T.equal(border.severity, C.SEVERITY.MEDIUM, "leger exces (×1.22) -> MEDIUM prudent (anti-FP)")

T.section("clocksync : horloge normale -> rien")
CK.forget(2)
local ok
cs, ss = 0, 0
for i = 1, 12 do
    cs = cs + 100 + math.random(-5, 5); ss = ss + 100   -- ~1:1 avec jitter
    ok = CK.observe(2, { client_ts = cs, now = ss })
end
T.falsy(ok, "horloge ~synchrone (jitter) -> pas de faux positif")

T.section("wave8 : desactivation")
ZShield.Config.load({ fusion = { enabled = false }, markov = { enabled = false }, clocksync = { enabled = false } })
T.falsy(F.observe(1, { source = 1, severity = C.SEVERITY.CRITICAL, confidence = 0.9 }), "fusion off -> rien")
T.falsy(MK.observe(1, "fire"), "markov off -> rien")
T.falsy(CK.observe(1, { client_ts = 99999, now = 1 }), "clocksync off -> rien")

os.exit(T.summary() and 0 or 1)
