--[[
    FILE:         tests/run_config_impact.lua
    PURPOSE:      PREUVE que la configuration a un IMPACT RÉEL sur le cœur. Chaque cas
                  bascule une option, puis montre que le comportement du détecteur ou
                  du gate change vraiment. Si une option n'avait aucun effet, ce test
                  échouerait — c'est exactement le garde-fou demandé.
    USAGE:        lua5.4 tests/run_config_impact.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/firewall/ratelimit.lua')
dofile('server/detection/weapon.lua')
dofile('server/detection/health.lua')
dofile('server/blacklist.lua')
dofile('server/firewall/gameevents.lua')
dofile('server/connection.lua')
dofile('server/protections.lua')

local C = ZShield.Const
local Weapon = ZShield.Weapon
local GE = ZShield.GameEvents
local Conn = ZShield.Connection
local Prot = ZShield.Protections
ZShield.Log.console = false

local function fireBurst(n)
    Weapon.forget(1)
    local sig
    for i = 1, n do
        sig = Weapon.observe(1, { weaponType = 453432689, weaponDamage = 25 }, 1000 + i)
    end
    return sig
end

-- ===========================================================================
T.section("'Détecteur d'arme' désactivé -> plus aucune détection d'arme")

ZShield.Config.load({ game_events = { weapon_detector = true, max_shots_per_sec = 25 } })
T.truthy(fireBurst(40), 'détecteur ACTIF : rafale de 40 tirs -> signal')

ZShield.Config.load({ game_events = { weapon_detector = false } })
T.falsy(fireBurst(40), 'détecteur DÉSACTIVÉ : même rafale -> aucun signal (impact réel)')

-- ===========================================================================
T.section("'Cadence de tir max' change le seuil de déclenchement")

ZShield.Config.load({ game_events = { weapon_detector = true, max_shots_per_sec = 25 } })
T.falsy(fireBurst(20), 'plafond 25 : 20 tirs -> sous le seuil, rien')
ZShield.Config.load({ game_events = { weapon_detector = true, max_shots_per_sec = 10 } })
T.truthy(fireBurst(20), 'plafond abaissé à 10 : 20 tirs -> déclenche (impact réel)')

-- ===========================================================================
T.section("'Anti-crash' désactivé -> les valeurs impossibles ne sont plus bloquées")

ZShield.Config.load({ game_events = { anti_crash = true } })
T.truthy(GE.checkExplosion({ source = 1, explosionType = 2, posX = math.huge }).block,
    'anti-crash ACTIF : coordonnée infinie -> bloquée')
ZShield.Config.load({ game_events = { anti_crash = false } })
T.falsy(GE.checkExplosion({ source = 1, explosionType = 2, posX = math.huge }).block,
    'anti-crash DÉSACTIVÉ : plus de blocage (impact réel)')

-- ===========================================================================
T.section("'Blacklist explosions' : ajouter un type le bloque vraiment")

ZShield.Config.load({ game_events = {} })
T.falsy(GE.checkExplosion({ source = 1, explosionType = 59, posX = 1, posY = 1, posZ = 1 }).block,
    'type 59 non listé -> non bloqué')
ZShield.Config.load({ game_events = { explosion_type_blocklist = { [59] = true } } })
T.truthy(GE.checkExplosion({ source = 1, explosionType = 59, posX = 1, posY = 1, posZ = 1 }).block,
    'type 59 ajouté à la liste -> bloqué (impact réel)')

-- ===========================================================================
T.section("'Anti-VPN' bascule le score de menace à la connexion")

ZShield.Config.load({ connection = { anti_vpn = false, max_threat_score = 30 } })
T.truthy(Conn.assess({ name = 'Jo', vpn = true, identifiers = { license = 'l1' } }).allow,
    'anti-VPN OFF : un joueur VPN passe')
ZShield.Config.load({ connection = { anti_vpn = true, max_threat_score = 30 } })
T.falsy(Conn.assess({ name = 'Jo', vpn = true, identifiers = { license = 'l1' } }).allow,
    'anti-VPN ON : le même joueur VPN est refusé (impact réel)')

-- ===========================================================================
T.section("Réglage 'Surveiller / Bloquer' : le gate change l'exécution")

-- Sans réglage reçu : tout est en 'block' (comportement d'origine).
Prot.set(nil)
local inc = { category = C.CATEGORY.DAMAGE, protection = 'wp_fire_rate' }
T.equal(Prot.gate(inc), 'block', 'aucun réglage -> block (sûr par défaut)')

-- Le client met CETTE protection en 'watch' -> on observe, on ne sanctionne plus.
Prot.set({ { id = 'wp_fire_rate', enabled = true, mode = 'watch' } })
T.equal(Prot.gate(inc), 'watch', 'réglée en Surveiller -> watch (impact réel)')

-- Le client la désactive -> l'incident est abandonné.
Prot.set({ { id = 'wp_fire_rate', enabled = false, mode = 'block' } })
T.equal(Prot.gate(inc), 'drop', 'désactivée -> drop (impact réel)')

os.exit(T.summary() and 0 or 1)
