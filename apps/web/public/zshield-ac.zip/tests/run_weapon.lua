--[[
    FILE:         tests/run_weapon.lua
    PURPOSE:      Prouve le détecteur d'arme comportemental : cadence de tir soutenue,
                  dégâts incompatibles avec l'arme, et absence de faux positif sur un
                  tir normal. Horloge injectée (déterministe).
    USAGE:        lua5.4 tests/run_weapon.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/detection/weapon.lua')

local Weapon = ZShield.Weapon
local Config = ZShield.Config
ZShield.Log.console = false
Config.load({})

-- ===========================================================================
T.section('arme : cadence de tir normale -> aucun signal')

Weapon.forget(10)
local last
for k = 0, 9 do
    -- 10 tirs répartis sur 1 s (un toutes les 100 ms) : cadence plausible.
    last = Weapon.observe(10, { weaponType = 453432689, weaponDamage = 30 }, 5000 + k * 100)
end
T.falsy(last, '10 tirs/s -> pas de signal')

-- ===========================================================================
T.section('arme : cadence de tir impossible -> signal')

Weapon.forget(11)
local sig
for k = 0, 39 do
    -- 40 tirs en ~0,4 s : bien au-delà du plafond (25/s).
    sig = Weapon.observe(11, { weaponType = 453432689, weaponDamage = 30 }, 8000 + k * 10)
end
T.truthy(sig, 'cadence excessive -> signal émis')
T.equal(sig.category, 'damage', 'catégorie damage')
T.equal(sig.source, 11, 'source = le joueur')
T.truthy(sig.protection == 'wp_fire_rate' or sig.protection == 'wp_shots_impossible',
    'protection cadence de tir')
T.truthy(sig.confidence > 0.5, 'confiance non nulle')

-- ===========================================================================
T.section("arme : dégâts incompatibles avec l'arme -> wp_damage_fake")

Weapon.forget(12)
-- WEAPON_PISTOL (max ~40) avec 200 de dégât forcé : impossible.
local d = Weapon.observe(12, {
    weaponType = 453432689, weaponDamage = 200, overrideDefaultDamage = true,
}, 12000)
T.truthy(d, 'dégâts absurdes -> signal')
T.equal(d.protection, 'wp_damage_fake', 'protection dégâts truqués')
T.truthy(d.confidence >= 0.75, 'confiance élevée sur borne dure')

-- Dégât normal pour l'arme : pas de signal de dégât.
Weapon.forget(13)
local ok = Weapon.observe(13, {
    weaponType = 453432689, weaponDamage = 35, overrideDefaultDamage = true,
}, 13000)
T.falsy(ok, 'dégât plausible -> aucun signal')

-- ===========================================================================
T.section('arme : ratio de coups instantanément létaux (indice, faible confiance)')

Weapon.forget(14)
local aim
for k = 0, 19 do
    -- 20 coups, tous willKill : ratio ~100 %. Cadence espacée pour ne pas croiser
    -- le signal de cadence.
    aim = Weapon.observe(14, { weaponType = 453432689, weaponDamage = 30, willKill = true },
        20000 + k * 300)
end
T.truthy(aim, 'ratio létal élevé -> indice émis')
T.equal(aim.protection, 'ai_precision', 'indice aimbot statistique')
T.truthy(aim.confidence < 0.5, 'confiance FAIBLE (à corréler, jamais sanction seule)')

os.exit(T.summary() and 0 or 1)
