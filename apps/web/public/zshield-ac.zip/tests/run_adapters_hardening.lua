--[[
    FILE:         tests/run_adapters_hardening.lua
    PURPOSE:      Tests de l'abstraction de framework (§46) et du hardening (§24, §71-73,
                  §55). Prouve que le core dégrade proprement sans framework, qu'un
                  adaptateur fautif ne le fait pas tomber (§104), et que l'audit CONSEILLE
                  sans jamais modifier une convar (§24, §71).
    USAGE:        lua5.4 tests/run_adapters_hardening.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/adapters/framework.lua'); dofile('server/hardening.lua')

local C = ZShield.Const
local Framework = ZShield.Framework
local Hardening = ZShield.Hardening

ZShield.Log.console = false
H.reset()

-- ===========================================================================
T.section('framework : repli standalone §46')

-- Par défaut : standalone, aucune dépendance.
T.equal(Framework.active().name, 'standalone', 'adaptateur par défaut standalone §46')
T.equal(Framework.getMoney(1), nil, 'standalone : money inconnu (le ledger core fait foi)')
T.falsy(Framework.isAdmin(1), 'standalone : personne admin par défaut §04')

-- Détection sans natives framework -> standalone (ne devine jamais).
T.equal(Framework.detect(), 'standalone', 'détection sans framework -> standalone §46')

-- ===========================================================================
T.section('framework : adaptateur enregistré et utilisé §46')

Framework.register('esx', {
    getMoney = function(source) return source == 5 and 1500 or 0 end,
    getJob = function() return 'police' end,
    isAdmin = function(source) return source == 5 end,
})
T.truthy((Framework.use('esx')), 'adaptateur esx sélectionné')
T.equal(Framework.active().name, 'esx', 'esx actif')
T.equal(Framework.getMoney(5), 1500, 'money via adaptateur esx')
T.equal(Framework.getJob(5), 'police', 'job via adaptateur')
T.truthy(Framework.isAdmin(5), 'admin via adaptateur (calculé serveur) §04')
T.falsy(Framework.isAdmin(6), 'non-admin correctement identifié')

-- Adaptateur inconnu rejeté.
T.falsy((Framework.use('nonexistent')), 'adaptateur inconnu rejeté')

-- ===========================================================================
T.section('framework : adaptateur fautif isolé §104')

Framework.register('buggy', {
    getMoney = function() error('adapter boom') end,
    isAdmin = function() error('boom') end,
})
Framework.use('buggy')
-- Une méthode qui lève ne fait pas tomber le core : renvoie nil/false, journalise.
local safe = pcall(Framework.getMoney, 1)
T.truthy(safe, 'getMoney ne propage pas l exception de l adaptateur §104')
T.equal(Framework.getMoney(1), nil, 'adaptateur fautif -> money nil (dégradé proprement)')
T.falsy(Framework.isAdmin(1), 'adaptateur fautif -> isAdmin false (jamais admin par erreur)')

-- Méthode absente : dégrade proprement.
Framework.register('partial', { getMoney = function() return 100 end }) -- pas de isAdmin
Framework.use('partial')
T.equal(Framework.getMoney(1), 100, 'méthode présente fonctionne')
T.falsy(Framework.isAdmin(1), 'méthode absente -> valeur neutre (pas de crash) §46')

Framework.use('standalone') -- restaurer

-- ===========================================================================
T.section('hardening : audit conseille sans modifier §24 §71')

-- Sans natives GetConvar : les convars sont "non défini", statut WARNING.
local report = Hardening.audit()
T.truthy(report.controls ~= nil, 'audit produit des contrôles')
T.truthy(#report.controls >= 4, 'plusieurs contrôles audités')
T.truthy(report.note:find('CONSEILLE') or report.note:find('conseille'), 'note : le rapport conseille')
T.truthy(report.note:find('modifié'), 'note : aucune convar modifiée §24 §71')

-- Chaque contrôle documente purpose/risk/benefit/compat/rollback (§71).
local first = report.controls[1]
T.truthy(first.purpose ~= nil, 'contrôle documente purpose §71')
T.truthy(first.risk ~= nil, 'contrôle documente risk §71')
T.truthy(first.benefit ~= nil, 'contrôle documente benefit §71')
T.truthy(first.compatibility ~= nil, 'contrôle documente compatibility §71')
T.truthy(first.rollback ~= nil, 'contrôle documente rollback §71')

-- ===========================================================================
T.section('hardening : audit avec convars simulées §73')

-- Simuler des convars via le harness.
SetConvar('sv_scriptHookAllowed', '0')      -- conforme au conseil
SetConvar('sv_pureLevel', '0')              -- diffère du conseil (1)
SetConvar('onesync', 'on')                  -- conforme

report = Hardening.audit()
local byConvar = {}
for _, c in ipairs(report.controls) do byConvar[c.convar] = c end

T.equal(byConvar['sv_scriptHookAllowed'].status, 'OK', 'sv_scriptHookAllowed=0 conforme -> OK')
T.equal(byConvar['sv_pureLevel'].status, 'RECOMMENDED', 'sv_pureLevel=0 diffère -> RECOMMENDED')
T.equal(byConvar['onesync'].status, 'OK', 'onesync=on conforme -> OK')

-- Le current lu reflète la convar simulée.
T.equal(byConvar['sv_scriptHookAllowed'].current, '0', 'current lu correctement')

-- ===========================================================================
T.section('hardening : score de posture §72')

-- Tout conforme -> score élevé.
SetConvar('sv_scriptHookAllowed', '0')
SetConvar('sv_pureLevel', '1')
SetConvar('sv_filterRequestControl', '2')
SetConvar('onesync', 'on')
local score = Hardening.securityScore()
T.equal(score.score, 100, 'toutes convars conformes -> posture 100% §72')
T.truthy(score.note:find('posture') or score.note:find('joueur'), 'note : mesure la posture, pas un joueur §72')

-- Une convar non conforme -> score réduit.
SetConvar('onesync', 'off')
score = Hardening.securityScore()
T.truthy(score.score < 100, 'convar non conforme -> posture réduite')
T.truthy(score.score > 0, 'posture partielle reflétée')

-- Le score mesure la config, PAS un joueur (§72) : aucun paramètre de joueur ici.
T.truthy(score.breakdown ~= nil, 'détail par convar fourni')

-- ===========================================================================
T.section('hardening : lignes console §73')

local lines = Hardening.lines()
T.truthy(#lines >= 3, 'audit produit des lignes formatées')
T.truthy(lines[1]:find('Audit'), 'en-tête d audit présent')

os.exit(T.summary() and 0 or 1)
