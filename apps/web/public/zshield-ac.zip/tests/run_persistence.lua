--[[
    FILE:         tests/run_persistence.lua
    PURPOSE:      Tests de la persistance (§36, §37, §38, §52, §55). Prouve que : la file est
                  bornée avec éviction par priorité (télémétrie sacrifiée avant incidents),
                  qu'une panne SQL ne perd rien et ne plante rien, que le disjoncteur ouvre/
                  récupère, et que la sécurité continue pendant la panne.
    USAGE:        lua5.4 tests/run_persistence.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/persistence/circuit.lua'); dofile('server/persistence/store.lua')

local Circuit = ZShield.Circuit
local Store = ZShield.Store
local Config = ZShield.Config

ZShield.Log.console = false
local _rawLoad = Config.load
Config.load = function(raw) local ok, r = _rawLoad(raw); ZShield.Log.console = false; return ok, r end
Config.load({ mode = 'ENFORCE' })
H.reset()

-- ===========================================================================
T.section('disjoncteur : ouverture après échecs §52')

local cb = Circuit.new('test', { failure_threshold = 3, open_ms = 5000 })
T.equal(cb:state(), 'closed', 'état initial fermé')

-- Trois échecs consécutifs -> ouverture.
for _ = 1, 3 do cb:call(function() error('sql down') end) end
T.equal(cb:state(), 'open', 'ouvert après 3 échecs §52')

-- Circuit ouvert : les appels sont refusés SANS exécuter fn (protège la dépendance).
local executed = false
local ok, err = cb:call(function() executed = true; return 'ok' end)
T.falsy(ok, 'appel refusé quand ouvert')
T.equal(err, 'circuit_open', 'raison : circuit ouvert')
T.falsy(executed, 'fn NON exécutée quand ouvert (protège la dépendance) §52')

-- ===========================================================================
T.section('disjoncteur : récupération half-open §52')

-- Après open_ms, passage en half_open et une sonde autorisée.
H.advance(5000)
T.equal(cb:state(), 'half_open', 'passe en half-open après la fenêtre')

-- La sonde réussit : le circuit se referme.
ok = cb:call(function() return 'recovered' end)
T.truthy(ok, 'sonde réussie')
T.equal(cb:state(), 'closed', 'circuit refermé après récupération §52')

-- Si la sonde échoue, le circuit rouvre.
local cb2 = Circuit.new('test2', { failure_threshold = 2, open_ms = 1000 })
cb2:call(function() error('x') end); cb2:call(function() error('x') end)
T.equal(cb2:state(), 'open', 'rouvert')
H.advance(1000)
cb2:state() -- déclenche half_open
cb2:call(function() error('still down') end) -- sonde échoue
T.equal(cb2:state(), 'open', 'sonde échouée -> rouvert §52')

-- ===========================================================================
T.section('event store : file bornée et éviction par priorité §37')

Store.clear()
Store.stats = { enqueued = 0, flushed = 0, dropped = 0, batches = 0, sink_errors = 0 }
Config.load({ mode = 'ENFORCE' })
Store.configure()
Store.maxSize = 5  -- forcé pour le test (le schéma impose un minimum de 100 en prod)

-- Remplir avec de la télémétrie (basse priorité).
for i = 1, 5 do Store.enqueue('telemetry', { i = i }) end
T.equal(Store.size(), 5, 'file remplie de télémétrie')

-- Un incident (haute priorité) arrive sur file pleine : évince une télémétrie.
Store.enqueue('incident', { id = 'inc1' })
T.equal(Store.size(), 5, 'file toujours à 5 (éviction)')
-- L'incident est présent, une télémétrie a été sacrifiée (§37).
local hasIncident = false
for _, e in ipairs(Store.queue) do if e.kind == 'incident' then hasIncident = true end end
T.truthy(hasIncident, 'incident conservé, télémétrie évincée §37')
T.truthy(Store.stats.dropped >= 1, 'perte comptée, jamais silencieuse §37')

-- Une télémétrie sur file pleine d'incidents : REFUSÉE (rien de moins important à évincer).
Store.clear(); Store.stats.dropped = 0
for i = 1, 5 do Store.enqueue('incident', { i = i }) end
local accepted = Store.enqueue('telemetry', { late = true })
T.falsy(accepted, 'télémétrie refusée si rien de moins important à évincer §37')
T.truthy(Store.stats.dropped >= 1, 'refus compté')

-- ===========================================================================
T.section('event store : SQL down ne perd rien et ne plante pas §37 §38')

Store.clear()
Store.stats = { enqueued = 0, flushed = 0, dropped = 0, batches = 0, sink_errors = 0 }
Config.load({ mode = 'ENFORCE', persistence = { event_store_max = 1000 } })
Store.configure()

-- Sink qui échoue systématiquement (SQL down).
local sinkCalls = 0
Store.setSink(function(batch) sinkCalls = sinkCalls + 1; error('sql unavailable') end)

for i = 1, 50 do Store.enqueue('incident', { i = i }) end
T.equal(Store.size(), 50, '50 incidents en file')

-- Tenter de vider : le sink échoue, mais la file reste INTACTE (rien perdu).
local flushed = Store.drain()
T.equal(flushed, 0, 'rien écrit (SQL down)')
T.equal(Store.size(), 50, 'file intacte : AUCUNE perte pendant la panne §38')

-- Le disjoncteur ouvre après plusieurs cycles de flush échoués. drain() ne tente qu'un
-- lot par appel en cas d'échec (pour ne pas marteler) ; en production le flush périodique
-- rappelle drain à chaque tick. On simule ces cycles.
for _ = 1, 6 do H.advance(100); Store.drain() end
local circuitState = Store.circuit:state()
T.truthy(circuitState == 'open' or circuitState == 'half_open', 'disjoncteur a ouvert après plusieurs cycles, SQL protégé §52')

-- Point crucial (§38) : enqueue continue de fonctionner pendant la panne.
local stillWorks = Store.enqueue('incident', { during = 'outage' })
T.truthy(stillWorks, 'la sécurité continue d enfiler pendant la panne SQL §38')

-- ===========================================================================
T.section('event store : récupération quand SQL revient §37')

-- SQL revient : le sink réussit désormais.
local written = {}
Store.setSink(function(batch)
    for _, e in ipairs(batch) do written[#written + 1] = e end
    return true
end)

-- Attendre que le disjoncteur repasse en half_open puis referme.
H.advance(30000) -- > open_ms par défaut
local totalFlushed = Store.drain(20)
T.truthy(totalFlushed > 0, 'écriture reprend quand SQL revient §37')
T.truthy(#written > 0, 'les événements en attente sont bien persistés')
-- Aucun événement perdu : tout ce qui était en file finit écrit.
T.truthy(Store.size() < 51, 'la file se vide après récupération')

-- ===========================================================================
T.section('event store : écriture par lots, pas par frame §36')

Store.clear()
Store.stats = { enqueued = 0, flushed = 0, dropped = 0, batches = 0, sink_errors = 0 }
Store.circuit = Circuit.new('sql', { failure_threshold = 5, open_ms = 30000 })
local batchSizes = {}
Store.setSink(function(batch) batchSizes[#batchSizes + 1] = #batch; return true end)

-- 250 événements, batchSize 100 : doit produire des lots, pas 250 écritures unitaires.
for i = 1, 250 do Store.enqueue('signal', { i = i }) end
Store.drain(10)
T.truthy(#batchSizes >= 2, 'écriture par lots (§36)')
T.truthy(batchSizes[1] <= 100, 'lot borné à batchSize')
local totalWritten = 0
for _, n in ipairs(batchSizes) do totalWritten = totalWritten + n end
T.equal(totalWritten, 250, 'tous les événements écrits, en lots')

-- ===========================================================================
T.section('event store : pas de sink = pas de perte §37')

Store.clear()
Store.stats = { enqueued = 0, flushed = 0, dropped = 0, batches = 0, sink_errors = 0 }
Store.setSink(nil)
for i = 1, 10 do Store.enqueue('audit', { i = i }) end
local f, remaining = Store.flush()
T.equal(f, 0, 'sans sink : rien écrit')
T.equal(remaining, 10, 'sans sink : tout conservé en file (pas de perte) §37')

os.exit(T.summary() and 0 or 1)
