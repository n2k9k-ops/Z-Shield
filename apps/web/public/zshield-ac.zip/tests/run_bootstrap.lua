--[[
    FILE:         tests/run_bootstrap.lua
    PURPOSE:      Tests de la santé (§50-51) et du bootstrap complet (§107-110, §55). Le test
                  le plus important : un FLUX DE BOUT EN BOUT à travers tous les moteurs
                  câblés par le bootstrap — un joueur qui triche produit un signal qui
                  remonte jusqu'à l'incident et l'enforcement, sans câblage manuel.
    USAGE:        lua5.4 tests/run_bootstrap.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

-- Charger TOUT le core dans l'ordre du fxmanifest.
dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/firewall/ratelimit.lua'); dofile('server/context.lua'); dofile('server/firewall/firewall.lua')
dofile('server/detection/engine.lua'); dofile('server/detection/correlation.lua'); dofile('server/detection/risk.lua')
dofile('server/incident.lua')
dofile('server/enforcement/policy.lua'); dofile('server/enforcement/enforcement.lua')
dofile('server/detection/movement.lua'); dofile('server/detection/entity.lua'); dofile('server/detection/economy.lua')
dofile('server/persistence/circuit.lua'); dofile('server/persistence/store.lua')
dofile('server/integrations/discord.lua')
dofile('server/api.lua'); dofile('server/sdk.lua')
dofile('server/health.lua'); dofile('server/bootstrap.lua')

local C = ZShield.Const
local Health = ZShield.Health
local Bootstrap = ZShield.Bootstrap

ZShield.Log.console = false
H.reset()

-- ===========================================================================
T.section('santé : agrégation pessimiste §50')

Health.components = {}
Health.set('a', C.HEALTH.HEALTHY)
Health.set('b', C.HEALTH.HEALTHY)
T.equal(Health.aggregate(), 'HEALTHY', 'tout sain -> HEALTHY')

Health.set('c', C.HEALTH.DEGRADED)
T.equal(Health.aggregate(), 'DEGRADED', 'un dégradé -> DEGRADED')

Health.set('d', C.HEALTH.FAILED)
T.equal(Health.aggregate(), 'FAILED', 'un en échec -> FAILED (pessimiste) §50')

-- Le rapport ne contient aucun secret (par construction).
Health.set('e', C.HEALTH.HEALTHY, 'detail sans secret')
local report = Health.report()
T.truthy(report.overall ~= nil, 'rapport a un verdict global')
T.truthy(report.version == C.VERSION, 'rapport versionné')
T.truthy(report.components.e ~= nil, 'composant présent dans le rapport')

-- ===========================================================================
T.section('auto-surveillance : détecte queue saturée §51')

Health.components = {}
ZShield.Config.load({ mode = 'ENFORCE', persistence = { event_store_max = 100 } })
ZShield.Log.console = false
ZShield.Store.clear(); ZShield.Store.configure()
ZShield.Store.maxSize = 100

-- Remplir la file à > 90%.
ZShield.Store.setSink(nil) -- pas de sink : rien ne se vide
for i = 1, 95 do ZShield.Store.enqueue('signal', { i = i }) end
Health.selfCheck()
T.equal(Health.get('storage').status, 'FAILED', 'queue saturée (>90%) -> storage FAILED §51')

-- Vider un peu : repasse dégradé puis sain.
ZShield.Store.clear()
for i = 1, 70 do ZShield.Store.enqueue('signal', { i = i }) end
Health.selfCheck()
T.equal(Health.get('storage').status, 'DEGRADED', 'queue à 70% -> DEGRADED')

ZShield.Store.clear()
Health.selfCheck()
T.equal(Health.get('storage').status, 'HEALTHY', 'queue vide -> HEALTHY')

-- ===========================================================================
T.section('auto-surveillance : détecte détecteur dégradé §51 §104')

ZShield.Detection.detectors = {}; ZShield.Detection.order = {}; ZShield.Detection.health = {}
ZShield.Detection.register({ id = 'faulty', evaluate = function() error('boom') end })
ZShield.Detection.register({ id = 'good', evaluate = function() return nil end })
ZShield.Detection.evaluate({}) -- déclenche l'erreur, marque 'faulty' DEGRADED
Health.selfCheck()
T.equal(Health.get('detectors').status, 'DEGRADED', 'détecteur en erreur -> detectors DEGRADED §51')

-- ===========================================================================
T.section('auto-surveillance : détecte circuit SQL ouvert §51 §52')

Health.components = {}
ZShield.Store.clear(); ZShield.Store.configure()
-- Forcer le disjoncteur ouvert.
ZShield.Store.circuit.state_ = 'open'
ZShield.Store.circuit.openedAt = Util and Util.now() or 0
ZShield.Store.setSink(function() return true end)
for i = 1, 5 do ZShield.Store.enqueue('signal', { i = i }) end
Health.selfCheck()
T.equal(Health.get('database').status, 'FAILED', 'circuit ouvert -> database FAILED §51')

-- ===========================================================================
T.section('bootstrap : démarrage câble tout §107')

H.reset()
Bootstrap.started = false
Health.components = {}
-- Réinitialiser les moteurs.
ZShield.Detection.detectors = {}; ZShield.Detection.order = {}; ZShield.Detection.health = {}
ZShield.Incident.incidents = {}; ZShield.Incident.order = {}; ZShield.Incident.dedup = {}; ZShield.Incident.byPlayer = {}
ZShield.Incident.stats = { opened = 0, deduplicated = 0, decided = 0 }
ZShield.Risk.players = {}; ZShield.Correlation.players = {}
-- Vider les abonnements du bus pour repartir propre.
ZShield.Bus.handlers = {}

local started = Bootstrap.start({ mode = 'ENFORCE', scoring = { thresholds = { observe = 20, suspicious = 40, high_risk = 65, critical = 85 } } })
ZShield.Log.console = false
T.truthy(started, 'bootstrap démarre')
T.truthy(Bootstrap.started, 'état démarré')

-- Config invalide : refus de démarrer (§107).
Bootstrap.started = false
local badStart = Bootstrap.start({ mode = 'INVALID_MODE' })
ZShield.Log.console = false
T.falsy(badStart, 'config invalide -> refus de démarrer §107')
T.equal(Health.get('configuration').status, 'FAILED', 'configuration marquée FAILED')

-- ===========================================================================
T.section('bootstrap : FLUX DE BOUT EN BOUT §106 §179')

-- LE test qui compte : un joueur triche, le signal remonte automatiquement à
-- travers TOUS les moteurs câblés, jusqu'à l'incident et l'enforcement.
H.reset()
Bootstrap.started = false
ZShield.Bus.handlers = {}
Health.components = {}
ZShield.Detection.detectors = {}; ZShield.Detection.order = {}; ZShield.Detection.health = {}
ZShield.Incident.incidents = {}; ZShield.Incident.order = {}; ZShield.Incident.dedup = {}; ZShield.Incident.byPlayer = {}
ZShield.Incident.stats = { opened = 0, deduplicated = 0, decided = 0 }
ZShield.Risk.players = {}; ZShield.Correlation.players = {}
ZShield.Enforcement.executors = {}; ZShield.Enforcement.audit = {}
ZShield.Enforcement.stats = { applied = 0, shadowed = 0, mode_blocked = 0, contained = 0, executor_errors = 0 }

Bootstrap.start({
    mode = 'ENFORCE',
    enforcement = { two_phase = false },
    scoring = { thresholds = { observe = 20, suspicious = 40, high_risk = 60, critical = 85 } },
})
ZShield.Log.console = false

-- Brancher un exécuteur pour CHAQUE action de l'échelle, pour observer laquelle est prise.
local enforced = {}
for _, action in ipairs(C.ACTION_ORDER) do
    ZShield.Enforcement.setExecutor(action, function(inc) enforced[#enforced + 1] = { action = action, source = inc.source } end)
end

-- Un joueur existe, à l'état ACTIVE.
ZShield.Context.init(42); ZShield.Context.forceState(42, 'ACTIVE')

-- Injecter un signal fort (comme le ferait un détecteur). Il DOIT remonter tout seul :
-- detection.emit -> bus -> correlation + risk -> risk.level_changed -> incident.opened ->
-- enforcement.handle -> executor de l'action décidée.
ZShield.Detection.emit({
    detector = 'movement.teleport', category = C.CATEGORY.MOVEMENT,
    severity = 'CRITICAL', confidence = 0.95, score = 70, source = 42,
})

-- Vérifier chaque maillon de la chaîne, automatiquement câblé par le bootstrap.
local score, level = ZShield.GetRisk(42)
T.truthy(score >= 60, 'le risque a monté via le bus (score ' .. score .. ')')
T.truthy(level == 'HIGH_RISK' or level == 'CRITICAL', 'niveau de risque élevé atteint')
T.truthy(ZShield.Incident.stats.opened >= 1, 'un incident a été ouvert automatiquement §106')
-- L'enforcement a agi automatiquement : l'action exacte dépend du score atteint (échelle
-- §86), mais la CHAÎNE COMPLÈTE a fonctionné sans câblage manuel.
T.truthy(#enforced >= 1, 'l enforcement a agi automatiquement — chaîne complète §179')
T.equal(enforced[1].source, 42, 'le bon joueur a été sanctionné')
T.truthy(enforced[1].action ~= nil, 'une action de l échelle a été appliquée (' .. tostring(enforced[1].action) .. ')')

-- L'incident porte sa chaîne de preuve.
local incs = ZShield.Incident.forPlayer(42)
T.truthy(#incs >= 1, 'incident lié au joueur')
T.truthy(incs[1].decision ~= nil, 'incident porte la décision d enforcement')

-- ===========================================================================
T.section('bootstrap : arrêt propre §108')

Bootstrap.stop()
T.falsy(Bootstrap.started, 'arrêté')

-- Le bootstrap émet les événements de cycle de vie.
local lifecycleEvents = {}
ZShield.Bus:on('zshield.started', function() lifecycleEvents[#lifecycleEvents + 1] = 'started' end)
ZShield.Bus:on('zshield.stopped', function() lifecycleEvents[#lifecycleEvents + 1] = 'stopped' end)
Bootstrap.started = false
Bootstrap.start({ mode = 'SHADOW' }); ZShield.Log.console = false
Bootstrap.stop()
T.truthy(#lifecycleEvents >= 2, 'événements de cycle de vie émis (started + stopped)')

os.exit(T.summary() and 0 or 1)
