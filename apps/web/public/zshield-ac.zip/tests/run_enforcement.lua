--[[
    FILE:         tests/run_enforcement.lua
    PURPOSE:      Tests de l'enforcement (§86-88, §31, §43, §55). Prouve l'échelle de
                  sanction, la deux-phases, le respect des modes SHADOW/MONITOR/ENFORCE, le
                  containment réversible, l'audit, et l'isolation des exécuteurs fautifs.
    USAGE:        lua5.4 tests/run_enforcement.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua')
dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/incident.lua')
dofile('server/enforcement/policy.lua'); dofile('server/enforcement/enforcement.lua')

local C = ZShield.Const
local Policy = ZShield.Policy
local Enforcement = ZShield.Enforcement
local Incident = ZShield.Incident
local Config = ZShield.Config

ZShield.Log.console = false
local _rawLoad = Config.load
Config.load = function(raw) local ok, r = _rawLoad(raw); ZShield.Log.console = false; return ok, r end

local function resetEnf()
    Enforcement.executors = {}; Enforcement.containers = {}; Enforcement.audit = {}
    Enforcement.stats = { applied = 0, shadowed = 0, mode_blocked = 0, contained = 0, executor_errors = 0 }
    Incident.incidents = {}; Incident.order = {}; Incident.dedup = {}; Incident.byPlayer = {}
    Incident.stats = { opened = 0, deduplicated = 0, decided = 0 }
end

-- ===========================================================================
T.section('policy : échelle de sanction §86')

Config.load({ mode = 'ENFORCE', enforcement = { two_phase = false } })
resetEnf()

-- Score sous le premier palier : aucune action.
T.falsy(Policy.decide({ source = 1, category = 'movement', severity = 'LOW', confidence = 0.5, risk_after = 10 }),
    'score 10 -> aucune action')

-- Paliers croissants (two_phase off pour tester l'échelle brute).
T.equal(Policy.decide({ source = 1, category = 'movement', severity = 'LOW', confidence = 0.5, risk_after = 25 }).action, 'LOG', 'score 25 -> LOG')
T.equal(Policy.decide({ source = 1, category = 'movement', severity = 'MEDIUM', confidence = 0.5, risk_after = 45 }).action, 'WARN', 'score 45 -> WARN')
T.equal(Policy.decide({ source = 1, category = 'movement', severity = 'HIGH', confidence = 0.6, risk_after = 60 }).action, 'RESTRICT', 'score 60 -> RESTRICT')
T.equal(Policy.decide({ source = 1, category = 'movement', severity = 'HIGH', confidence = 0.7, risk_after = 72 }).action, 'KICK', 'score 72 -> KICK')
T.equal(Policy.decide({ source = 1, category = 'movement', severity = 'CRITICAL', confidence = 0.8, risk_after = 88 }).action, 'TEMP_BAN', 'score 88 -> TEMP_BAN')

-- ===========================================================================
T.section('policy : la confiance gouverne §11 §87')

-- Score élevé (90) mais confiance FAIBLE (0.4) : on ne banni pas définitivement.
-- Le palier PERM_BAN exige confidence 0.9 ; TEMP_BAN exige 0.75. À 0.4, on redescend.
local lowConf = Policy.decide({ source = 1, category = 'movement', severity = 'HIGH', confidence = 0.4, risk_after = 90 })
T.truthy(lowConf.action ~= 'PERM_BAN' and lowConf.action ~= 'TEMP_BAN',
    'score 90 mais confiance 0.4 -> pas de ban (' .. lowConf.action .. ') §11')

-- Même score, confiance ÉLEVÉE : le ban devient possible.
local highConf = Policy.decide({ source = 1, category = 'movement', severity = 'CRITICAL', confidence = 0.95, risk_after = 96 })
T.equal(highConf.action, 'PERM_BAN', 'score 96 + confiance 0.95 -> PERM_BAN')

-- ===========================================================================
T.section('policy : deux phases §87')

Config.load({ mode = 'ENFORCE', enforcement = { two_phase = true } })

-- Premier incident (occurrence 1), action dure non critique : rétrogradé en observation.
local firstHard = Policy.decide({ source = 2, category = 'movement', severity = 'HIGH', confidence = 0.7, risk_after = 72, occurrences = 1 })
T.equal(firstHard.action, 'WARN', 'action dure première fois -> rétrogradée en WARN §87')
T.equal(firstHard.phase, 'observe', 'phase = observe')
T.equal(firstHard.downgraded_from, 'KICK', 'note la rétrogradation depuis KICK')

-- Confirmé (occurrence 2) : la sanction dure s'applique.
local confirmed = Policy.decide({ source = 2, category = 'movement', severity = 'HIGH', confidence = 0.7, risk_after = 72, occurrences = 2 })
T.equal(confirmed.action, 'KICK', 'confirmé (répétition) -> KICK appliqué §87')
T.equal(confirmed.phase, 'enforce', 'phase = enforce')

-- Critique : pas de deux-phases, sanction immédiate même à la 1re occurrence.
local crit = Policy.decide({ source = 2, category = 'state', severity = 'CRITICAL', confidence = 0.9, risk_after = 90, occurrences = 1 })
T.equal(crit.action, 'TEMP_BAN', 'critique -> sanction immédiate (pas de deux-phases) §87')

-- ===========================================================================
T.section('policy : containment immédiat §88')

-- Catégorie entity : risque technique immédiat -> containment réversible.
local entityInc = Policy.decide({ source = 3, category = 'entity', severity = 'HIGH', confidence = 0.7, risk_after = 72, occurrences = 1 })
T.equal(entityInc.containment, 'REMOVE_ENTITY', 'entity -> containment REMOVE_ENTITY §88')

local netInc = Policy.decide({ source = 3, category = 'network', severity = 'HIGH', confidence = 0.7, risk_after = 72, occurrences = 1 })
T.equal(netInc.containment, 'BLOCK_ACTION', 'network -> containment BLOCK_ACTION §88')

-- Mouvement : pas de containment immédiat (pas un risque technique cassant le jeu).
local movInc = Policy.decide({ source = 3, category = 'movement', severity = 'HIGH', confidence = 0.7, risk_after = 72, occurrences = 2 })
T.falsy(movInc.containment, 'movement -> pas de containment immédiat')

-- ===========================================================================
T.section('enforcement : mode SHADOW n applique rien §31')

Config.load({ mode = 'SHADOW' })
resetEnf()
local applied = {}
Enforcement.setExecutor('KICK', function(inc) applied[#applied + 1] = 'KICK:' .. inc.source end)

local inc = Incident.open({ source = 10, detector = 'd', category = 'movement', severity = 'HIGH',
                            confidence = 0.8, risk_after = 90, occurrences = 3 })
local result = Enforcement.handle(inc)
T.truthy(result.shadow, 'SHADOW : décision marquée shadow')
T.falsy(result.applied, 'SHADOW : rien appliqué §31')
T.equal(#applied, 0, 'l exécuteur KICK n a PAS été appelé en SHADOW')
T.equal(Enforcement.stats.shadowed, 1, 'compteur shadow incrémenté')
-- Mais la décision est enregistrée sur l'incident (pour les stats / analyse).
T.truthy(inc.decision ~= nil, 'décision tout de même enregistrée en SHADOW')

-- ===========================================================================
T.section('enforcement : mode MONITOR bloque le destructif §31')

-- two_phase OFF pour tester le blocage MONITOR isolément : sinon la première occurrence
-- d'une action dure est rétrogradée en WARN (deux-phases) avant d'atteindre le blocage.
Config.load({ mode = 'MONITOR', enforcement = { two_phase = false } })
resetEnf()
applied = {}
Enforcement.setExecutor('KICK', function(inc) applied[#applied + 1] = 'KICK' end)
Enforcement.setExecutor('TEMP_BAN', function(inc) applied[#applied + 1] = 'TEMP_BAN' end)

-- Action destructive : bloquée en MONITOR.
inc = Incident.open({ source = 11, detector = 'd', category = 'movement', severity = 'HIGH',
                      confidence = 0.8, risk_after = 90 })
result = Enforcement.handle(inc)
T.truthy(result.blocked_by_mode, 'MONITOR : action destructive bloquée §31')
T.equal(#applied, 0, 'action destructive non appliquée en MONITOR')

-- Action non destructive (WARN via score moyen) : appliquée en MONITOR.
resetEnf()
Enforcement.setExecutor('WARN', function() applied[#applied + 1] = 'WARN' end)
applied = {}
inc = Incident.open({ source = 12, detector = 'd', category = 'movement', severity = 'MEDIUM',
                      confidence = 0.5, risk_after = 45, occurrences = 1 })
result = Enforcement.handle(inc)
T.truthy(result.applied, 'MONITOR : action non destructive appliquée')

-- ===========================================================================
T.section('enforcement : mode ENFORCE applique §31')

Config.load({ mode = 'ENFORCE', enforcement = { two_phase = false } })
resetEnf()
applied = {}
Enforcement.setExecutor('KICK', function(inc) applied[#applied + 1] = inc.source end)

inc = Incident.open({ source = 13, detector = 'd', category = 'movement', severity = 'HIGH',
                      confidence = 0.7, risk_after = 72, occurrences = 1 })
result = Enforcement.handle(inc)
T.truthy(result.applied, 'ENFORCE : action appliquée')
T.equal(result.action, 'KICK', 'KICK appliqué')
T.equal(#applied, 1, 'exécuteur KICK appelé une fois')
T.equal(applied[1], 13, 'exécuteur reçu le bon joueur')

-- ===========================================================================
T.section('enforcement : containment appliqué (réversible) §88')

Config.load({ mode = 'ENFORCE', enforcement = { two_phase = false } })
resetEnf()
local contained = {}
Enforcement.setContainer('REMOVE_ENTITY', function(inc) contained[#contained + 1] = inc.source end)

inc = Incident.open({ source = 14, detector = 'd', category = 'entity', severity = 'HIGH',
                      confidence = 0.7, risk_after = 72, occurrences = 1 })
result = Enforcement.handle(inc)
T.equal(#contained, 1, 'containment REMOVE_ENTITY appliqué §88')
T.equal(Enforcement.stats.contained, 1, 'compteur containment incrémenté')

-- ===========================================================================
T.section('enforcement : audit §43')

Config.load({ mode = 'ENFORCE', enforcement = { two_phase = false } })
resetEnf()
Enforcement.setExecutor('KICK', function() end)
inc = Incident.open({ source = 15, detector = 'd', category = 'movement', severity = 'HIGH',
                      confidence = 0.7, risk_after = 72, occurrences = 1 })
Enforcement.handle(inc)
local auditLog = Enforcement.getAudit(10)
T.truthy(#auditLog >= 1, 'action auditée §43')
local last = auditLog[#auditLog]
T.equal(last.target, 15, 'audit nomme la cible')
T.equal(last.action, 'KICK', 'audit nomme l action')
T.truthy(last.reason ~= nil, 'audit contient la raison')
T.truthy(last.result == 'applied', 'audit contient le résultat')

-- Action manuelle admin auditée avec l'acteur (§43).
Enforcement.manualAction({ admin = 'admin_bob', target = 20, action = 'TEMP_BAN', reason = 'manual review' })
last = Enforcement.getAudit(1)[1]
T.equal(last.actor, 'admin_bob', 'action manuelle : acteur audité §43')
T.truthy(last.manual, 'marquée manuelle')

-- ===========================================================================
T.section('enforcement : exécuteur fautif isolé §104')

Config.load({ mode = 'ENFORCE', enforcement = { two_phase = false } })
resetEnf()
Enforcement.setExecutor('KICK', function() error('executor boom') end)
inc = Incident.open({ source = 16, detector = 'd', category = 'movement', severity = 'HIGH',
                      confidence = 0.7, risk_after = 72, occurrences = 1 })
local safe = pcall(Enforcement.handle, inc)
T.truthy(safe, 'handle ne propage pas l exception de l exécuteur §104')
T.equal(Enforcement.stats.executor_errors, 1, 'erreur d exécuteur comptée')

-- L'enforcement reste fonctionnel pour l'incident suivant.
Enforcement.setExecutor('WARN', function() end)
inc = Incident.open({ source = 17, detector = 'd', category = 'movement', severity = 'MEDIUM',
                      confidence = 0.5, risk_after = 45, occurrences = 1 })
result = Enforcement.handle(inc)
T.truthy(result.applied, 'enforcement reste fonctionnel après erreur §104')

-- ===========================================================================
T.section('enforcement : action dure sans exécuteur ne prétend pas §54')

Config.load({ mode = 'ENFORCE', enforcement = { two_phase = false } })
resetEnf()
-- Aucun exécuteur KICK enregistré (adaptateur non installé).
inc = Incident.open({ source = 18, detector = 'd', category = 'movement', severity = 'HIGH',
                      confidence = 0.7, risk_after = 72, occurrences = 1 })
result = Enforcement.handle(inc)
T.falsy(result.applied, 'action dure sans exécuteur : NON appliquée')
T.equal(result.reason, 'no executor', 'raison honnête : pas d exécuteur (pas de faux succès) §54')

-- ===========================================================================
T.section('exemption STAFF/ADMIN : jamais sanctionné (§04)')

-- Correspondance d'identifiants (pure).
T.truthy(Enforcement.matchStaffIdentifiers({ 'license:abc', 'discord:42' }, { 'discord:42' }),
    'identifiant staff reconnu')
T.truthy(Enforcement.matchStaffIdentifiers({ 'LICENSE:ABC' }, { 'license:abc' }),
    'correspondance insensible à la casse')
T.falsy(Enforcement.matchStaffIdentifiers({ 'license:zzz' }, { 'license:abc' }),
    'non-staff non reconnu')

-- Un joueur STAFF (via liste d'identifiants) : décision dure calculée, mais RIEN appliqué.
Config.load({ mode = 'ENFORCE', enforcement = { two_phase = false },
              staff = { exempt = true, identifiers = { 'license:staffguy' } } })
resetEnf()
Enforcement.setExecutor('PERM_BAN', function() error('un staff ne doit JAMAIS être banni') end)
-- On simule GetPlayerIdentifiers pour ce test.
local _gpi = GetPlayerIdentifiers
GetPlayerIdentifiers = function(s) return (tostring(s) == '19') and { 'license:staffguy' } or {} end
inc = Incident.open({ source = 19, detector = 'inj', category = 'resource', severity = 'CRITICAL',
                      confidence = 0.98, risk_after = 100, occurrences = 2 })
result = Enforcement.handle(inc)
T.falsy(result.applied, 'staff : aucune sanction appliquée')
T.truthy(result.staff_exempt, 'marqué staff_exempt')
-- Un NON-staff dans la même situation EST banni (contraste), avec un exécuteur qui réussit.
resetEnf()
local banned = false
Enforcement.setExecutor('PERM_BAN', function() banned = true return { ok = true } end)
inc = Incident.open({ source = 20, detector = 'inj', category = 'resource', severity = 'CRITICAL',
                      confidence = 0.98, risk_after = 100, occurrences = 2 })
result = Enforcement.handle(inc)
T.truthy(banned, 'non-staff : sanction appliquée (contraste)')
GetPlayerIdentifiers = _gpi
Config.load({})

os.exit(T.summary() and 0 or 1)
