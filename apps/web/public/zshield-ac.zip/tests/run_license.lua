--[[
    FILE:         tests/run_license.lua
    PURPOSE:      Tests du système de licence : signature infalsifiable, expiration, et
                  surtout — la protection est COUPÉE et signalée au démarrage quand la
                  licence est absente ou expirée.
    USAGE:        lua5.4 tests/run_license.lua
]]

local H = dofile('tests/harness.lua')
local T = H.T

-- Charger le core dans l'ordre du fxmanifest (avec sha256 + license).
dofile('shared/constants.lua'); dofile('core/log.lua'); dofile('core/util.lua'); dofile('core/perf.lua')
dofile('shared/sha256.lua'); dofile('shared/schema.lua'); dofile('core/config.lua')
dofile('server/license.lua')
dofile('server/firewall/ratelimit.lua'); dofile('server/context.lua'); dofile('server/firewall/firewall.lua')
dofile('server/detection/engine.lua'); dofile('server/detection/reputation.lua'); dofile('server/detection/evidence.lua')
dofile('server/detection/correlation.lua'); dofile('server/detection/risk.lua')
dofile('server/incident.lua')
dofile('server/enforcement/policy.lua'); dofile('server/enforcement/enforcement.lua')
dofile('server/detection/movement.lua'); dofile('server/detection/entity.lua'); dofile('server/detection/economy.lua')
dofile('server/firewall/gameevents.lua'); dofile('server/firewall/statebag.lua'); dofile('server/hardening/orchestrator.lua')
dofile('server/persistence/circuit.lua'); dofile('server/persistence/store.lua')
dofile('server/integrations/discord.lua')
dofile('server/api.lua'); dofile('server/sdk.lua')
dofile('server/adapters/framework.lua'); dofile('server/hardening.lua')
dofile('server/health.lua'); dofile('server/bootstrap.lua')

local License = ZShield.License
local Bootstrap = ZShield.Bootstrap
local now = os.time()
ZShield.Log.console = false
License.setSecret('test-signing-secret')

-- ===========================================================================
T.section('sha256 : vecteur connu')
T.equal(ZShield.Sha256.hash('abc'),
    'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad', 'sha256("abc") correct')

-- ===========================================================================
T.section('licence : signature et vérification')

local valid = License.sign({ server_id = 'any', plan = 'pro', issued_at = now, expires_at = now + 7 * 86400 })
local r = License.verify(valid, now)
T.equal(r.state, 'VALID', 'jeton bien signé et non expiré -> VALID')
T.equal(r.plan, 'pro', 'plan lu depuis la licence')
T.truthy(r.days_left >= 6, 'jours restants calculés (' .. tostring(r.days_left) .. ')')

-- Expiration (ex : fin d'essai gratuit).
local expired = License.sign({ server_id = 'any', plan = 'trial', issued_at = now - 8 * 86400, expires_at = now - 86400 })
T.equal(License.verify(expired, now).state, 'EXPIRED', 'jeton dépassé -> EXPIRED')

-- Falsification : on change un octet de la signature.
local tampered = valid:sub(1, #valid - 1) .. (valid:sub(-1) == 'a' and 'b' or 'a')
T.equal(License.verify(tampered, now).state, 'INVALID', 'signature modifiée -> INVALID')

-- Payload modifié (prolonger l'expiration) sans re-signer : rejeté.
local forged = valid:gsub('|(%d+)~', '|' .. (now + 9999 * 86400) .. '~', 1)
T.equal(License.verify(forged, now).state, 'INVALID', 'expiration trafiquée sans signature -> INVALID')

-- Absence de licence.
T.equal(License.verify('', now).state, 'MISSING', 'aucune licence -> MISSING')
T.equal(License.verify(nil, now).state, 'MISSING', 'licence nil -> MISSING')

-- ===========================================================================
T.section('licence : liaison à un serveur')

-- Licence liée à l'empreinte 'serverAAA'.
local bound = License.sign({ server_id = 'serverAAA', plan = 'pro', issued_at = now, expires_at = now + 86400 })
T.equal(License.verify(bound, now, 'serverAAA').state, 'VALID', 'bon serveur -> VALID')
T.equal(License.verify(bound, now, 'serverBBB').state, 'WRONG_SERVER', 'autre serveur -> WRONG_SERVER (partage bloqué)')

-- Licence 'any' : passe sur n'importe quel serveur.
local anyLic = License.sign({ server_id = 'any', plan = 'pro', issued_at = now, expires_at = now + 86400 })
T.equal(License.verify(anyLic, now, 'serverAAA').state, 'VALID', "licence 'any' passe sur serverAAA")
T.equal(License.verify(anyLic, now, 'serverZZZ').state, 'VALID', "licence 'any' passe sur serverZZZ")

-- L'empreinte est déterministe et courte.
License.setIdentity(nil)
T.truthy(#License.identity() == 16, 'empreinte de 16 caractères')

-- ===========================================================================
T.section('démarrage : licence expirée coupe la protection')

local function resetEngines()
    H.reset()
    Bootstrap.started = false
    Bootstrap.armed = false
    ZShield.licensed = false
    ZShield.Bus.handlers = {}
    ZShield.Health.components = {}
    ZShield.Detection.detectors = {}; ZShield.Detection.order = {}; ZShield.Detection.health = {}
end

resetEngines()
local started = Bootstrap.start({ mode = 'ENFORCE', license = { key = expired } })
ZShield.Log.console = false
T.truthy(started, 'la ressource se charge quand même (pour pouvoir re-vérifier)')
T.falsy(ZShield.licensed, 'licence expirée -> non licencié')
T.equal(#ZShield.Detection.order, 0, 'AUCUN détecteur armé : protection coupée')
T.equal(ZShield.Health.get('license').status, 'FAILED', 'santé licence = FAILED')

-- Une bannière lisible est produite pour l'affichage au démarrage.
local banner = License.banner(License.verify(expired, now))
T.truthy(banner ~= nil and #banner >= 3, 'bannière de licence produite pour la console')
local joined = table.concat(banner, ' ')
T.truthy(joined:find('DÉSACTIVÉE'), 'la bannière annonce la protection désactivée')

-- ===========================================================================
T.section('démarrage : licence valide arme la protection')

resetEngines()
Bootstrap.start({ mode = 'ENFORCE', license = { key = valid } })
ZShield.Log.console = false
T.truthy(ZShield.licensed, 'licence valide -> licencié')
T.truthy(#ZShield.Detection.order >= 1, 'les détecteurs sont armés (protection active)')
T.equal(ZShield.Health.get('license').status, 'HEALTHY', 'santé licence = HEALTHY')

-- ===========================================================================
T.section('détection auto : la clé arrive après le démarrage (agent)')

-- Démarrage SANS licence : protection coupée.
resetEngines()
Bootstrap.start({ mode = 'ENFORCE', license = { key = '' } })
ZShield.Log.console = false
T.falsy(ZShield.licensed, 'sans clé -> non licencié')
T.equal(#ZShield.Detection.order, 0, 'aucune protection armée au départ')

-- L'agent livre la clé à chaud via l'export. Elle doit être détectée et armer la protection.
local ok2 = ZShield.SetLicense(valid)
ZShield.Log.console = false
T.truthy(ok2, 'SetLicense(valide) accepté')
T.truthy(ZShield.licensed, 'clé détectée -> licencié, sans rien coller')
T.truthy(#ZShield.Detection.order >= 1, 'protection armée automatiquement à réception de la clé')

-- Une clé pour un AUTRE serveur, livrée à chaud, est refusée.
resetEngines()
Bootstrap.start({ mode = 'ENFORCE', license = { key = '' } })
ZShield.Log.console = false
local okBad = ZShield.SetLicense(bound)  -- bound = pour 'serverAAA', pas ce serveur
T.falsy(okBad, 'clé d\'un autre serveur refusée')
T.falsy(ZShield.licensed, 'toujours non licencié après une mauvaise clé')

os.exit(T.summary() and 0 or 1)
