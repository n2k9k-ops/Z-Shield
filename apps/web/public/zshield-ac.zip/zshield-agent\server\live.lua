--[[
    zshield-agent / server/live.lua

    PURPOSE
        "Vue live" : envoie au dashboard un instantané des joueurs connectés
        (position, santé, arme, ping) pour afficher la carte en direct.

    DIFFÉRENCE AVEC LA TÉLÉMÉTRIE
        La télémétrie ne contient jamais de donnée de joueur. La vue live, elle,
        en contient — c'est son rôle — donc elle est séparée, DÉSACTIVÉE par
        défaut (config `live.enabled = false`) et ÉPHÉMÈRE : la plateforme ne
        l'écrit dans aucune base, elle ne garde que le DERNIER instantané, en
        mémoire, quelques secondes. Rien n'est historisé.

    DONNÉES (par joueur, plafonnées à live.max_players)
        id (slot serveur), name, identifier (licence, si live.identifiers), x, y, z,
        h (cap), hp, armor, veh (dans un véhicule ?), weapon (hash), ping.
        Jamais d'IP, de Steam, de Discord, de HWID.

    ROBUSTESSE
        - Un seul envoi à la fois ; en cas d'échec on ralentit (x2, plafonné à 60 s)
          puis on reprend l'intervalle normal au premier succès.
        - Les natives sont injectables (Live.setNatives) pour les tests hors FiveM.
        - Aucune file d'attente : un instantané périmé n'a aucune valeur.

    PUBLIC API
        ZShield.Live.collect()  -> players[]
        ZShield.Live.push()     -> ok, count
        ZShield.Live.start() / stop() / stats()
        ZShield.Live.setNatives(tbl)   -- tests
]]

ZShield = ZShield or {}

local Const = ZShield.Const
local Log = ZShield.Log

local Live = {}

local running = false
local stats = { sent = 0, failed = 0, last_push_at = nil, last_count = 0 }
local inFlight = false

local function defaultNatives()
    return {
        players = GetPlayers,
        name = GetPlayerName,
        ping = GetPlayerPing,
        ped = GetPlayerPed,
        coords = GetEntityCoords,
        heading = GetEntityHeading,
        health = GetEntityHealth,
        armour = GetPedArmour,
        inVehicle = function(ped)
            if not GetVehiclePedIsIn then return false end
            local v = GetVehiclePedIsIn(ped, false)
            return v ~= nil and v ~= 0
        end,
        weapon = GetSelectedPedWeapon,
        license = function(id)
            if not GetPlayerIdentifierByType then return nil end
            return GetPlayerIdentifierByType(id, 'license')
        end,
    }
end

local natives = nil
local function N()
    if not natives then natives = defaultNatives() end
    return natives
end

--- Remplace les natives (tests hors FiveM).
function Live.setNatives(tbl)
    natives = tbl
end

local function round1(v)
    if type(v) ~= 'number' then return 0 end
    return math.floor(v * 10 + 0.5) / 10
end

local function clip(s, n)
    s = tostring(s or '')
    if #s > n then s = s:sub(1, n) end
    return s
end

local function liveConfig()
    local cfg = ZShield.Agent and ZShield.Agent.config and ZShield.Agent.config()
    return (cfg and cfg.live) or { enabled = false, interval = 5, max_players = 128, identifiers = true }
end

--- Construit la liste des joueurs. Chaque lecture est protégée : un joueur en
--- cours de connexion (ped absent) ou une native indisponible ne casse pas le lot.
function Live.collect()
    local n = N()
    local conf = liveConfig()
    local out = {}
    if not n.players then return out end

    local okList, ids = pcall(n.players)
    if not okList or type(ids) ~= 'table' then return out end

    for i = 1, #ids do
        if #out >= conf.max_players then break end
        local id = tonumber(ids[i])
        if id then
            local okP, entry = pcall(function()
                local ped = n.ped and n.ped(id) or 0
                if not ped or ped == 0 then return nil end -- pas encore spawné
                local c = n.coords(ped)
                if not c then return nil end
                local e = {
                    id = id,
                    name = clip(n.name and n.name(id) or ('#' .. id), 64),
                    x = round1(c.x), y = round1(c.y), z = round1(c.z),
                    h = round1(n.heading and n.heading(ped) or 0),
                    hp = math.floor(tonumber(n.health and n.health(ped) or 0) or 0),
                    armor = math.floor(tonumber(n.armour and n.armour(ped) or 0) or 0),
                    veh = n.inVehicle and n.inVehicle(ped) or false,
                    ping = math.floor(tonumber(n.ping and n.ping(id) or 0) or 0),
                }
                local w = n.weapon and n.weapon(ped)
                if type(w) == 'number' then e.weapon = w end
                if conf.identifiers and n.license then
                    local lic = n.license(id)
                    if type(lic) == 'string' and lic ~= '' then e.identifier = clip(lic, 64) end
                end
                return e
            end)
            if okP and entry then out[#out + 1] = entry end
        end
    end
    return out
end

--- Envoie un instantané. Retourne ok, count.
function Live.push()
    if inFlight then return false, 0 end
    inFlight = true
    local players = Live.collect()
    local ok, _, errCode, reason = ZShield.Agent.request('POST', Const.ENDPOINT.LIVE, {
        sampled_at = os.time(),
        players = players,
    }, { kind = 'live' })
    inFlight = false

    if not ok then
        stats.failed = stats.failed + 1
        Log.debug('live push failed', { error = errCode, reason = reason })
        return false, 0
    end
    stats.sent = stats.sent + 1
    stats.last_push_at = os.time()
    stats.last_count = #players
    return true, #players
end

function Live.start()
    if running then return end
    running = true

    CreateThread(function()
        local penalty = 0
        while running do
            local conf = liveConfig()
            local wait = conf.interval
            if conf.enabled and ZShield.Agent.isOperational() then
                local okCall, ok = pcall(Live.push)
                if not okCall then
                    Log.error('live push raised an error', { error = tostring(ok) })
                    ok = false
                end
                if ok then
                    penalty = 0
                else
                    penalty = math.min(60, math.max(conf.interval, penalty * 2))
                end
            end
            Wait(math.max(wait, penalty) * 1000)
        end
    end)

    Log.info('live module ready', { enabled = liveConfig().enabled })
end

function Live.stop()
    running = false
end

function Live.stats()
    return {
        enabled = liveConfig().enabled,
        sent = stats.sent,
        failed = stats.failed,
        last_push_at = stats.last_push_at,
        last_count = stats.last_count,
    }
end

ZShield.Live = Live

return Live
