fx_version 'cerulean'
game 'gta5'

name 'zshield-client'
author 'Z-Shield'
description 'Module client Z-Shield : détections d\'état de jeu, énumération des ressources client chargées, et capture de la FENÊTRE DE JEU à la demande du serveur (preuve d\'incident), remontées par rapports signés. Ne lit jamais le bureau, les fichiers, la mémoire d\'autres process, ni d\'autres applications — uniquement le jeu et son propre environnement de ressources.'
version '1.0.0'

-- Logique de détection PURE (partagée, testée hors jeu) + crypto de signature.
shared_scripts {
    'shared/sha256.lua',
    'shared/detections.lua',
}

-- Couche d'exécution FiveM : échantillonne l'état du jeu, signe, envoie.
client_scripts {
    'client/main.lua',
}
