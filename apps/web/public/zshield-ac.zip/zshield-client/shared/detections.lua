--[[
    FILE:         shared/detections.lua  (zshield-client)
    PURPOSE:      Détections CÔTÉ CLIENT, pures et testables. Chaque règle lit un
                  ÉCHANTILLON D'ÉTAT DU JEU (natives du joueur local : arme, caméra,
                  endurance, modèle, entités attachées…) et renvoie un signal quand
                  l'état est anormal. Ce sont exactement les cas qu'un anticheat
                  SERVEUR ne peut pas voir seul (état purement client).

    LIMITE ASSUMÉE : le joueur contrôle sa machine ; une détection client est donc
    CORROBORANTE, jamais une preuve absolue. La force du module vient de deux choses
    que le SERVEUR, lui, vérifie : (1) le heartbeat signé — un tricheur qui retire le
    module cesse d'émettre, ce qui est observable ; (2) l'intégrité — le hash des
    scripts client est comparé côté serveur. Voir server/clientguard.lua.

    VIE PRIVÉE : on ne lit QUE l'état du jeu (comme tout anticheat FiveM client).
    Jamais l'écran, les fichiers, ni une autre application.

    PUBLIC API :  ZShieldClient.Detections.scan(sample, isEnabled) -> { signals... }
                  ZShieldClient.Detections.RULES  (id -> règle)
]]

ZShieldClient = ZShieldClient or {}

local D = { RULES = {} }

-- Une règle : id (= clé de config), libellé, sévérité, et test(sample) -> reason|nil.
local function rule(id, label, severity, test)
    D.RULES[#D.RULES + 1] = { id = id, label = label, severity = severity, test = test }
end

-- Chaque test reçoit `s` (l'échantillon). Retourne une raison (string) si anormal.
rule('no_recoil', 'Anti No Recoil', 'HIGH', function(s)
    -- Tir en cours mais recul mesuré ~0 sur plusieurs tirs : aide à la visée.
    if s.firing and (s.shots or 0) >= 6 and (s.recoil or 1) <= 0.01 then
        return 'no recoil while firing'
    end
end)

rule('no_reload', 'Anti No Reload', 'HIGH', function(s)
    if (s.shotsSinceReload or 0) > (s.clipSize or 30) then
        return 'shots exceed clip size without reload'
    end
end)

rule('hitbox', 'Anti Hitbox Modifier', 'HIGH', function(s)
    if s.hitboxScale and s.hitboxScale > 1.05 then return 'enlarged hitbox' end
end)

rule('weapon_component', 'Anti Weapon Component Modifier', 'MEDIUM', function(s)
    if s.illegalComponent == true then return 'illegal weapon component' end
end)

rule('night_vision', 'Anti Night Vision', 'MEDIUM', function(s)
    if s.nightVision == true and s.nightVisionAllowed ~= true then return 'night vision on' end
end)

rule('infinite_stamina', 'Anti Infinite Stamina', 'MEDIUM', function(s)
    -- Course prolongée sans consommation d'endurance.
    if (s.sprintSeconds or 0) > 30 and (s.staminaDrained or 1) <= 0 then
        return 'sprinting without stamina drain'
    end
end)

rule('combat_roll', 'Anti Infinite Combat Roll', 'MEDIUM', function(s)
    if (s.rollsInWindow or 0) > (s.rollLimit or 3) then return 'combat roll spam' end
end)

rule('invisibility', 'Anti Invisibility', 'HIGH', function(s)
    if s.visible == false or (s.alpha ~= nil and s.alpha < 200) then
        return 'local player invisible/transparent'
    end
end)

rule('model_change', 'Anti Model Change', 'MEDIUM', function(s)
    if s.modelChanged == true and s.modelAllowed ~= true then return 'unauthorized model' end
end)

rule('dev_tools', 'Anti Dev Tools', 'HIGH', function(s)
    if s.devMode == true then return 'developer/menu tooling active' end
end)

rule('clear_tasks', 'Anti Clear Tasks', 'MEDIUM', function(s)
    if (s.clearTasksOnOthers or 0) > 0 then return 'clearing tasks on other players' end
end)

rule('afk_bypass', 'Anti AFK Bypass', 'LOW', function(s)
    if s.afkBypass == true then return 'AFK bypass tooling' end
end)

rule('voice_exploit', 'Anti Voice Exploits', 'MEDIUM', function(s)
    if s.voiceRange and s.voiceRange > (s.voiceMax or 20) then return 'voice range beyond max' end
end)

rule('magneto', 'Anti Magneto', 'MEDIUM', function(s)
    if (s.attachedEntities or 0) > (s.attachLimit or 2) then return 'abnormal entity attachment (magneto)' end
end)

rule('particles', 'AI Anti Particle', 'LOW', function(s)
    if (s.particleCount or 0) > (s.particleLimit or 20) or (s.particleScale or 0) > (s.particleScaleLimit or 10) then
        return 'particle abuse'
    end
end)

rule('sound_exploit', 'Anti Sound Exploits', 'LOW', function(s)
    if (s.soundsInWindow or 0) > (s.soundLimit or 30) then return 'sound spam' end
end)

rule('vehicle_handling', 'Anti Vehicle Handling Modifier', 'HIGH', function(s)
    if s.handlingModified == true then return 'vehicle handling modified' end
end)

rule('super_punch', 'Anti Super Punch', 'HIGH', function(s)
    if s.meleeForce and s.meleeForce > (s.meleeMax or 1000) then return 'impossible melee force' end
end)

--- Passe l'échantillon dans toutes les règles ACTIVÉES. `isEnabled(id)` -> bool
--- (par défaut tout activé). Retourne la liste des signaux détectés.
function D.scan(sample, isEnabled)
    sample = sample or {}
    local out = {}
    for _, r in ipairs(D.RULES) do
        if isEnabled == nil or isEnabled(r.id) then
            local ok, reason = pcall(r.test, sample)
            if ok and reason then
                out[#out + 1] = { id = r.id, severity = r.severity, reason = reason }
            end
        end
    end
    return out
end

-- ===========================================================================
-- Balayage d'ENVIRONNEMENT client (§ intégrité client, faisable dans FiveM).
--
-- Ce qu'un script client FiveM PEUT observer honnêtement : la liste des ressources
-- client chargées, et les globales présentes dans son propre environnement Lua. Un
-- exécuteur/menu injecté ajoute souvent une ressource non déclarée et/ou des globales
-- caractéristiques. On les REMONTE (signal corroborant, faible/moyen — renommables,
-- donc jamais un ban sec ; le serveur corrèle).
--
-- CE QUE ÇA N'EST PAS : ce n'est PAS un scan de la mémoire du process, ni des modules
-- DLL de l'OS, ni un anti-debug/anti-overlay noyau. FiveM (Lua/NUI) n'expose AUCUNE
-- API pour ça — cela exigerait un driver natif séparé (voir docs). On ne prétend donc
-- pas le faire : on couvre le niveau RESSOURCE/ENVIRONNEMENT FiveM, honnêtement.
-- ===========================================================================

-- Signatures de ressources client typiques d'exécuteurs/menus (sous-chaînes, minuscules).
D.CHEAT_RESOURCE_SIGS = {
    'eulen', 'redengine', 'unex', 'lynx', 'skript', 'hydrogen', 'brutan',
    'susano', 'tzx', 'tsunami', 'absolute', 'lumia', 'cherax', 'hammafia',
    'executor', 'injector', 'cheat', 'menu_hack',
}
-- Globales notoires posées par certains exécuteurs dans l'environnement client.
D.CHEAT_GLOBAL_SIGS = {
    'eulen', 'lynx_loaded', 'redengine', '__executor', 'cheat_menu', 'hax',
}

local function lc(s) return type(s) == 'string' and s:lower() or '' end

--- Analyse l'environnement client. Entrées :
---   resources : liste des noms de ressources client chargées.
---   globals   : liste des noms de globales présentes dans _G.
---   opts      : { allow = { [nom]=true } } — ressources connues à ignorer (anti-FP).
--- Retourne des signaux { id, severity, reason }. Fonction PURE (testée hors jeu).
function D.scanEnvironment(resources, globals, opts)
    opts = opts or {}
    local allow = opts.allow or {}
    local out = {}
    for _, name in ipairs(resources or {}) do
        local low = lc(name)
        if not allow[name] then
            for _, sig in ipairs(D.CHEAT_RESOURCE_SIGS) do
                if low ~= '' and low:find(sig, 1, true) then
                    out[#out + 1] = { id = 'cheat_resource', severity = 'MEDIUM',
                        reason = 'ressource client suspecte: ' .. name }
                    break
                end
            end
        end
    end
    for _, gname in ipairs(globals or {}) do
        local low = lc(gname)
        for _, sig in ipairs(D.CHEAT_GLOBAL_SIGS) do
            if low ~= '' and low:find(sig, 1, true) then
                out[#out + 1] = { id = 'cheat_global', severity = 'LOW',
                    reason = 'globale client suspecte: ' .. gname }
                break
            end
        end
    end
    return out
end

ZShieldClient.Detections = D
return D
