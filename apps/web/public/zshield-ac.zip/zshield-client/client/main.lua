--[[
    FILE:         client/main.lua  (zshield-client)
    PURPOSE:      Couche d'exécution FiveM du module client. Lit périodiquement
                  l'ÉTAT DU JEU du joueur local (natives), passe l'échantillon dans
                  les détections pures (shared/detections.lua), et envoie au serveur
                  un rapport SIGNÉ (HMAC) avec un secret de session.

    CE QU'ON LIT : uniquement l'état du jeu (arme, caméra, endurance, modèle,
    entités attachées…). JAMAIS l'écran, les fichiers, ni une autre application.

    NB : cette couche dépend des natives FiveM ; elle n'est pas testée en isolation.
    Toute la LOGIQUE de détection est dans shared/detections.lua, testée à part.
]]

local Detections = ZShieldClient.Detections
local sessionSecret = nil
local nonceCounter = 0

-- HMAC-SHA256 attendu par le serveur. On réutilise l'implémentation partagée.
local function hmac(key, msg)
    return ZShieldClient.Sha256 and ZShieldClient.Sha256.hmac(key, msg) or ''
end

local function nowMs() return GetGameTimer() end
local function nextNonce()
    nonceCounter = nonceCounter + 1
    return string.format('%d-%d', GetGameTimer(), nonceCounter)
end

-- HWID CÔTÉ CLIENT : purement CORROBORANT. La source de vérité reste le HWID
-- OBSERVÉ serveur (jetons FiveM, non falsifiables). Ici on ne fait que rapporter
-- ce que le client voit ; le serveur compare les deux (une divergence = signal).
-- On ne lit AUCUN identifiant hors-jeu : uniquement l'identifiant fourni par
-- FiveM au titre du jeu (aucune lecture de disque, de matériel tiers, etc.).
local function clientHwid()
    local ok, id = pcall(function()
        return GetPlayerToken and GetPlayerToken(PlayerId(), 0) or nil
    end)
    return (ok and type(id) == 'string') and id or ''
end

-- Hash d'intégrité : condensé des scripts client (détecte une falsification locale).
local function integrityHash()
    local res = GetCurrentResourceName()
    local parts = {}
    for _, f in ipairs({ 'shared/detections.lua', 'client/main.lua' }) do
        parts[#parts + 1] = LoadResourceFile(res, f) or ''
    end
    return ZShieldClient.Sha256 and ZShieldClient.Sha256.hash(table.concat(parts, '|')) or ''
end

-- Clé de provisioning partagée (posée par l'opérateur via convar, comme la clé
-- d'agent). Sert à DÉRIVER le secret de session sans jamais le transmettre.
local function provisioningKey()
    return GetConvar('zshield_client_provisioning_key', '')
end

local myClientNonce = nil
local currentHash = nil

-- 1) Handshake : on envoie NOTRE nonce ; le serveur renvoie les nonces publics.
--    On dérive alors le secret localement (HMAC(clé, sessionId|serverNonce|clientNonce)).
RegisterNetEvent('zshield:cg:handshake', function(hs)
    if type(hs) ~= 'table' then return end
    if hs.mode == 'derived' and hs.session_id and hs.server_nonce and myClientNonce then
        local prov = provisioningKey()
        if prov ~= '' then
            sessionSecret = ZShieldClient.Sha256.hmac(prov,
                hs.session_id .. '|' .. hs.server_nonce .. '|' .. myClientNonce)
        end
    elseif hs.mode == 'direct' and hs.secret then
        sessionSecret = hs.secret   -- repli dev (aucune clé de provisioning)
    end
end)

-- 3) Attestation d'intégrité : répondre au défi frais par HMAC(secret, défi | hash).
RegisterNetEvent('zshield:cg:challenge', function(challenge)
    if sessionSecret and type(challenge) == 'string' then
        local h = currentHash or integrityHash()
        TriggerServerEvent('zshield:cg:attest',
            ZShieldClient.Sha256.hmac(sessionSecret, challenge .. '|' .. h))
    end
end)

CreateThread(function()
    Wait(2000)
    myClientNonce = string.format('%d-%d', GetGameTimer(), math.random(1, 1e9))
    currentHash = integrityHash()
    TriggerServerEvent('zshield:cg:register', myClientNonce)
end)

local function isEnabled(id)
    -- L'opérateur peut couper une règle : convar poussée par la config serveur.
    return GetConvar('zshield_client_' .. id, 'true') ~= 'false'
end

-- Ressources client chargées (niveau FiveM). Un menu injecté ajoute souvent une
-- ressource non déclarée. On ne lit QUE la liste FiveM — pas les modules de l'OS.
local function collectResources()
    local list = {}
    if type(GetNumResources) ~= 'function' then return list end
    for i = 0, (GetNumResources() - 1) do
        local ok, name = pcall(GetResourceByFindIndex, i)
        if ok and type(name) == 'string' then list[#list + 1] = name end
    end
    return list
end

-- Globales présentes dans NOTRE environnement Lua client (plafonné). Certains
-- exécuteurs y laissent des globales caractéristiques. On ne lit que _G local.
local function collectGlobals()
    local names, n = {}, 0
    local ok = pcall(function()
        for k in pairs(_G) do
            if type(k) == 'string' then n = n + 1; names[n] = k; if n >= 4000 then break end end
        end
    end)
    return ok and names or {}
end

-- Capture d'écran À LA DEMANDE (preuve d'incident). Le serveur déclenche
-- 'zshield:evidence:capture' avec une URL d'upload ; on capture la FENÊTRE DE JEU
-- via screenshot-basic (ressource standard) et on renvoie l'URL au serveur. On ne
-- capture jamais le bureau ni une autre fenêtre — uniquement le rendu du jeu.
RegisterNetEvent('zshield:evidence:capture', function(payload)
    if type(payload) ~= 'table' or type(payload.upload_url) ~= 'string' then return end
    local ok = pcall(function()
        exports['screenshot-basic']:requestClientScreenshotUpload(payload.upload_url, 'file', {
            encoding = 'jpg', quality = 0.7,
        }, function(err, data)
            TriggerServerEvent('zshield:evidence:captured', {
                incident = payload.incident, ok = (err == nil or err == false), url = data,
            })
        end)
    end)
    if not ok then
        TriggerServerEvent('zshield:evidence:captured',
            { incident = payload.incident, ok = false, url = nil })
    end
end)

-- 2) Construit un échantillon d'état de jeu. Chaque champ vient d'une native ;
--    ici on centralise, les valeurs réelles sont lues par des helpers dédiés.
local function sampleState()
    local ped = PlayerPedId()
    local s = {}
    -- Exemples de lectures serveur-invisibles (état purement client) :
    s.nightVision = GetUsingnightvision and false or false      -- remplacé par la vraie native
    s.visible = IsEntityVisible(ped)
    s.alpha = GetEntityAlpha(ped)
    s.model = GetEntityModel(ped)
    -- (Les autres champs — recoil, stamina, hitbox, handling… — sont renseignés
    --  par des sondes dédiées, omises ici pour rester concis.)
    return s
end

-- 3) Boucle de rapport : échantillonne, détecte, signe, envoie.
CreateThread(function()
    while true do
        Wait(5000)
        if sessionSecret then
            local signals = Detections.scan(sampleState(), isEnabled)
            -- Balayage d'environnement FiveM (ressources + globales), si activé.
            if isEnabled('environment') and Detections.scanEnvironment then
                local envSig = Detections.scanEnvironment(collectResources(), collectGlobals(), {})
                for _, s in ipairs(envSig) do signals[#signals + 1] = s end
            end
            local ids = {}
            for _, sig in ipairs(signals) do ids[#ids + 1] = sig.id end

            local ts = nowMs()
            local nonce = nextNonce()
            local src = GetPlayerServerId(PlayerId())
            local canonical = table.concat({ tostring(src), tostring(ts), nonce, table.concat(ids, ',') }, '|')
            TriggerServerEvent('zshield:cg:report', {
                ts = ts, nonce = nonce, ids = ids,
                sig = hmac(sessionSecret, canonical),
                hash = integrityHash(),
                hwid = clientHwid(),  -- corroborant ; la vérité vient du serveur
            })
        end
    end
end)
