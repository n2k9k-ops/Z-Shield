--[[
    FILE:         server/detection/fakechat.lua
    PURPOSE:      ANTI FAUX CHAT / USURPATION. Un client ne doit jamais pouvoir faire parler
                  QUELQU'UN D'AUTRE, ni forger un message au nom du serveur/staff, ni injecter
                  un event de chat pour un autre joueur. Le serveur connaît la VRAIE source
                  réseau de l'event : si le message prétend venir d'une autre source (ou usurpe
                  un préfixe staff/serveur), c'est une usurpation.

    100 % serveur-autoritatif : la source réseau ne se falsifie pas côté serveur. C'est un
    signal FORT (pas juste corrélant) car il n'y a aucune raison légitime qu'un client émette
    un message au nom d'un autre.

    DEPENDENCIES: shared/constants.lua, core/config.lua
    PUBLIC API:   ZShield.FakeChat.observe(source, msg) -> signal|nil
                  ZShield.FakeChat.register()

    msg = { claimed_source = id?, real_source = id?, author = string?, prefix_staff = bool? }
]]

ZShield = ZShield or {}
local C = ZShield.Const

local F = {}

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

function F.observe(source, msg)
    if cfg('fake_chat.enabled', true) ~= true then return nil end
    if type(msg) ~= 'table' then return nil end

    local real = msg.real_source or source
    local claimed = msg.claimed_source

    -- 1) Le message prétend venir d'une autre source réseau que la vraie -> usurpation directe.
    if claimed ~= nil and tostring(claimed) ~= tostring(real) then
        return {
            detector = 'fakechat', category = C.CATEGORY.EVENT,
            severity = C.SEVERITY.HIGH, confidence = 0.9,
            reason = string.format('message de chat usurpé : prétend venir de %s (vraie source %s)', tostring(claimed), tostring(real)),
            source = real, metadata = { claimed = claimed, real = real, kind = 'spoofed_source' },
        }
    end

    -- 2) Usurpation d'identité serveur/staff dans le message (préfixe réservé).
    if msg.prefix_staff == true then
        return {
            detector = 'fakechat', category = C.CATEGORY.EVENT,
            severity = C.SEVERITY.HIGH, confidence = 0.8,
            reason = 'message forgé avec un préfixe réservé (serveur/staff) — usurpation',
            source = real, metadata = { author = msg.author, kind = 'impersonation' },
        }
    end

    return nil
end

function F.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'fakechat', category = C.CATEGORY.EVENT,
            evaluate = function() return {} end })
    end
end

ZShield.FakeChat = F
return F
