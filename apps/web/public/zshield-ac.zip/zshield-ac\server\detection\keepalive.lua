--[[
    FILE:         server/detection/keepalive.lua
    PURPOSE:      SYSTÈME KEEP-ALIVE. Le client de confiance envoie un battement périodique
                  (signé/attendu). Si un joueur cesse d'émettre son battement alors qu'il est
                  toujours connecté et actif, c'est que sa partie cliente de l'anticheat a été
                  tuée/déchargée (vecteur classique des internals : « kill » du script client).

    HONNÊTETÉ : corrélant. Un battement PRÉSENT ne prouve pas l'innocence (un internal peut
    laisser le heartbeat tourner). Mais un battement ABSENT chez un joueur actif est un signal
    fort de client trafiqué. Mode 1 = alerte ; Mode 2 = plus strict (fenêtre courte).

    DEPENDENCIES: shared/constants.lua, core/util.lua, core/config.lua
    PUBLIC API:   ZShield.KeepAlive.beat(source, now)          -- appelé à chaque battement reçu
                  ZShield.KeepAlive.track(source, now)         -- marque un joueur comme suivi
                  ZShield.KeepAlive.sweep(now) -> { signal, ... } -- battements manquants
                  ZShield.KeepAlive.forget(source) / .register()
]]

ZShield = ZShield or {}
local C = ZShield.Const
local Util = ZShield.Util

local KA = {}
KA._last = {}   -- source -> dernier battement (ms)

local function cfg(path, default)
    if ZShield.Config and ZShield.Config.value then
        return ZShield.Config.value(path, default)
    end
    return default
end

function KA.beat(source, now) KA._last[source] = tonumber(now) or Util.now() end
function KA.track(source, now) if KA._last[source] == nil then KA._last[source] = tonumber(now) or Util.now() end end
function KA.forget(source) KA._last[source] = nil end

--- Balaye les joueurs suivis et retourne un signal par battement manquant.
function KA.sweep(now)
    if cfg('keep_alive.enabled', false) ~= true then return {} end
    now = tonumber(now) or Util.now()
    local timeout = tonumber(cfg('keep_alive.timeout_ms', 15000)) or 15000
    local mode = tonumber(cfg('keep_alive.mode', 1)) or 1
    -- Mode 2 : plus strict, fenêtre effective réduite.
    local eff = (mode >= 2) and (timeout * 0.6) or timeout

    local out = {}
    for source, last in pairs(KA._last) do
        local silent = now - last
        if silent > eff then
            local ratio = (eff > 0) and (silent / eff) or 2
            local severity, confidence
            if ratio >= 2 then severity, confidence = C.SEVERITY.HIGH, 0.7
            else               severity, confidence = C.SEVERITY.MEDIUM, 0.55
            end
            out[#out + 1] = {
                detector = 'keepalive', category = C.CATEGORY.STATE,
                severity = severity, confidence = confidence,
                reason = string.format('battement client absent depuis %.0f s (seuil %.0f s) — client déchargé ?', silent / 1000, eff / 1000),
                source = source,
                metadata = { silent_ms = silent, timeout_ms = eff, mode = mode, kind = 'missing_heartbeat' },
            }
        end
    end
    return out
end

function KA.register()
    if ZShield.Detection and ZShield.Detection.register then
        ZShield.Detection.register({ id = 'keepalive', category = C.CATEGORY.STATE,
            evaluate = function() return {} end })
    end
end

ZShield.KeepAlive = KA
return KA
